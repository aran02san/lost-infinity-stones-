package xol.lostinfinity.client;

import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.tileentity.TileEntityCthulhuSpawner;
import xol.lostinfinity.block.tileentity.TileEntityEternalBeacon;
import xol.lostinfinity.block.tileentity.TileEntityKillerVine;
import xol.lostinfinity.block.tileentity.TileEntityLightEmitter;
import xol.lostinfinity.block.tileentity.TileEntityNicroniumInfuser;
import xol.lostinfinity.block.tileentity.TileEntityPortalNexus;
import xol.lostinfinity.block.tileentity.TileEntityPortalNode;
import xol.lostinfinity.block.tileentity.TileEntityTeslaTower;
import xol.lostinfinity.block.tileentity.TileEntityVoidVacuum;
import xol.lostinfinity.block.tileentity.render.RenderCthulhuSpawner;
import xol.lostinfinity.block.tileentity.render.RenderEternalBeacon;
import xol.lostinfinity.block.tileentity.render.RenderKillerVine;
import xol.lostinfinity.block.tileentity.render.RenderNicroniumInfuserEffect;
import xol.lostinfinity.block.tileentity.render.RenderPortalNexus;
import xol.lostinfinity.block.tileentity.render.RenderPortalNodeEffect;
import xol.lostinfinity.block.tileentity.render.RenderTeslaTower;
import xol.lostinfinity.block.tileentity.render.RenderVoidVacuum;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.item.armor.ItemLostArmor;
import xol.lostinfinity.mob.entity.base.EntityParticleTrojan;
import xol.lostinfinity.mob.entity.boss.EntityAlestria;
import xol.lostinfinity.mob.entity.boss.EntityArash;
import xol.lostinfinity.mob.entity.boss.EntityArenaEvent;
import xol.lostinfinity.mob.entity.boss.EntityAtlasCrystal;
import xol.lostinfinity.mob.entity.boss.EntityAtlasSpire;
import xol.lostinfinity.mob.entity.boss.EntityBarul;
import xol.lostinfinity.mob.entity.boss.EntityCryonus;
import xol.lostinfinity.mob.entity.boss.EntityDarrio;
import xol.lostinfinity.mob.entity.boss.EntityDeviantCrystal;
import xol.lostinfinity.mob.entity.boss.EntityDeviantWither;
import xol.lostinfinity.mob.entity.boss.EntityDroidBoss;
import xol.lostinfinity.mob.entity.boss.EntityDuskerQueen;
import xol.lostinfinity.mob.entity.boss.EntityElara;
import xol.lostinfinity.mob.entity.boss.EntityNuxuro;
import xol.lostinfinity.mob.entity.boss.EntityOzor;
import xol.lostinfinity.mob.entity.boss.EntityOzorDecoy;
import xol.lostinfinity.mob.entity.boss.EntityPuzzleMaster;
import xol.lostinfinity.mob.entity.boss.EntityRestorationCrystal;
import xol.lostinfinity.mob.entity.boss.EntityRikarus;
import xol.lostinfinity.mob.entity.boss.EntitySentryCrystal;
import xol.lostinfinity.mob.entity.boss.EntityThundyron;
import xol.lostinfinity.mob.entity.boss.EntityUrogo;
import xol.lostinfinity.mob.entity.boss.EntityVelo;
import xol.lostinfinity.mob.entity.boss.EntityVycellia;
import xol.lostinfinity.mob.entity.boss.EntityWitherSkullling;
import xol.lostinfinity.mob.entity.contest.EntityBloodhunter;
import xol.lostinfinity.mob.entity.contest.EntityContestHologram;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerBattleSnakes;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerBombers;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerDuelArena;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerHolodeck;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerHunters;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerInkBattle;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerLaserTag;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerLightBridge;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerParkour;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerRedlight;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerTargets;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerTrampolineDodgeball;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerTreadmill;
import xol.lostinfinity.mob.entity.contest.misc.EntityTreadmillObstacle;
import xol.lostinfinity.mob.entity.contest.misc.EntityTreadmillObstacleJumpable;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorBattleSnakes;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorBombers;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorDuelArena;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorHolodeck;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorHunters;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorInkBattle;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorLaserTag;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorLightBridge;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorParkour;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorRedlight;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorTargets;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorTrampolineDodgeball;
import xol.lostinfinity.mob.entity.contest.operator.EntityOperatorTreadmill;
import xol.lostinfinity.mob.entity.contest.trader.EntityArcheologist;
import xol.lostinfinity.mob.entity.contest.trader.EntityChemist;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderBattleSnakes;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderBombers;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderHolodeck;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderHunters;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderInkBattle;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderLaserTag;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderLightbridge;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderMarket;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderParkour;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderRedlight;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderTargets;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderTrampolineDodgeball;
import xol.lostinfinity.mob.entity.contest.trader.EntityContraderTreadmill;
import xol.lostinfinity.mob.entity.cthulhu.EntityCelestialStatue;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhu;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuBlackHole;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuCloud;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuDeathFX;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuHealingOrb;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuPart;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuRift;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuSpear;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuTentacle;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhuTurret;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantAmalgam;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantBat;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantBear;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantBlaze;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantCaveSpider;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantChicken;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantCow;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantCreeper;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantDimTrader;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantEnderman;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantEvoker;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantEvokerVex;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantGhast;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantGolem;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantGuardian;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantHorse;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantHusk;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantLlama;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantMagmacube;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantMooshroom;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantOcelote;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantPig;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantPiglin;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSheep;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantShulker;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSkeleton;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSkyworm;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSlime;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSlimeStrider;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSnowman;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSpider;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSquid;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantStray;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantVex;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantWitch;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantWitherSkeleton;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantWolf;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantZombie;
import xol.lostinfinity.mob.entity.deviant.EntityLostDeviant;
import xol.lostinfinity.mob.entity.deviant.prime.EntityAzross;
import xol.lostinfinity.mob.entity.deviant.prime.EntityKalikos;
import xol.lostinfinity.mob.entity.deviant.prime.EntityLivorax;
import xol.lostinfinity.mob.entity.deviant.prime.EntityZenon;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanBlaze;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanCreeper;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanEnderman;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanLlama;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanMagmacube;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanPiglin;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanShulker;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanSkeleton;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanSpider;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanStray;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanVex;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTitanZombie;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTrialObserver;
import xol.lostinfinity.mob.entity.fungal.EntityFungfly;
import xol.lostinfinity.mob.entity.fungal.EntityMushmerra;
import xol.lostinfinity.mob.entity.fungal.EntityMushmerraClone;
import xol.lostinfinity.mob.entity.fungal.EntityShroomite;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxyBeast;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxyDragon;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxyGladiator;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxyGulper;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxySorcerer;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxySpire;
import xol.lostinfinity.mob.entity.galaxy.EntityLaserSpire;
import xol.lostinfinity.mob.entity.labyrinth.EntityAspect;
import xol.lostinfinity.mob.entity.labyrinth.EntityClinger;
import xol.lostinfinity.mob.entity.labyrinth.EntityCyclos;
import xol.lostinfinity.mob.entity.labyrinth.EntityGloop;
import xol.lostinfinity.mob.entity.labyrinth.EntityGloopMother;
import xol.lostinfinity.mob.entity.labyrinth.EntityLabWarrior;
import xol.lostinfinity.mob.entity.labyrinth.EntityLabWizard;
import xol.lostinfinity.mob.entity.labyrinth.EntityNat;
import xol.lostinfinity.mob.entity.labyrinth.EntitySentry;
import xol.lostinfinity.mob.entity.labyrinth.EntityStickler;
import xol.lostinfinity.mob.entity.labyrinth.EntityVectosect;
import xol.lostinfinity.mob.entity.minion.EntityAbyssalCrabulon;
import xol.lostinfinity.mob.entity.minion.EntityAuraOfAllegiance;
import xol.lostinfinity.mob.entity.minion.EntityBombDrone;
import xol.lostinfinity.mob.entity.minion.EntityLostBlade;
import xol.lostinfinity.mob.entity.minion.EntityLuminousGuardian;
import xol.lostinfinity.mob.entity.minion.andromeda.EntityAndromedaChaser;
import xol.lostinfinity.mob.entity.minion.andromeda.EntityAndromedaController;
import xol.lostinfinity.mob.entity.minion.andromeda.EntityAndromedaSegment;
import xol.lostinfinity.mob.entity.misc.EntityBomberBomb;
import xol.lostinfinity.mob.entity.misc.EntityCellGameMerchant;
import xol.lostinfinity.mob.entity.misc.EntityClusterCannon;
import xol.lostinfinity.mob.entity.misc.EntityConnectGameMerchant;
import xol.lostinfinity.mob.entity.misc.EntityCourseRing;
import xol.lostinfinity.mob.entity.misc.EntityDimensionalMerchant;
import xol.lostinfinity.mob.entity.misc.EntityDroid;
import xol.lostinfinity.mob.entity.misc.EntityEffigyEffect;
import xol.lostinfinity.mob.entity.misc.EntityEidolonMist;
import xol.lostinfinity.mob.entity.misc.EntityFeralMerchant;
import xol.lostinfinity.mob.entity.misc.EntityGhostCopy;
import xol.lostinfinity.mob.entity.misc.EntityIonExplosion;
import xol.lostinfinity.mob.entity.misc.EntityLightGame;
import xol.lostinfinity.mob.entity.misc.EntityMarkOfInfiniteDespair;
import xol.lostinfinity.mob.entity.misc.EntityMemPuzzleMerchant;
import xol.lostinfinity.mob.entity.misc.EntityMirrorZombie;
import xol.lostinfinity.mob.entity.misc.EntityMortarCannon;
import xol.lostinfinity.mob.entity.misc.EntityMultiverseGhost;
import xol.lostinfinity.mob.entity.misc.EntityNuclearExplosion;
import xol.lostinfinity.mob.entity.misc.EntityPickleMan;
import xol.lostinfinity.mob.entity.misc.EntityPipeGameMerchant;
import xol.lostinfinity.mob.entity.misc.EntityPlasmaBomb;
import xol.lostinfinity.mob.entity.misc.EntityPlasmaExplosion;
import xol.lostinfinity.mob.entity.misc.EntityPlasmaSlicer;
import xol.lostinfinity.mob.entity.misc.EntityPlayerLimb;
import xol.lostinfinity.mob.entity.misc.EntityRhythmGameMerchant;
import xol.lostinfinity.mob.entity.misc.EntityRift;
import xol.lostinfinity.mob.entity.misc.EntityRisingPhantom;
import xol.lostinfinity.mob.entity.misc.EntityRocketStrappedExplosive;
import xol.lostinfinity.mob.entity.misc.EntitySandAttack;
import xol.lostinfinity.mob.entity.misc.EntitySkybooster;
import xol.lostinfinity.mob.entity.misc.EntitySkycrab;
import xol.lostinfinity.mob.entity.misc.EntitySlimeStrider;
import xol.lostinfinity.mob.entity.misc.EntitySpectre;
import xol.lostinfinity.mob.entity.misc.EntityStarfiend;
import xol.lostinfinity.mob.entity.misc.EntityStickyBomb;
import xol.lostinfinity.mob.entity.misc.EntityStormBomb;
import xol.lostinfinity.mob.entity.misc.EntitySupplyTrader;
import xol.lostinfinity.mob.entity.misc.EntityTNTZombie;
import xol.lostinfinity.mob.entity.misc.EntityTentacleTrap;
import xol.lostinfinity.mob.entity.misc.EntityThunderBomb;
import xol.lostinfinity.mob.entity.misc.EntityTornIndividual;
import xol.lostinfinity.mob.entity.misc.EntityTotemMoon;
import xol.lostinfinity.mob.entity.misc.EntityTotemPylon;
import xol.lostinfinity.mob.entity.misc.EntityTotemSplitter;
import xol.lostinfinity.mob.entity.misc.EntityUnstableMerchant;
import xol.lostinfinity.mob.entity.misc.EntityUnstableRift;
import xol.lostinfinity.mob.entity.misc.EntityWhackGameMerchant;
import xol.lostinfinity.mob.entity.misc.EntityWormholePortal;
import xol.lostinfinity.mob.entity.mount.EntityJetMount;
import xol.lostinfinity.mob.entity.mount.EntityXScreacher;
import xol.lostinfinity.mob.entity.murk.EntityCaveTerror;
import xol.lostinfinity.mob.entity.murk.EntityDoomsday;
import xol.lostinfinity.mob.entity.murk.EntityScorpwing;
import xol.lostinfinity.mob.entity.murk.EntityScreamer;
import xol.lostinfinity.mob.entity.murk.EntitySkyre;
import xol.lostinfinity.mob.entity.murk.EntityTorpedon;
import xol.lostinfinity.mob.entity.murk.EntityWhisper;
import xol.lostinfinity.mob.entity.nebula.EntityNebulaGiant;
import xol.lostinfinity.mob.entity.nebula.EntityNebulaGrunt;
import xol.lostinfinity.mob.entity.nebula.EntityNebulaWizard;
import xol.lostinfinity.mob.entity.sea.EntityCrabulon;
import xol.lostinfinity.mob.entity.sea.EntityDoublerang;
import xol.lostinfinity.mob.entity.sea.EntityEelShark;
import xol.lostinfinity.mob.entity.sea.EntityGlowfish;
import xol.lostinfinity.mob.entity.sea.EntityLongfin;
import xol.lostinfinity.mob.entity.sea.EntityOctobrella;
import xol.lostinfinity.mob.entity.sea.EntityPearlCollector;
import xol.lostinfinity.mob.entity.sea.EntityRayfish;
import xol.lostinfinity.mob.entity.sea.EntityRibshark;
import xol.lostinfinity.mob.entity.sea.EntityUnderfin;
import xol.lostinfinity.mob.entity.sea.leviathan.EntityLeviathanController;
import xol.lostinfinity.mob.entity.sea.leviathan.EntityLeviathanHead;
import xol.lostinfinity.mob.entity.sea.leviathan.EntityLeviathanSegment;
import xol.lostinfinity.mob.entity.sea.leviathan.EntityLeviathanTail;
import xol.lostinfinity.mob.entity.sea.seaserpent.EntitySeaSerpentController;
import xol.lostinfinity.mob.entity.sea.seaserpent.EntitySeaSerpentHead;
import xol.lostinfinity.mob.entity.sea.seaserpent.EntitySeaSerpentSegment;
import xol.lostinfinity.mob.entity.sea.seaserpent.EntitySeaSerpentTail;
import xol.lostinfinity.mob.entity.starforge.EntityAcidback;
import xol.lostinfinity.mob.entity.starforge.EntityAugmenticon;
import xol.lostinfinity.mob.entity.starforge.EntityBlisterweed;
import xol.lostinfinity.mob.entity.starforge.EntityChomper;
import xol.lostinfinity.mob.entity.starforge.EntityClusterweed;
import xol.lostinfinity.mob.entity.starforge.EntityClyster;
import xol.lostinfinity.mob.entity.starforge.EntityCrawker;
import xol.lostinfinity.mob.entity.starforge.EntityCrusher;
import xol.lostinfinity.mob.entity.starforge.EntityDoomDog;
import xol.lostinfinity.mob.entity.starforge.EntityDoublejaw;
import xol.lostinfinity.mob.entity.starforge.EntityDrippler;
import xol.lostinfinity.mob.entity.starforge.EntityDusker;
import xol.lostinfinity.mob.entity.starforge.EntityEssenceDweller;
import xol.lostinfinity.mob.entity.starforge.EntityEssenceIdol;
import xol.lostinfinity.mob.entity.starforge.EntityExplosect;
import xol.lostinfinity.mob.entity.starforge.EntityEyeSlug;
import xol.lostinfinity.mob.entity.starforge.EntityFlapper;
import xol.lostinfinity.mob.entity.starforge.EntityFlashfly;
import xol.lostinfinity.mob.entity.starforge.EntityFlurky;
import xol.lostinfinity.mob.entity.starforge.EntityFlutterbee;
import xol.lostinfinity.mob.entity.starforge.EntityFlutterfyre;
import xol.lostinfinity.mob.entity.starforge.EntityFyreweed;
import xol.lostinfinity.mob.entity.starforge.EntityGalacticTerror;
import xol.lostinfinity.mob.entity.starforge.EntityGiantFlapper;
import xol.lostinfinity.mob.entity.starforge.EntityGiantFyreweed;
import xol.lostinfinity.mob.entity.starforge.EntityGiantRockslug;
import xol.lostinfinity.mob.entity.starforge.EntityGlangler;
import xol.lostinfinity.mob.entity.starforge.EntityGloboon;
import xol.lostinfinity.mob.entity.starforge.EntityGlobro;
import xol.lostinfinity.mob.entity.starforge.EntityGlochipper;
import xol.lostinfinity.mob.entity.starforge.EntityGlomite;
import xol.lostinfinity.mob.entity.starforge.EntityGnawer;
import xol.lostinfinity.mob.entity.starforge.EntityGorger;
import xol.lostinfinity.mob.entity.starforge.EntityGrappler;
import xol.lostinfinity.mob.entity.starforge.EntityGravhead;
import xol.lostinfinity.mob.entity.starforge.EntityGrubber;
import xol.lostinfinity.mob.entity.starforge.EntityHanger;
import xol.lostinfinity.mob.entity.starforge.EntityHurler;
import xol.lostinfinity.mob.entity.starforge.EntityHypnosaur;
import xol.lostinfinity.mob.entity.starforge.EntityLeer;
import xol.lostinfinity.mob.entity.starforge.EntityLurcher;
import xol.lostinfinity.mob.entity.starforge.EntityMinimite;
import xol.lostinfinity.mob.entity.starforge.EntityNightshyre;
import xol.lostinfinity.mob.entity.starforge.EntityOrbiter;
import xol.lostinfinity.mob.entity.starforge.EntityPhaser;
import xol.lostinfinity.mob.entity.starforge.EntityRavager;
import xol.lostinfinity.mob.entity.starforge.EntityReflectal;
import xol.lostinfinity.mob.entity.starforge.EntityRibrex;
import xol.lostinfinity.mob.entity.starforge.EntityRockpest;
import xol.lostinfinity.mob.entity.starforge.EntityRockslug;
import xol.lostinfinity.mob.entity.starforge.EntityRockworm;
import xol.lostinfinity.mob.entity.starforge.EntityScreacher;
import xol.lostinfinity.mob.entity.starforge.EntityShimmer;
import xol.lostinfinity.mob.entity.starforge.EntitySightwalker;
import xol.lostinfinity.mob.entity.starforge.EntitySnapper;
import xol.lostinfinity.mob.entity.starforge.EntitySpinovern;
import xol.lostinfinity.mob.entity.starforge.EntitySpyker;
import xol.lostinfinity.mob.entity.starforge.EntityTentaclon;
import xol.lostinfinity.mob.entity.starforge.EntityTerrorFly;
import xol.lostinfinity.mob.entity.starforge.EntityTetherbug;
import xol.lostinfinity.mob.entity.starforge.EntityTitanopod;
import xol.lostinfinity.mob.entity.starforge.EntityVilebulb;
import xol.lostinfinity.mob.entity.starforge.EntityWeaver;
import xol.lostinfinity.mob.entity.starforge.EntityWisp;
import xol.lostinfinity.mob.render.arena.RenderAlestria;
import xol.lostinfinity.mob.render.arena.RenderArash;
import xol.lostinfinity.mob.render.arena.RenderArenaEvent;
import xol.lostinfinity.mob.render.arena.RenderAtlasCrystal;
import xol.lostinfinity.mob.render.arena.RenderAtlasSpire;
import xol.lostinfinity.mob.render.arena.RenderBarul;
import xol.lostinfinity.mob.render.arena.RenderCryonus;
import xol.lostinfinity.mob.render.arena.RenderDarrio;
import xol.lostinfinity.mob.render.arena.RenderDeviantWither;
import xol.lostinfinity.mob.render.arena.RenderDroidBoss;
import xol.lostinfinity.mob.render.arena.RenderDuskerQueen;
import xol.lostinfinity.mob.render.arena.RenderElara;
import xol.lostinfinity.mob.render.arena.RenderNuxuro;
import xol.lostinfinity.mob.render.arena.RenderOzor;
import xol.lostinfinity.mob.render.arena.RenderOzorDecoy;
import xol.lostinfinity.mob.render.arena.RenderPuzzleMaster;
import xol.lostinfinity.mob.render.arena.RenderRestorationCrystal;
import xol.lostinfinity.mob.render.arena.RenderRikarus;
import xol.lostinfinity.mob.render.arena.RenderSentryCrystal;
import xol.lostinfinity.mob.render.arena.RenderThundyron;
import xol.lostinfinity.mob.render.arena.RenderUrogo;
import xol.lostinfinity.mob.render.arena.RenderVelo;
import xol.lostinfinity.mob.render.arena.RenderVycellia;
import xol.lostinfinity.mob.render.arena.RenderWitherSkullling;
import xol.lostinfinity.mob.render.contest.RenderArcheologist;
import xol.lostinfinity.mob.render.contest.RenderBloodhunter;
import xol.lostinfinity.mob.render.contest.RenderChemist;
import xol.lostinfinity.mob.render.contest.RenderContestHologram;
import xol.lostinfinity.mob.render.contest.RenderContraderBattleSnakes;
import xol.lostinfinity.mob.render.contest.RenderContraderBombers;
import xol.lostinfinity.mob.render.contest.RenderContraderHolodeck;
import xol.lostinfinity.mob.render.contest.RenderContraderHunters;
import xol.lostinfinity.mob.render.contest.RenderContraderInkBattle;
import xol.lostinfinity.mob.render.contest.RenderContraderLaserTag;
import xol.lostinfinity.mob.render.contest.RenderContraderLightbridge;
import xol.lostinfinity.mob.render.contest.RenderContraderMarket;
import xol.lostinfinity.mob.render.contest.RenderContraderParkour;
import xol.lostinfinity.mob.render.contest.RenderContraderRedlight;
import xol.lostinfinity.mob.render.contest.RenderContraderTargets;
import xol.lostinfinity.mob.render.contest.RenderContraderTrampolineDodgeball;
import xol.lostinfinity.mob.render.contest.RenderContraderTreadmill;
import xol.lostinfinity.mob.render.contest.RenderControllerBattleSnakes;
import xol.lostinfinity.mob.render.contest.RenderControllerBombers;
import xol.lostinfinity.mob.render.contest.RenderControllerDuelArena;
import xol.lostinfinity.mob.render.contest.RenderControllerHolodeck;
import xol.lostinfinity.mob.render.contest.RenderControllerHunters;
import xol.lostinfinity.mob.render.contest.RenderControllerInkBattle;
import xol.lostinfinity.mob.render.contest.RenderControllerLaserTag;
import xol.lostinfinity.mob.render.contest.RenderControllerLightBridge;
import xol.lostinfinity.mob.render.contest.RenderControllerParkour;
import xol.lostinfinity.mob.render.contest.RenderControllerRedlight;
import xol.lostinfinity.mob.render.contest.RenderControllerTargets;
import xol.lostinfinity.mob.render.contest.RenderControllerTrampolineDodgeball;
import xol.lostinfinity.mob.render.contest.RenderControllerTreadmill;
import xol.lostinfinity.mob.render.contest.RenderOperatorBattleSnakes;
import xol.lostinfinity.mob.render.contest.RenderOperatorBombers;
import xol.lostinfinity.mob.render.contest.RenderOperatorDuelArena;
import xol.lostinfinity.mob.render.contest.RenderOperatorHolodeck;
import xol.lostinfinity.mob.render.contest.RenderOperatorHunters;
import xol.lostinfinity.mob.render.contest.RenderOperatorInkBattle;
import xol.lostinfinity.mob.render.contest.RenderOperatorLaserTag;
import xol.lostinfinity.mob.render.contest.RenderOperatorLightBridge;
import xol.lostinfinity.mob.render.contest.RenderOperatorParkour;
import xol.lostinfinity.mob.render.contest.RenderOperatorRedlight;
import xol.lostinfinity.mob.render.contest.RenderOperatorTargets;
import xol.lostinfinity.mob.render.contest.RenderOperatorTrampolineDodgeball;
import xol.lostinfinity.mob.render.contest.RenderOperatorTreadmill;
import xol.lostinfinity.mob.render.contest.RenderTreadmillObstacle;
import xol.lostinfinity.mob.render.contest.RenderTreadmillObstacleJumpable;
import xol.lostinfinity.mob.render.cthulhu.RenderCelestialStatue;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhu;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuBlackHole;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuCloud;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuDeathFX;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuHealingOrb;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuPart;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuRift;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuSpear;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuTentacle;
import xol.lostinfinity.mob.render.cthulhu.RenderCthulhuTurret;
import xol.lostinfinity.mob.render.deviant.RenderDeviantAmalgam;
import xol.lostinfinity.mob.render.deviant.RenderDeviantBat;
import xol.lostinfinity.mob.render.deviant.RenderDeviantBear;
import xol.lostinfinity.mob.render.deviant.RenderDeviantBlaze;
import xol.lostinfinity.mob.render.deviant.RenderDeviantCaveSpider;
import xol.lostinfinity.mob.render.deviant.RenderDeviantChicken;
import xol.lostinfinity.mob.render.deviant.RenderDeviantCow;
import xol.lostinfinity.mob.render.deviant.RenderDeviantCreeper;
import xol.lostinfinity.mob.render.deviant.RenderDeviantCrystal;
import xol.lostinfinity.mob.render.deviant.RenderDeviantDimTrader;
import xol.lostinfinity.mob.render.deviant.RenderDeviantEnderman;
import xol.lostinfinity.mob.render.deviant.RenderDeviantEvoker;
import xol.lostinfinity.mob.render.deviant.RenderDeviantEvokerVex;
import xol.lostinfinity.mob.render.deviant.RenderDeviantGhast;
import xol.lostinfinity.mob.render.deviant.RenderDeviantGolem;
import xol.lostinfinity.mob.render.deviant.RenderDeviantGuardian;
import xol.lostinfinity.mob.render.deviant.RenderDeviantHorse;
import xol.lostinfinity.mob.render.deviant.RenderDeviantHusk;
import xol.lostinfinity.mob.render.deviant.RenderDeviantLlama;
import xol.lostinfinity.mob.render.deviant.RenderDeviantMagmacube;
import xol.lostinfinity.mob.render.deviant.RenderDeviantMooshroom;
import xol.lostinfinity.mob.render.deviant.RenderDeviantOcelote;
import xol.lostinfinity.mob.render.deviant.RenderDeviantPig;
import xol.lostinfinity.mob.render.deviant.RenderDeviantPiglin;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSheep;
import xol.lostinfinity.mob.render.deviant.RenderDeviantShulker;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSkeleton;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSkyworm;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSlime;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSlimeStrider;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSnowman;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSpider;
import xol.lostinfinity.mob.render.deviant.RenderDeviantSquid;
import xol.lostinfinity.mob.render.deviant.RenderDeviantStray;
import xol.lostinfinity.mob.render.deviant.RenderDeviantVex;
import xol.lostinfinity.mob.render.deviant.RenderDeviantWitch;
import xol.lostinfinity.mob.render.deviant.RenderDeviantWitherSkeleton;
import xol.lostinfinity.mob.render.deviant.RenderDeviantWolf;
import xol.lostinfinity.mob.render.deviant.RenderDeviantZombie;
import xol.lostinfinity.mob.render.deviant.RenderLostDeviant;
import xol.lostinfinity.mob.render.fungal.RenderFungfly;
import xol.lostinfinity.mob.render.fungal.RenderMushmerra;
import xol.lostinfinity.mob.render.fungal.RenderMushmerraClone;
import xol.lostinfinity.mob.render.fungal.RenderShroomite;
import xol.lostinfinity.mob.render.galaxy.RenderGalaxyBeast;
import xol.lostinfinity.mob.render.galaxy.RenderGalaxyDragon;
import xol.lostinfinity.mob.render.galaxy.RenderGalaxyGladiator;
import xol.lostinfinity.mob.render.galaxy.RenderGalaxyGulper;
import xol.lostinfinity.mob.render.galaxy.RenderGalaxySorcerer;
import xol.lostinfinity.mob.render.galaxy.RenderGalaxySpire;
import xol.lostinfinity.mob.render.galaxy.RenderLaserSpire;
import xol.lostinfinity.mob.render.labyrinth.RenderAspect;
import xol.lostinfinity.mob.render.labyrinth.RenderClinger;
import xol.lostinfinity.mob.render.labyrinth.RenderCyclos;
import xol.lostinfinity.mob.render.labyrinth.RenderGloop;
import xol.lostinfinity.mob.render.labyrinth.RenderGloopMother;
import xol.lostinfinity.mob.render.labyrinth.RenderLabWarrior;
import xol.lostinfinity.mob.render.labyrinth.RenderLabWizard;
import xol.lostinfinity.mob.render.labyrinth.RenderNat;
import xol.lostinfinity.mob.render.labyrinth.RenderSentry;
import xol.lostinfinity.mob.render.labyrinth.RenderStickler;
import xol.lostinfinity.mob.render.labyrinth.RenderVectosect;
import xol.lostinfinity.mob.render.minion.RenderAbyssalCrabulon;
import xol.lostinfinity.mob.render.minion.RenderAuraOfAllegiance;
import xol.lostinfinity.mob.render.minion.RenderLostBlade;
import xol.lostinfinity.mob.render.minion.RenderLuminousGuardian;
import xol.lostinfinity.mob.render.minion.andromeda.RenderAndromedaController;
import xol.lostinfinity.mob.render.minion.andromeda.RenderAndromedaSegment;
import xol.lostinfinity.mob.render.misc.RenderBomberBomb;
import xol.lostinfinity.mob.render.misc.RenderCellGameMerchant;
import xol.lostinfinity.mob.render.misc.RenderClusterCannon;
import xol.lostinfinity.mob.render.misc.RenderConnectGameMerchant;
import xol.lostinfinity.mob.render.misc.RenderCourseRing;
import xol.lostinfinity.mob.render.misc.RenderDimensionalMerchant;
import xol.lostinfinity.mob.render.misc.RenderDroid;
import xol.lostinfinity.mob.render.misc.RenderEffigyEffect;
import xol.lostinfinity.mob.render.misc.RenderEidolonMist;
import xol.lostinfinity.mob.render.misc.RenderFeralMerchant;
import xol.lostinfinity.mob.render.misc.RenderGhostCopy;
import xol.lostinfinity.mob.render.misc.RenderIonExplosion;
import xol.lostinfinity.mob.render.misc.RenderLightPuzzleMerchant;
import xol.lostinfinity.mob.render.misc.RenderMarkOfInfiniteDespair;
import xol.lostinfinity.mob.render.misc.RenderMemPuzzleMerchant;
import xol.lostinfinity.mob.render.misc.RenderMirrorZombie;
import xol.lostinfinity.mob.render.misc.RenderMortarCannon;
import xol.lostinfinity.mob.render.misc.RenderMultiverseGhost;
import xol.lostinfinity.mob.render.misc.RenderParticleTrojan;
import xol.lostinfinity.mob.render.misc.RenderPickleMan;
import xol.lostinfinity.mob.render.misc.RenderPipeGameMerchant;
import xol.lostinfinity.mob.render.misc.RenderPlasmaBomb;
import xol.lostinfinity.mob.render.misc.RenderPlasmaExplosion;
import xol.lostinfinity.mob.render.misc.RenderPlasmaSlicer;
import xol.lostinfinity.mob.render.misc.RenderPlayerLimb;
import xol.lostinfinity.mob.render.misc.RenderRhythmGameMerchant;
import xol.lostinfinity.mob.render.misc.RenderRift;
import xol.lostinfinity.mob.render.misc.RenderRisingPhantom;
import xol.lostinfinity.mob.render.misc.RenderRocketStrappedExplosive;
import xol.lostinfinity.mob.render.misc.RenderSandAttack;
import xol.lostinfinity.mob.render.misc.RenderSkybooster;
import xol.lostinfinity.mob.render.misc.RenderSkycrab;
import xol.lostinfinity.mob.render.misc.RenderSlimeStrider;
import xol.lostinfinity.mob.render.misc.RenderSpectre;
import xol.lostinfinity.mob.render.misc.RenderStarfiend;
import xol.lostinfinity.mob.render.misc.RenderStickyBomb;
import xol.lostinfinity.mob.render.misc.RenderStormBomb;
import xol.lostinfinity.mob.render.misc.RenderSupplyTrader;
import xol.lostinfinity.mob.render.misc.RenderTNTZombie;
import xol.lostinfinity.mob.render.misc.RenderTentacleTrap;
import xol.lostinfinity.mob.render.misc.RenderThunderBomb;
import xol.lostinfinity.mob.render.misc.RenderTornIndividual;
import xol.lostinfinity.mob.render.misc.RenderTotemMoon;
import xol.lostinfinity.mob.render.misc.RenderTotemPylon;
import xol.lostinfinity.mob.render.misc.RenderTotemSplitter;
import xol.lostinfinity.mob.render.misc.RenderUnstableMerchant;
import xol.lostinfinity.mob.render.misc.RenderUnstableRift;
import xol.lostinfinity.mob.render.misc.RenderWhackGameMerchant;
import xol.lostinfinity.mob.render.misc.RenderWormholePortal;
import xol.lostinfinity.mob.render.mount.RenderBombDrone;
import xol.lostinfinity.mob.render.mount.RenderJetMount;
import xol.lostinfinity.mob.render.mount.RenderXScreacher;
import xol.lostinfinity.mob.render.murk.RenderCaveTerror;
import xol.lostinfinity.mob.render.murk.RenderDoomsday;
import xol.lostinfinity.mob.render.murk.RenderScorpwing;
import xol.lostinfinity.mob.render.murk.RenderScreamer;
import xol.lostinfinity.mob.render.murk.RenderSkyre;
import xol.lostinfinity.mob.render.murk.RenderTorpedon;
import xol.lostinfinity.mob.render.murk.RenderWhisper;
import xol.lostinfinity.mob.render.nebula.RenderNebulaGiant;
import xol.lostinfinity.mob.render.nebula.RenderNebulaGrunt;
import xol.lostinfinity.mob.render.nebula.RenderNebulaWizard;
import xol.lostinfinity.mob.render.prime.RenderAzross;
import xol.lostinfinity.mob.render.prime.RenderKalikos;
import xol.lostinfinity.mob.render.prime.RenderLivorax;
import xol.lostinfinity.mob.render.prime.RenderZenon;
import xol.lostinfinity.mob.render.sea.RenderCrabulon;
import xol.lostinfinity.mob.render.sea.RenderDoublerang;
import xol.lostinfinity.mob.render.sea.RenderEelShark;
import xol.lostinfinity.mob.render.sea.RenderGlowfish;
import xol.lostinfinity.mob.render.sea.RenderLeviathanController;
import xol.lostinfinity.mob.render.sea.RenderLeviathanSegment;
import xol.lostinfinity.mob.render.sea.RenderLongfin;
import xol.lostinfinity.mob.render.sea.RenderOctobrella;
import xol.lostinfinity.mob.render.sea.RenderPearlCollector;
import xol.lostinfinity.mob.render.sea.RenderRayfish;
import xol.lostinfinity.mob.render.sea.RenderRibshark;
import xol.lostinfinity.mob.render.sea.RenderSeaSerpentController;
import xol.lostinfinity.mob.render.sea.RenderSeaSerpentSegment;
import xol.lostinfinity.mob.render.sea.RenderUnderfin;
import xol.lostinfinity.mob.render.starforge.RenderAcidback;
import xol.lostinfinity.mob.render.starforge.RenderAugmenticon;
import xol.lostinfinity.mob.render.starforge.RenderBlisterweed;
import xol.lostinfinity.mob.render.starforge.RenderChomper;
import xol.lostinfinity.mob.render.starforge.RenderClusterweed;
import xol.lostinfinity.mob.render.starforge.RenderClyster;
import xol.lostinfinity.mob.render.starforge.RenderCrawker;
import xol.lostinfinity.mob.render.starforge.RenderCrusher;
import xol.lostinfinity.mob.render.starforge.RenderDoomDog;
import xol.lostinfinity.mob.render.starforge.RenderDoublejaw;
import xol.lostinfinity.mob.render.starforge.RenderDrippler;
import xol.lostinfinity.mob.render.starforge.RenderDusker;
import xol.lostinfinity.mob.render.starforge.RenderEssenceDweller;
import xol.lostinfinity.mob.render.starforge.RenderEssenceIdol;
import xol.lostinfinity.mob.render.starforge.RenderExplosect;
import xol.lostinfinity.mob.render.starforge.RenderEyeSlug;
import xol.lostinfinity.mob.render.starforge.RenderFlapper;
import xol.lostinfinity.mob.render.starforge.RenderFlashfly;
import xol.lostinfinity.mob.render.starforge.RenderFlurky;
import xol.lostinfinity.mob.render.starforge.RenderFlutterbee;
import xol.lostinfinity.mob.render.starforge.RenderFlutterfyre;
import xol.lostinfinity.mob.render.starforge.RenderFyreweed;
import xol.lostinfinity.mob.render.starforge.RenderGalacticTerror;
import xol.lostinfinity.mob.render.starforge.RenderGiantFlapper;
import xol.lostinfinity.mob.render.starforge.RenderGiantFyreweed;
import xol.lostinfinity.mob.render.starforge.RenderGiantRockslug;
import xol.lostinfinity.mob.render.starforge.RenderGlangler;
import xol.lostinfinity.mob.render.starforge.RenderGloboon;
import xol.lostinfinity.mob.render.starforge.RenderGlobro;
import xol.lostinfinity.mob.render.starforge.RenderGlochipper;
import xol.lostinfinity.mob.render.starforge.RenderGlomite;
import xol.lostinfinity.mob.render.starforge.RenderGnawer;
import xol.lostinfinity.mob.render.starforge.RenderGorger;
import xol.lostinfinity.mob.render.starforge.RenderGrappler;
import xol.lostinfinity.mob.render.starforge.RenderGravhead;
import xol.lostinfinity.mob.render.starforge.RenderGrubber;
import xol.lostinfinity.mob.render.starforge.RenderHanger;
import xol.lostinfinity.mob.render.starforge.RenderHurler;
import xol.lostinfinity.mob.render.starforge.RenderHypnosaur;
import xol.lostinfinity.mob.render.starforge.RenderLeer;
import xol.lostinfinity.mob.render.starforge.RenderLurcher;
import xol.lostinfinity.mob.render.starforge.RenderMinimite;
import xol.lostinfinity.mob.render.starforge.RenderNightshyre;
import xol.lostinfinity.mob.render.starforge.RenderOrbiter;
import xol.lostinfinity.mob.render.starforge.RenderPhaser;
import xol.lostinfinity.mob.render.starforge.RenderRavager;
import xol.lostinfinity.mob.render.starforge.RenderReflectal;
import xol.lostinfinity.mob.render.starforge.RenderRibrex;
import xol.lostinfinity.mob.render.starforge.RenderRockpest;
import xol.lostinfinity.mob.render.starforge.RenderRockslug;
import xol.lostinfinity.mob.render.starforge.RenderRockworm;
import xol.lostinfinity.mob.render.starforge.RenderScreacher;
import xol.lostinfinity.mob.render.starforge.RenderShimmer;
import xol.lostinfinity.mob.render.starforge.RenderSightwalker;
import xol.lostinfinity.mob.render.starforge.RenderSnapper;
import xol.lostinfinity.mob.render.starforge.RenderSpinovern;
import xol.lostinfinity.mob.render.starforge.RenderSpyker;
import xol.lostinfinity.mob.render.starforge.RenderTentaclon;
import xol.lostinfinity.mob.render.starforge.RenderTerrorFly;
import xol.lostinfinity.mob.render.starforge.RenderTetherbug;
import xol.lostinfinity.mob.render.starforge.RenderTitanopod;
import xol.lostinfinity.mob.render.starforge.RenderVilebulb;
import xol.lostinfinity.mob.render.starforge.RenderWeaver;
import xol.lostinfinity.mob.render.starforge.RenderWisp;
import xol.lostinfinity.mob.render.titan.RenderTitanBlaze;
import xol.lostinfinity.mob.render.titan.RenderTitanCreeper;
import xol.lostinfinity.mob.render.titan.RenderTitanEnderman;
import xol.lostinfinity.mob.render.titan.RenderTitanLlama;
import xol.lostinfinity.mob.render.titan.RenderTitanMagmacube;
import xol.lostinfinity.mob.render.titan.RenderTitanPiglin;
import xol.lostinfinity.mob.render.titan.RenderTitanShulker;
import xol.lostinfinity.mob.render.titan.RenderTitanSkeleton;
import xol.lostinfinity.mob.render.titan.RenderTitanSpider;
import xol.lostinfinity.mob.render.titan.RenderTitanStray;
import xol.lostinfinity.mob.render.titan.RenderTitanVex;
import xol.lostinfinity.mob.render.titan.RenderTitanZombie;
import xol.lostinfinity.mob.render.titan.RenderTrialObserver;
import xol.lostinfinity.projectile.cthulhu.EntityCthulhuBeam;
import xol.lostinfinity.projectile.cthulhu.EntityCthulhuMeteor;
import xol.lostinfinity.projectile.cthulhu.EntityCthulhuMissile;
import xol.lostinfinity.projectile.cthulhu.EntityCthulhuTurretBullet;
import xol.lostinfinity.projectile.cthulhu.RenderCthulhuBeam;
import xol.lostinfinity.projectile.entity.EntityAcidRainDrop;
import xol.lostinfinity.projectile.entity.EntityAcidicConcoction;
import xol.lostinfinity.projectile.entity.EntityArcBlast;
import xol.lostinfinity.projectile.entity.EntityAsteroid;
import xol.lostinfinity.projectile.entity.EntityAstralShot;
import xol.lostinfinity.projectile.entity.EntityAtlasAttack;
import xol.lostinfinity.projectile.entity.EntityAvenger;
import xol.lostinfinity.projectile.entity.EntityAvengerLightning;
import xol.lostinfinity.projectile.entity.EntityBallOfContainedGluons;
import xol.lostinfinity.projectile.entity.EntityBallOfContainedQuarks;
import xol.lostinfinity.projectile.entity.EntityBarulChain;
import xol.lostinfinity.projectile.entity.EntityBeeAttack;
import xol.lostinfinity.projectile.entity.EntityBlightBomb;
import xol.lostinfinity.projectile.entity.EntityBlightPellet;
import xol.lostinfinity.projectile.entity.EntityBlightedComet;
import xol.lostinfinity.projectile.entity.EntityBloodhunterBlast;
import xol.lostinfinity.projectile.entity.EntityBossPortalEffect;
import xol.lostinfinity.projectile.entity.EntityCarrierProjectile;
import xol.lostinfinity.projectile.entity.EntityCelestialFire;
import xol.lostinfinity.projectile.entity.EntityCellularRock;
import xol.lostinfinity.projectile.entity.EntityChainOfVenomsAttack;
import xol.lostinfinity.projectile.entity.EntityChampionDodgeball;
import xol.lostinfinity.projectile.entity.EntityClusterBlast;
import xol.lostinfinity.projectile.entity.EntityComet;
import xol.lostinfinity.projectile.entity.EntityCrabulonProjectile;
import xol.lostinfinity.projectile.entity.EntityCreepingVineArrow;
import xol.lostinfinity.projectile.entity.EntityCreepingVinePod;
import xol.lostinfinity.projectile.entity.EntityCryoBeamEffect;
import xol.lostinfinity.projectile.entity.EntityCryoBolt;
import xol.lostinfinity.projectile.entity.EntityCrystalGellball;
import xol.lostinfinity.projectile.entity.EntityCrystalShard;
import xol.lostinfinity.projectile.entity.EntityDarkSpell;
import xol.lostinfinity.projectile.entity.EntityDeathShot;
import xol.lostinfinity.projectile.entity.EntityDebtCollectorEffect;
import xol.lostinfinity.projectile.entity.EntityDestabilizer;
import xol.lostinfinity.projectile.entity.EntityDeviantDeployer;
import xol.lostinfinity.projectile.entity.EntityDeviantEvokerBomb;
import xol.lostinfinity.projectile.entity.EntityDeviantEvokerFangs;
import xol.lostinfinity.projectile.entity.EntityDeviantEvokerShot;
import xol.lostinfinity.projectile.entity.EntityDeviantSnowball;
import xol.lostinfinity.projectile.entity.EntityDeviantSpit;
import xol.lostinfinity.projectile.entity.EntityDeviantSucker;
import xol.lostinfinity.projectile.entity.EntityDoomBlast;
import xol.lostinfinity.projectile.entity.EntityDoomShot;
import xol.lostinfinity.projectile.entity.EntityDroidBall;
import xol.lostinfinity.projectile.entity.EntityDroidLaser;
import xol.lostinfinity.projectile.entity.EntityDroidSucker;
import xol.lostinfinity.projectile.entity.EntityDroidZapper;
import xol.lostinfinity.projectile.entity.EntityDryadsGripAttack;
import xol.lostinfinity.projectile.entity.EntityDuskerQueenWeb;
import xol.lostinfinity.projectile.entity.EntityEchoBlast;
import xol.lostinfinity.projectile.entity.EntityEchoOfGravity;
import xol.lostinfinity.projectile.entity.EntityEffigyShot;
import xol.lostinfinity.projectile.entity.EntityElaraShot;
import xol.lostinfinity.projectile.entity.EntityElementiumAir;
import xol.lostinfinity.projectile.entity.EntityElementiumBlight;
import xol.lostinfinity.projectile.entity.EntityElementiumEarth;
import xol.lostinfinity.projectile.entity.EntityElementiumFire;
import xol.lostinfinity.projectile.entity.EntityElementiumPlague;
import xol.lostinfinity.projectile.entity.EntityElementiumPrime;
import xol.lostinfinity.projectile.entity.EntityElementiumShadow;
import xol.lostinfinity.projectile.entity.EntityElementiumWater;
import xol.lostinfinity.projectile.entity.EntityEmberShot;
import xol.lostinfinity.projectile.entity.EntityEnergyBurst;
import xol.lostinfinity.projectile.entity.EntityExothermite;
import xol.lostinfinity.projectile.entity.EntityExplosiveGoo;
import xol.lostinfinity.projectile.entity.EntityFallingStar;
import xol.lostinfinity.projectile.entity.EntityFearBomb;
import xol.lostinfinity.projectile.entity.EntityFirePellet;
import xol.lostinfinity.projectile.entity.EntityFluxBall;
import xol.lostinfinity.projectile.entity.EntityForbiddenBrand;
import xol.lostinfinity.projectile.entity.EntityFountainPellet;
import xol.lostinfinity.projectile.entity.EntityFractureBomb;
import xol.lostinfinity.projectile.entity.EntityGalaxyBlast;
import xol.lostinfinity.projectile.entity.EntityGalaxyBomb;
import xol.lostinfinity.projectile.entity.EntityGalaxyDragonFireball;
import xol.lostinfinity.projectile.entity.EntityGalaxyKnife;
import xol.lostinfinity.projectile.entity.EntityGalaxyLaser;
import xol.lostinfinity.projectile.entity.EntityGalaxySpell;
import xol.lostinfinity.projectile.entity.EntityGenericBomb;
import xol.lostinfinity.projectile.entity.EntityGloomSpell;
import xol.lostinfinity.projectile.entity.EntityGravityWarper;
import xol.lostinfinity.projectile.entity.EntityHomingBlight;
import xol.lostinfinity.projectile.entity.EntityInfinityTrident;
import xol.lostinfinity.projectile.entity.EntityInfinityTridentMK2;
import xol.lostinfinity.projectile.entity.EntityInkBomb;
import xol.lostinfinity.projectile.entity.EntityInkShot;
import xol.lostinfinity.projectile.entity.EntityIonicChakram;
import xol.lostinfinity.projectile.entity.EntityLaserBlast;
import xol.lostinfinity.projectile.entity.EntityLaserGunBeam;
import xol.lostinfinity.projectile.entity.EntityLaunchedKnife;
import xol.lostinfinity.projectile.entity.EntityLeviathanBreath;
import xol.lostinfinity.projectile.entity.EntityLeviathanTeslaOrb;
import xol.lostinfinity.projectile.entity.EntityLeviathanTracer;
import xol.lostinfinity.projectile.entity.EntityLuminousGuardianLaser;
import xol.lostinfinity.projectile.entity.EntityMeteor;
import xol.lostinfinity.projectile.entity.EntityMicroRocket;
import xol.lostinfinity.projectile.entity.EntityMiniChakram;
import xol.lostinfinity.projectile.entity.EntityMobComet;
import xol.lostinfinity.projectile.entity.EntityMortarShot;
import xol.lostinfinity.projectile.entity.EntityNebulaSpell;
import xol.lostinfinity.projectile.entity.EntityPicklePortal;
import xol.lostinfinity.projectile.entity.EntityPiercingShot;
import xol.lostinfinity.projectile.entity.EntityPlagueBlast;
import xol.lostinfinity.projectile.entity.EntityPoisonousBubble;
import xol.lostinfinity.projectile.entity.EntityPortalEffect;
import xol.lostinfinity.projectile.entity.EntityPowerPulse;
import xol.lostinfinity.projectile.entity.EntityProjectileKiller;
import xol.lostinfinity.projectile.entity.EntityPuzzleMasterArrow;
import xol.lostinfinity.projectile.entity.EntityRainDrop;
import xol.lostinfinity.projectile.entity.EntityRecursor;
import xol.lostinfinity.projectile.entity.EntityRockshot;
import xol.lostinfinity.projectile.entity.EntityScreamerBlast;
import xol.lostinfinity.projectile.entity.EntityScreamerPortalEffect;
import xol.lostinfinity.projectile.entity.EntitySelectionLaser;
import xol.lostinfinity.projectile.entity.EntitySelectorAttack;
import xol.lostinfinity.projectile.entity.EntitySkullShot;
import xol.lostinfinity.projectile.entity.EntitySkyStrike;
import xol.lostinfinity.projectile.entity.EntitySkycrabAttack;
import xol.lostinfinity.projectile.entity.EntitySonicAttack;
import xol.lostinfinity.projectile.entity.EntitySoundwaveBullet;
import xol.lostinfinity.projectile.entity.EntitySpiderBlast;
import xol.lostinfinity.projectile.entity.EntitySpikeBall;
import xol.lostinfinity.projectile.entity.EntityStarBlast;
import xol.lostinfinity.projectile.entity.EntityStickyProjectile;
import xol.lostinfinity.projectile.entity.EntityStrappedFirework;
import xol.lostinfinity.projectile.entity.EntityStunAttack;
import xol.lostinfinity.projectile.entity.EntitySunstoneRock;
import xol.lostinfinity.projectile.entity.EntityTNTStrapper;
import xol.lostinfinity.projectile.entity.EntityTekBullet;
import xol.lostinfinity.projectile.entity.EntityTentacleSeed;
import xol.lostinfinity.projectile.entity.EntityTetherBall;
import xol.lostinfinity.projectile.entity.EntityTitanRing;
import xol.lostinfinity.projectile.entity.EntityTormentorChain;
import xol.lostinfinity.projectile.entity.EntityUltraCrystalGel;
import xol.lostinfinity.projectile.entity.EntityUnstableBalloon;
import xol.lostinfinity.projectile.entity.EntityVeloMagic;
import xol.lostinfinity.projectile.entity.EntityVenomBlast;
import xol.lostinfinity.projectile.entity.EntityVoidLaser;
import xol.lostinfinity.projectile.entity.EntityVoltaicIonizerAttack;
import xol.lostinfinity.projectile.entity.EntityWandAttack;
import xol.lostinfinity.projectile.entity.EntityWhirlpool;
import xol.lostinfinity.projectile.entity.EntityWitchMagic;
import xol.lostinfinity.projectile.entity.EntityWitherBomb;
import xol.lostinfinity.projectile.entity.EntityWizardBlast;
import xol.lostinfinity.projectile.entity.EntityWormholeShot;
import xol.lostinfinity.projectile.entity.EntityXSonicAttack;
import xol.lostinfinity.projectile.entity.EntityZenonShot;
import xol.lostinfinity.projectile.render.RenderAlternatingArrow;
import xol.lostinfinity.projectile.render.RenderAlternatingThrowable;
import xol.lostinfinity.projectile.render.RenderAvenger;
import xol.lostinfinity.projectile.render.RenderAvengerLightning;
import xol.lostinfinity.projectile.render.RenderBarulChain;
import xol.lostinfinity.projectile.render.RenderBossPortalEffect;
import xol.lostinfinity.projectile.render.RenderChainOfVenomsAttack;
import xol.lostinfinity.projectile.render.RenderChampionDodgeball;
import xol.lostinfinity.projectile.render.RenderCryoBeamEffect;
import xol.lostinfinity.projectile.render.RenderDebtCollectorEffect;
import xol.lostinfinity.projectile.render.RenderDeviantEvokerFangs;
import xol.lostinfinity.projectile.render.RenderDuskerQueenWeb;
import xol.lostinfinity.projectile.render.RenderForbiddenBrand;
import xol.lostinfinity.projectile.render.RenderGalaxyDragonFireball;
import xol.lostinfinity.projectile.render.RenderInfinityThrowable;
import xol.lostinfinity.projectile.render.RenderInfinityTrident;
import xol.lostinfinity.projectile.render.RenderInfinityTridentMK2;
import xol.lostinfinity.projectile.render.RenderIonicChakram;
import xol.lostinfinity.projectile.render.RenderLaserGunBeam;
import xol.lostinfinity.projectile.render.RenderLeviathanBreath;
import xol.lostinfinity.projectile.render.RenderLightBeamEffect;
import xol.lostinfinity.projectile.render.RenderLuminousGuardianLaser;
import xol.lostinfinity.projectile.render.RenderMiniChakram;
import xol.lostinfinity.projectile.render.RenderNuclearExplosion;
import xol.lostinfinity.projectile.render.RenderPicklePortal;
import xol.lostinfinity.projectile.render.RenderPortalEffect;
import xol.lostinfinity.projectile.render.RenderScreamerPortalEffect;
import xol.lostinfinity.projectile.render.RenderSelectorAttack;
import xol.lostinfinity.projectile.render.RenderSpecialArrow;
import xol.lostinfinity.projectile.render.RenderTitanRing;
import xol.lostinfinity.projectile.render.RenderTormentorChain;
import xol.lostinfinity.projectile.render.RenderVoltaicIonizerAttack;
import xol.lostinfinity.projectile.render.RenderWandAttack;
import xol.lostinfinity.projectile.render.RenderWhirlpool;
import xol.lostinfinity.stone.EntityInfinityStone;
import xol.lostinfinity.stone.RenderInfinityStone;

@EventBusSubscriber
public class ModelRegistry {
   private static <T extends Entity> void registerRender(Class<T> entityClass, IRenderFactory<? super T> renderFactory) {
      RenderingRegistry.registerEntityRenderingHandler(entityClass, renderFactory);
   }

   @SubscribeEvent
   @SideOnly(Side.CLIENT)
   public static void registerAllModels(ModelRegistryEvent event) {
      for (Item item : ItemInit.ITEMS) {
         lostinfinity.proxy.registerItemRenderer(item, 0, "invetory");
      }

      for (ItemLostArmor armor : ItemInit.ARMORS) {
         lostinfinity.proxy.registerItemRenderer(armor, 0, "invetory");
      }

      registerRender(EntityTreadmillObstacle.class, manager -> new RenderTreadmillObstacle(manager));
      registerRender(EntityTreadmillObstacleJumpable.class, manager -> new RenderTreadmillObstacleJumpable(manager));
      registerRender(EntityDimensionalMerchant.class, manager -> new RenderDimensionalMerchant(manager));
      registerRender(EntityDeviantCow.class, manager -> new RenderDeviantCow(manager));
      registerRender(EntityDeviantSheep.class, manager -> new RenderDeviantSheep(manager));
      registerRender(EntityDeviantPig.class, manager -> new RenderDeviantPig(manager));
      registerRender(EntityDeviantHorse.class, manager -> new RenderDeviantHorse(manager));
      registerRender(EntityDeviantEvoker.class, manager -> new RenderDeviantEvoker(manager));
      registerRender(EntityDeviantEvokerVex.class, manager -> new RenderDeviantEvokerVex(manager));
      registerRender(EntityDeviantBear.class, manager -> new RenderDeviantBear(manager));
      registerRender(EntityDeviantChicken.class, manager -> new RenderDeviantChicken(manager));
      registerRender(EntityDeviantShulker.class, manager -> new RenderDeviantShulker(manager));
      registerRender(EntityDeviantEnderman.class, manager -> new RenderDeviantEnderman(manager));
      registerRender(EntityDeviantGhast.class, manager -> new RenderDeviantGhast(manager));
      registerRender(EntityElara.class, manager -> new RenderElara(manager));
      registerRender(EntityDeviantSkyworm.class, manager -> new RenderDeviantSkyworm(manager));
      registerRender(EntityInfinityStone.class, manager -> new RenderInfinityStone(manager));
      registerRender(EntityUrogo.class, manager -> new RenderUrogo(manager));
      registerRender(EntityDeviantSkeleton.class, manager -> new RenderDeviantSkeleton(manager));
      registerRender(EntityDeviantCreeper.class, manager -> new RenderDeviantCreeper(manager));
      registerRender(EntityDroid.class, manager -> new RenderDroid(manager));
      registerRender(EntityDroidBoss.class, manager -> new RenderDroidBoss(manager));
      registerRender(EntityArenaEvent.class, manager -> new RenderArenaEvent(manager));
      registerRender(EntityLostDeviant.class, manager -> new RenderLostDeviant(manager));
      registerRender(EntityCourseRing.class, manager -> new RenderCourseRing(manager));
      registerRender(EntityLabWarrior.class, manager -> new RenderLabWarrior(manager));
      registerRender(EntityLabWizard.class, manager -> new RenderLabWizard(manager));
      registerRender(EntitySandAttack.class, manager -> new RenderSandAttack(manager));
      registerRender(EntityDeviantSpider.class, manager -> new RenderDeviantSpider(manager));
      registerRender(EntityAspect.class, manager -> new RenderAspect(manager));
      registerRender(EntitySlimeStrider.class, manager -> new RenderSlimeStrider(manager));
      registerRender(EntityVelo.class, manager -> new RenderVelo(manager));
      registerRender(EntityGalaxyBeast.class, manager -> new RenderGalaxyBeast(manager));
      registerRender(EntityGalaxyBeast.class, manager -> new RenderGalaxyBeast(manager));
      registerRender(EntityGalaxySorcerer.class, manager -> new RenderGalaxySorcerer(manager));
      registerRender(EntityGalaxyGladiator.class, manager -> new RenderGalaxyGladiator(manager));
      registerRender(EntityDeviantAmalgam.class, manager -> new RenderDeviantAmalgam(manager));
      registerRender(EntityGalaxySpire.class, manager -> new RenderGalaxySpire(manager));
      registerRender(EntityStarfiend.class, manager -> new RenderStarfiend(manager));
      registerRender(EntityBloodhunter.class, manager -> new RenderBloodhunter(manager));
      registerRender(EntityPuzzleMaster.class, manager -> new RenderPuzzleMaster(manager));
      registerRender(EntityRikarus.class, manager -> new RenderRikarus(manager));
      registerRender(EntityRestorationCrystal.class, manager -> new RenderRestorationCrystal(manager));
      registerRender(EntityDeviantWitch.class, manager -> new RenderDeviantWitch(manager));
      registerRender(EntityMirrorZombie.class, manager -> new RenderMirrorZombie(manager));
      registerRender(EntityDeviantSlimeStrider.class, manager -> new RenderDeviantSlimeStrider(manager));
      registerRender(EntityDeviantGuardian.class, manager -> new RenderDeviantGuardian(manager));
      registerRender(EntityDeviantBlaze.class, manager -> new RenderDeviantBlaze(manager));
      registerRender(EntityTitanBlaze.class, manager -> new RenderTitanBlaze(manager));
      registerRender(EntityTitanShulker.class, manager -> new RenderTitanShulker(manager));
      registerRender(EntityTitanSpider.class, manager -> new RenderTitanSpider(manager));
      registerRender(EntityTitanSkeleton.class, manager -> new RenderTitanSkeleton(manager));
      registerRender(EntityTrialObserver.class, manager -> new RenderTrialObserver(manager));
      registerRender(EntityHanger.class, manager -> new RenderHanger(manager));
      registerRender(EntityAcidback.class, manager -> new RenderAcidback(manager));
      registerRender(EntityReflectal.class, manager -> new RenderReflectal(manager));
      registerRender(EntityGravhead.class, manager -> new RenderGravhead(manager));
      registerRender(EntityRockpest.class, manager -> new RenderRockpest(manager));
      registerRender(EntitySpinovern.class, manager -> new RenderSpinovern(manager));
      registerRender(EntityHypnosaur.class, manager -> new RenderHypnosaur(manager));
      registerRender(EntityChomper.class, manager -> new RenderChomper(manager));
      registerRender(EntityRibrex.class, manager -> new RenderRibrex(manager));
      registerRender(EntityGnawer.class, manager -> new RenderGnawer(manager));
      registerRender(EntityScreacher.class, manager -> new RenderScreacher(manager));
      registerRender(EntityEyeSlug.class, manager -> new RenderEyeSlug(manager));
      registerRender(EntityFlutterfyre.class, manager -> new RenderFlutterfyre(manager));
      registerRender(EntityDeviantSnowman.class, manager -> new RenderDeviantSnowman(manager));
      registerRender(EntityNuxuro.class, manager -> new RenderNuxuro(manager));
      registerRender(EntityClyster.class, manager -> new RenderClyster(manager));
      registerRender(EntityCrawker.class, manager -> new RenderCrawker(manager));
      registerRender(EntityDusker.class, manager -> new RenderDusker(manager));
      registerRender(EntityExplosect.class, manager -> new RenderExplosect(manager));
      registerRender(EntityFlapper.class, manager -> new RenderFlapper(manager));
      registerRender(EntityFlurky.class, manager -> new RenderFlurky(manager));
      registerRender(EntityFyreweed.class, manager -> new RenderFyreweed(manager));
      registerRender(EntityGrappler.class, manager -> new RenderGrappler(manager));
      registerRender(EntityHurler.class, manager -> new RenderHurler(manager));
      registerRender(EntityPhaser.class, manager -> new RenderPhaser(manager));
      registerRender(EntityShimmer.class, manager -> new RenderShimmer(manager));
      registerRender(EntitySpyker.class, manager -> new RenderSpyker(manager));
      registerRender(EntityDeviantMooshroom.class, manager -> new RenderDeviantMooshroom(manager));
      registerRender(EntityDeviantZombie.class, manager -> new RenderDeviantZombie(manager));
      registerRender(EntityDeviantSlime.class, manager -> new RenderDeviantSlime(manager));
      registerRender(EntityDeviantPiglin.class, manager -> new RenderDeviantPiglin(manager));
      registerRender(EntityDeviantLlama.class, manager -> new RenderDeviantLlama(manager));
      registerRender(EntityDeviantStray.class, manager -> new RenderDeviantStray(manager));
      registerRender(EntityDeviantVex.class, manager -> new RenderDeviantVex(manager));
      registerRender(EntityDeviantMagmacube.class, manager -> new RenderDeviantMagmacube(manager));
      registerRender(EntityArash.class, manager -> new RenderArash(manager));
      registerRender(EntityAlestria.class, manager -> new RenderAlestria(manager));
      registerRender(EntityAtlasSpire.class, manager -> new RenderAtlasSpire(manager));
      registerRender(EntityDarrio.class, manager -> new RenderDarrio(manager));
      registerRender(EntityBarul.class, manager -> new RenderBarul(manager));
      registerRender(EntityAtlasCrystal.class, manager -> new RenderAtlasCrystal(manager));
      registerRender(EntitySentryCrystal.class, manager -> new RenderSentryCrystal(manager));
      registerRender(EntityDeviantCrystal.class, manager -> new RenderDeviantCrystal(manager));
      registerRender(EntityTitanStray.class, manager -> new RenderTitanStray(manager));
      registerRender(EntityTitanVex.class, manager -> new RenderTitanVex(manager));
      registerRender(EntityTitanCreeper.class, manager -> new RenderTitanCreeper(manager));
      registerRender(EntityTitanEnderman.class, manager -> new RenderTitanEnderman(manager));
      registerRender(EntityTitanPiglin.class, manager -> new RenderTitanPiglin(manager));
      registerRender(EntityTitanLlama.class, manager -> new RenderTitanLlama(manager));
      registerRender(EntityTitanZombie.class, manager -> new RenderTitanZombie(manager));
      registerRender(EntityTitanMagmacube.class, manager -> new RenderTitanMagmacube(manager));
      registerRender(EntityGloop.class, manager -> new RenderGloop(manager));
      registerRender(EntityGloopMother.class, manager -> new RenderGloopMother(manager));
      registerRender(EntityCyclos.class, manager -> new RenderCyclos(manager));
      registerRender(EntityClinger.class, manager -> new RenderClinger(manager));
      registerRender(EntityDeviantDimTrader.class, manager -> new RenderDeviantDimTrader(manager));
      registerRender(EntityMemPuzzleMerchant.class, manager -> new RenderMemPuzzleMerchant(manager));
      registerRender(EntitySkybooster.class, manager -> new RenderSkybooster(manager));
      registerRender(EntityRocketStrappedExplosive.class, manager -> new RenderRocketStrappedExplosive(manager));
      registerRender(EntityMarkOfInfiniteDespair.class, manager -> new RenderMarkOfInfiniteDespair(manager));
      registerRender(EntitySpectre.class, manager -> new RenderSpectre(manager));
      registerRender(EntityContraderMarket.class, manager -> new RenderContraderMarket(manager));
      registerRender(EntityContraderHolodeck.class, manager -> new RenderContraderHolodeck(manager));
      registerRender(EntityContraderHunters.class, manager -> new RenderContraderHunters(manager));
      registerRender(EntityContraderLightbridge.class, manager -> new RenderContraderLightbridge(manager));
      registerRender(EntityContraderTargets.class, manager -> new RenderContraderTargets(manager));
      registerRender(EntityContraderTrampolineDodgeball.class, manager -> new RenderContraderTrampolineDodgeball(manager));
      registerRender(EntityOperatorHolodeck.class, manager -> new RenderOperatorHolodeck(manager));
      registerRender(EntityOperatorHunters.class, manager -> new RenderOperatorHunters(manager));
      registerRender(EntityOperatorTargets.class, manager -> new RenderOperatorTargets(manager));
      registerRender(EntityOperatorTrampolineDodgeball.class, manager -> new RenderOperatorTrampolineDodgeball(manager));
      registerRender(EntityControllerHolodeck.class, manager -> new RenderControllerHolodeck(manager));
      registerRender(EntityControllerHunters.class, manager -> new RenderControllerHunters(manager));
      registerRender(EntityControllerTargets.class, manager -> new RenderControllerTargets(manager));
      registerRender(EntityControllerLightBridge.class, manager -> new RenderControllerLightBridge(manager));
      registerRender(EntityControllerDuelArena.class, manager -> new RenderControllerDuelArena(manager));
      registerRender(EntityControllerTrampolineDodgeball.class, manager -> new RenderControllerTrampolineDodgeball(manager));
      registerRender(EntityOperatorLightBridge.class, manager -> new RenderOperatorLightBridge(manager));
      registerRender(EntityOperatorDuelArena.class, manager -> new RenderOperatorDuelArena(manager));
      registerRender(EntityContestHologram.class, manager -> new RenderContestHologram(manager));
      registerRender(EntityParticleTrojan.class, manager -> new RenderParticleTrojan(manager));
      registerRender(EntityPlasmaExplosion.class, manager -> new RenderPlasmaExplosion(manager));
      registerRender(EntityAzross.class, manager -> new RenderAzross(manager));
      registerRender(EntityDuskerQueen.class, manager -> new RenderDuskerQueen(manager));
      registerRender(EntityOperatorRedlight.class, manager -> new RenderOperatorRedlight(manager));
      registerRender(EntityControllerRedlight.class, manager -> new RenderControllerRedlight(manager));
      registerRender(EntityContraderRedlight.class, manager -> new RenderContraderRedlight(manager));
      registerRender(EntityOperatorBattleSnakes.class, manager -> new RenderOperatorBattleSnakes(manager));
      registerRender(EntityControllerBattleSnakes.class, manager -> new RenderControllerBattleSnakes(manager));
      registerRender(EntityContraderBattleSnakes.class, manager -> new RenderContraderBattleSnakes(manager));
      registerRender(EntityOperatorLaserTag.class, manager -> new RenderOperatorLaserTag(manager));
      registerRender(EntityControllerLaserTag.class, manager -> new RenderControllerLaserTag(manager));
      registerRender(EntityContraderLaserTag.class, manager -> new RenderContraderLaserTag(manager));
      registerRender(EntityOperatorParkour.class, manager -> new RenderOperatorParkour(manager));
      registerRender(EntityControllerParkour.class, manager -> new RenderControllerParkour(manager));
      registerRender(EntityContraderParkour.class, manager -> new RenderContraderParkour(manager));
      registerRender(EntityOperatorInkBattle.class, manager -> new RenderOperatorInkBattle(manager));
      registerRender(EntityControllerInkBattle.class, manager -> new RenderControllerInkBattle(manager));
      registerRender(EntityContraderInkBattle.class, manager -> new RenderContraderInkBattle(manager));
      registerRender(EntityOperatorTreadmill.class, manager -> new RenderOperatorTreadmill(manager));
      registerRender(EntityControllerTreadmill.class, manager -> new RenderControllerTreadmill(manager));
      registerRender(EntityContraderTreadmill.class, manager -> new RenderContraderTreadmill(manager));
      registerRender(EntityDeviantWither.class, manager -> new RenderDeviantWither(manager));
      registerRender(EntityWitherSkullling.class, manager -> new RenderWitherSkullling(manager));
      registerRender(EntityArcheologist.class, manager -> new RenderArcheologist(manager));
      registerRender(EntityGlangler.class, manager -> new RenderGlangler(manager));
      registerRender(EntityGlochipper.class, manager -> new RenderGlochipper(manager));
      registerRender(EntityGloboon.class, manager -> new RenderGloboon(manager));
      registerRender(EntityEssenceDweller.class, manager -> new RenderEssenceDweller(manager));
      registerRender(EntityEssenceIdol.class, manager -> new RenderEssenceIdol(manager));
      registerRender(EntityGlobro.class, manager -> new RenderGlobro(manager));
      registerRender(EntityAugmenticon.class, manager -> new RenderAugmenticon(manager));
      registerRender(EntityGalaxyGulper.class, manager -> new RenderGalaxyGulper(manager));
      registerRender(EntityLaserSpire.class, manager -> new RenderLaserSpire(manager));
      registerRender(EntityIonExplosion.class, manager -> new RenderIonExplosion(manager));
      registerRender(EntityGiantFlapper.class, manager -> new RenderGiantFlapper(manager));
      registerRender(EntityDeviantGolem.class, manager -> new RenderDeviantGolem(manager));
      registerRender(EntityTornIndividual.class, manager -> new RenderTornIndividual(manager));
      registerRender(EntityDeviantCaveSpider.class, manager -> new RenderDeviantCaveSpider(manager));
      registerRender(EntityFeralMerchant.class, manager -> new RenderFeralMerchant(manager));
      registerRender(EntityUnstableMerchant.class, manager -> new RenderUnstableMerchant(manager));
      registerRender(EntityStickler.class, manager -> new RenderStickler(manager));
      registerRender(EntityVectosect.class, manager -> new RenderVectosect(manager));
      registerRender(EntityStickyBomb.class, manager -> new RenderStickyBomb(manager));
      registerRender(EntityRavager.class, manager -> new RenderRavager(manager));
      registerRender(EntityVycellia.class, manager -> new RenderVycellia(manager));
      registerRender(EntityNightshyre.class, manager -> new RenderNightshyre(manager));
      registerRender(EntityGiantFyreweed.class, manager -> new RenderGiantFyreweed(manager));
      registerRender(EntityBomberBomb.class, manager -> new RenderBomberBomb(manager));
      registerRender(EntitySkycrab.class, manager -> new RenderSkycrab(manager));
      registerRender(EntityGlomite.class, manager -> new RenderGlomite(manager));
      registerRender(EntityTNTZombie.class, manager -> new RenderTNTZombie(manager));
      registerRender(EntityDeviantBat.class, manager -> new RenderDeviantBat(manager));
      registerRender(EntityContraderBombers.class, manager -> new RenderContraderBombers(manager));
      registerRender(EntityControllerBombers.class, manager -> new RenderControllerBombers(manager));
      registerRender(EntityOperatorBombers.class, manager -> new RenderOperatorBombers(manager));
      registerRender(EntityRockslug.class, manager -> new RenderRockslug(manager));
      registerRender(EntityGiantRockslug.class, manager -> new RenderGiantRockslug(manager));
      registerRender(EntityLightGame.class, manager -> new RenderLightPuzzleMerchant(manager));
      registerRender(EntityWhackGameMerchant.class, manager -> new RenderWhackGameMerchant(manager));
      registerRender(EntityConnectGameMerchant.class, manager -> new RenderConnectGameMerchant(manager));
      registerRender(EntityRhythmGameMerchant.class, manager -> new RenderRhythmGameMerchant(manager));
      registerRender(EntityFlutterbee.class, manager -> new RenderFlutterbee(manager));
      registerRender(EntityOzor.class, manager -> new RenderOzor(manager));
      registerRender(EntityOzorDecoy.class, manager -> new RenderOzorDecoy(manager));
      registerRender(EntityTotemMoon.class, manager -> new RenderTotemMoon(manager));
      registerRender(EntityTotemPylon.class, manager -> new RenderTotemPylon(manager));
      registerRender(EntityThundyron.class, manager -> new RenderThundyron(manager));
      registerRender(EntityCryonus.class, manager -> new RenderCryonus(manager));
      registerRender(EntityThunderBomb.class, manager -> new RenderThunderBomb(manager));
      registerRender(EntityStormBomb.class, manager -> new RenderStormBomb(manager));
      registerRender(EntityPlasmaBomb.class, manager -> new RenderPlasmaBomb(manager));
      registerRender(EntityPipeGameMerchant.class, manager -> new RenderPipeGameMerchant(manager));
      registerRender(EntityPearlCollector.class, manager -> new RenderPearlCollector(manager));
      registerRender(EntityZenon.class, manager -> new RenderZenon(manager));
      registerRender(EntityCrusher.class, manager -> new RenderCrusher(manager));
      registerRender(EntityDrippler.class, manager -> new RenderDrippler(manager));
      registerRender(EntityGorger.class, manager -> new RenderGorger(manager));
      registerRender(EntityDoublejaw.class, manager -> new RenderDoublejaw(manager));
      registerRender(EntityMinimite.class, manager -> new RenderMinimite(manager));
      registerRender(EntityClusterweed.class, manager -> new RenderClusterweed(manager));
      registerRender(EntityWisp.class, manager -> new RenderWisp(manager));
      registerRender(EntityTetherbug.class, manager -> new RenderTetherbug(manager));
      registerRender(EntityCellGameMerchant.class, manager -> new RenderCellGameMerchant(manager));
      registerRender(EntityLuminousGuardian.class, manager -> new RenderLuminousGuardian(manager));
      registerRender(EntityVilebulb.class, manager -> new RenderVilebulb(manager));
      registerRender(EntitySightwalker.class, manager -> new RenderSightwalker(manager));
      registerRender(EntityWeaver.class, manager -> new RenderWeaver(manager));
      registerRender(EntityDoomDog.class, manager -> new RenderDoomDog(manager));
      registerRender(EntityBlisterweed.class, manager -> new RenderBlisterweed(manager));
      registerRender(EntityGrubber.class, manager -> new RenderGrubber(manager));
      registerRender(EntityLeer.class, manager -> new RenderLeer(manager));
      registerRender(EntityTitanopod.class, manager -> new RenderTitanopod(manager));
      registerRender(EntityFlashfly.class, manager -> new RenderFlashfly(manager));
      registerRender(EntitySnapper.class, manager -> new RenderSnapper(manager));
      registerRender(EntityTerrorFly.class, manager -> new RenderTerrorFly(manager));
      registerRender(EntityTentaclon.class, manager -> new RenderTentaclon(manager));
      registerRender(EntityGalacticTerror.class, manager -> new RenderGalacticTerror(manager));
      registerRender(EntityDeviantWitherSkeleton.class, manager -> new RenderDeviantWitherSkeleton(manager));
      registerRender(EntityPickleMan.class, manager -> new RenderPickleMan(manager));
      registerRender(EntityWhisper.class, manager -> new RenderWhisper(manager));
      registerRender(EntityTorpedon.class, manager -> new RenderTorpedon(manager));
      registerRender(EntityLurcher.class, manager -> new RenderLurcher(manager));
      registerRender(EntityMortarCannon.class, manager -> new RenderMortarCannon(manager));
      registerRender(EntityClusterCannon.class, manager -> new RenderClusterCannon(manager));
      registerRender(EntityDeviantOcelote.class, manager -> new RenderDeviantOcelote(manager));
      registerRender(EntityLivorax.class, manager -> new RenderLivorax(manager));
      registerRender(EntityCaveTerror.class, manager -> new RenderCaveTerror(manager));
      registerRender(EntityRift.class, manager -> new RenderRift(manager));
      registerRender(EntityUnstableRift.class, manager -> new RenderUnstableRift(manager));
      registerRender(EntityNat.class, manager -> new RenderNat(manager));
      registerRender(EntitySentry.class, manager -> new RenderSentry(manager));
      registerRender(EntityTotemSplitter.class, manager -> new RenderTotemSplitter(manager));
      registerRender(EntityTentacleTrap.class, manager -> new RenderTentacleTrap(manager));
      registerRender(EntityScorpwing.class, manager -> new RenderScorpwing(manager));
      registerRender(EntityOrbiter.class, manager -> new RenderOrbiter(manager));
      registerRender(EntitySkyre.class, manager -> new RenderSkyre(manager));
      registerRender(EntityDoomsday.class, manager -> new RenderDoomsday(manager));
      registerRender(EntityRockworm.class, manager -> new RenderRockworm(manager));
      registerRender(EntityKalikos.class, manager -> new RenderKalikos(manager));
      registerRender(EntityGhostCopy.class, manager -> new RenderGhostCopy(manager));
      registerRender(EntityDoublerang.class, manager -> new RenderDoublerang(manager));
      registerRender(EntityLongfin.class, manager -> new RenderLongfin(manager));
      registerRender(EntityGlowfish.class, manager -> new RenderGlowfish(manager));
      registerRender(EntityOctobrella.class, manager -> new RenderOctobrella(manager));
      registerRender(EntityRayfish.class, manager -> new RenderRayfish(manager));
      registerRender(EntityUnderfin.class, manager -> new RenderUnderfin(manager));
      registerRender(EntityEelShark.class, manager -> new RenderEelShark(manager));
      registerRender(EntityChemist.class, manager -> new RenderChemist(manager));
      registerRender(EntityDeviantSquid.class, manager -> new RenderDeviantSquid(manager));
      registerRender(EntityScreamer.class, manager -> new RenderScreamer(manager));
      registerRender(EntityNebulaGrunt.class, RenderNebulaGrunt::new);
      registerRender(EntityNebulaWizard.class, RenderNebulaWizard::new);
      registerRender(EntityNebulaGiant.class, RenderNebulaGiant::new);
      registerRender(EntityLeviathanController.class, RenderLeviathanController::new);
      registerRender(EntityLeviathanHead.class, RenderLeviathanSegment::new);
      registerRender(EntityLeviathanSegment.class, RenderLeviathanSegment::new);
      registerRender(EntityLeviathanTail.class, RenderLeviathanSegment::new);
      registerRender(EntitySeaSerpentController.class, RenderSeaSerpentController::new);
      registerRender(EntitySeaSerpentHead.class, RenderSeaSerpentSegment::new);
      registerRender(EntitySeaSerpentSegment.class, RenderSeaSerpentSegment::new);
      registerRender(EntitySeaSerpentTail.class, RenderSeaSerpentSegment::new);
      registerRender(EntityGalaxyDragon.class, RenderGalaxyDragon::new);
      registerRender(EntityXScreacher.class, RenderXScreacher::new);
      registerRender(EntityCrabulon.class, RenderCrabulon::new);
      registerRender(EntityRibshark.class, RenderRibshark::new);
      registerRender(EntityMushmerra.class, RenderMushmerra::new);
      registerRender(EntityMushmerraClone.class, RenderMushmerraClone::new);
      registerRender(EntityShroomite.class, RenderShroomite::new);
      registerRender(EntityDeviantWolf.class, RenderDeviantWolf::new);
      registerRender(EntityDeviantHusk.class, RenderDeviantHusk::new);
      registerRender(EntityAndromedaController.class, RenderAndromedaController::new);
      registerRender(EntityAndromedaSegment.class, RenderAndromedaSegment::new);
      registerRender(EntityFungfly.class, RenderFungfly::new);
      registerRender(EntityCthulhuCloud.class, RenderCthulhuCloud::new);
      registerRender(EntityDeviantEvokerFangs.class, RenderDeviantEvokerFangs::new);
      registerRender(
         EntityElaraShot.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elarashot.png"))
      );
      registerRender(
         EntityDroidBall.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/droidball.png"))
      );
      registerRender(
         EntityDroidZapper.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/droidzapper.png"))
      );
      registerRender(
         EntitySkullShot.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/skullshot.png"))
      );
      registerRender(
         EntityDeviantEvokerShot.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/deviantevokershot.png"))
      );
      registerRender(
         EntityDeviantEvokerBomb.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/deviantevokerbomb.png"))
      );
      registerRender(
         EntityDoomShot.class, manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/doomshot.png"))
      );
      registerRender(
         EntityRainDrop.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/rain_drop.png"))
      );
      registerRender(
         EntityAcidRainDrop.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/acid_rain_drop.png"))
      );
      registerRender(
         EntityDroidSucker.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/droidzapper.png"))
      );
      registerRender(
         EntityVeloMagic.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/velomagic.png"))
      );
      registerRender(
         EntityWizardBlast.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/wizardblast.png"))
      );
      registerRender(
         EntityFluxBall.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/velomagic.png"))
      );
      registerRender(
         EntityInkShot.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/ink_shot.png"))
      );
      registerRender(
         EntityInkBomb.class, manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/ink_bomb.png"))
      );
      registerRender(
         EntityGalaxyBlast.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/galaxyblast.png"))
      );
      registerRender(
         EntityGalaxySpell.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/galaxyspell.png"))
      );
      registerRender(
         EntityGalaxyBomb.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/galaxybomb.png"))
      );
      registerRender(
         EntityGalaxyKnife.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/galaxyknife.png"))
      );
      registerRender(
         EntityDeviantSucker.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/droidzapper.png"))
      );
      registerRender(
         EntityDeviantDeployer.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/deviantball.png"))
      );
      registerRender(
         EntityWitchMagic.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/witchmagic.png"))
      );
      registerRender(
         EntityCrystalGellball.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/crystalgel.png"))
      );
      registerRender(
         EntityCarrierProjectile.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/carriershot.png"))
      );
      registerRender(
         EntityFallingStar.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/fallingstar.png"))
      );
      registerRender(
         EntityRockshot.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/rockshot.png"))
      );
      registerRender(
         EntitySonicAttack.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            3.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/sonicattack_blue.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/sonicattack_orange.png")
         )
      );
      registerRender(
         EntityXSonicAttack.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            3.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/sonicattack_blue.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/sonicattack_orange.png")
         )
      );
      registerRender(EntityWandAttack.class, manager -> new RenderWandAttack(manager));
      registerRender(
         EntityDeviantSnowball.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/deviantsnowball.png"))
      );
      registerRender(
         EntityCelestialFire.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            2.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/celestialfire_red.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/celestialfire_yellow.png")
         )
      );
      registerRender(
         EntityExplosiveGoo.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            1.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/explosivegoo_orange.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/explosivegoo_yellow.png"),
            3
         )
      );
      registerRender(
         EntityStunAttack.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            1.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/stunattack_1.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/stunattack_2.png"),
            4
         )
      );
      registerRender(
         EntityDarkSpell.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/darkspell.png"))
      );
      registerRender(
         EntityCrystalShard.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/crystalshard.png"))
      );
      registerRender(
         EntityDestabilizer.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/destabilizer.png"))
      );
      registerRender(
         EntityComet.class, manager -> new RenderInfinityThrowable(manager, 3.0F, new ResourceLocation("lostinfinity", "textures/projectiles/comet.png"))
      );
      registerRender(
         EntityMobComet.class, manager -> new RenderInfinityThrowable(manager, 4.0F, new ResourceLocation("lostinfinity", "textures/projectiles/comet.png"))
      );
      registerRender(
         EntityBlightedComet.class,
         manager -> new RenderInfinityThrowable(manager, 4.0F, new ResourceLocation("lostinfinity", "textures/projectiles/blighted_comet.png"))
      );
      registerRender(
         EntityTentacleSeed.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/tentacle_seed.png"))
      );
      registerRender(
         EntityHomingBlight.class,
         manager -> new RenderInfinityThrowable(manager, 4.0F, new ResourceLocation("lostinfinity", "textures/projectiles/homing_blight.png"))
      );
      registerRender(
         EntityAtlasAttack.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/galaxyblast.png"))
      );
      registerRender(
         EntityDeviantSpit.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/deviantspit.png"))
      );
      registerRender(
         EntityVoidLaser.class,
         manager -> new RenderInfinityThrowable(manager, 1.5F, new ResourceLocation("lostinfinity", "textures/projectiles/voidlaser.png"))
      );
      registerRender(
         EntitySkyStrike.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            2.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/charged_comet1.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/charged_comet2.png"),
            10
         )
      );
      registerRender(
         EntityProjectileKiller.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/projectile_killer.png"))
      );
      registerRender(
         EntityVenomBlast.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/venom_blast.png"))
      );
      registerRender(
         EntityBloodhunterBlast.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/bloodhunter_blast.png"))
      );
      registerRender(
         EntityPowerPulse.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/power_pulse.png"))
      );
      registerRender(
         EntityGravityWarper.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/gravity_warper.png"))
      );
      registerRender(
         EntityWitherBomb.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/wither_bomb.png"))
      );
      registerRender(
         EntityElementiumFire.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_fire.png"))
      );
      registerRender(
         EntityElementiumWater.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_water.png"))
      );
      registerRender(
         EntityElementiumEarth.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_earth.png"))
      );
      registerRender(
         EntityElementiumAir.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_air.png"))
      );
      registerRender(
         EntityDroidLaser.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/laser_ring.png"))
      );
      registerRender(
         EntityGalaxyLaser.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/laser_ball.png"))
      );
      registerRender(
         EntityStickyProjectile.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/sticky_bomb.png"))
      );
      registerRender(
         EntityGenericBomb.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/generic_bomb.png"))
      );
      registerRender(
         EntityPlagueBlast.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/dark_skull.png"))
      );
      registerRender(
         EntityFractureBomb.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/fracture_bomb.png"))
      );
      registerRender(
         EntityUltraCrystalGel.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/ultra_crystalgel.png"))
      );
      registerRender(
         EntitySpiderBlast.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/spider_blast.png"))
      );
      registerRender(
         EntityGloomSpell.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/gloom_spell.png"))
      );
      registerRender(
         EntityEchoBlast.class, manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/echo.png"))
      );
      registerRender(
         EntityZenonShot.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/zenon_shot.png"))
      );
      registerRender(
         EntityElementiumShadow.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_shadow.png"))
      );
      registerRender(
         EntityElementiumBlight.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_blight.png"))
      );
      registerRender(
         EntityElementiumPlague.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_plague.png"))
      );
      registerRender(
         EntityTNTStrapper.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/carriershot.png"))
      );
      registerRender(
         EntityPuzzleMasterArrow.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/puzzle_master_arrow.png"))
      );
      registerRender(
         EntitySkycrabAttack.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/skycrab_attack.png"))
      );
      registerRender(
         EntityCellularRock.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/cellular_rock.png"))
      );
      registerRender(
         EntitySunstoneRock.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/sunstone_rock.png"))
      );
      registerRender(EntityInfinityTrident.class, manager -> new RenderInfinityTrident(manager));
      registerRender(EntityInfinityTridentMK2.class, manager -> new RenderInfinityTridentMK2(manager));
      registerRender(EntityAvenger.class, manager -> new RenderAvenger(manager));
      registerRender(EntityTitanRing.class, manager -> new RenderTitanRing(manager));
      registerRender(EntityLuminousGuardianLaser.class, RenderLuminousGuardianLaser::new);
      registerRender(EntityLaserGunBeam.class, RenderLaserGunBeam::new);
      registerRender(
         EntityChampionDodgeball.class,
         manager -> new RenderChampionDodgeball(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/champion_dodgeball.png"))
      );
      registerRender(
         EntitySpikeBall.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/spikeball.png"))
      );
      registerRender(
         EntityNebulaSpell.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/nebula_spell.png"))
      );
      registerRender(
         EntityRecursor.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/infinity_razor.png"))
      );
      registerRender(EntityIonicChakram.class, manager -> new RenderIonicChakram(manager));
      registerRender(EntityMiniChakram.class, manager -> new RenderMiniChakram(manager));
      registerRender(
         EntityExothermite.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/exothermite.png"))
      );
      registerRender(
         EntityBallOfContainedQuarks.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/ball_of_contained_quarks.png"))
      );
      registerRender(
         EntityBallOfContainedGluons.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/ball_of_contained_gluons.png"))
      );
      registerRender(
         EntityAcidicConcoction.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/acidic_concoction.png"))
      );
      registerRender(
         EntityPoisonousBubble.class,
         manager -> new RenderInfinityThrowable(manager, 0.1F, new ResourceLocation("lostinfinity", "textures/projectiles/poisonous_bubble.png"))
      );
      registerRender(
         EntityBeeAttack.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/bee_attack.png"))
      );
      registerRender(
         EntityMortarShot.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/mortar_shot.png"))
      );
      registerRender(
         EntityUnstableBalloon.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/unstable_balloon.png"))
      );
      registerRender(
         EntityPiercingShot.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/crystal_arrow.png"))
      );
      registerRender(
         EntityLaserBlast.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/laser_ball.png"))
      );
      registerRender(
         EntitySelectionLaser.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/laser_ball.png"))
      );
      registerRender(
         EntityDryadsGripAttack.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/nature_spell.png"))
      );
      registerRender(
         EntityTetherBall.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/web_attack.png"))
      );
      registerRender(
         EntityFirePellet.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/fire_pellet.png"))
      );
      registerRender(
         EntityFountainPellet.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/fountain_pellet.png"))
      );
      registerRender(
         EntityClusterBlast.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/fracture_bomb.png"))
      );
      registerRender(
         EntityWormholeShot.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/wormhole_shot.png"))
      );
      registerRender(
         EntityFearBomb.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/flurry_arrow.png"))
      );
      registerRender(
         EntityEnergyBurst.class,
         manager -> new RenderAlternatingArrow(
            manager,
            new ResourceLocation("lostinfinity", "textures/projectiles/energy_burst.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/energy_burst_alternate.png")
         )
      );
      registerRender(
         EntityBlightPellet.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/blight_pellet.png"))
      );
      registerRender(
         EntityEffigyShot.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/effigy_doll.png"))
      );
      registerRender(
         EntityEchoOfGravity.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/echo.png"))
      );
      registerRender(
         EntityStarBlast.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/fallingstar.png"))
      );
      registerRender(
         EntityAsteroid.class,
         manager -> new RenderInfinityThrowable(manager, 30.0F, new ResourceLocation("lostinfinity", "textures/projectiles/asteroid.png"), true)
      );
      registerRender(
         EntityMeteor.class, manager -> new RenderInfinityThrowable(manager, 4.0F, new ResourceLocation("lostinfinity", "textures/projectiles/meteor.png"))
      );
      registerRender(
         EntityDoomBlast.class,
         manager -> new RenderInfinityThrowable(manager, 2.0F, new ResourceLocation("lostinfinity", "textures/projectiles/doom_blast.png"))
      );
      registerRender(
         EntityAstralShot.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/astral_shot.png"))
      );
      registerRender(
         EntityLaunchedKnife.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/launched_knife.png"))
      );
      registerRender(
         EntityElementiumPrime.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/elementium_prime.png"))
      );
      registerRender(
         EntityArcBlast.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/gravity_warper.png"))
      );
      registerRender(
         EntityBlightBomb.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/venom_blast.png"))
      );
      registerRender(
         EntityTekBullet.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/rockshot.png"))
      );
      registerRender(
         EntityStrappedFirework.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/strapped_firework.png"))
      );
      registerRender(
         EntityCryoBolt.class, manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/cryo_bolt.png"))
      );
      registerRender(
         EntityScreamerBlast.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            1.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/screamer_blast.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/screamer_blast_alternate.png"),
            2
         )
      );
      registerRender(EntityEffigyEffect.class, manager -> new RenderEffigyEffect(manager));
      registerRender(EntityEidolonMist.class, manager -> new RenderEidolonMist(manager));
      registerRender(EntityWormholePortal.class, manager -> new RenderWormholePortal(manager));
      registerRender(EntityPlasmaSlicer.class, manager -> new RenderPlasmaSlicer(manager));
      registerRender(EntityAvengerLightning.class, manager -> new RenderAvengerLightning(manager));
      registerRender(EntityChainOfVenomsAttack.class, manager -> new RenderChainOfVenomsAttack(manager));
      registerRender(EntityVoltaicIonizerAttack.class, manager -> new RenderVoltaicIonizerAttack(manager));
      registerRender(EntitySelectorAttack.class, manager -> new RenderSelectorAttack(manager));
      registerRender(EntityBarulChain.class, manager -> new RenderBarulChain(manager));
      registerRender(EntityTormentorChain.class, manager -> new RenderTormentorChain(manager));
      registerRender(EntityDuskerQueenWeb.class, manager -> new RenderDuskerQueenWeb(manager));
      registerRender(EntityPortalEffect.class, manager -> new RenderPortalEffect(manager));
      registerRender(EntityScreamerPortalEffect.class, manager -> new RenderScreamerPortalEffect(manager));
      registerRender(EntityPicklePortal.class, manager -> new RenderPicklePortal(manager));
      registerRender(EntityBossPortalEffect.class, manager -> new RenderBossPortalEffect(manager));
      registerRender(EntityCryoBeamEffect.class, manager -> new RenderCryoBeamEffect(manager));
      registerRender(EntityDebtCollectorEffect.class, manager -> new RenderDebtCollectorEffect(manager));
      registerRender(EntityForbiddenBrand.class, manager -> new RenderForbiddenBrand(manager));
      registerRender(
         EntityMicroRocket.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/micro_rocket.png"))
      );
      registerRender(
         EntityDeathShot.class, manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/death_shot.png"))
      );
      registerRender(
         EntityCrabulonProjectile.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/crabulon_projectile.png"))
      );
      registerRender(EntityMultiverseGhost.class, RenderMultiverseGhost::new);
      registerRender(EntityRisingPhantom.class, RenderRisingPhantom::new);
      registerRender(EntityLostBlade.class, RenderLostBlade::new);
      registerRender(EntityAbyssalCrabulon.class, RenderAbyssalCrabulon::new);
      registerRender(
         EntitySoundwaveBullet.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            1.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/echo_attack_white.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/echo_attack_red.png"),
            3
         )
      );
      registerRender(
         EntityLeviathanTracer.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/leviathan_tracer.png"))
      );
      registerRender(
         EntityLeviathanTeslaOrb.class,
         manager -> new RenderInfinityThrowable(manager, 3.0F, new ResourceLocation("lostinfinity", "textures/projectiles/leviathan_tesla.png"))
      );
      registerRender(EntityLeviathanBreath.class, RenderLeviathanBreath::new);
      registerRender(EntityGalaxyDragonFireball.class, RenderGalaxyDragonFireball::new);
      registerRender(EntityWhirlpool.class, manager -> new RenderWhirlpool(manager));
      registerRender(EntityNuclearExplosion.class, RenderNuclearExplosion::new);
      registerRender(EntityAuraOfAllegiance.class, RenderAuraOfAllegiance::new);
      registerRender(EntitySupplyTrader.class, RenderSupplyTrader::new);
      registerRender(EntityJetMount.class, RenderJetMount::new);
      registerRender(
         EntityEmberShot.class,
         manager -> new RenderAlternatingThrowable(
            manager,
            1.0F,
            new ResourceLocation("lostinfinity", "textures/projectiles/embershot.png"),
            new ResourceLocation("lostinfinity", "textures/projectiles/embershot_alternate.png")
         )
      );
      registerRender(
         EntityCreepingVineArrow.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/creeping_vine_arrow.png"))
      );
      registerRender(
         EntityCreepingVinePod.class,
         manager -> new RenderInfinityThrowable(manager, 1.0F, new ResourceLocation("lostinfinity", "textures/projectiles/creeping_vine_pod.png"))
      );
      registerRender(
         EntityAndromedaChaser.class,
         manager -> new RenderInfinityThrowable(manager, 7.0F, new ResourceLocation("lostinfinity", "textures/projectiles/andromeda_chaser.png"))
      );
      registerRender(EntityBombDrone.class, RenderBombDrone::new);
      registerRender(EntityPlayerLimb.class, RenderPlayerLimb::new);
      registerRender(EntityCthulhu.class, RenderCthulhu::new);
      registerRender(EntityCthulhuTurret.class, RenderCthulhuTurret::new);
      registerRender(
         EntityCthulhuTurretBullet.class,
         manager -> new RenderInfinityThrowable(manager, new ResourceLocation("lostinfinity", "textures/projectiles/cthulhu/turret_bullet.png"))
      );
      registerRender(
         EntityCthulhuMissile.class,
         manager -> new RenderSpecialArrow(manager, new ResourceLocation("lostinfinity", "textures/projectiles/cthulhu/missile.png"))
      );
      registerRender(
         EntityCthulhuMeteor.class,
         manager -> new RenderInfinityThrowable(manager, 30.0F, new ResourceLocation("lostinfinity", "textures/projectiles/cthulhu/meteor.png"), true)
      );
      registerRender(EntityCthulhuTentacle.class, RenderCthulhuTentacle::new);
      registerRender(EntityCthulhuBeam.class, RenderCthulhuBeam::new);
      registerRender(EntityCthulhuRift.class, RenderCthulhuRift::new);
      registerRender(EntityCthulhuBlackHole.class, RenderCthulhuBlackHole::new);
      registerRender(EntityCthulhuHealingOrb.class, RenderCthulhuHealingOrb::new);
      registerRender(EntityCelestialStatue.class, RenderCelestialStatue::new);
      registerRender(EntityCthulhuSpear.class, RenderCthulhuSpear::new);
      registerRender(EntityCthulhuPart.class, RenderCthulhuPart::new);
      registerRender(EntityCthulhuDeathFX.class, RenderCthulhuDeathFX::new);
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityLightEmitter.class, new RenderLightBeamEffect());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityNicroniumInfuser.class, new RenderNicroniumInfuserEffect());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityPortalNode.class, new RenderPortalNodeEffect());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityPortalNexus.class, new RenderPortalNexus());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityVoidVacuum.class, new RenderVoidVacuum());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityTeslaTower.class, new RenderTeslaTower());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityEternalBeacon.class, new RenderEternalBeacon());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityCthulhuSpawner.class, new RenderCthulhuSpawner());
      ClientRegistry.bindTileEntitySpecialRenderer(TileEntityKillerVine.class, new RenderKillerVine());
   }
}
