package xol.lostinfinity.client.screen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xol.lostinfinity.init.PotionInit;

public class DistortionCover {
   Minecraft mc = Minecraft.getMinecraft();
   private float distortionAlpha = 0.0F;

   @SubscribeEvent
   public void onRender(Post event) {
      if (event.getType() == ElementType.HELMET) {
         this.onTickRender();
      }
   }

   private void onTickRender() {
      if (this.mc.currentScreen == null) {
         if (this.mc.player.isPotionActive(PotionInit.DISTORTION)) {
            GlStateManager.enableBlend();
            GlStateManager.blendFunc(770, 771);
            int level = this.mc.player.getActivePotionEffect(PotionInit.DISTORTION).getAmplifier();
            this.mc.getTextureManager().bindTexture(this.getResourceFromLevel(level));
            ScaledResolution res = new ScaledResolution(this.mc);
            Tessellator tess = Tessellator.getInstance();
            BufferBuilder buff = tess.getBuffer();
            int ticksExisted = this.mc.player.ticksExisted;
            int remainingDuration = this.mc.player.getActivePotionEffect(PotionInit.DISTORTION).getDuration();
            if (remainingDuration * 0.05F <= this.distortionAlpha) {
               this.distortionAlpha -= 0.05F;
            } else if (this.distortionAlpha < 0.95F) {
               this.distortionAlpha += 0.05F;
            }

            GlStateManager.pushAttrib();
            GlStateManager.color(1.0F, 0.75F + 0.25F * MathHelper.sin(ticksExisted * 0.1F), 1.0F, this.distortionAlpha);
            buff.begin(7, DefaultVertexFormats.POSITION_TEX_NORMAL);
            buff.pos(0.0, res.getScaledHeight_double(), -90.0).tex(0.0, 1.0).normal(0.0F, 1.0F, 0.0F).endVertex();
            buff.pos(res.getScaledWidth_double(), res.getScaledHeight_double(), -90.0).tex(1.0, 1.0).normal(0.0F, 1.0F, 0.0F).endVertex();
            buff.pos(res.getScaledWidth_double(), 0.0, -90.0).tex(1.0, 0.0).normal(0.0F, 1.0F, 0.0F).endVertex();
            buff.pos(0.0, 0.0, -90.0).tex(0.0, 0.0).normal(0.0F, 1.0F, 0.0F).endVertex();
            tess.draw();
            GlStateManager.disableBlend();
            GlStateManager.depthMask(true);
            GlStateManager.popAttrib();
         } else {
            this.distortionAlpha = 0.0F;
         }
      }
   }

   private ResourceLocation getResourceFromLevel(int i) {
      return i == 0
         ? new ResourceLocation("lostinfinity", "textures/gui/distortion/distortion_0.png")
         : new ResourceLocation("lostinfinity", "textures/gui/distortion/distortion_1.png");
   }
}
