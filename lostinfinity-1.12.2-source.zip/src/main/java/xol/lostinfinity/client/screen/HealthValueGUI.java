package xol.lostinfinity.client.screen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xol.lostinfinity.util.ConfigurationHandler;

public class HealthValueGUI {
   private int tick_count = 0;
   private int diffclr = 0;
   Minecraft mc = Minecraft.getMinecraft();

   @SubscribeEvent
   public void onRender(Post event) {
      if (event.getType() == ElementType.ALL) {
         this.onTickRender();
         this.tick_count++;
         if (this.tick_count == 100) {
            this.tick_count = 0;
         }
      }
   }

   private void onTickRender() {
      if (this.mc.currentScreen == null) {
         GlStateManager.color(1.0F, 1.0F, 1.0F);
         GuiIngame gig = this.mc.ingameGUI;
         ScaledResolution scaledresolution = new ScaledResolution(this.mc);
         int i = scaledresolution.getScaledWidth();
         int k = scaledresolution.getScaledHeight();
         this.mc.getTextureManager().bindTexture(new ResourceLocation("lostinfinity", "textures/gui/healthicon.png"));
         int max_hp = Math.round(this.mc.player.getMaxHealth());
         int cur_hp = Math.round(this.mc.player.getHealth());
         String maxstr = this.convert_health(max_hp);
         String curstr = this.convert_health(cur_hp);
         String healthtxt = curstr + "/" + maxstr;
         if (this.tick_count % 5 == 0) {
            this.diffclr++;
            if (this.diffclr == healthtxt.length() * 4 + 4) {
               this.diffclr = 0;
            }
         }

         String lenstr = healthtxt.replace(".", "");
         int width = lenstr.length() * 9;
         int x = (scaledresolution.getScaledWidth() / 2 - 91) / 2 - width / 2 + ConfigurationHandler.health_x;
         int y = scaledresolution.getScaledHeight() - 13 + ConfigurationHandler.health_y;
         int hsep = 0;

         for (int ind = 0; ind < healthtxt.length(); ind++) {
            char c = healthtxt.charAt(ind);
            int sep = this.getFontSprFromCh(c);
            gig.drawTexturedModalRect(x + hsep, y, sep, Math.floorDiv(this.diffclr, 4) != ind ? 0 : 9 * (this.diffclr % 4), 9, 9);
            if (c == '.') {
               hsep += 3;
            } else {
               hsep += 9;
            }
         }

         gig.drawTexturedModalRect(x - 11, y, 0, 0, 9, 9);
      }
   }

   private String convert_health(int hNum) {
      String retstr;
      if (hNum > 1000) {
         float newVal = Math.round(hNum / 100.0F) / 10.0F;
         retstr = newVal + "k";
      } else {
         retstr = Integer.toString(hNum);
      }

      return retstr;
   }

   private int getFontSprFromCh(char s) {
      if (s != '.' && s != 'k' && s != '/') {
         return 10 + Character.getNumericValue(s) * 9;
      } else {
         switch (s) {
            case '.':
               return 118;
            case '/':
               return 109;
            case 'k':
               return 100;
            default:
               return 100;
         }
      }
   }
}
