package xol.lostinfinity.client.screen;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngame;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Post;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhu;

public class CthulhuBossBar {
   private int tick_count = 0;
   private int ticks = 0;
   private static final int totalNameWidth = 114;
   private static final int animationTime = 300;
   Minecraft mc = Minecraft.getMinecraft();

   @SubscribeEvent
   public void onRender(Post event) {
      if (event.getType() == ElementType.ALL) {
         this.onTickRender();
         this.tick_count++;
         if (this.tick_count == 100) {
            this.tick_count = 0;
         }
      }
   }

   private void onTickRender() {
      if (this.mc.currentScreen == null) {
         this.ticks++;
         EntityCthulhu cthulhu = null;

         for (Entity entity : this.mc.world.loadedEntityList) {
            if (entity instanceof EntityCthulhu) {
               cthulhu = (EntityCthulhu)entity;
               break;
            }
         }

         if (cthulhu == null) {
            return;
         }

         GlStateManager.color(1.0F, 1.0F, 1.0F);
         GuiIngame gig = this.mc.ingameGUI;
         ScaledResolution scaledresolution = new ScaledResolution(this.mc);
         this.mc.getTextureManager().bindTexture(new ResourceLocation("lostinfinity", "textures/gui/boss_hp_bar.png"));
         int max = cthulhu.numberOfLives();
         int cur = cthulhu.remainingLives();
         int parts = (int)((double)(cur * 160) / max);
         int x = scaledresolution.getScaledWidth() / 2 - 84;
         int y = (int)(scaledresolution.getScaledHeight() / 50.0);
         gig.drawTexturedModalRect(x, y, 0, 0, 167, 25);
         gig.drawTexturedModalRect(x + 4, y + 16, 0, 28, parts, 5);
         int width = 114;
         int offsetX = 0;
         int mod = this.ticks % 300;
         if (mod < 150) {
            width = (int)(114.0 * (mod * 2 / 300.0));
         } else {
            int k = mod - 150;
            width = (int)(114.0 * ((300 - k * 2) / 300.0));
            offsetX = (int)(114.0 * (k * 2 / 300.0));
         }

         gig.drawTexturedModalRect(x + 27 + offsetX, y + 2, offsetX, 36, width, 9);
      }
   }
}
