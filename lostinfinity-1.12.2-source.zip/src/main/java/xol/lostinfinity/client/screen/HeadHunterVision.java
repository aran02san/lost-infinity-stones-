package xol.lostinfinity.client.screen;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.util.math.LMath;

public class HeadHunterVision {
   public static final Map<UUID, Vec3d> oorPlayer = new ConcurrentHashMap<>();
   private static final ResourceLocation BULLSEYE = new ResourceLocation("lostinfinity:textures/gui/bullseye.png");
   private static final int DISTANCE = 160000;
   private final Minecraft mc = Minecraft.getMinecraft();

   @SubscribeEvent
   public void onPostRender(RenderWorldLastEvent event) {
      if (this.mc.player.getHeldItem(EnumHand.MAIN_HAND).getItem() != ItemInit.headHunter
         && this.mc.player.getHeldItem(EnumHand.OFF_HAND).getItem() != ItemInit.headHunter) {
         oorPlayer.clear();
      } else {
         Set<UUID> rendered = new HashSet<>();

         for (EntityPlayer player : this.mc.world.playerEntities) {
            if (player != this.mc.player) {
               double dist = player.getPositionVector().squareDistanceTo(this.mc.player.getPositionVector());
               if (dist <= 160000.0) {
                  this.onTickRender(player, dist);
                  rendered.add(player.getUniqueID());
               }
            }
         }

         if (this.mc.getConnection() == null) {
            return;
         }

         for (UUID uuid : oorPlayer.keySet()) {
            if (!rendered.contains(uuid)) {
               NetworkPlayerInfo info = this.mc.getConnection().getPlayerInfo(uuid);
               if (info == null) {
                  oorPlayer.remove(uuid);
               } else {
                  Vec3d pos = oorPlayer.get(uuid);
                  double dist = this.mc.player.getPositionVector().squareDistanceTo(pos);
                  if (dist <= 160000.0) {
                     this.onTickRender(info.getLocationSkin(), pos.x, pos.y, pos.z, dist);
                  }
               }
            }
         }
      }
   }

   private void onTickRender(EntityPlayer other, double dist) {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      double partialTicks = this.mc.getRenderPartialTicks();
      double dX = MathHelper.clampedLerp(other.lastTickPosX, other.posX, partialTicks);
      double dY = MathHelper.clampedLerp(other.lastTickPosY, other.posY, partialTicks);
      double dZ = MathHelper.clampedLerp(other.lastTickPosZ, other.posZ, partialTicks);
      this.onTickRender(((AbstractClientPlayer)other).getLocationSkin(), dX, dY, dZ, dist);
   }

   private void onTickRender(ResourceLocation skin, double dX, double dY, double dZ, double dist) {
      GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
      double partialTicks = this.mc.getRenderPartialTicks();
      EntityPlayer camera = this.mc.player;
      double cX = MathHelper.clampedLerp(camera.lastTickPosX, camera.posX, partialTicks);
      double cY = MathHelper.clampedLerp(camera.lastTickPosY, camera.posY, partialTicks);
      double cZ = MathHelper.clampedLerp(camera.lastTickPosZ, camera.posZ, partialTicks);
      double yaw = LMath.degreeLerp(camera.prevRotationYawHead, camera.rotationYawHead, partialTicks);
      double pitch = LMath.degreeLerp(camera.prevRotationPitch, camera.rotationPitch, partialTicks);
      Vec3d normalized = LMath.fastNormalize(new Vec3d(dX - cX, dY - cY, dZ - cZ)).scale(5.0);
      double r = MathHelper.clampedLerp(0.5, 1.0, 1.0 - dist / 160000.0);
      this.initialize(normalized.x, normalized.y + camera.getEyeHeight(), normalized.z, (float)yaw, (float)pitch);
      if (skin != null) {
         this.drawPlayerFace(skin, 0.5 * r, 0.5 * r);
      }

      this.drawBullseye(0.5 * r, 0.5 * r, r);
      this.cleanup();
   }

   private void initialize(double x, double y, double z, float cameraYaw, float cameraPitch) {
      GlStateManager.pushMatrix();
      GlStateManager.translate(x, y, z);
      GlStateManager.rotate(-cameraYaw, 0.0F, 1.0F, 0.0F);
      GlStateManager.rotate(cameraPitch, 1.0F, 0.0F, 0.0F);
      GlStateManager.disableDepth();
      RenderHelper.disableStandardItemLighting();
   }

   private void cleanup() {
      RenderHelper.enableStandardItemLighting();
      GlStateManager.enableDepth();
      GlStateManager.popMatrix();
   }

   private void drawPlayerFace(ResourceLocation playerSkin, double width, double height) {
      float widthScale = 0.015625F;
      float heightScale = 0.015625F;
      double growX = 0.0625 * width;
      double growY = 0.0625 * height;
      this.mc.getTextureManager().bindTexture(playerSkin);
      Tessellator tessellator = Tessellator.getInstance();
      BufferBuilder bufferbuilder = tessellator.getBuffer();
      bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
      bufferbuilder.pos(-width * 0.5, height * 0.5, 0.0).tex(16.0F * widthScale, 8.0F * heightScale).endVertex();
      bufferbuilder.pos(width * 0.5, height * 0.5, 0.0).tex(8.0F * widthScale, 8.0F * heightScale).endVertex();
      bufferbuilder.pos(width * 0.5, -height * 0.5, 0.0).tex(8.0F * widthScale, 16.0F * heightScale).endVertex();
      bufferbuilder.pos(-width * 0.5, -height * 0.5, 0.0).tex(16.0F * widthScale, 16.0F * heightScale).endVertex();
      tessellator.draw();
      bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
      bufferbuilder.pos(-width * 0.5 - growX, height * 0.5 + growY, 0.0).tex(48.0F * widthScale, 8.0F * heightScale).endVertex();
      bufferbuilder.pos(width * 0.5 + growX, height * 0.5 + growY, 0.0).tex(40.0F * widthScale, 8.0F * heightScale).endVertex();
      bufferbuilder.pos(width * 0.5 + growX, -height * 0.5 - growY, 0.0).tex(40.0F * widthScale, 16.0F * heightScale).endVertex();
      bufferbuilder.pos(-width * 0.5 - growX, -height * 0.5 - growY, 0.0).tex(48.0F * widthScale, 16.0F * heightScale).endVertex();
      tessellator.draw();
   }

   private void drawBullseye(double width, double height, double size) {
      this.mc.getTextureManager().bindTexture(BULLSEYE);
      Tessellator tessellator = Tessellator.getInstance();
      BufferBuilder bufferbuilder = tessellator.getBuffer();
      double growX = 0.0625 * width + 0.4 * size;
      double growY = 0.0625 * height + 0.4 * size;
      bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
      bufferbuilder.pos(-width * 0.5 - growX, height * 0.5 + growY, 0.0).tex(1.0, 0.0).endVertex();
      bufferbuilder.pos(width * 0.5 + growX, height * 0.5 + growY, 0.0).tex(0.0, 0.0).endVertex();
      bufferbuilder.pos(width * 0.5 + growX, -height * 0.5 - growY, 0.0).tex(0.0, 1.0).endVertex();
      bufferbuilder.pos(-width * 0.5 - growX, -height * 0.5 - growY, 0.0).tex(1.0, 1.0).endVertex();
      tessellator.draw();
   }
}
