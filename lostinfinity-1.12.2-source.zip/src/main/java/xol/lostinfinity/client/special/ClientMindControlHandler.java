package xol.lostinfinity.client.special;

import net.minecraft.util.EnumActionResult;
import net.minecraft.util.MovementInput;
import net.minecraftforge.client.event.InputUpdateEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ClientDisconnectionFromServerEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.common.packets.PacketSendInput;
import xol.lostinfinity.common.special.CommonMindControlHandler;

@SideOnly(Side.CLIENT)
public class ClientMindControlHandler {
   public static ClientMindControlHandler INSTANCE;
   public CommonMindControlHandler.State state = CommonMindControlHandler.State.NONE;
   public float lastForward = 0.0F;
   public float lastStrafe = 0.0F;
   public boolean lastJump = false;
   public boolean lastSneak = false;

   public ClientMindControlHandler() {
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onClientDisconnect(ClientDisconnectionFromServerEvent event) {
      this.state = CommonMindControlHandler.State.NONE;
   }

   @SubscribeEvent
   public void onRightClick(PlayerInteractEvent event) {
      if (this.state == CommonMindControlHandler.State.CONTROLLED) {
         event.setCancellationResult(EnumActionResult.PASS);
         if (event.isCancelable()) {
            event.setCanceled(true);
         }
      }
   }

   @SubscribeEvent
   public void onInputEvent(InputUpdateEvent event) {
      switch (this.state) {
         case CONTROLLED: {
            MovementInput input = event.getMovementInput();
            this.forceInput(input);
            break;
         }
         case CONTROLLING: {
            MovementInput input = event.getMovementInput();
            if (this.lastForward == input.moveForward
               && this.lastStrafe == input.moveStrafe
               && this.lastJump == input.jump
               && this.lastSneak == input.sneak) {
               this.voidInput(input);
            } else {
               this.recordInput(input);
               this.voidInput(input);
            }
         }
      }
   }

   private void recordInput(MovementInput input) {
      this.lastForward = input.moveForward;
      this.lastStrafe = input.moveStrafe;
      this.lastJump = input.jump;
      this.lastSneak = input.sneak;
      lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketSendInput(this.lastForward, this.lastStrafe, this.lastJump, this.lastSneak));
   }

   private void voidInput(MovementInput input) {
      input.moveForward = 0.0F;
      input.moveStrafe = 0.0F;
      input.jump = false;
      input.sneak = false;
   }

   private void forceInput(MovementInput input) {
      input.moveForward = this.lastForward;
      input.moveStrafe = this.lastStrafe;
      input.jump = this.lastJump;
      input.sneak = this.lastSneak;
   }
}
