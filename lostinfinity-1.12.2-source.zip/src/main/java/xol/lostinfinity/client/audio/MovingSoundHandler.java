package xol.lostinfinity.client.audio;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class MovingSoundHandler {
   public static final MovingSoundHandler instance = new MovingSoundHandler();
   private final Map<Integer, UniversalMovingSound> activeSounds = Maps.newConcurrentMap();

   public void trackSound(int sourceId, UniversalMovingSound sound) {
      if (!this.activeSounds.containsKey(sourceId)) {
         Minecraft.getMinecraft().getSoundHandler().playSound(sound);
         this.activeSounds.put(sourceId, sound);
      }
   }

   public void stopSound(int sourceId) {
      UniversalMovingSound sound = this.activeSounds.remove(sourceId);
      if (sound != null) {
         sound.setDonePlaying(true);
      }
   }
}
