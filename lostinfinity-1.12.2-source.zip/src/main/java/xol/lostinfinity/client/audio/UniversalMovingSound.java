package xol.lostinfinity.client.audio;

import net.minecraft.client.audio.MovingSound;
import net.minecraft.client.audio.ISound.AttenuationType;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import xol.lostinfinity.item.classify.IMovingSoundSource;

public class UniversalMovingSound extends MovingSound {
   private final IMovingSoundSource.Special special;

   public UniversalMovingSound(SoundEvent soundIn, SoundCategory categoryIn, IMovingSoundSource.Special special, float volume, float pitch) {
      super(soundIn, categoryIn);
      this.special = special;
      this.volume = volume;
      this.pitch = pitch;
      special.onInit(this);
   }

   public void update() {
      this.special.onUpdate(this);
   }

   public void setAttenuationType(AttenuationType type) {
      this.attenuationType = type;
   }

   public void setRepeat(boolean flag) {
      this.repeat = flag;
   }

   public void setRepeatDelay(int value) {
      this.repeatDelay = value;
   }

   public void setVolume(float value) {
      this.volume = value;
   }

   public void setPitch(float value) {
      this.pitch = value;
   }

   public void setXPosF(float value) {
      this.xPosF = value;
   }

   public void setYPosF(float value) {
      this.yPosF = value;
   }

   public void setZPosF(float value) {
      this.zPosF = value;
   }

   public void setDonePlaying(boolean flag) {
      this.donePlaying = flag;
   }

   public boolean canRepeat() {
      if (!super.canRepeat()) {
         this.special.onDone(this);
         return false;
      } else {
         return true;
      }
   }
}
