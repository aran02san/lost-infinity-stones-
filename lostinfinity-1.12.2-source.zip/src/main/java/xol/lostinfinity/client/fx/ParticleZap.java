package xol.lostinfinity.client.fx;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;

public class ParticleZap extends LostParticle {
   private static final Random RANDOM = new Random();

   protected ParticleZap(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeed, double zSpeedIn) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, 0.5 - RANDOM.nextDouble(), ySpeed, 0.5 - RANDOM.nextDouble());
      this.motionY *= 0.2F;
      if (xSpeedIn == 0.0 && zSpeedIn == 0.0) {
         this.motionX *= 0.1F;
         this.motionZ *= 0.1F;
      }

      this.scale = RANDOM.nextFloat();
      this.particleMaxAge = (int)(14.0 / (Math.random() * 0.8 + 0.2));
      this.setParticleTexture(ParticleInit.ZAP_SPRITE);
   }

   public ParticleZap setParticleGravity(double motionY) {
      this.motionY = motionY;
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      this.updatePos();
      this.updateAngle();
      if (this.particleMaxAge - this.particleAge < 8) {
         if (this.scale > 0.5) {
            this.prevScale = this.scale;
            this.scale = (float)(this.scale - 0.5);
         }
      } else if (this.scale < 3.0F) {
         this.prevScale = this.scale;
         this.scale = (float)(this.scale + 0.2);
      } else {
         this.prevScale = this.scale;
      }

      if (this.particleAge++ >= this.particleMaxAge) {
         this.setExpired();
      }

      this.motionY += 0.002;
      this.move(this.motionX, this.motionY, this.motionZ);
      if (this.posY == this.prevPosY) {
         this.motionX *= 1.1;
         this.motionZ *= 1.1;
      }

      this.motionX *= 0.96F;
      this.motionY *= 0.96F;
      this.motionZ *= 0.96F;
      if (this.onGround) {
         this.motionX *= 0.7F;
         this.motionZ *= 0.7F;
      }
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class Factory implements IParticleFactory {
      @Nullable
      public Particle createParticle(int particleID, World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... p_178902_15_) {
         return new ParticleZap(world, x, y, z, xSpeed, ySpeed, zSpeed);
      }
   }
}
