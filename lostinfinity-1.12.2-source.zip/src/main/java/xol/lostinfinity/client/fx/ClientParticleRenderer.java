package xol.lostinfinity.client.fx;

import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;
import xol.lostinfinity.util.data.CustomParticleConfig;

@SideOnly(Side.CLIENT)
public class ClientParticleRenderer {
   public static void renderSimple(int id, int extra, double posX, double posY, double posZ) {
      World world = Minecraft.getMinecraft().player.world;
      Random rand = world.rand;
      switch (id) {
         case 0:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.VENOM, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }

            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.VENOM_RING, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 1:
            for (int ixx = 0; ixx < 4; ixx++) {
               world.spawnParticle(ParticleInit.PLASMA_EXPLOSION, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[]{2});
            }
            break;
         case 2:
            for (int i = 0; i < 5 + extra; i++) {
               world.spawnParticle(
                  EnumParticleTypes.DRAGON_BREATH,
                  true,
                  posX + getROD(rand, 1.0),
                  posY + 0.75,
                  posZ + getROD(rand, 1.0),
                  getROD(rand, 1.0),
                  Math.abs(getROD(rand, 1.0)),
                  getROD(rand, 1.0),
                  new int[0]
               );
            }

            if (extra != 0) {
               world.spawnParticle(EnumParticleTypes.EXPLOSION_HUGE, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            }
            break;
         case 3:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.QUANTUM_MARK, true, posX + getROD(rand, 2.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 2.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 4:
            for (int ixx = 0; ixx < 3; ixx++) {
               world.spawnParticle(
                  ParticleInit.ATTRACT_FIELD, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 5:
            for (int ixx = 0; ixx < 3; ixx++) {
               world.spawnParticle(
                  ParticleInit.REPEL_FIELD, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 6:
            for (int ixx = 0; ixx < 2; ixx++) {
               world.spawnParticle(
                  ParticleInit.SLAM, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 7:
            world.spawnParticle(ParticleInit.WARP, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            break;
         case 8:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.GOO_RING, true, posX + getROD(rand, 2.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 2.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 9:
            world.spawnParticle(ParticleInit.EXPLOSION, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            break;
         case 10:
            for (int ixx = 0; ixx < 3; ixx++) {
               world.spawnParticle(
                  ParticleInit.EXPLOSION_RING, true, posX + getROD(rand, 2.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 2.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 11:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.ZAP, true, posX + getROD(rand, 3.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 3.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 12:
            world.spawnParticle(ParticleInit.DARK_MAGIC, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            world.spawnParticle(ParticleInit.PLAGUE, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            break;
         case 13:
            for (int ixx = 0; ixx < 3; ixx++) {
               world.spawnParticle(
                  ParticleInit.GLOOM_BURST, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 14:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.LIGHT_FLASH, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 15:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.DARK_FLASH, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 16:
            for (int ixx = 0; ixx < 1 + extra; ixx++) {
               world.spawnParticle(
                  ParticleInit.FLAME_SMALL,
                  true,
                  posX + getROD(rand, 1.0),
                  posY,
                  posZ + getROD(rand, 1.0),
                  0.3F * getROD(rand, 1.0),
                  0.0,
                  0.3F * getROD(rand, 1.0),
                  new int[0]
               );
            }
            break;
         case 17:
            for (int ixx = 0; ixx < 1 + 2 * extra; ixx++) {
               world.spawnParticle(
                  ParticleInit.FLAME_MEDIUM,
                  true,
                  posX + getROD(rand, 1.0),
                  posY,
                  posZ + getROD(rand, 1.0),
                  0.3F * getROD(rand, 1.0),
                  0.0,
                  0.3F * getROD(rand, 1.0),
                  new int[0]
               );
            }
            break;
         case 18:
            for (int ixx = 0; ixx < 1 + 4 * extra; ixx++) {
               world.spawnParticle(
                  ParticleInit.FLAME_LARGE,
                  true,
                  posX + getROD(rand, 1.0),
                  posY,
                  posZ + getROD(rand, 1.0),
                  0.3F * getROD(rand, 1.0),
                  0.0,
                  0.3F * getROD(rand, 1.0),
                  new int[0]
               );
            }
            break;
         case 19:
            for (int ixx = 0; ixx < 8; ixx++) {
               world.spawnParticle(
                  ParticleInit.FIREGOO,
                  posX + getROD(rand, 1.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 1.0),
                  getROD(rand, 1.0),
                  getROD(rand, 1.0),
                  getROD(rand, 1.0),
                  new int[0]
               );
            }
            break;
         case 20:
            world.spawnParticle(ParticleInit.BOMBER_EXPLOSION, true, posX + 0.5, posY, posZ + 0.5, 0.0, 0.0, 0.0, new int[0]);
            break;
         case 21:
            world.spawnParticle(ParticleInit.GLOMITE_WARP, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            break;
         case 22:
            for (int ixx = 0; ixx < 8; ixx++) {
               world.spawnParticle(
                  ParticleInit.SPACE_MAGIC, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 23:
            world.spawnParticle(ParticleInit.POWER_FIELD, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            break;
         case 24:
            world.spawnParticle(ParticleInit.POWER_LOSS, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            break;
         case 25:
            for (int ixx = 0; ixx < 8; ixx++) {
               world.spawnParticle(ParticleInit.PLAGUE, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            }
            break;
         case 26:
            for (int ixx = 0; ixx < 14; ixx++) {
               world.spawnParticle(
                  ParticleInit.ANCIENT_SPELL,
                  true,
                  posX + getROD(rand, 1.0),
                  posY,
                  posZ + getROD(rand, 1.0),
                  0.3F * getROD(rand, 1.0),
                  0.0,
                  0.3F * getROD(rand, 1.0),
                  new int[0]
               );
            }
            break;
         case 27:
            for (int ixx = 0; ixx < 8; ixx++) {
               world.spawnParticle(
                  ParticleInit.CLAW_MARKS, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 28:
            for (int ixx = 0; ixx < 3; ixx++) {
               world.spawnParticle(
                  rand.nextBoolean() ? ParticleInit.ELECTRIC_EXPLOSION_BLUE : ParticleInit.ELECTRIC_EXPLOSION_YELLOW,
                  true,
                  posX + getROD(rand, 2.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 2.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 29:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.CORRUPTION_MAGIC, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 30:
            for (int ixx = 0; ixx < 3; ixx++) {
               world.spawnParticle(ParticleInit.NATURE_RING, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
            }
            break;
         case 31:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.NATURE_MAGIC, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 32:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.CRYSTAL_MAGIC, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 33:
            for (int ixx = 0; ixx < 2; ixx++) {
               world.spawnParticle(
                  ParticleInit.VENOM, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }

            world.spawnParticle(
               ParticleInit.VENOM_RING, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
            );
            break;
         case 34:
            world.spawnParticle(
               ParticleInit.SHADOW_BLAST, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
            );
            break;
         case 35:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.POISON_BUBBLE, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 36:
            for (int ixx = 0; ixx < 12; ixx++) {
               world.spawnParticle(
                  ParticleInit.PURPLE_SKULL, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 37:
            for (int ixx = 0; ixx < 4; ixx++) {
               world.spawnParticle(
                  ParticleInit.BLIGHT_SPELL_GREEN,
                  true,
                  posX + getROD(rand, 4.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 4.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 38:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.DARK_MAGIC, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 39:
            world.spawnParticle(
               ParticleInit.BLUE_SKULL, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
            );
            break;
         case 40:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.ION_BLAST, true, posX + getROD(rand, 6.0), posY + getROD(rand, 4.0), posZ + getROD(rand, 6.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 41:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.NUCLEAR_BLAST, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 42:
            for (int ixx = 0; ixx < 10; ixx++) {
               world.spawnParticle(
                  ParticleInit.EXPLOSION, true, posX + getROD(rand, 8.0), posY + getROD(rand, 2.0), posZ + getROD(rand, 8.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 43:
            for (int ixx = 0; ixx < 8; ixx++) {
               world.spawnParticle(
                  ParticleInit.PLASMA_RIFT, true, posX + getROD(rand, 3.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 3.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 44:
            for (int ixx = 0; ixx < 20; ixx++) {
               world.spawnParticle(
                  ParticleInit.MURK, true, posX + getROD(rand, 5.0), posY + getROD(rand, 2.0), posZ + getROD(rand, 5.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 45:
            world.spawnParticle(
               ParticleInit.SPECTRAL, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
            );
            break;
         case 46:
            for (int ixx = 0; ixx < 5; ixx++) {
               switch (rand.nextInt(3)) {
                  case 0:
                     world.spawnParticle(
                        ParticleInit.PRISMATIC_EXPLOSION_TYPE1,
                        true,
                        posX + getROD(rand, 1.0),
                        posY + getROD(rand, 1.0),
                        posZ + getROD(rand, 1.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 1:
                     world.spawnParticle(
                        ParticleInit.PRISMATIC_EXPLOSION_TYPE2,
                        true,
                        posX + getROD(rand, 1.0),
                        posY + getROD(rand, 1.0),
                        posZ + getROD(rand, 1.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 2:
                     world.spawnParticle(
                        ParticleInit.PRISMATIC_EXPLOSION_TYPE3,
                        true,
                        posX + getROD(rand, 1.0),
                        posY + getROD(rand, 1.0),
                        posZ + getROD(rand, 1.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
               }
            }
            break;
         case 47:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.PRISMATIC_EXPLOSION_TYPE1,
                  true,
                  posX + getROD(rand, 1.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 1.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 48:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.PRISMATIC_EXPLOSION_TYPE2,
                  true,
                  posX + getROD(rand, 1.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 1.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 49:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.PRISMATIC_EXPLOSION_TYPE3,
                  true,
                  posX + getROD(rand, 1.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 1.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 50:
            for (int ixx = 0; ixx < 5; ixx++) {
               world.spawnParticle(
                  ParticleInit.EXPLOSION_RING_DARK,
                  true,
                  posX + getROD(rand, 1.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 1.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 51:
            for (int ix = 0; ix < 3; ix++) {
               if (rand.nextBoolean()) {
                  world.spawnParticle(
                     ParticleInit.EXPLOSION_BLUE, true, posX + getROD(rand, 5.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 5.0), 0.0, 0.0, 0.0, new int[0]
                  );
               } else {
                  world.spawnParticle(
                     ParticleInit.EXPLOSION_TEAL, true, posX + getROD(rand, 5.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 5.0), 0.0, 0.0, 0.0, new int[0]
                  );
               }
            }

            for (int ixx = 0; ixx < 7; ixx++) {
               world.spawnParticle(
                  ParticleInit.MURK, true, posX + getROD(rand, 10.0), posY + getROD(rand, 2.0), posZ + getROD(rand, 10.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 52:
            for (int ix = 0; ix < 2; ix++) {
               world.spawnParticle(
                  ParticleInit.CLAW_MARKS, true, posX + getROD(rand, 2.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 2.0), 0.0, 0.0, 0.0, new int[0]
               );
               world.spawnParticle(
                  ParticleInit.BLOOD_DROP, true, posX + getROD(rand, 2.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 2.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 53:
            for (int ix = 0; ix < 10; ix++) {
               world.spawnParticle(
                  ParticleInit.ION_BLAST, true, posX + getROD(rand, 6.0), posY + getROD(rand, 4.0), posZ + getROD(rand, 6.0), 0.0, 0.0, 0.0, new int[0]
               );
               world.spawnParticle(
                  ParticleInit.EXPLOSION_LAVENDER,
                  true,
                  posX + getROD(rand, 5.0),
                  posY + getROD(rand, 1.0),
                  posZ + getROD(rand, 5.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 54:
            for (int ixx = 0; ixx < 15; ixx++) {
               world.spawnParticle(
                  ParticleInit.POISON_EXPLOSION,
                  true,
                  posX + getROD(rand, 15.0),
                  posY + getROD(rand, 2.0),
                  posZ + getROD(rand, 15.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
         case 55:
            switch (rand.nextInt(4)) {
               case 0:
                  world.spawnParticle(
                     ParticleInit.COSMIC_EXPLOSION_TYPE1,
                     true,
                     posX + getROD(rand, 5.0),
                     posY + getROD(rand, 1.0),
                     posZ + getROD(rand, 5.0),
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
                  break;
               case 1:
                  world.spawnParticle(
                     ParticleInit.COSMIC_EXPLOSION_TYPE2,
                     true,
                     posX + getROD(rand, 5.0),
                     posY + getROD(rand, 1.0),
                     posZ + getROD(rand, 5.0),
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
                  break;
               case 2:
                  world.spawnParticle(
                     ParticleInit.COSMIC_EXPLOSION_TYPE3,
                     true,
                     posX + getROD(rand, 5.0),
                     posY + getROD(rand, 1.0),
                     posZ + getROD(rand, 5.0),
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
                  break;
               case 3:
                  world.spawnParticle(
                     ParticleInit.COSMIC_EXPLOSION_TYPE4,
                     true,
                     posX + getROD(rand, 5.0),
                     posY + getROD(rand, 1.0),
                     posZ + getROD(rand, 5.0),
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
            }

            for (int ix = 0; ix < 4; ix++) {
               switch (rand.nextInt(4)) {
                  case 0:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE1,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 1:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE2,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 2:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE3,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 3:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE4,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
               }
            }
            break;
         case 56:
            for (int ixx = 0; ixx < 4; ixx++) {
               world.spawnParticle(
                  ParticleInit.VENOM_RING, true, posX + getROD(rand, 15.0), posY + getROD(rand, 2.0), posZ + getROD(rand, 15.0), 0.0, 0.0, 0.0, new int[0]
               );
               world.spawnParticle(
                  ParticleInit.EXPLOSION_RING_DARK,
                  true,
                  posX + getROD(rand, 15.0),
                  posY + getROD(rand, 2.0),
                  posZ + getROD(rand, 15.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
         case 57:
            for (int ix = 0; ix < 5; ix++) {
               world.spawnParticle(
                  ParticleInit.MIASMA, true, posX + getROD(rand, 4.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 4.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
            break;
         case 58:
            if (rand.nextBoolean()) {
               for (int ix = 0; ix < 2; ix++) {
                  world.spawnParticle(ParticleInit.SUPERSONIC_BLUE, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
               }
            } else {
               for (int ix = 0; ix < 2; ix++) {
                  world.spawnParticle(ParticleInit.SUPERSONIC_RED, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);
               }
            }
            break;
         case 59:
            for (int i = 0; i < 15; i++) {
               if (rand.nextBoolean()) {
                  world.spawnParticle(
                     ParticleInit.EXPLOSION_RED,
                     true,
                     posX + getROD(rand, 25.0),
                     posY + getROD(rand, 4.0),
                     posZ + getROD(rand, 25.0),
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
               } else {
                  world.spawnParticle(
                     ParticleInit.EXPLOSION_ORANGE,
                     true,
                     posX + getROD(rand, 25.0),
                     posY + getROD(rand, 4.0),
                     posZ + getROD(rand, 25.0),
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
               }
            }
            break;
         case 60:
            world.spawnParticle(ParticleInit.POWER_FIELD, true, posX, posY, posZ, 0.0, 0.0, 0.0, new int[0]);

            for (int i = 0; i < 12; i++) {
               world.spawnParticle(
                  rand.nextBoolean() ? ParticleInit.EXPLOSION_BLUE : ParticleInit.EXPLOSION_LAVENDER,
                  true,
                  posX + getROD(rand, 18.0),
                  posY + getROD(rand, 2.0),
                  posZ + getROD(rand, 18.0),
                  0.0,
                  0.0,
                  0.0,
                  new int[0]
               );
            }
            break;
         case 61:
            for (int i = 0; i < 4 + extra; i++) {
               switch (rand.nextInt(4)) {
                  case 0:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE1,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 1:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE2,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 2:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE3,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
                     break;
                  case 3:
                     world.spawnParticle(
                        ParticleInit.BASIC_STAR_TYPE4,
                        true,
                        posX + getROD(rand, 5.0),
                        posY + getROD(rand, 3.0),
                        posZ + getROD(rand, 5.0),
                        0.0,
                        0.0,
                        0.0,
                        new int[0]
                     );
               }
            }
            break;
         case 62:
            for (int i = 0; i < 5; i++) {
               world.spawnParticle(
                  ParticleInit.LASER_FIZZLE, true, posX + getROD(rand, 1.0), posY + getROD(rand, 1.0), posZ + getROD(rand, 1.0), 0.0, 0.0, 0.0, new int[0]
               );
            }
      }
   }

   public static void renderComplex(CustomParticleConfig config) {
      World world = Minecraft.getMinecraft().player.world;
      Random rand = world.rand;
      if (config.particles.size() == 1) {
         renderInstance(world, config.origin, rand, config.particles.get(0));
      } else {
         int totalWeight = 0;

         for (CustomParticleConfig.Instance instance : config.particles) {
            totalWeight += instance.weight;
         }

         for (int i = 0; i < config.count; i++) {
            int landed = rand.nextInt(totalWeight);

            for (CustomParticleConfig.Instance instance : config.particles) {
               landed -= instance.weight;
               if (landed < 0) {
                  renderInstance(world, config.origin, rand, instance);
                  break;
               }
            }
         }
      }
   }

   private static void renderInstance(World world, Vec3d origin, Random rand, CustomParticleConfig.Instance instance) {
      Vec3d offset = instance.offset;
      Vec3d speed = instance.speed;
      Vec3d spread = instance.spread;
      Vec3d velSpread = instance.velSpread;

      for (int i = 0; i < instance.count; i++) {
         world.spawnParticle(
            instance.particleType,
            instance.ignoreRange,
            origin.x + offset.x + getROD(rand, spread.x),
            origin.y + offset.y + getROD(rand, spread.y),
            origin.z + offset.z + getROD(rand, spread.z),
            speed.x * getROD(rand, velSpread.x),
            speed.y * getROD(rand, velSpread.y),
            speed.z * getROD(rand, velSpread.z),
            instance.args
         );
      }
   }

   private static double getROD(Random rand, double multi) {
      return (-0.5 + rand.nextDouble()) * multi;
   }
}
