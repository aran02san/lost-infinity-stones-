package xol.lostinfinity.client.fx;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;

public class ParticleNatureRing extends LostParticle {
   private static final Random RANDOM = new Random();

   protected ParticleNatureRing(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeed, double zSpeedIn) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, 0.5 - RANDOM.nextDouble(), ySpeed, 0.5 - RANDOM.nextDouble());
      this.motionY *= 0.2F;
      if (xSpeedIn == 0.0 && zSpeedIn == 0.0) {
         this.motionX *= 0.0;
         this.motionZ *= 0.1F;
      }

      this.scale = 1.0F;
      this.particleMaxAge = (int)(7.0 / (this.rand.nextFloat() * 0.8 + 0.2)) + 7;
      this.growSpeed = (0.3F + this.rand.nextFloat() / 2.0F) * 9.0F;
      this.setParticleTexture(ParticleInit.NATURE_RING_SPRITE);
      this.canCollide = false;
   }

   public ParticleNatureRing setParticleGravity(double motionY) {
      this.motionY = motionY;
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      super.onUpdate();
      if (this.scale >= 40.0F) {
         this.particleAge = this.particleMaxAge;
      }

      if (this.particleAge++ >= this.particleMaxAge) {
         this.setExpired();
      }

      this.motionY += 0.002;
      this.move(this.motionX, this.motionY, this.motionZ);
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class Factory implements IParticleFactory {
      @Nullable
      public Particle createParticle(int particleID, World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... p_178902_15_) {
         return new ParticleNatureRing(world, x, y, z, xSpeed, ySpeed, zSpeed);
      }
   }
}
