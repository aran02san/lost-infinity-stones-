package xol.lostinfinity.client.fx;

import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ParticleBasic extends LostParticle {
   protected ParticleBasic(World worldIn, double xPos, double yPos, double zPos, double xSpeed, double ySpeed, double zSpeed) {
      super(worldIn, xPos, yPos, zPos, xSpeed, ySpeed, zSpeed);
      this.particleMaxAge = (int)(8.0 / (Math.random() * 0.8 + 0.2));
   }

   public ParticleBasic setTexture(TextureAtlasSprite sprite) {
      this.setParticleTexture(sprite);
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      super.onUpdate();
      if (this.particleAge++ >= this.particleMaxAge) {
         this.setExpired();
      }

      this.move(this.motionX, this.motionY, this.motionZ);
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class BaseParticleFactory implements IParticleFactory {
      public Particle createParticle(
         int particleID,
         World worldIn,
         double xCoordIn,
         double yCoordIn,
         double zCoordIn,
         double xSpeedIn,
         double ySpeedIn,
         double zSpeedIn,
         int... p_178902_15_
      ) {
         Particle particle = new ParticleBasic(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);
         particle.setMaxAge(20);
         return particle;
      }
   }
}
