package xol.lostinfinity.client.fx;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;

public class ParticlePlasmaExplosion extends LostParticle {
   private static final Random RANDOM = new Random();
   private int tickOffset = 0;

   protected ParticlePlasmaExplosion(
      World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeed, double ySpeed, double zSpeed, int multi_scl
   ) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, 0.5 - RANDOM.nextDouble(), ySpeed, 0.5 - RANDOM.nextDouble());
      this.particleAngle = 0.5F * this.rand.nextFloat() - 0.25F;
      this.scale = 10.0F + RANDOM.nextFloat() * 3.0F + multi_scl;
      this.particleMaxAge = 16;
      this.tickOffset = RANDOM.nextInt(3);
      this.setAlphaF(0.3F + this.rand.nextFloat() / 3.0F);
      this.particleBlue = 0.75F + (float)this.rand.nextGaussian() / 4.0F;
      this.particleRed = (float)this.rand.nextGaussian() / 2.0F;
      this.setParticleTexture(ParticleInit.PLASMA_EXPLOSION_SPRITE);
   }

   public ParticlePlasmaExplosion setParticleGravity(double motionY) {
      this.motionY = motionY;
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      super.onUpdate();
      if (this.particleAge++ >= this.particleMaxAge) {
         this.setExpired();
      }
   }

   @Override
   public void renderParticle(
      BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ
   ) {
      if ((entityIn.ticksExisted + this.tickOffset) % 2 == 0) {
         super.renderParticle(buffer, entityIn, partialTicks, rotationX, rotationZ, rotationYZ, rotationXY, rotationXZ);
      }
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class Factory implements IParticleFactory {
      @Nullable
      public Particle createParticle(int particleID, World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... args) {
         return new ParticlePlasmaExplosion(world, x, y, z, xSpeed, ySpeed, zSpeed, args[0]);
      }
   }
}
