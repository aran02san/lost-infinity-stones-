package xol.lostinfinity.client.fx;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public abstract class LostParticle extends Particle {
   protected float growSpeed;
   protected float rotateSpeed;
   protected float scale;
   protected float prevScale;

   public LostParticle(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeedIn, double zSpeedIn) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, xSpeedIn, ySpeedIn, zSpeedIn);
   }

   public void onUpdate() {
      this.updatePos();
      this.updateScale();
      this.updateAngle();
   }

   protected void updatePos() {
      this.prevPosX = this.posX;
      this.prevPosY = this.posY;
      this.prevPosZ = this.posZ;
   }

   protected void updateScale() {
      this.prevScale = this.scale;
      this.scale = this.scale + this.growSpeed;
   }

   protected void updateAngle() {
      this.prevParticleAngle = this.particleAngle;
      this.particleAngle = this.particleAngle + this.rotateSpeed;
   }

   public void renderParticle(
      BufferBuilder buffer, Entity entityIn, float partialTicks, float rotationX, float rotationZ, float rotationYZ, float rotationXY, float rotationXZ
   ) {
      this.particleScale = (float)MathHelper.clampedLerp(this.prevScale, this.scale, partialTicks);
      super.renderParticle(buffer, entityIn, partialTicks, rotationX, rotationZ, rotationYZ, rotationXY, rotationXZ);
   }
}
