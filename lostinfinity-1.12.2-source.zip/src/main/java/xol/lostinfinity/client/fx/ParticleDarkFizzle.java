package xol.lostinfinity.client.fx;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;

public class ParticleDarkFizzle extends LostParticle {
   private static final Random RANDOM = new Random();

   protected ParticleDarkFizzle(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeed, double zSpeedIn) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, 0.5 - RANDOM.nextDouble(), ySpeed, 0.5 - RANDOM.nextDouble());
      this.motionY *= 0.0;
      this.motionX *= 0.1F;
      this.motionZ *= 0.1F;
      this.scale = 4.5F + 2.0F * this.rand.nextFloat();
      this.particleAlpha = 0.0F;
      this.particleMaxAge = (int)(14.0 / (Math.random() * 0.8 + 0.2));
      this.setParticleTexture(ParticleInit.DARK_FIZZLE_SPRITE);
   }

   public ParticleDarkFizzle setParticleGravity(double motionY) {
      this.motionY = motionY;
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      super.onUpdate();
      if (this.particleAge < 20) {
         if (this.particleAlpha < 1.0F) {
            this.particleAlpha += 0.2F;
         }
      } else if (this.particleAlpha > 0.0F) {
         this.particleAlpha -= 0.1F;
      } else {
         this.setExpired();
      }

      this.particleAge++;
      this.move(this.motionX, this.motionY, this.motionZ);
      this.motionX *= 0.96F;
      this.motionY *= 0.96F;
      this.motionZ *= 0.96F;
      if (this.onGround) {
         this.motionX *= 0.7F;
         this.motionZ *= 0.7F;
      }
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class Factory implements IParticleFactory {
      @Nullable
      public Particle createParticle(int particleID, World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... p_178902_15_) {
         return new ParticleDarkFizzle(world, x, y, z, xSpeed, ySpeed, zSpeed);
      }
   }
}
