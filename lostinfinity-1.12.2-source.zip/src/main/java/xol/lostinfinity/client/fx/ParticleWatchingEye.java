package xol.lostinfinity.client.fx;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;

public class ParticleWatchingEye extends LostParticle {
   private static final Random RANDOM = new Random();

   protected ParticleWatchingEye(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeed, double ySpeed, double zSpeed) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, 0.5 - RANDOM.nextDouble(), ySpeed, 0.5 - RANDOM.nextDouble());
      this.motionY *= 0.2F;
      if (xSpeed == 0.0 && zSpeed == 0.0) {
         this.motionX *= 0.1F;
         this.motionZ *= 0.1F;
      }

      this.rotateSpeed = 0.0F;
      this.scale = RANDOM.nextFloat() * 0.5F;
      this.particleMaxAge = (int)(5.0 / (this.rand.nextFloat() * 0.8 + 0.2)) + 30;
      this.growSpeed = 0.1F;
      this.setParticleTexture(ParticleInit.WATCHING_EYE_SPRITE);
   }

   public ParticleWatchingEye setParticleGravity(double motionY) {
      this.motionY = motionY;
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      super.onUpdate();
      if (this.scale >= 40.0F) {
         this.particleAge = this.particleMaxAge;
      }

      if (this.particleAge++ >= this.particleMaxAge) {
         this.particleAlpha -= 0.05F;
         if (this.particleAlpha <= 0.0F) {
            this.setExpired();
         }
      }

      this.motionY = 0.0;
      this.motionX = 0.0;
      this.motionZ = 0.0;
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class Factory implements IParticleFactory {
      @Nullable
      public Particle createParticle(int particleID, World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... p_178902_15_) {
         return new ParticleWatchingEye(world, x, y, z, xSpeed, ySpeed, zSpeed);
      }
   }
}
