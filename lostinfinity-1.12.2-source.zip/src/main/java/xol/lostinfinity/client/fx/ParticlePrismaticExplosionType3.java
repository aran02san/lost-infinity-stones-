package xol.lostinfinity.client.fx;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;

public class ParticlePrismaticExplosionType3 extends LostParticle {
   private static final Random RANDOM = new Random();

   protected ParticlePrismaticExplosionType3(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeed, double zSpeedIn) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, 0.5 - RANDOM.nextDouble(), ySpeed, 0.5 - RANDOM.nextDouble());
      this.motionY *= 0.2F;
      if (xSpeedIn == 0.0 && zSpeedIn == 0.0) {
         this.motionX *= 0.1F;
         this.motionZ *= 0.1F;
      }

      this.rotateSpeed = this.rand.nextFloat();
      this.scale = RANDOM.nextFloat() * 0.5F;
      this.particleMaxAge = (int)(5.0 / (this.rand.nextFloat() * 0.8 + 0.2)) + 2;
      this.growSpeed = (0.3F + this.rand.nextFloat() / 2.0F) * 9.0F;
      this.setParticleTexture(ParticleInit.PRISMATIC_EXPLOSION_TYPE3_SPRITE);
   }

   public ParticlePrismaticExplosionType3 setParticleGravity(double motionY) {
      this.motionY = motionY;
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      super.onUpdate();
      if (this.scale >= 40.0F) {
         this.particleAge = this.particleMaxAge;
      }

      if (this.particleAge++ >= this.particleMaxAge) {
         this.setExpired();
      }

      this.motionY += 0.002;
      this.move(this.motionX, this.motionY, this.motionZ);
      if (this.posY == this.prevPosY) {
         this.motionX *= 1.1;
         this.motionZ *= 1.1;
      }

      this.motionX *= 0.96F;
      this.motionY *= 0.96F;
      this.motionZ *= 0.96F;
      if (this.onGround) {
         this.motionX *= 0.7F;
         this.motionZ *= 0.7F;
      }
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class Factory implements IParticleFactory {
      @Nullable
      public Particle createParticle(int particleID, World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... p_178902_15_) {
         return new ParticlePrismaticExplosionType3(world, x, y, z, xSpeed, ySpeed, zSpeed);
      }
   }
}
