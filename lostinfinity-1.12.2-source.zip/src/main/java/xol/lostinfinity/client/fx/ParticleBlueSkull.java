package xol.lostinfinity.client.fx;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.client.particle.IParticleFactory;
import net.minecraft.client.particle.Particle;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.ParticleInit;

public class ParticleBlueSkull extends LostParticle {
   private static final Random RANDOM = new Random();

   protected ParticleBlueSkull(World worldIn, double xCoordIn, double yCoordIn, double zCoordIn, double xSpeedIn, double ySpeed, double zSpeedIn) {
      super(worldIn, xCoordIn, yCoordIn, zCoordIn, 0.5 - RANDOM.nextDouble(), ySpeed, 0.5 - RANDOM.nextDouble());
      this.motionY = 0.05;
      if (xSpeedIn == 0.0 && zSpeedIn == 0.0) {
         this.motionX *= 0.1F;
         this.motionZ *= 0.1F;
      }

      this.scale = 3.0F + RANDOM.nextFloat() * 0.5F;
      this.particleMaxAge = 40 + this.rand.nextInt(20);
      this.growSpeed = 0.2F;
      this.setParticleTexture(ParticleInit.BLUE_SKULL_SPRITE);
   }

   public ParticleBlueSkull setParticleGravity(double motionY) {
      this.motionY = motionY;
      return this;
   }

   public boolean shouldDisableDepth() {
      return true;
   }

   @Override
   public void onUpdate() {
      this.updatePos();
      this.updateAngle();
      if (this.scale < 100.0F) {
         this.updateScale();
      } else {
         this.prevScale = this.scale;
      }

      if (this.particleAge++ >= this.particleMaxAge) {
         this.particleAlpha -= 0.05F;
         if (this.particleAlpha <= 0.0F) {
            this.setExpired();
         }
      }

      this.move(this.motionX, this.motionY, this.motionZ);
      if (this.posY == this.prevPosY) {
         this.motionX *= 1.1;
         this.motionZ *= 1.1;
      }

      this.motionX *= 0.96F;
      this.motionZ *= 0.96F;
      if (this.onGround) {
         this.motionX *= 0.7F;
         this.motionZ *= 0.7F;
      }
   }

   public int getFXLayer() {
      return 1;
   }

   @SideOnly(Side.CLIENT)
   public static class Factory implements IParticleFactory {
      @Nullable
      public Particle createParticle(int particleID, World world, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... p_178902_15_) {
         return new ParticleBlueSkull(world, x, y, z, xSpeed, ySpeed, zSpeed);
      }
   }
}
