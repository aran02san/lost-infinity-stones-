package xol.lostinfinity.dimension.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.MapStorage;
import net.minecraft.world.storage.WorldSavedData;

public class CustomWorldSavedData extends WorldSavedData {
   private static final String DATA_NAME = "lostinfinity_custom_data";
   private HashMap<Integer, ArrayList<BlockData>> dataMap = new HashMap<>();
   private ArrayList<Integer> tileIDs = new ArrayList<>();
   private HashMap<Integer, BlockPos> tilePositions = new HashMap<>();

   public CustomWorldSavedData() {
      super("lostinfinity_custom_data");
   }

   public CustomWorldSavedData(String s) {
      super(s);
   }

   public void readFromNBT(NBTTagCompound nbt) {
      if (this.tileIDs.size() > 0) {
         this.tileIDs.clear();
      }

      if (this.tilePositions.size() > 0) {
         this.tilePositions.clear();
      }

      if (this.dataMap.size() > 0) {
         this.dataMap.clear();
      }

      if (nbt.hasKey("tileIDs")) {
         int[] tempids = nbt.getIntArray("tileIDs");

         for (int i = 0; i < tempids.length; i++) {
            this.tileIDs.add(tempids[i]);
         }
      }

      for (int id : this.tileIDs) {
         String id_str = String.valueOf(id);
         if (nbt.hasKey("tileX" + id_str) && nbt.hasKey("tileY" + id_str) && nbt.hasKey("tileZ" + id_str)) {
            int tileX = nbt.getInteger("tileX" + id_str);
            int tileY = nbt.getInteger("tileY" + id_str);
            int tileZ = nbt.getInteger("tileZ" + id_str);
            BlockPos tilePos = new BlockPos(tileX, tileY, tileZ);
            this.tilePositions.put(id, tilePos);
            if (nbt.hasKey("xPos" + id_str)
               && nbt.hasKey("yPos" + id_str)
               && nbt.hasKey("zPos" + id_str)
               && nbt.hasKey("meta" + id_str)
               && nbt.hasKey("ids" + id_str)) {
               int[] xPos = nbt.getIntArray("xPos" + id_str);
               int[] yPos = nbt.getIntArray("yPos" + id_str);
               int[] zPos = nbt.getIntArray("zPos" + id_str);
               int[] meta = nbt.getIntArray("meta" + id_str);
               int[] ids = nbt.getIntArray("ids" + id_str);
               if (xPos.length > 0 && yPos.length > 0 && zPos.length > 0 && meta.length > 0) {
                  ArrayList<BlockData> newData = new ArrayList<>();

                  for (int i = 0; i < xPos.length; i++) {
                     if (i >= yPos.length || i >= zPos.length || i >= meta.length) {
                        return;
                     }

                     BlockPos pos = new BlockPos(xPos[i], yPos[i], zPos[i]);
                     BlockData data = new BlockData(pos, meta[i], ids[i]);
                     newData.add(data);
                  }

                  if (newData.size() > 1) {
                     this.dataMap.put(id, newData);
                  }
               }
            }
         }
      }
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      int[] tileids = new int[this.tileIDs.size()];

      for (int j = 0; j < this.tileIDs.size(); j++) {
         int id = this.tileIDs.get(j);
         tileids[j] = id;
         String id_str = String.valueOf(id);
         ArrayList<BlockData> block_data = this.dataMap.get(id);
         if (this.tilePositions.containsKey(id)) {
            BlockPos tilePos = this.tilePositions.get(id);
            compound.setInteger("tileX" + id_str, tilePos.getX());
            compound.setInteger("tileY" + id_str, tilePos.getY());
            compound.setInteger("tileZ" + id_str, tilePos.getZ());
            compound.setIntArray("tileIDs", tileids);
            if (block_data != null && block_data.size() > 0) {
               int[] xPos = new int[block_data.size()];
               int[] yPos = new int[block_data.size()];
               int[] zPos = new int[block_data.size()];
               int[] meta = new int[block_data.size()];
               int[] ids = new int[block_data.size()];

               for (int i = 0; i < block_data.size(); i++) {
                  BlockData data = block_data.get(i);
                  if (data != null) {
                     BlockPos pos = data.getPos();
                     int blockid = data.getId();
                     int metaNum = data.getMeta();
                     if (pos != null) {
                        xPos[i] = pos.getX();
                        yPos[i] = pos.getY();
                        zPos[i] = pos.getZ();
                        meta[i] = metaNum;
                        ids[i] = blockid;
                     }
                  }
               }

               compound.setIntArray("xPos" + id_str, xPos);
               compound.setIntArray("yPos" + id_str, yPos);
               compound.setIntArray("zPos" + id_str, zPos);
               compound.setIntArray("meta" + id_str, meta);
               compound.setIntArray("ids" + id_str, ids);
            }
         }
      }

      return compound;
   }

   public static CustomWorldSavedData get(World world) {
      MapStorage storage = world.getPerWorldStorage();
      CustomWorldSavedData instance = (CustomWorldSavedData)storage.getOrLoadData(CustomWorldSavedData.class, "lostinfinity_custom_data");
      if (instance == null) {
         instance = new CustomWorldSavedData();
         storage.setData("lostinfinity_custom_data", instance);
      }

      return instance;
   }

   public void setBlockData(ArrayList<BlockData> block_data, BlockPos pos) {
      if (this.tilePositions.containsValue(pos)) {
         for (int id : this.tileIDs) {
            BlockPos tilePos = this.tilePositions.get(id);
            if (tilePos != null && tilePos.equals(pos)) {
               this.dataMap.put(id, block_data);
            }
         }
      } else {
         Random rand = new Random();
         int randId = rand.nextInt();

         while (this.tileIDs.contains(randId) || randId == -1) {
            randId = rand.nextInt();
         }

         this.tileIDs.add(randId);
         this.tilePositions.put(randId, pos);
         this.dataMap.put(randId, block_data);
      }

      this.markDirty();
   }

   public ArrayList<BlockData> getBlockData(BlockPos pos) {
      if (this.tilePositions.containsValue(pos)) {
         for (int id : this.tileIDs) {
            BlockPos tilePos = this.tilePositions.get(id);
            if (tilePos != null && tilePos.equals(pos)) {
               return this.dataMap.get(id);
            }
         }
      }

      return null;
   }

   public void clearBlockData(BlockPos pos) {
      if (this.tilePositions.containsValue(pos)) {
         int toRemove = -1;

         for (int id : this.tileIDs) {
            BlockPos tilePos = this.tilePositions.get(id);
            if (tilePos != null && tilePos.equals(pos)) {
               toRemove = id;
               break;
            }
         }

         if (toRemove != -1) {
            this.dataMap.remove(toRemove);
            this.tilePositions.remove(toRemove);
            this.tileIDs.remove(Integer.valueOf(toRemove));
         }
      }
   }
}
