package xol.lostinfinity.dimension.data;

import java.util.ArrayList;
import java.util.List;

public class BomberMap {
   private int col;
   private int row;
   private static int softWallRatio = 50;
   private BomberNode[][] bomberGrid;

   public static void main(String[] args) {
      int c = 31;
      int r = 31;
      BomberMap bombMap = new BomberMap(c, r, 10);
      bombMap.setSpawns(3);

      for (int i = 0; i < c; i++) {
         for (int j = 0; j < r; j++) {
            BomberNode node = bombMap.getNodeAtLocation(i, j);
            String type = node.getType();
            switch (type) {
               case "hard":
                  System.out.print("[]");
                  break;
               case "soft":
                  System.out.print("{}");
                  break;
               case "spawn1":
                  System.out.print("^!");
                  break;
               case "spawn2":
                  System.out.print("^|");
                  break;
               case "spawn3":
                  System.out.print("!^");
                  break;
               case "air":
                  System.out.print("||");
            }
         }

         System.out.print("\r\n");
      }
   }

   public BomberMap(int columns, int rows, int numPowerups) {
      int y = 0;
      this.col = columns;
      this.row = rows;
      this.bomberGrid = new BomberNode[columns][rows];

      for (int i = 0; i < columns; i++) {
         for (int j = 0; j < rows; j++) {
            BomberNode node;
            if (i % 3 == 2 && j % 3 == 2) {
               node = new BomberNode(i, y, j, "hard");
            } else {
               int randInt = (int)(Math.random() * 100.0);
               if (randInt < softWallRatio) {
                  node = new BomberNode(i, y, j, "soft");
               } else {
                  node = new BomberNode(i, y, j, "air");
               }
            }

            this.bomberGrid[i][j] = node;
         }
      }

      int powerUpsLeft = numPowerups;

      while (powerUpsLeft > 0) {
         int randCol = (int)(Math.random() * columns);
         int randRow = (int)(Math.random() * rows);
         BomberNode node = this.getNodeAtLocation(randCol, randRow);
         if (node.getType().equals("soft")) {
            node.setType("powerup");
            powerUpsLeft--;
         }
      }
   }

   public void setSpawns(int numPlayers) {
      int c = this.col;
      int r = this.row;
      int perimeter = 2 * c + 2 * r;
      int distPoint = perimeter / numPlayers;
      int startX = 0;
      int startZ = 0;
      BomberNode startNode = this.getNodeAtLocation(startX, startZ);
      startNode.setType("spawn1");

      for (BomberNode spawn : this.findSpawnPointsFromPerimeterDist(startNode, distPoint, numPlayers)) {
         for (BomberNode neighbour : spawn.getNeighbours(this)) {
            if (neighbour != null) {
               neighbour.setType("air");
            }
         }
      }
   }

   public List<BomberNode> findSpawnPointsFromPerimeterDist(BomberNode startNode, int pointDist, int n) {
      List<BomberNode> spawnList = new ArrayList<>();
      spawnList.add(startNode);
      String side = "";
      int c = this.col - 1;
      int r = this.row - 1;
      int x = startNode.getX();
      int z = startNode.getZ();

      for (int i = 1; i < n; i++) {
         String type = "spawn" + Integer.toString(i + 1);
         System.out.println(type);
         int dist = pointDist;
         if (x == 0 && z >= 0) {
            side = "left";
         } else if (x > 0 && z == 0) {
            side = "bottom";
         } else if (x >= 0 && z == r) {
            side = "top";
         } else if (x == c && z >= 0) {
            side = "right";
         } else {
            System.out.println("bad things happened");
         }

         while (dist > 0) {
            switch (side) {
               case "left":
                  if (dist <= r - z) {
                     z += dist;
                     dist = 0;
                  } else {
                     dist -= r - z;
                     z = r;
                     side = "top";
                  }
                  break;
               case "top":
                  if (dist <= c - x) {
                     x += dist;
                     dist = 0;
                  } else {
                     dist -= c - x;
                     x = c;
                     side = "right";
                  }
                  break;
               case "right":
                  if (dist <= z) {
                     z -= dist;
                     dist = 0;
                  } else {
                     dist -= z;
                     z = 0;
                     side = "bottom";
                  }
                  break;
               case "bottom":
                  if (dist <= x) {
                     x -= dist;
                     dist = 0;
                  } else {
                     dist -= x;
                     x = 0;
                     side = "left";
                  }
            }
         }

         BomberNode spawn = this.getNodeAtLocation(x, z);
         spawn.setType(type);
         spawnList.add(spawn);
      }

      return spawnList;
   }

   public BomberNode getNodeAtLocation(int col, int row) {
      return col >= 0 && row >= 0 && col < this.col && row < this.row ? this.bomberGrid[col][row] : null;
   }
}
