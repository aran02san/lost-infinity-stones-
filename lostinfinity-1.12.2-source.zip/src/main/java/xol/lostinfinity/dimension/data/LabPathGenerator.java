package xol.lostinfinity.dimension.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class LabPathGenerator {
   private LabPathNode[][] pathMap;

   public LabPathGenerator(int rows, int columns) {
      Random rand = new Random();
      boolean complete = false;

      while (!complete) {
         this.pathMap = new LabPathNode[columns][rows];

         for (int i = 0; i < columns; i++) {
            for (int j = 0; j < rows; j++) {
               this.pathMap[i][j] = new LabPathNode(i, j);
            }
         }

         ArrayList<ArrayList<LabPathNode>> doors = new ArrayList<>();
         ArrayList<LabPathGenerator.LabPath> paths = new ArrayList<>();
         doors.add(this.get2x2(0, 6));
         doors.add(this.get2x2(6, 0));
         doors.add(this.get2x2(12, 6));
         doors.add(this.get2x2(6, 12));
         Collections.shuffle(doors);

         for (ArrayList<LabPathNode> door : doors) {
            visit(door);
         }

         int numDeadEnds = 0;
         int numToConnect = 0;
         ArrayList<Integer> needsConnection = new ArrayList<>();
         needsConnection.add(0);
         needsConnection.add(1);
         needsConnection.add(2);
         needsConnection.add(3);

         for (int i = 0; i < 4; i++) {
            ArrayList<Integer> connectedDoors = new ArrayList<>();
            int startDoor = i;
            boolean isDeadEnd = rand.nextBoolean();
            if (isDeadEnd && numDeadEnds <= 2) {
               paths.add(new LabPathGenerator.LabPath(connectedDoors, true, i));
               numDeadEnds++;
            } else {
               int numConnected = rand.nextInt(3);

               for (int j = 0; j < numConnected; j++) {
                  if (!needsConnection.isEmpty()) {
                     if (needsConnection.size() == 1 && needsConnection.get(0) == startDoor) {
                        break;
                     }

                     int randDoor = needsConnection.get(rand.nextInt(needsConnection.size()));

                     while (randDoor == startDoor) {
                        randDoor = needsConnection.get(rand.nextInt(needsConnection.size()));
                     }

                     connectedDoors.add(randDoor);
                     numToConnect++;
                     needsConnection.remove(needsConnection.indexOf(randDoor));
                  }
               }

               if (connectedDoors.size() > 1) {
                  paths.add(new LabPathGenerator.LabPath(connectedDoors, true, startDoor));
               } else {
                  if (numDeadEnds > 2) {
                     break;
                  }

                  paths.add(new LabPathGenerator.LabPath(connectedDoors, false, startDoor));
                  numDeadEnds++;
               }
            }
         }

         if (numDeadEnds < 2 && numToConnect < 2) {
            System.out.println("Failed");
         }

         for (LabPathGenerator.LabPath path : paths) {
            ArrayList<Integer> connectedDoors = path.getConnectedDoors();
            ArrayList<LabPathNode> doorNodes = path.getDoorNodes();
            ArrayList<LabPathNode> endNodes = path.getEndNodes();
            ArrayList<LabPathNode> visited = path.getVisited();

            for (int connectedDoor : connectedDoors) {
               ArrayList<LabPathNode> door = doors.get(connectedDoor);
               if (door != null) {
                  doorNodes.addAll(door);
               }
            }

            endNodes.addAll(doors.get(path.getStartDoor()));
            visited.addAll(doors.get(path.getStartDoor()));
            visit(doors.get(path.getStartDoor()));
            boolean end = true;
            if (!this.drawPath(path)) {
               end = false;
            }

            if (end) {
               complete = true;
            }
         }
      }
   }

   private boolean drawPath(LabPathGenerator.LabPath path) {
      ArrayList<LabPathNode> endNodes = path.getEndNodes();
      ArrayList<LabPathNode> visited = path.getVisited();
      ArrayList<LabPathNode> doorNodes = path.getDoorNodes();
      boolean pathComplete = false;
      int iterations = 0;

      while (!pathComplete && iterations < 20) {
         iterations++;
         Collections.shuffle(endNodes);
         LabPathNode toAdd = null;
         ArrayList<LabPathNode> check = null;

         label110:
         for (LabPathNode node : endNodes) {
            int i = 0;

            label108:
            while (true) {
               if (i < 2) {
                  int j = 0;

                  while (true) {
                     if (j >= 2) {
                        i++;
                        continue label108;
                     }

                     check = this.get2x2(i + node.getX(), j + node.getZ());
                     boolean connected = false;
                     boolean canAdd = true;

                     for (LabPathNode subNode : check) {
                        if (subNode == null) {
                           canAdd = false;
                           break;
                        }

                        for (LabPathNode adjacent : this.getAdjacents(subNode)) {
                           if (adjacent != null && !visited.contains(adjacent) && adjacent.visited() && !doorNodes.contains(adjacent)) {
                              canAdd = false;
                              break;
                           }
                        }

                        if (endNodes.contains(subNode)) {
                           connected = true;
                        } else if (visited.contains(subNode) && subNode.visited()) {
                           canAdd = false;
                           break;
                        }
                     }

                     if (connected && canAdd) {
                        toAdd = this.getNodeAtLocation(i + node.getX(), j + node.getZ());
                        break;
                     }

                     j++;
                  }
               }

               if (toAdd != null) {
                  break label110;
               }
               break;
            }
         }

         if (toAdd != null && check != null) {
            ArrayList<LabPathNode> toRemove = new ArrayList<>();

            for (LabPathNode node : check) {
               if (endNodes.contains(node)) {
                  toRemove.add(node);
               }

               if (doorNodes.contains(node)) {
                  pathComplete = true;
               }
            }

            check.removeAll(toRemove);
            visit(check);
            endNodes.clear();
            endNodes.addAll(check);
            visited.addAll(check);
            if (pathComplete) {
               return true;
            }
         }
      }

      return false;
   }

   private ArrayList<LabPathNode> getAdjacents(LabPathNode subNode) {
      ArrayList<LabPathNode> adjacents = new ArrayList<>();
      adjacents.add(this.getNodeAtLocation(subNode.getX() + 1, subNode.getZ()));
      adjacents.add(this.getNodeAtLocation(subNode.getX(), subNode.getZ() + 1));
      adjacents.add(this.getNodeAtLocation(subNode.getX(), subNode.getZ() - 1));
      adjacents.add(this.getNodeAtLocation(subNode.getX() - 1, subNode.getZ()));
      return adjacents;
   }

   public static void visit(ArrayList<LabPathNode> nodes) {
      for (LabPathNode node : nodes) {
         if (node != null) {
            node.setVisited();
         }
      }
   }

   public static void main(String[] args) {
      int c = 14;
      int r = 14;
      LabPathGenerator pathMap = new LabPathGenerator(c, r);

      for (int i = 0; i < c; i++) {
         for (int j = 0; j < r; j++) {
            LabPathNode node = pathMap.getNodeAtLocation(j, i);
            if (node != null) {
               boolean visited = node.visited();
               if (visited) {
                  System.out.print("[]");
               } else {
                  System.out.print("{}");
               }
            }
         }

         System.out.print("\r\n");
      }
   }

   public LabPathNode getNodeAtLocation(int i, int j) {
      return this.pathMap != null && i >= 0 && j >= 0 && this.pathMap.length > i && this.pathMap[i].length > j ? this.pathMap[i][j] : null;
   }

   private ArrayList<LabPathNode> get2x2(int i, int j) {
      ArrayList<LabPathNode> nodes = new ArrayList<>();
      nodes.add(this.getNodeAtLocation(i, j));
      nodes.add(this.getNodeAtLocation(i + 1, j));
      nodes.add(this.getNodeAtLocation(i, j + 1));
      nodes.add(this.getNodeAtLocation(i + 1, j + 1));
      return nodes;
   }

   private class LabPath {
      ArrayList<LabPathNode> endNodes;
      ArrayList<LabPathNode> visited = new ArrayList<>();
      ArrayList<LabPathNode> doorNodes;
      ArrayList<Integer> connectedDoors;
      int startDoor;
      boolean isDeadEnd;

      public LabPath(ArrayList<Integer> connectedDoors, boolean isDeadEnd, int startDoor) {
         this.endNodes = new ArrayList<>();
         this.doorNodes = new ArrayList<>();
         this.startDoor = startDoor;
         this.connectedDoors = connectedDoors;
         this.isDeadEnd = isDeadEnd;
      }

      public int getStartDoor() {
         return this.startDoor;
      }

      public ArrayList<LabPathNode> getDoorNodes() {
         return this.doorNodes;
      }

      public void setDoorNodes(ArrayList<LabPathNode> doorNodes) {
         this.doorNodes = doorNodes;
      }

      public void setEndNodes(ArrayList<LabPathNode> endNodes) {
         this.endNodes = endNodes;
      }

      public ArrayList<LabPathNode> getEndNodes() {
         return this.endNodes;
      }

      public void setVisited(ArrayList<LabPathNode> visited) {
         this.visited = visited;
      }

      public ArrayList<LabPathNode> getVisited() {
         return this.visited;
      }

      public void addVisited(LabPathNode node) {
         if (this.visited != null) {
            this.visited.add(node);
         }
      }

      public boolean isDeadEnd() {
         return this.isDeadEnd;
      }

      public ArrayList<Integer> getConnectedDoors() {
         return this.connectedDoors;
      }
   }
}
