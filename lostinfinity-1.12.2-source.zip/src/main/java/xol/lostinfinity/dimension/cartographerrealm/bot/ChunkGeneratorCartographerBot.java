package xol.lostinfinity.dimension.cartographerrealm.bot;

import java.util.List;
import java.util.Random;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.Biome.SpawnListEntry;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;
import xol.lostinfinity.dimension.cartographerrealm.ICartographerRealm;
import xol.lostinfinity.dimension.util.WorldGenStructure;

public class ChunkGeneratorCartographerBot implements IChunkGenerator, ICartographerRealm {
   private final Random rand;
   private final World world;
   private Biome[] biomesForGeneration;

   public ChunkGeneratorCartographerBot(World world, long seed) {
      this.world = world;
      this.rand = new Random(seed);
   }

   public void populate(int chunkX, int chunkZ) {
      this.rand.setSeed(this.world.getSeed());
      long k = this.rand.nextLong() / 2L * 2L + 1L;
      long l = this.rand.nextLong() / 2L * 2L + 1L;
      this.rand.setSeed(chunkX * k + chunkZ * l ^ this.world.getSeed());
      this.doGeneration(this.world, this.rand, chunkX, chunkZ);
      if (Math.abs(chunkX) <= 1 && Math.abs(chunkZ) <= 1) {
         if (chunkX == -1 && chunkZ == -1) {
            int posX = chunkX * 16;
            int posZ = chunkZ * 16;
            new WorldGenStructure("labyrinth/labyrinth_puzzlemaster1").generate(this.world, this.rand, new BlockPos(posX + 8, 30, posZ + 8));
         }

         if (chunkX == 0 && chunkZ == -1) {
            int posX = chunkX * 16;
            int posZ = chunkZ * 16;
            new WorldGenStructure("labyrinth/labyrinth_puzzlemaster2").generate(this.world, this.rand, new BlockPos(posX + 8, 30, posZ + 8));
         }

         if (chunkX == -1 && chunkZ == 0) {
            int posX = chunkX * 16;
            int posZ = chunkZ * 16;
            new WorldGenStructure("labyrinth/labyrinth_puzzlemaster3").generate(this.world, this.rand, new BlockPos(posX + 8, 30, posZ + 8));
         }

         if (chunkX == 0 && chunkZ == 0) {
            int posX = chunkX * 16;
            int posZ = chunkZ * 16;
            new WorldGenStructure("labyrinth/labyrinth_puzzlemaster4").generate(this.world, this.rand, new BlockPos(posX + 8, 30, posZ + 8));
         }
      }
   }

   @Override
   public String teleRoom() {
      return "labyrinth/bottomlabcross1";
   }

   @Override
   public String gateRoom() {
      return "labyrinth/bottomlabcross1";
   }

   @Override
   public String[] stairsRoom() {
      return new String[]{"labyrinth/bottomlabelevatortop", "labyrinth/bottomlabelevatorbot"};
   }

   @Override
   public String[] twoLevelRoom() {
      return new String[]{"labyrinth/bottomlabelevatortop", "labyrinth/bottomlabelevatorbot"};
   }

   @Override
   public String connectorRoom() {
      int con_pick = this.rand.nextInt(16);
      return "labyrinth/bottomlabcon" + ++con_pick;
   }

   @Override
   public String crossRoom() {
      int cross_pick = this.rand.nextInt(5);
      return "labyrinth/bottomlabcross" + ++cross_pick;
   }

   @Override
   public String gameRoom() {
      int game_pick = this.rand.nextInt(11);
      return "labyrinth/bottomlabspeccross" + ++game_pick;
   }

   @Override
   public String portalRoom() {
      int con_pick = this.rand.nextInt(16);
      return "labyrinth/bottomlabcon" + ++con_pick;
   }

   public Chunk generateChunk(int x, int z) {
      this.rand.setSeed(x * 341873128712L + z * 132897987541L);
      this.biomesForGeneration = this.world.getBiomeProvider().getBiomes(this.biomesForGeneration, x * 16, z * 16, 16, 16);
      ChunkPrimer primer = new ChunkPrimer();
      Chunk chunk = new Chunk(this.world, primer, x, z);
      byte[] abyte = chunk.getBiomeArray();

      for (int i = 0; i < abyte.length; i++) {
         abyte[i] = (byte)Biome.getIdForBiome(this.biomesForGeneration[i]);
      }

      chunk.generateSkylightMap();
      return chunk;
   }

   public List<SpawnListEntry> getPossibleCreatures(EnumCreatureType creatureType, BlockPos pos) {
      return null;
   }

   public boolean generateStructures(Chunk chunkIn, int chunkX, int chunkZ) {
      return false;
   }

   public void recreateStructures(Chunk p_180514_1_, int x, int z) {
   }

   public boolean isInsideStructure(World worldIn, String structureName, BlockPos pos) {
      return false;
   }

   public BlockPos getNearestStructurePos(World worldIn, String structureName, BlockPos position, boolean findUnexplored) {
      return null;
   }
}
