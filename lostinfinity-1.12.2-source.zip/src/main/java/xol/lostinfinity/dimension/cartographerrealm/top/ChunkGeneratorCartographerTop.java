package xol.lostinfinity.dimension.cartographerrealm.top;

import java.util.List;
import java.util.Random;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.Biome.SpawnListEntry;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;
import xol.lostinfinity.dimension.cartographerrealm.ICartographerRealm;

public class ChunkGeneratorCartographerTop implements IChunkGenerator, ICartographerRealm {
   private final Random rand;
   private final World world;
   private Biome[] biomesForGeneration;

   public ChunkGeneratorCartographerTop(World world, long seed) {
      this.world = world;
      this.rand = new Random(seed);
   }

   public void populate(int chunkX, int chunkZ) {
      this.rand.setSeed(this.world.getSeed());
      long k = this.rand.nextLong() / 2L * 2L + 1L;
      long l = this.rand.nextLong() / 2L * 2L + 1L;
      this.rand.setSeed(chunkX * k + chunkZ * l ^ this.world.getSeed());
      this.doGeneration(this.world, this.rand, chunkX, chunkZ);
   }

   private String randomLowerConnector() {
      int con_pick = this.rand.nextInt(16);
      return "labyrinth/lowerlabcon" + ++con_pick;
   }

   private String randomLowerCross() {
      int cross_pick = this.rand.nextInt(6);
      return "labyrinth/lowerlabcross" + ++cross_pick;
   }

   private String randomLowSpecCross() {
      int cross_pick = this.rand.nextInt(12);
      return "labyrinth/lowerlabspeccross" + ++cross_pick;
   }

   @Override
   public String teleRoom() {
      return "labyrinth/labteleroom";
   }

   @Override
   public String gateRoom() {
      return "labyrinth/labgateroom";
   }

   @Override
   public String[] stairsRoom() {
      String[] stairs = new String[2];
      int style = this.rand.nextInt(2);
      stairs[0] = "labyrinth/labelevatortop" + ++style;
      stairs[1] = "labyrinth/labelevatorbase" + style;
      return stairs;
   }

   @Override
   public String[] twoLevelRoom() {
      String[] room = new String[2];
      int game_pick = this.rand.nextInt(3);
      game_pick++;
      room[0] = "labyrinth/labaspectroom";
      room[1] = "labyrinth/labgameroom" + game_pick;
      return room;
   }

   @Override
   public String connectorRoom() {
      int con_pick = this.rand.nextInt(16);
      return "labyrinth/labconnector" + ++con_pick;
   }

   @Override
   public String crossRoom() {
      int cross_pick = this.rand.nextInt(8);
      return "labyrinth/labcross" + ++cross_pick;
   }

   @Override
   public String gameRoom() {
      int cross_pick = this.rand.nextInt(13);
      return "labyrinth/labspeccross" + ++cross_pick;
   }

   @Override
   public String portalRoom() {
      return "labyrinth/labportal";
   }

   public Chunk generateChunk(int x, int z) {
      this.rand.setSeed(x * 341873128712L + z * 132897987541L);
      this.biomesForGeneration = this.world.getBiomeProvider().getBiomes(this.biomesForGeneration, x * 16, z * 16, 16, 16);
      ChunkPrimer primer = new ChunkPrimer();
      Chunk chunk = new Chunk(this.world, primer, x, z);
      byte[] abyte = chunk.getBiomeArray();

      for (int i = 0; i < abyte.length; i++) {
         abyte[i] = (byte)Biome.getIdForBiome(this.biomesForGeneration[i]);
      }

      chunk.generateSkylightMap();
      return chunk;
   }

   public List<SpawnListEntry> getPossibleCreatures(EnumCreatureType creatureType, BlockPos pos) {
      return null;
   }

   public boolean generateStructures(Chunk chunkIn, int chunkX, int chunkZ) {
      return false;
   }

   public void recreateStructures(Chunk p_180514_1_, int x, int z) {
   }

   public boolean isInsideStructure(World worldIn, String structureName, BlockPos pos) {
      return false;
   }

   public BlockPos getNearestStructurePos(World worldIn, String structureName, BlockPos position, boolean findUnexplored) {
      return null;
   }
}
