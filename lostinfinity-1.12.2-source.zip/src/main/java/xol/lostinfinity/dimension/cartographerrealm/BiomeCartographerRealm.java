package xol.lostinfinity.dimension.cartographerrealm;

import java.awt.Color;
import java.util.Random;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome.BiomeProperties;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.dimension.util.DimensionNoBuild;

public class BiomeCartographerRealm extends DimensionNoBuild {
   private static BiomeProperties properties = new BiomeProperties("cartographerrealm").setRainDisabled();

   public BiomeCartographerRealm() {
      super(properties, "cartographerrealm");
   }

   @SideOnly(Side.CLIENT)
   public int getSkyColorByTemp(float par1) {
      return Color.BLACK.getRGB();
   }

   public void decorate(World worldIn, Random rand, BlockPos pos) {
   }
}
