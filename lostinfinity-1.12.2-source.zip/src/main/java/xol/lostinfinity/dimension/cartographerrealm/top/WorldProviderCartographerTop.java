package xol.lostinfinity.dimension.cartographerrealm.top;

import javax.annotation.Nullable;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.dimension.cartographerrealm.BiomeProviderCartographerRealm;
import xol.lostinfinity.init.DimensionInit;

public class WorldProviderCartographerTop extends WorldProvider {
   public void init() {
      this.biomeProvider = new BiomeProviderCartographerRealm();
      this.nether = false;
      this.hasSkyLight = false;
   }

   public IChunkGenerator createChunkGenerator() {
      return new ChunkGeneratorCartographerTop(this.world, this.world.getSeed() + this.getDimension());
   }

   public float calculateCelestialAngle(long worldTime, float partialTicks) {
      return 0.1F;
   }

   public boolean canRespawnHere() {
      return false;
   }

   public boolean isSurfaceWorld() {
      return false;
   }

   @SideOnly(Side.CLIENT)
   public float getCloudHeight() {
      return 100.0F;
   }

   public int getAverageGroundLevel() {
      return 100;
   }

   public DimensionType getDimensionType() {
      return DimensionInit.cartographerRealmTop;
   }

   @Nullable
   public String getSaveFolder() {
      return "CartographerRealmTop";
   }
}
