package xol.lostinfinity.dimension.celestialvoid;

import javax.annotation.Nullable;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.DimensionInit;

public class WorldProviderCelestialVoid extends WorldProvider {
   public void init() {
      this.biomeProvider = new BiomeProviderCelestialVoid();
      this.nether = false;
      this.hasSkyLight = false;
   }

   public IChunkGenerator createChunkGenerator() {
      return new ChunkGeneratorCelestialVoid(this.world, this.world.getSeed() + this.getDimension());
   }

   public float calculateCelestialAngle(long worldTime, float partialTicks) {
      return 0.1F;
   }

   public boolean canRespawnHere() {
      return false;
   }

   public boolean isSurfaceWorld() {
      return false;
   }

   @SideOnly(Side.CLIENT)
   public float getCloudHeight() {
      return 8.0F;
   }

   public int getAverageGroundLevel() {
      return 70;
   }

   @SideOnly(Side.CLIENT)
   public Vec3d getFogColor(float f, float f1) {
      return new Vec3d(0.1F, 0.1F, 0.1F);
   }

   public DimensionType getDimensionType() {
      return DimensionInit.celestialVoid;
   }

   @Nullable
   public String getSaveFolder() {
      return "CelestialVoid";
   }
}
