package xol.lostinfinity.dimension.celestialvoid;

import java.util.List;
import java.util.Random;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.Biome.SpawnListEntry;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkPrimer;
import net.minecraft.world.gen.IChunkGenerator;
import xol.lostinfinity.dimension.util.WorldGenStructure;

public class ChunkGeneratorCelestialVoid implements IChunkGenerator {
   private final Random rand;
   private final World world;
   private Biome[] biomesForGeneration;

   public ChunkGeneratorCelestialVoid(World world, long seed) {
      this.world = world;
      this.rand = new Random(seed);
   }

   public Chunk generateChunk(int x, int z) {
      this.rand.setSeed(x * 341873128712L + z * 132897987541L);
      this.biomesForGeneration = this.world.getBiomeProvider().getBiomes(this.biomesForGeneration, x * 16, z * 16, 16, 16);
      ChunkPrimer primer = new ChunkPrimer();
      Chunk chunk = new Chunk(this.world, primer, x, z);
      byte[] abyte = chunk.getBiomeArray();

      for (int i = 0; i < abyte.length; i++) {
         abyte[i] = (byte)Biome.getIdForBiome(this.biomesForGeneration[i]);
      }

      chunk.generateSkylightMap();
      return chunk;
   }

   public List<SpawnListEntry> getPossibleCreatures(EnumCreatureType creatureType, BlockPos pos) {
      Biome biome = this.world.getBiomeProvider().getBiome(pos);
      return biome != null ? biome.getSpawnableList(creatureType) : null;
   }

   public boolean generateStructures(Chunk chunkIn, int chunkX, int chunkZ) {
      return false;
   }

   public void recreateStructures(Chunk p_180514_1_, int x, int z) {
   }

   public boolean isInsideStructure(World worldIn, String structureName, BlockPos pos) {
      return false;
   }

   public BlockPos getNearestStructurePos(World worldIn, String structureName, BlockPos position, boolean findUnexplored) {
      return null;
   }

   public void populate(int chunkX, int chunkZ) {
      if (chunkX == 0 && chunkZ == 0) {
         this.generateGrandArena(chunkX, chunkZ);
      } else if (chunkX == 31 && chunkZ == 31) {
         this.generateTrialArena(chunkX, chunkZ);
      } else if (chunkX == 60 && chunkZ == 60) {
         this.generateDeviationArena(chunkX, chunkZ);
      } else if (chunkX == 60 && chunkZ == 60) {
         this.generateDeviationArena(chunkX, chunkZ);
      } else if (chunkX == 90 && chunkZ == 30) {
         this.generateCelestialMaze(chunkX, chunkZ);
      }
   }

   private void generateCelestialMaze(int chunkX, int chunkZ) {
      int posX = chunkX * 16;
      int posZ = chunkZ * 16;
      new WorldGenStructure("celestialmaze/celestialmazep1").generate(this.world, this.rand, new BlockPos(posX, 30, posZ));
      new WorldGenStructure("celestialmaze/celestialmazep2").generate(this.world, this.rand, new BlockPos(posX + 32, 30, posZ));
      new WorldGenStructure("celestialmaze/celestialmazep3").generate(this.world, this.rand, new BlockPos(posX, 62, posZ));
      new WorldGenStructure("celestialmaze/celestialmazep4").generate(this.world, this.rand, new BlockPos(posX + 32, 62, posZ));
      new WorldGenStructure("celestialmaze/celestialmazep5").generate(this.world, this.rand, new BlockPos(posX, 30, posZ + 32));
      new WorldGenStructure("celestialmaze/celestialmazep6").generate(this.world, this.rand, new BlockPos(posX + 32, 30, posZ + 32));
      new WorldGenStructure("celestialmaze/celestialmazep7").generate(this.world, this.rand, new BlockPos(posX, 62, posZ + 32));
      new WorldGenStructure("celestialmaze/celestialmazep8").generate(this.world, this.rand, new BlockPos(posX + 32, 62, posZ + 32));
      new WorldGenStructure("celestialmaze/celestialmazep9").generate(this.world, this.rand, new BlockPos(posX + 19, 94, posZ + 26));
      new WorldGenStructure("celestialmaze/celestialmazep10").generate(this.world, this.rand, new BlockPos(posX + 7, 63, posZ - 34));
      new WorldGenStructure("celestialmaze/celestialmazep11").generate(this.world, this.rand, new BlockPos(posX + 39, 63, posZ - 34));
      new WorldGenStructure("celestialmaze/celestialmazep12").generate(this.world, this.rand, new BlockPos(posX + 39, 63, posZ - 52));
      new WorldGenStructure("celestialmaze/celestialmazep13").generate(this.world, this.rand, new BlockPos(posX + 7, 63, posZ - 52));
   }

   private void generateTrialArena(int chunkX, int chunkZ) {
      int posX = chunkX * 16;
      int posZ = chunkZ * 16;
      new WorldGenStructure("trials/trial_arena_p1").generate(this.world, this.rand, new BlockPos(posX, 30, posZ));
      new WorldGenStructure("trials/trial_arena_p2").generate(this.world, this.rand, new BlockPos(posX + 32, 30, posZ));
      new WorldGenStructure("trials/trial_arena_p3").generate(this.world, this.rand, new BlockPos(posX, 62, posZ));
      new WorldGenStructure("trials/trial_arena_p4").generate(this.world, this.rand, new BlockPos(posX + 32, 62, posZ));
      new WorldGenStructure("trials/trial_arena_p5").generate(this.world, this.rand, new BlockPos(posX, 30, posZ + 32));
      new WorldGenStructure("trials/trial_arena_p6").generate(this.world, this.rand, new BlockPos(posX + 32, 30, posZ + 32));
      new WorldGenStructure("trials/trial_arena_p7").generate(this.world, this.rand, new BlockPos(posX, 62, posZ + 32));
      new WorldGenStructure("trials/trial_arena_p8").generate(this.world, this.rand, new BlockPos(posX + 32, 62, posZ + 32));
      new WorldGenStructure("trials/trial_arena_p9").generate(this.world, this.rand, new BlockPos(posX + 19, 94, posZ + 26));
      new WorldGenStructure("trials/trial_arena_p10").generate(this.world, this.rand, new BlockPos(posX + 19, 32, posZ - 25));
      new WorldGenStructure("trials/trial_arena_p11").generate(this.world, this.rand, new BlockPos(posX + 19, 57, posZ - 34));
      new WorldGenStructure("trials/trial_arena_p12").generate(this.world, this.rand, new BlockPos(posX - 3, 60, posZ - 66));
      new WorldGenStructure("trials/trial_arena_p13").generate(this.world, this.rand, new BlockPos(posX + 29, 60, posZ - 66));
      new WorldGenStructure("trials/trial_arena_p14").generate(this.world, this.rand, new BlockPos(posX - 3, 60, posZ - 90));
      new WorldGenStructure("trials/trial_arena_p15").generate(this.world, this.rand, new BlockPos(posX + 29, 60, posZ - 90));
   }

   private void generateDeviationArena(int chunkX, int chunkZ) {
      int posX = chunkX * 16;
      int posZ = chunkZ * 16;
      new WorldGenStructure("deviation/deviation_arena_p1").generate(this.world, this.rand, new BlockPos(posX, 30, posZ));
      new WorldGenStructure("deviation/deviation_arena_p2").generate(this.world, this.rand, new BlockPos(posX + 32, 30, posZ));
      new WorldGenStructure("deviation/deviation_arena_p3").generate(this.world, this.rand, new BlockPos(posX, 62, posZ));
      new WorldGenStructure("deviation/deviation_arena_p4").generate(this.world, this.rand, new BlockPos(posX + 32, 62, posZ));
      new WorldGenStructure("deviation/deviation_arena_p5").generate(this.world, this.rand, new BlockPos(posX, 30, posZ + 32));
      new WorldGenStructure("deviation/deviation_arena_p6").generate(this.world, this.rand, new BlockPos(posX + 32, 30, posZ + 32));
      new WorldGenStructure("deviation/deviation_arena_p7").generate(this.world, this.rand, new BlockPos(posX, 62, posZ + 32));
      new WorldGenStructure("deviation/deviation_arena_p8").generate(this.world, this.rand, new BlockPos(posX + 32, 62, posZ + 32));
      new WorldGenStructure("deviation/deviation_arena_p9").generate(this.world, this.rand, new BlockPos(posX + 19, 94, posZ + 26));
      new WorldGenStructure("deviation/deviation_arena_p10").generate(this.world, this.rand, new BlockPos(posX + 19, 32, posZ - 25));
      new WorldGenStructure("deviation/deviation_arena_p11").generate(this.world, this.rand, new BlockPos(posX + 19, 57, posZ - 34));
      new WorldGenStructure("deviation/deviation_arena_p12").generate(this.world, this.rand, new BlockPos(posX - 3, 60, posZ - 66));
      new WorldGenStructure("deviation/deviation_arena_p13").generate(this.world, this.rand, new BlockPos(posX + 29, 60, posZ - 66));
      new WorldGenStructure("deviation/deviation_arena_p14").generate(this.world, this.rand, new BlockPos(posX - 3, 60, posZ - 90));
      new WorldGenStructure("deviation/deviation_arena_p15").generate(this.world, this.rand, new BlockPos(posX + 29, 60, posZ - 90));
   }

   private void generateGrandArena(int chunkX, int chunkZ) {
      new WorldGenStructure("grandarena/celestialarenap1").generate(this.world, this.rand, new BlockPos(chunkX, 30, chunkZ));
      new WorldGenStructure("grandarena/celestialarenap2").generate(this.world, this.rand, new BlockPos(chunkX + 32, 30, chunkZ));
      new WorldGenStructure("grandarena/celestialarenap3").generate(this.world, this.rand, new BlockPos(chunkX, 62, chunkZ));
      new WorldGenStructure("grandarena/celestialarenap4").generate(this.world, this.rand, new BlockPos(chunkX + 32, 62, chunkZ));
      new WorldGenStructure("grandarena/celestialarenap5").generate(this.world, this.rand, new BlockPos(chunkX, 30, chunkZ + 32));
      new WorldGenStructure("grandarena/celestialarenap6").generate(this.world, this.rand, new BlockPos(chunkX + 32, 30, chunkZ + 32));
      new WorldGenStructure("grandarena/celestialarenap7").generate(this.world, this.rand, new BlockPos(chunkX, 62, chunkZ + 32));
      new WorldGenStructure("grandarena/celestialarenap8").generate(this.world, this.rand, new BlockPos(chunkX + 32, 62, chunkZ + 32));
      new WorldGenStructure("grandarena/celestialarenap9").generate(this.world, this.rand, new BlockPos(chunkX + 19, 94, chunkZ + 26));
      new WorldGenStructure("grandarena/celestialarenap10").generate(this.world, this.rand, new BlockPos(chunkX + 19, 32, chunkZ - 25));
      new WorldGenStructure("grandarena/celestialarenap11").generate(this.world, this.rand, new BlockPos(chunkX + 19, 57, chunkZ - 34));
      new WorldGenStructure("grandarena/celestialarenap12").generate(this.world, this.rand, new BlockPos(chunkX - 3, 60, chunkZ - 66));
      new WorldGenStructure("grandarena/celestialarenap13").generate(this.world, this.rand, new BlockPos(chunkX + 29, 60, chunkZ - 66));
      new WorldGenStructure("grandarena/celestialarenap14").generate(this.world, this.rand, new BlockPos(chunkX - 3, 60, chunkZ - 98));
      new WorldGenStructure("grandarena/celestialarenap15").generate(this.world, this.rand, new BlockPos(chunkX + 29, 60, chunkZ - 98));
      new WorldGenStructure("grandarena/celestialarenap16").generate(this.world, this.rand, new BlockPos(chunkX - 3, 60, chunkZ - 130));
      new WorldGenStructure("grandarena/celestialarenap17").generate(this.world, this.rand, new BlockPos(chunkX + 29, 60, chunkZ - 130));
      new WorldGenStructure("grandarena/celestialarenap18").generate(this.world, this.rand, new BlockPos(chunkX - 3, 60, chunkZ - 153));
      new WorldGenStructure("grandarena/celestialarenap19").generate(this.world, this.rand, new BlockPos(chunkX + 29, 60, chunkZ - 153));
      new WorldGenStructure("grandarena/arenaextraroom1").generate(this.world, this.rand, new BlockPos(chunkX, 60, chunkZ - 180));
      new WorldGenStructure("grandarena/arenaextraroom2").generate(this.world, this.rand, new BlockPos(chunkX + 20, 60, chunkZ - 180));
      new WorldGenStructure("grandarena/arenaextraroom3").generate(this.world, this.rand, new BlockPos(chunkX + 40, 60, chunkZ - 180));
   }
}
