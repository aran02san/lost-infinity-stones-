package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.mob.entity.base.EntityImmaterial;
import xol.lostinfinity.projectile.entity.EntityPoisonousBubble;
import xol.lostinfinity.util.data.IMaxAttack;

public class BlockAcidicConcoctionGel extends Block implements IMaxAttack {
   protected static final AxisAlignedBB CARPET_AABB = new AxisAlignedBB(0.0, 0.0, 0.0, 1.0, 0.0625, 1.0);

   public BlockAcidicConcoctionGel(String name, float hardness, Material material) {
      this(name, hardness, material, TabsInit.TAB_BLOCKS);
   }

   public BlockAcidicConcoctionGel(String name, float hardness, Material material, CreativeTabs tab) {
      super(material);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setCreativeTab(tab);
      this.setBlockUnbreakable();
      this.setSoundType(SoundType.SLIME);
      this.setTickRandomly(true);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public AxisAlignedBB getBoundingBox(IBlockState state, IBlockAccess source, BlockPos pos) {
      return CARPET_AABB;
   }

   public boolean isOpaqueCube(IBlockState state) {
      return false;
   }

   public boolean isFullCube(IBlockState state) {
      return false;
   }

   public boolean canPlaceBlockAt(World worldIn, BlockPos pos) {
      return super.canPlaceBlockAt(worldIn, pos) && this.canBlockStay(worldIn, pos);
   }

   public void neighborChanged(IBlockState state, World worldIn, BlockPos pos, Block blockIn, BlockPos fromPos) {
      this.checkForDrop(worldIn, pos, state);
   }

   public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn) {
      if (!worldIn.isRemote && entityIn instanceof EntityLivingBase && !(entityIn instanceof EntityImmaterial) && entityIn.ticksExisted % 4 == 2) {
         if (entityIn instanceof EntityPlayer && ((EntityPlayer)entityIn).isPotionActive(PotionInit.ACIDIC)) {
            return;
         }

         IMaxAttack.dealPotionDamage((EntityLivingBase)entityIn, ((EntityLivingBase)entityIn).getMaxHealth() / 10.0F);
      }
   }

   public void getDrops(NonNullList<ItemStack> drops, IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
      drops.clear();
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      if (rand.nextBoolean()) {
         worldIn.setBlockState(pos, Blocks.AIR.getDefaultState());
      } else {
         releasePoison(worldIn, pos);
      }
   }

   private static void releasePoison(World worldIn, BlockPos pos) {
      if (!worldIn.isRemote) {
         int radius = 2;

         for (BlockPos poisonPos : BlockPos.getAllInBox(pos.add(-radius, -radius, -radius), pos.add(radius, radius, radius))) {
            if (worldIn.getBlockState(poisonPos).equals(BlockInit.acidicConcoctionGel.getDefaultState()) && worldIn.rand.nextInt(3) == 0) {
               for (int i = 0; i < 2; i++) {
                  EntityPoisonousBubble bubble = new EntityPoisonousBubble(worldIn);
                  bubble.setPositionAndUpdate(
                     poisonPos.getX() + worldIn.rand.nextDouble() * 0.5 - 0.25,
                     poisonPos.getY() + 0.2F,
                     poisonPos.getZ() + worldIn.rand.nextDouble() * 0.5 - 0.25
                  );
                  bubble.shoot(0.0, 1.0, 0.0, 0.2F, 3.0F);
                  worldIn.spawnEntity(bubble);
               }
            }
         }
      }
   }

   private boolean checkForDrop(World worldIn, BlockPos pos, IBlockState state) {
      if (!this.canBlockStay(worldIn, pos)) {
         worldIn.setBlockToAir(pos);
         return false;
      } else {
         return true;
      }
   }

   private boolean canBlockStay(World worldIn, BlockPos pos) {
      return !worldIn.isAirBlock(pos.down());
   }

   @SideOnly(Side.CLIENT)
   public boolean shouldSideBeRendered(IBlockState blockState, IBlockAccess blockAccess, BlockPos pos, EnumFacing side) {
      if (side == EnumFacing.UP) {
         return true;
      } else {
         return blockAccess.getBlockState(pos.offset(side)).getBlock() == this ? true : super.shouldSideBeRendered(blockState, blockAccess, pos, side);
      }
   }

   public BlockFaceShape getBlockFaceShape(IBlockAccess worldIn, IBlockState state, BlockPos pos, EnumFacing face) {
      return face == EnumFacing.DOWN ? BlockFaceShape.SOLID : BlockFaceShape.UNDEFINED;
   }
}
