package xol.lostinfinity.block.misc;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.init.ItemInit;

public class BlockBlightedCore extends BlockBasicBoolState {
   public BlockBlightedCore(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      if (stack.getItem() == ItemInit.polychargeSolution) {
         if (!worldIn.isRemote) {
            worldIn.setBlockState(pos, this.getStateFromMeta(1));
            worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
         }

         stack.shrink(1);
      }

      return true;
   }
}
