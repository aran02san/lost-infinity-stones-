package xol.lostinfinity.block.misc;

import java.util.ArrayList;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.SoundInit;

public class BlockArchlumioGate extends BlockBasicGlass {
   public BlockArchlumioGate(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
      return NULL_AABB;
   }

   public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn) {
      if (!worldIn.isRemote && entityIn instanceof EntityLivingBase) {
         EntityLivingBase killed = (EntityLivingBase)entityIn;
         if (killed.getHealth() > 0.0F) {
            killed.setHealth(0.0F);
            worldIn.playSound(null, pos, SoundInit.SCANNER, SoundCategory.MASTER, 1.0F, 1.0F);
         }
      }
   }

   public void propogatePass(World worldIn, BlockPos pos, ArrayList<BlockPos> visited) {
      if (visited == null) {
         visited = new ArrayList<>();
      }

      if (!visited.contains(pos)) {
         visited.add(pos);
         worldIn.setBlockState(pos, BlockInit.archlumioGatePass.getDefaultState());

         for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
               for (int k = -1; k <= 1; k++) {
                  if (i != 0 || j != 0 || k != 0) {
                     BlockPos check = pos.add(i, j, k);
                     Block block = worldIn.getBlockState(check).getBlock();
                     if (block.equals(BlockInit.archlumioGate)) {
                        ((BlockArchlumioGate)block).propogatePass(worldIn, check, visited);
                     }
                  }
               }
            }
         }
      }
   }
}
