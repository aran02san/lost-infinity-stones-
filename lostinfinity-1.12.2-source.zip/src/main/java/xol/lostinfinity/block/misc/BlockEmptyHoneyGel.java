package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicNoCollide;
import xol.lostinfinity.init.BlockInit;

public class BlockEmptyHoneyGel extends BlockBasicNoCollide {
   public BlockEmptyHoneyGel(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         boolean foundEntity = false;

         for (EntityLivingBase any : world.getEntitiesWithinAABB(EntityLivingBase.class, new AxisAlignedBB(pos))) {
            foundEntity = true;
         }

         if (!foundEntity) {
            world.setBlockState(pos, BlockInit.honeyGel.getDefaultState());
         }
      }
   }
}
