package xol.lostinfinity.block.misc;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.basic.BlockBasicRotational;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockLaunchCoordinator extends BlockBasicRotational {
   private int coord_color;
   private int coord_shape;

   public BlockLaunchCoordinator(String name, int color, int shape) {
      super(name);
      this.setLightLevel(1.0F);
      this.coord_color = color;
      this.coord_shape = shape;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         ItemStack held = playerIn.getHeldItem(hand);
         boolean flag = false;
         if (held.getItem().equals(ItemInit.configurationCellColor)) {
            flag = true;
            if (!worldIn.isRemote) {
               boolean run = true;

               while (run) {
                  BlockLaunchCoordinator newBlock = (BlockLaunchCoordinator)getRandomCoordinator(worldIn);
                  if (newBlock.getShape() == this.getShape() && newBlock.getColor() != this.getColor()) {
                     worldIn.setBlockState(pos, newBlock.getStateFromMeta(this.getMetaFromState(state)));
                     run = false;
                  }
               }
            }
         } else if (held.getItem().equals(ItemInit.configurationCellShape)) {
            flag = true;
            if (!worldIn.isRemote) {
               boolean run = true;

               while (run) {
                  BlockLaunchCoordinator newBlock = (BlockLaunchCoordinator)getRandomCoordinator(worldIn);
                  if (newBlock.getColor() == this.getColor() && newBlock.getShape() != this.getShape()) {
                     worldIn.setBlockState(pos, newBlock.getStateFromMeta(this.getMetaFromState(state)));
                     run = false;
                  }
               }
            }
         }

         if (flag) {
            held.shrink(1);
            worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_PLACE, SoundCategory.MASTER, 1.0F, 1.0F);
         }
      }

      return true;
   }

   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
      if (!worldIn.isRemote && placer instanceof EntityPlayer) {
         worldIn.setBlockState(pos, getRandomCoordinator(worldIn).getDefaultState());
      }
   }

   public int getColor() {
      return this.coord_color;
   }

   public int getShape() {
      return this.coord_shape;
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return null;
   }

   private static Block getRandomCoordinator(World worldIn) {
      Block[] coord = new Block[]{
         BlockInit.launchCoordinatorBlue1,
         BlockInit.launchCoordinatorBlue3,
         BlockInit.launchCoordinatorBlue4,
         BlockInit.launchCoordinatorBlue5,
         BlockInit.launchCoordinatorPurple1,
         BlockInit.launchCoordinatorPurple3,
         BlockInit.launchCoordinatorPurple4,
         BlockInit.launchCoordinatorPurple5,
         BlockInit.launchCoordinatorGreen1,
         BlockInit.launchCoordinatorGreen3,
         BlockInit.launchCoordinatorGreen4,
         BlockInit.launchCoordinatorGreen5,
         BlockInit.launchCoordinatorRed1,
         BlockInit.launchCoordinatorRed3,
         BlockInit.launchCoordinatorRed4,
         BlockInit.launchCoordinatorRed5
      };
      int block = worldIn.rand.nextInt(coord.length);
      return coord[block];
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Gold + "Becomes a random launch coordinator when placed.");
      tooltip.add(TextFmt.Red + "Drops nothing when mined.");
   }
}
