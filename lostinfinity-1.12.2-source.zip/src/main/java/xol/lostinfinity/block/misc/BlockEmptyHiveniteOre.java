package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockEmptyHiveniteOre extends BlockBasic {
   public BlockEmptyHiveniteOre(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         world.setBlockState(pos, BlockInit.hivenite.getDefaultState());
      }
   }
}
