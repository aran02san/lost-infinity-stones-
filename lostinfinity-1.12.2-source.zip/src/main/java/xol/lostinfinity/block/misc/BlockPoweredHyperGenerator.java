package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.mob.entity.misc.EntityTornIndividual;

public class BlockPoweredHyperGenerator extends BlockBasic {
   public BlockPoweredHyperGenerator(String name) {
      super(name);
      this.setLightLevel(1.0F);
      this.setTickRandomly(true);
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      if (!worldIn.isRemote) {
         worldIn.setBlockState(pos, BlockInit.hyperGeneratorUnpowered.getDefaultState());
         EntityTornIndividual torn = new EntityTornIndividual(worldIn);
         torn.setPosition(pos.getX(), pos.getY() + 1, pos.getZ());
         worldIn.spawnEntity(torn);
      }
   }
}
