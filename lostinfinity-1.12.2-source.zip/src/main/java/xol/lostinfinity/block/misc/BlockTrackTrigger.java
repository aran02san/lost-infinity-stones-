package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantBlaze;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantCreeper;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantDimTrader;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantEnderman;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantPiglin;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSkeleton;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantSpider;
import xol.lostinfinity.mob.entity.deviant.EntityDeviantStray;

public class BlockTrackTrigger extends BlockBasicLight {
   private int active_num = 0;

   public BlockTrackTrigger(String name, int triggernum) {
      super(name);
      this.active_num = triggernum;
      BlockInit.TRIGGER_BLOCKS.add(this);
   }

   public void trigger(World world, BlockPos pos) {
      if (!world.isRemote) {
         switch (this.active_num) {
            case 0:
               EntityDeviantCreeper Creeper = new EntityDeviantCreeper(world);
               Creeper.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Creeper);
               break;
            case 1:
               EntityDeviantSkeleton Skeleton = new EntityDeviantSkeleton(world);
               Skeleton.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Skeleton);
               break;
            case 2:
               EntityDeviantStray Stray = new EntityDeviantStray(world);
               Stray.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Stray);
               break;
            case 3:
               EntityDeviantPiglin Piglin = new EntityDeviantPiglin(world);
               Piglin.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Piglin);
               break;
            case 4:
               EntityDeviantEnderman Enderman = new EntityDeviantEnderman(world);
               Enderman.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Enderman);
               break;
            case 5:
               EntityDeviantSpider Spider = new EntityDeviantSpider(world);
               Spider.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Spider);
               break;
            case 6:
               EntityDeviantBlaze Blaze = new EntityDeviantBlaze(world);
               Blaze.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Blaze);
               break;
            case 7:
               EntityDeviantDimTrader Dimtrader = new EntityDeviantDimTrader(world);
               Dimtrader.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
               world.spawnEntity(Dimtrader);
               break;
            case 8:
               if (world.rand.nextBoolean()) {
                  EntityDeviantBlaze DevBlaze = new EntityDeviantBlaze(world);
                  DevBlaze.setPosition(pos.getX(), pos.getY() + 2, pos.getZ());
                  DevBlaze.setMutation(2);
                  world.spawnEntity(DevBlaze);
               } else {
                  EntityItem crystalx = new EntityItem(
                     world,
                     pos.getX(),
                     pos.getY() + 3,
                     pos.getZ(),
                     new ItemStack(ItemInit.crystallizedAlloy, 2 + world.rand.nextInt(3))
                  );
                  crystalx.motionX = 0.0;
                  crystalx.motionY = 0.0;
                  crystalx.motionZ = 0.0;
                  world.spawnEntity(crystalx);
               }
               break;
            case 9:
               EntityItem crystal = new EntityItem(
                  world,
                  pos.getX(),
                  pos.getY() + 3,
                  pos.getZ(),
                  new ItemStack(ItemInit.masterForgedIngot, 5 + world.rand.nextInt(5))
               );
               crystal.motionX = 0.0;
               crystal.motionY = 0.0;
               crystal.motionZ = 0.0;
               world.spawnEntity(crystal);
         }
      }
   }

   public static Block randomTriggerBlock(Random rand) {
      return BlockInit.TRIGGER_BLOCKS.get(rand.nextInt(BlockInit.TRIGGER_BLOCKS.size()));
   }
}
