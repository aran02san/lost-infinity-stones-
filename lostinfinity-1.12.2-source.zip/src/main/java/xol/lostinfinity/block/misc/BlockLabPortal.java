package xol.lostinfinity.block.misc;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;
import xol.lostinfinity.dimension.util.DimensionActivator;
import xol.lostinfinity.init.DimensionInit;

public class BlockLabPortal extends BlockBasicGlass {
   private int portalLocation = 0;

   public BlockLabPortal(String name, int portal) {
      super(name);
      this.portalLocation = portal;
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         int bound = 1000;
         int roomRand_X = worldIn.rand.nextInt(bound) - bound / 2;
         int roomRand_Z = worldIn.rand.nextInt(bound) - bound / 2;
         double yPlace;
         if (roomRand_X == roomRand_Z) {
            yPlace = 16.0;
         } else {
            yPlace = 25.0;
         }

         if (this.portalLocation == 0) {
            DimensionActivator.transferEntityWithCoords(playerIn, DimensionInit.cartographerRealmMid, 15 + 160 * roomRand_X, yPlace, 15 + 160 * roomRand_Z);
         } else {
            DimensionActivator.transferEntityWithCoords(playerIn, DimensionInit.cartographerRealmBot, 15 + 160 * roomRand_X, yPlace, 15 + 160 * roomRand_Z);
         }
      }

      return true;
   }
}
