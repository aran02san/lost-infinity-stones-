package xol.lostinfinity.block.misc;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicCrop;
import xol.lostinfinity.block.tileentity.TileEntityKillerVine;

public class BlockKillerVine extends BlockBasicCrop implements ITileEntityProvider {
   public BlockKillerVine(String name) {
      super(name);
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityKillerVine();
   }

   public boolean hasTileEntity() {
      return true;
   }

   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
      if (!worldIn.isRemote && this.hasTileEntity) {
         TileEntity tileentity = worldIn.getTileEntity(pos);
         if (tileentity instanceof TileEntityKillerVine) {
            TileEntityKillerVine vineentity = (TileEntityKillerVine)tileentity;
            if (placer instanceof EntityPlayer) {
               vineentity.setPlacer((EntityPlayer)placer);
            }
         }
      }

      super.onBlockPlacedBy(worldIn, pos, state, placer, stack);
   }
}
