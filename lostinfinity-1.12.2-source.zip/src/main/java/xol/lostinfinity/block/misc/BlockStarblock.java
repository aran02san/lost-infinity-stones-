package xol.lostinfinity.block.misc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.mob.entity.misc.EntityStarfiend;

public class BlockStarblock extends BlockBasic {
   public BlockStarblock(String name) {
      super(name);
   }

   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
      if (!worldIn.isRemote && placer instanceof EntityPlayer) {
         List<BlockPos> validBlocks = this.isStructureComplete(worldIn, state.getBlock(), pos);
         if (!validBlocks.isEmpty()) {
            AxisAlignedBB aabb = this.getAxisFromList(validBlocks);

            for (double y = aabb.maxY; y >= aabb.minY; y--) {
               for (double x = aabb.maxX; x >= aabb.minX; x--) {
                  for (double z = aabb.maxZ; z >= aabb.minZ; z--) {
                     worldIn.setBlockToAir(new BlockPos(x, y, z));
                  }
               }
            }

            EntityStarfiend starfiend = new EntityStarfiend(worldIn);
            starfiend.setPosition(pos.getX(), pos.getY(), pos.getZ());
            worldIn.spawnEntity(starfiend);
         }
      }
   }

   private AxisAlignedBB getAxisFromList(List<BlockPos> blocks) {
      int lowx = 0;
      int lowy = 0;
      int lowz = 0;

      for (int i = 0; i < blocks.size(); i++) {
         BlockPos pos = blocks.get(i);
         if (i == 0) {
            lowx = pos.getX();
            lowy = pos.getY();
            lowz = pos.getZ();
         } else {
            if (pos.getX() < lowx) {
               lowx = pos.getX();
            }

            if (pos.getY() < lowy) {
               lowy = pos.getY();
            }

            if (pos.getZ() < lowz) {
               lowz = pos.getZ();
            }
         }
      }

      return new AxisAlignedBB(new BlockPos(lowx, lowy, lowz), new BlockPos(lowx + 5, lowy + 4, lowz + 5));
   }

   private Block getBlockAt(BlockPos pos, World world) {
      return world.getBlockState(pos).getBlock();
   }

   private List<BlockPos> addBlocksToList(List<BlockPos> blocks, BlockPos basePos, int operationType) {
      blocks.add(basePos);
      if (operationType <= 1) {
         for (int i = 1; i <= 4; i++) {
            blocks.add(new BlockPos(basePos).add(operationType == 0 ? i : -i, -1, 0));
            if (i == 2) {
               for (int z = 2; z >= -2; z--) {
                  blocks.add(new BlockPos(basePos).add(operationType == 0 ? i : -i, z != 2 && z != -2 ? -1 : 0, operationType == 0 ? z : -z));
                  if (z == 0) {
                     blocks.add(new BlockPos(basePos).add(operationType == 0 ? i : -i, -2, operationType == 0 ? z : -z));
                     blocks.add(new BlockPos(basePos).add(operationType == 0 ? i : -i, -3, operationType == 0 ? z : -z));
                  }
               }
            }
         }
      } else {
         for (int ix = 1; ix <= 4; ix++) {
            blocks.add(new BlockPos(basePos).add(0, -1, operationType == 2 ? ix : -ix));
            if (ix == 2) {
               for (int zx = 2; zx >= -2; zx--) {
                  blocks.add(new BlockPos(basePos).add(operationType == 2 ? zx : -zx, zx != 2 && zx != -2 ? -1 : 0, operationType == 2 ? ix : -ix));
                  if (zx == 0) {
                     blocks.add(new BlockPos(basePos).add(operationType == 2 ? zx : -zx, -2, operationType == 2 ? ix : -ix));
                     blocks.add(new BlockPos(basePos).add(operationType == 2 ? zx : -zx, -3, operationType == 2 ? ix : -ix));
                  }
               }
            }
         }
      }

      return blocks;
   }

   private List<BlockPos> getValidBlocks(World world, Block block, BlockPos basePos) {
      List<BlockPos> allValidBlocks = new ArrayList<>();
      if (this.getBlockAt(new BlockPos(basePos).add(4, 0, 0), world).equals(block)) {
         allValidBlocks.add(new BlockPos(basePos).add(4, 0, 0));
         return this.addBlocksToList(allValidBlocks, basePos, 0);
      } else if (this.getBlockAt(new BlockPos(basePos).add(-4, 0, 0), world).equals(block)) {
         allValidBlocks.add(new BlockPos(basePos).add(-4, 0, 0));
         return this.addBlocksToList(allValidBlocks, basePos, 1);
      } else if (this.getBlockAt(new BlockPos(basePos).add(0, 0, 4), world).equals(block)) {
         allValidBlocks.add(new BlockPos(basePos).add(0, 0, 4));
         return this.addBlocksToList(allValidBlocks, basePos, 2);
      } else if (this.getBlockAt(new BlockPos(basePos).add(0, 0, -4), world).equals(block)) {
         allValidBlocks.add(new BlockPos(basePos).add(0, 0, -4));
         return this.addBlocksToList(allValidBlocks, basePos, 3);
      } else {
         return allValidBlocks;
      }
   }

   private List<BlockPos> isStructureComplete(World world, Block block, BlockPos pos) {
      List<BlockPos> validBlocks = this.getValidBlocks(world, block, pos);
      if (!validBlocks.isEmpty()) {
         int starblock = 0;
         int redstone = 0;

         for (int i = 0; i < validBlocks.size(); i++) {
            Block b = world.getBlockState(validBlocks.get(i)).getBlock();
            if (b.equals(block)) {
               starblock++;
            } else if (b.equals(Blocks.MAGMA)) {
               redstone++;
            }
         }

         if (starblock == 4 && redstone == 9) {
            return validBlocks;
         }

         validBlocks.clear();
      }

      return validBlocks;
   }
}
