package xol.lostinfinity.block.misc;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.init.SoundInit;

public class BlockLaserField extends BlockBasicGlass {
   private int securityLevel = 0;

   public BlockLaserField(String name, int security) {
      super(name);
      this.securityLevel = security;
      this.setLightLevel(1.0F);
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
      return NULL_AABB;
   }

   public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn) {
      if (!worldIn.isRemote) {
         boolean kill = true;
         if (entityIn instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entityIn;
            if (player.isPotionActive(PotionInit.SECURITY_CLEARANCE)) {
               int security_clear = player.getActivePotionEffect(PotionInit.SECURITY_CLEARANCE).getAmplifier() + 1;
               if (security_clear >= this.securityLevel) {
                  kill = false;
               }
            }
         }

         if (kill && entityIn instanceof EntityLivingBase) {
            EntityLivingBase killed = (EntityLivingBase)entityIn;
            if (killed.getHealth() > 0.0F) {
               killed.setHealth(0.0F);
               worldIn.playSound(null, pos, SoundInit.SCANNER, SoundCategory.MASTER, 1.0F, 1.0F);
            }
         }
      }
   }
}
