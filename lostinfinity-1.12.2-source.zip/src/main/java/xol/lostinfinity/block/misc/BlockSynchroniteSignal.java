package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.SoundInit;

public class BlockSynchroniteSignal extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 3);

   public BlockSynchroniteSignal(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public int tickRate(World worldIn) {
      return 3;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         int meta = this.getMetaFromState(state);
         boolean run = true;
         int newMeta = meta;

         while (run) {
            newMeta = worldIn.rand.nextInt(4);
            if (newMeta != meta) {
               run = false;
            }
         }

         worldIn.playSound(
            null, pos.down(), SoundInit.SYNCHRONITE_SWITCH, SoundCategory.BLOCKS, 1.5F, 0.8F + worldIn.rand.nextFloat() * 0.4F
         );
         worldIn.setBlockState(pos, this.getStateFromMeta(newMeta));
      }

      return true;
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int meta = this.getMetaFromState(state);
         boolean run = true;
         int newMeta = meta;

         while (run) {
            newMeta = rand.nextInt(4);
            if (newMeta != meta) {
               run = false;
            }
         }

         world.playSound(null, pos.down(), SoundInit.SYNCHRONITE_SWITCH, SoundCategory.BLOCKS, 1.5F, 0.8F + world.rand.nextFloat() * 0.4F);
         world.setBlockState(pos, this.getStateFromMeta(newMeta));
      }
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public IBlockState getStateWithAmount(int amount) {
      return this.getDefaultState().withProperty(AMOUNT, amount);
   }
}
