package xol.lostinfinity.block.misc;

import xol.lostinfinity.block.basic.BlockBasic;

public class BlockParkourPlatformSlippery extends BlockBasic {
   public BlockParkourPlatformSlippery(String name) {
      super(name);
      this.slipperiness = 0.98F;
   }
}
