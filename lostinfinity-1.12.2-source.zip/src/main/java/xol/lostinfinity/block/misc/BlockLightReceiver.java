package xol.lostinfinity.block.misc;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockLightReceiver extends BlockBasic {
   public BlockLightReceiver(String name) {
      super(name);
   }

   public void openGate(World worldIn, BlockPos pos) {
      for (int i = -1; i <= 1; i++) {
         for (int j = -1; j <= 1; j++) {
            for (int k = -1; k <= 1; k++) {
               if (i != 0 || j != 0 || k != 0) {
                  BlockPos check = pos.add(i, j, k);
                  Block block = worldIn.getBlockState(check).getBlock();
                  if (block.equals(BlockInit.galaxyGate)) {
                     this.propogatePass(worldIn, check, null, 1);
                  }
               }
            }
         }
      }
   }

   public void closeGate(World worldIn, BlockPos pos) {
      for (int i = -1; i <= 1; i++) {
         for (int j = -1; j <= 1; j++) {
            for (int k = -1; k <= 1; k++) {
               if (i != 0 || j != 0 || k != 0) {
                  BlockPos check = pos.add(i, j, k);
                  Block block = worldIn.getBlockState(check).getBlock();
                  if (block.equals(BlockInit.galaxyGate)) {
                     this.propogatePass(worldIn, check, null, 0);
                  }
               }
            }
         }
      }
   }

   public void propogatePass(World worldIn, BlockPos pos, ArrayList<BlockPos> visited, int meta) {
      if (visited == null) {
         visited = new ArrayList<>();
      }

      if (!visited.contains(pos)) {
         visited.add(pos);
         worldIn.setBlockState(pos, BlockInit.galaxyGate.getStateFromMeta(meta));

         for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
               for (int k = -1; k <= 1; k++) {
                  if (i != 0 || j != 0 || k != 0) {
                     BlockPos check = pos.add(i, j, k);
                     Block block = worldIn.getBlockState(check).getBlock();
                     if (block.equals(BlockInit.galaxyGate)) {
                        this.propogatePass(worldIn, check, visited, meta);
                     }
                  }
               }
            }
         }
      }
   }
}
