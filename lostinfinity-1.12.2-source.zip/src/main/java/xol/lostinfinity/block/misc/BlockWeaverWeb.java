package xol.lostinfinity.block.misc;

import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import xol.lostinfinity.block.basic.BlockBasicPlant;
import xol.lostinfinity.block.basic.ITetherable;

public class BlockWeaverWeb extends BlockBasicPlant implements ITetherable {
   public BlockWeaverWeb(String name) {
      super(name, Material.WEB);
      this.setSoundType(SoundType.CLOTH);
   }
}
