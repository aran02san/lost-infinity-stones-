package xol.lostinfinity.block.misc;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.block.basic.ITargetable;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerTargets;
import xol.lostinfinity.util.coordinates.ContestCoordinates;

public class BlockTarget extends BlockBasicBoolState implements ITargetable {
   public BlockTarget(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   @Override
   public void targetedResult(World worldIn, EntityPlayer playerIn, BlockPos pos) {
      for (EntityControllerTargets controller : worldIn.getEntitiesWithinAABB(EntityControllerTargets.class, ContestCoordinates.targetsArenaAABB())) {
         controller.scoreTarget(pos);
      }
   }

   public IBlockState getActiveState() {
      return this.getDefaultState().withProperty(ACTIVE, true);
   }

   public IBlockState getInactiveState() {
      return this.getDefaultState().withProperty(ACTIVE, false);
   }
}
