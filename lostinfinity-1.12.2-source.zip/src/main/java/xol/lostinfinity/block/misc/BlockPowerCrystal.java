package xol.lostinfinity.block.misc;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockPowerCrystal extends BlockBasic {
   public BlockPowerCrystal(String name) {
      super(name, Material.ROCK);
   }

   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
      if (!worldIn.isRemote && placer instanceof EntityPlayer) {
         int place_case = this.powerCoordsCorrect(worldIn, state.getBlock(), pos);
         if (place_case == 0) {
            worldIn.setBlockState(pos, Blocks.AIR.getDefaultState());
            if (!((EntityPlayer)placer).isCreative()) {
               placer.dropItem(state.getBlock().getItem(worldIn, pos, state).getItem(), 1);
            }
         } else if (place_case == 2) {
            worldIn.setBlockToAir(pos);
            BlockPos teleport = this.telePos(state.getBlock());
            placer.setPositionAndUpdate(teleport.getX(), teleport.getY(), teleport.getZ());
         }
      }
   }

   private BlockPos telePos(Block block) {
      if (block.equals(BlockInit.powerBlockBlue)) {
         return new BlockPos(767, 32, 357);
      } else if (block.equals(BlockInit.powerBlockYellow)) {
         return new BlockPos(767, 32, 363);
      } else if (block.equals(BlockInit.powerBlockPurple)) {
         return new BlockPos(784, 32, 363);
      } else {
         return block.equals(BlockInit.powerBlockGreen) ? new BlockPos(784, 32, 363) : new BlockPos(784, 24, 355);
      }
   }

   private int powerCoordsCorrect(World world, Block block, BlockPos pos) {
      BlockPos below = pos.down();
      if (world.getBlockState(below).getBlock() == BlockInit.powerKeyBlock) {
         return this.powerGateComplete(world, block, pos) ? 2 : 1;
      } else {
         return 0;
      }
   }

   private boolean powerGateComplete(World wl, Block blockcheck, BlockPos pos) {
      List<BlockPos> memory = new ArrayList<>();
      int otherRow = -2;
      if (wl.getBlockState(pos.up()).getBlock() == BlockInit.powerKeyBlock) {
         otherRow = 2;
      }

      int keycount = 0;
      int offset = 0;
      boolean keepGoing = true;

      while (keepGoing) {
         BlockPos testpos = pos.down().add(0, 0, --offset);
         if (wl.getBlockState(testpos).getBlock() == BlockInit.powerKeyBlock) {
            if (wl.getBlockState(testpos.up()).getBlock() == blockcheck) {
               keycount++;
               memory.add(testpos.up());
            } else {
               keepGoing = false;
            }
         } else {
            keepGoing = false;
         }
      }

      keepGoing = true;
      offset = 0;

      while (keepGoing) {
         BlockPos testpos = pos.down().add(0, 0, ++offset);
         if (wl.getBlockState(testpos).getBlock() == BlockInit.powerKeyBlock) {
            if (wl.getBlockState(testpos.up()).getBlock() == blockcheck) {
               keycount++;
               memory.add(testpos.up());
            } else {
               keepGoing = false;
            }
         } else {
            keepGoing = false;
         }
      }

      keepGoing = true;
      offset = 0;

      while (keepGoing) {
         BlockPos testpos = pos.down().add(0, otherRow, ++offset);
         if (wl.getBlockState(testpos).getBlock() == BlockInit.powerKeyBlock) {
            if (wl.getBlockState(testpos.up()).getBlock() == blockcheck) {
               keycount++;
               memory.add(testpos.up());
            } else {
               keepGoing = false;
            }
         } else {
            keepGoing = false;
         }
      }

      keepGoing = true;

      for (int var13 = 0; keepGoing; var13--) {
         BlockPos testpos = pos.down().add(0, otherRow, var13);
         if (wl.getBlockState(testpos).getBlock() == BlockInit.powerKeyBlock) {
            if (wl.getBlockState(testpos.up()).getBlock() == blockcheck) {
               keycount++;
               memory.add(testpos.up());
            } else {
               keepGoing = false;
            }
         } else {
            keepGoing = false;
         }
      }

      if (keycount >= 7) {
         for (BlockPos rem : memory) {
            wl.setBlockToAir(rem);
         }
      }

      return keycount >= 7;
   }
}
