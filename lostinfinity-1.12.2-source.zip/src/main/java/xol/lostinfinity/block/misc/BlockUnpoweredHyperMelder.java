package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockUnpoweredHyperMelder extends BlockBasic {
   public BlockUnpoweredHyperMelder(String name) {
      super(name);
      this.setLightLevel(1.0F);
      this.setTickRandomly(true);
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      if (!worldIn.isRemote) {
         int generators = 0;

         for (int addX = -9; addX < 9; addX++) {
            for (int addZ = -9; addZ < 9; addZ++) {
               BlockPos testPos = new BlockPos(pos.add(addX, -1, addZ));
               if (worldIn.getBlockState(testPos).getBlock() == BlockInit.hyperGeneratorPowered) {
                  generators++;
               }
            }
         }

         if (generators >= 8) {
            worldIn.setBlockState(pos, BlockInit.hyperMelderPowered.getDefaultState());
         }
      }
   }
}
