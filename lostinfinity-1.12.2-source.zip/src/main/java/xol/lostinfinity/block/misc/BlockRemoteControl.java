package xol.lostinfinity.block.misc;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityRemoteControl;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.item.basics.ItemRemoteControl;

public class BlockRemoteControl extends BlockBasic {
   public BlockRemoteControl(String name) {
      super(name);
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityRemoteControl();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         ItemStack held = playerIn.getHeldItem(hand);
         if (held.getItem() instanceof ItemRemoteControl) {
            ItemRemoteControl control = (ItemRemoteControl)held.getItem();
            if (control.getControlBlock() == worldIn.getBlockState(pos).getBlock()) {
               if (!held.hasTagCompound()) {
                  held.setTagCompound(new NBTTagCompound());
               }

               TileEntity te = worldIn.getTileEntity(pos);
               if (te != null && te instanceof TileEntityRemoteControl) {
                  TileEntityRemoteControl remTe = (TileEntityRemoteControl)te;
                  if (remTe.getPlacerID() == null) {
                     remTe.setPlacer(playerIn);
                  }

                  if (remTe.getPlacerID().equals(playerIn.getUniqueID())) {
                     held.getTagCompound().setDouble("BlockStoredX", pos.getX());
                     held.getTagCompound().setDouble("BlockStoredY", pos.getY());
                     held.getTagCompound().setDouble("BlockStoredZ", pos.getZ());
                     playerIn.sendMessage(
                        new TextComponentString(TextFmt.Gold + "Remote bound to " + pos.getX() + "," + pos.getY() + "," + pos.getZ())
                     );
                  }
               } else {
                  playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Improper Tile Entity found here. Replace block."));
               }
            }
         }
      }

      return true;
   }
}
