package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockCappedPlant;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockEtherstock extends BlockCappedPlant {
   public BlockEtherstock(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      if (stack.getItem() == ItemInit.magicBiopowder) {
         this.grow(worldIn, pos);
         if (!worldIn.isRemote) {
            worldIn.playSound(null, pos, SoundInit.MAGIC_POWDER, SoundCategory.MASTER, 1.0F, 1.0F);
         }

         stack.shrink(1);
      } else if (!worldIn.isRemote && this.getMetaFromState(worldIn.getBlockState(pos)) == 1) {
         for (BlockPos down = pos; worldIn.getBlockState(down).getBlock() instanceof BlockEtherstock; down = down.down()) {
            worldIn.setBlockToAir(down);
         }

         EntityItem ether = new EntityItem(worldIn, pos.getX(), pos.getY(), pos.getZ(), new ItemStack(ItemInit.etherflower, 1));
         ether.motionX = 0.0;
         ether.motionY = 0.0;
         ether.motionZ = 0.0;
         worldIn.spawnEntity(ether);
      }

      return true;
   }

   private void grow(World worldIn, BlockPos pos) {
      if (!worldIn.isRemote) {
         if (this.getMetaFromState(worldIn.getBlockState(pos)) == 1) {
            return;
         }

         if (worldIn.isAirBlock(pos.up())) {
            int radius = 48;
            boolean tallest = true;

            for (BlockPos checkPos : BlockPos.getAllInBox(pos.add(-radius, 0, -radius), pos.add(radius, 0, radius))) {
               if (!checkPos.equals(pos) && !worldIn.isAirBlock(checkPos)) {
                  tallest = false;
                  break;
               }
            }

            if (tallest) {
               worldIn.setBlockState(pos, this.getStateFromMeta(1));
            } else {
               worldIn.setBlockState(pos.up(), this.getStateFromMeta(0));
            }
         }
      }
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      this.grow(worldIn, pos);
   }
}
