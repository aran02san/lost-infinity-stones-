package xol.lostinfinity.block.misc;

import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityVoidVacuum;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.activate.ItemElasticThread;

public class BlockVoidVacuum extends BlockBasic implements ITileEntityProvider {
   public BlockVoidVacuum(String name) {
      super(name);
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityVoidVacuum();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         ItemStack held = playerIn.getHeldItem(hand);
         if (!held.hasTagCompound()) {
            held.setTagCompound(new NBTTagCompound());
         }

         if (held.getItem() instanceof ItemElasticThread) {
            if (held.getTagCompound().hasUniqueId("PlayerID")) {
               UUID pl_id = held.getTagCompound().getUniqueId("PlayerID");
               if (pl_id != null) {
                  EntityLivingBase target = (EntityLivingBase)worldIn.getMinecraftServer().getEntityFromUuid(pl_id);
                  if (target != null) {
                     Block result_block = state.getBlock();
                     TileEntity tile_entity = worldIn.getTileEntity(pos);
                     if (result_block instanceof BlockVoidVacuum && tile_entity != null && tile_entity instanceof TileEntityVoidVacuum) {
                        worldIn.playSound(null, target.getPosition(), SoundInit.GENERIC_BOING, SoundCategory.BLOCKS, 1.5F, 1.0F);
                        worldIn.playSound(null, pos, SoundInit.GENERIC_BOING, SoundCategory.BLOCKS, 1.5F, 1.0F);
                        TileEntityVoidVacuum vacuum = (TileEntityVoidVacuum)tile_entity;
                        vacuum.setTarget(target);
                        vacuum.setActive(true);
                        vacuum.resetPulled();
                        playerIn.setHeldItem(hand, ItemStack.EMPTY);
                     }
                  }
               }
            } else {
               held.getTagCompound().setDouble("VacX", pos.getX());
               held.getTagCompound().setDouble("VacY", pos.getY());
               held.getTagCompound().setDouble("VacZ", pos.getZ());
               playerIn.sendMessage(new TextComponentString(TextFmt.Green + "You have stuck one end of the thread to the vacuum."));
            }
         }
      }

      return true;
   }
}
