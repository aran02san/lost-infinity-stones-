package xol.lostinfinity.block.misc;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;

public class BlockTreadmillTrack extends BlockBasic {
   public BlockTreadmillTrack(String name) {
      super(name);
   }

   public void onEntityWalk(World worldIn, BlockPos pos, Entity entityIn) {
      if (!worldIn.isRemote) {
         entityIn.motionX -= 0.04F;
         entityIn.velocityChanged = true;
      }
   }
}
