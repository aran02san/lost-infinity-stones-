package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicPillar;
import xol.lostinfinity.init.BlockInit;

public class BlockTentacleEyePurpleEmpty extends BlockBasicPillar {
   public BlockTentacleEyePurpleEmpty(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int meta = this.getMetaFromState(world.getBlockState(pos));
         world.setBlockState(pos, BlockInit.purpleTentacleEye.getStateFromMeta(meta));
      }
   }
}
