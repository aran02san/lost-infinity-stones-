package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;

public class BlockLucientOre extends BlockBasicBoolState {
   public BlockLucientOre(String name) {
      super(name);
      this.setTickRandomly(true);
      this.setDefaultState(this.blockState.getBaseState().withProperty(ACTIVE, true));
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      if (!worldIn.isRemote) {
         int meta = this.getMetaFromState(state);
         if (meta == 0) {
            worldIn.setBlockState(pos, this.getStateFromMeta(1));
         }
      }
   }
}
