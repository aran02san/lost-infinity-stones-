package xol.lostinfinity.block.misc;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;

public class BlockPuzzleLava extends BlockBasicGlass {
   public BlockPuzzleLava(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
      return NULL_AABB;
   }

   public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn) {
      if (!worldIn.isRemote && entityIn instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)entityIn;
         if (!player.isCreative() && player.ticksExisted % 5 == 0 && player.getHealth() > 0.0F) {
            player.setHealth(player.getHealth() - player.getMaxHealth() / 6.0F);
         }
      }
   }
}
