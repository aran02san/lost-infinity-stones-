package xol.lostinfinity.block.misc;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockGalaxyPortal extends BlockBasicGlass {
   private int portalLocation = 0;

   public BlockGalaxyPortal(String name, int portal) {
      super(name);
      this.portalLocation = portal;
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote && worldIn.provider.getDimensionType() == DimensionInit.nonexistence) {
         BlockPos teleTo = GalaxyCoordinates.getGalaxyTeleporter(this.portalLocation);
         playerIn.setPositionAndUpdate(teleTo.getX(), teleTo.getY(), teleTo.getZ());
      }

      return true;
   }
}
