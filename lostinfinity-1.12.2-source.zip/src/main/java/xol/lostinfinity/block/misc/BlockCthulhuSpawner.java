package xol.lostinfinity.block.misc;

import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicRotational;
import xol.lostinfinity.block.tileentity.TileEntityCthulhuSpawner;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhu;

public class BlockCthulhuSpawner extends BlockBasicRotational implements ITileEntityProvider {
   public static final int BLOCK_DISTANCE = 30;

   public BlockCthulhuSpawner(String name) {
      super(name);
   }

   @Nullable
   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return new TileEntityCthulhuSpawner();
   }

   public static EnumFacing getFacing(World world, BlockPos pos) {
      IBlockState state = world.getBlockState(pos);
      return state.getBlock() != BlockInit.cthulhuSpawner ? EnumFacing.DOWN : (EnumFacing)state.getValue(FACING);
   }

   public static boolean spawnCthulhu(World world, BlockPos pos) {
      IBlockState state = world.getBlockState(pos);
      if (state.getBlock() != BlockInit.cthulhuSpawner) {
         return false;
      } else {
         BlockPos center = pos.offset(EnumFacing.NORTH, 30);
         BlockPos east = center.offset(EnumFacing.WEST, 30);
         BlockPos south = center.offset(EnumFacing.NORTH, 30);
         BlockPos west = center.offset(EnumFacing.EAST, 30);
         if (getFacing(world, east) == EnumFacing.EAST && getFacing(world, south) == EnumFacing.SOUTH && getFacing(world, west) == EnumFacing.WEST) {
            TileEntityCthulhuSpawner eastSpawner = (TileEntityCthulhuSpawner)world.getTileEntity(east);
            TileEntityCthulhuSpawner southSpawner = (TileEntityCthulhuSpawner)world.getTileEntity(south);
            TileEntityCthulhuSpawner westSpawner = (TileEntityCthulhuSpawner)world.getTileEntity(west);
            if (isValid(eastSpawner) && isValid(southSpawner) && isValid(westSpawner)) {
               eastSpawner.spawned = true;
               southSpawner.spawned = true;
               westSpawner.spawned = true;
               EntityCthulhu cthulhu = new EntityCthulhu(world);
               cthulhu.setPosition(center.getX() + 0.5, center.getY(), center.getZ() + 0.5);
               world.spawnEntity(cthulhu);
               world.playSound(null, cthulhu.getPosition(), SoundInit.TT_PORTAL, SoundCategory.HOSTILE, 1.0F, 1.0F);

               for (EntityPlayer contender : world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(cthulhu.getPosition()).grow(70.0))) {
                  world.playSound(null, contender.getPosition(), SoundInit.TT_PORTAL, SoundCategory.HOSTILE, 1.0F, 1.0F);
               }

               return true;
            } else {
               return false;
            }
         } else {
            return false;
         }
      }
   }

   private static boolean isValid(TileEntityCthulhuSpawner spawner) {
      return spawner != null && spawner.canSpawn();
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.CTHULHU_SPAWNER.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }
}
