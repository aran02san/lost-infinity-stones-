package xol.lostinfinity.block.misc;

import java.util.ArrayList;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.DimensionType;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.basic.ISpecialMurkMeta;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockRiftEntangledTile extends BlockBasic implements ISpecialMurkMeta {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 15);

   public BlockRiftEntangledTile(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote && playerIn.getHeldItem(hand).getItem().equals(ItemInit.powerAnalyzer)) {
         if (worldIn.provider.getDimensionType() == DimensionInit.infiniteMurk) {
            int radius = 5;
            BlockPos zeroPos = null;

            label99:
            for (int i = -radius; i <= radius; i++) {
               for (int j = -radius; j <= radius; j++) {
                  BlockPos check = pos.add(i, 0, j);
                  IBlockState checkState = worldIn.getBlockState(check);
                  if (checkState.getBlock() instanceof BlockRiftEntangledTile && this.getMetaFromState(checkState) == 0) {
                     zeroPos = check;
                     break label99;
                  }
               }
            }

            if (zeroPos != null) {
               ArrayList<Vec3i> positions = new ArrayList<>();
               positions.add(new Vec3i(0, 0, 1));
               positions.add(new Vec3i(0, 0, -1));
               positions.add(new Vec3i(1, 0, 0));
               positions.add(new Vec3i(-1, 0, 0));
               Vec3i dirRight = null;
               Vec3i dirDown = null;

               for (Vec3i position : positions) {
                  IBlockState checkState = worldIn.getBlockState(zeroPos.add(position));
                  if (checkState.getBlock() instanceof BlockRiftEntangledTile) {
                     if (this.getMetaFromState(checkState) == 1 && dirRight == null) {
                        dirRight = position;
                     }

                     if (this.getMetaFromState(checkState) == 4 && dirDown == null) {
                        dirDown = position;
                     }
                  }
               }

               boolean complete = true;
               int meta = 0;
               ArrayList<BlockPos> tiles = new ArrayList<>();

               label77:
               for (int i = 0; i < 4; i++) {
                  for (int jx = 0; jx < 4; jx++) {
                     BlockPos check = zeroPos.add(
                        dirRight.getX() * jx + dirDown.getX() * i, 0, dirRight.getZ() * jx + dirDown.getZ() * i
                     );
                     IBlockState checkState = worldIn.getBlockState(check);
                     if (!(checkState.getBlock() instanceof BlockRiftEntangledTile)) {
                        complete = false;
                        break label77;
                     }

                     if (this.getMetaFromState(checkState) != meta) {
                        complete = false;
                        break label77;
                     }

                     tiles.add(check);
                     meta++;
                  }
               }

               if (complete) {
                  worldIn.playSound(null, pos, SoundInit.MACHINE_CRAFT, SoundCategory.BLOCKS, 1.0F, 1.0F);
                  EntityItem item = new EntityItem(
                     worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.alignedDisc)
                  );
                  item.motionX = 0.0;
                  item.motionY = 0.0;
                  item.motionZ = 0.0;
                  worldIn.spawnEntity(item);

                  for (BlockPos tilePos : tiles) {
                     worldIn.setBlockToAir(tilePos);
                     World overworld = worldIn.getMinecraftServer().getWorld(0);
                     overworld.setBlockToAir(tilePos);
                  }
               }
            }
         } else if (worldIn.provider.getDimensionType() == DimensionType.OVERWORLD) {
            int meta = this.getMetaFromState(state);
            if (meta < 15) {
               meta++;
            } else {
               meta = 0;
            }

            playerIn.sendMessage(new TextComponentString(String.format("This block is showing: Tile %d", meta)));
            worldIn.setBlockState(pos, this.getStateFromMeta(meta));
            worldIn.playSound(null, pos, SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.BLOCKS, 1.0F, 1.0F);
         }
      }

      return true;
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public IBlockState getStateWithAmount(int amount) {
      return this.getDefaultState().withProperty(AMOUNT, amount);
   }

   @Override
   public int getMurkMeta(IBlockState state) {
      int meta = this.getMetaFromState(state);
      switch (meta) {
         case 0:
            return 13;
         case 1:
            return 6;
         case 2:
            return 11;
         case 3:
            return 15;
         case 4:
            return 5;
         case 5:
            return 0;
         case 6:
            return 3;
         case 7:
            return 12;
         case 8:
            return 1;
         case 9:
            return 7;
         case 10:
            return 14;
         case 11:
            return 2;
         case 12:
            return 8;
         case 13:
            return 4;
         case 14:
            return 9;
         case 15:
            return 10;
         default:
            return 0;
      }
   }
}
