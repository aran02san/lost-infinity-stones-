package xol.lostinfinity.block.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockPoweredHyperMelder extends BlockBasic {
   public BlockPoweredHyperMelder(String name) {
      super(name);
      this.setLightLevel(1.0F);
      this.setTickRandomly(true);
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      List<BlockPos> rememberPos = new ArrayList<>();
      if (!worldIn.isRemote) {
         int generators = 0;

         for (int addX = -9; addX < 9; addX++) {
            for (int addZ = -9; addZ < 9; addZ++) {
               BlockPos testPos = new BlockPos(pos.add(addX, -1, addZ));
               if (worldIn.getBlockState(testPos).getBlock() == BlockInit.hyperGeneratorPowered) {
                  generators++;
                  rememberPos.add(testPos);
               }
            }
         }

         if (generators < 8) {
            worldIn.setBlockState(pos, BlockInit.hyperMelderUnpowered.getDefaultState());
         } else {
            AxisAlignedBB aabb = new AxisAlignedBB(pos.add(-2, 0, -2), pos.add(2, 3, 2));
            boolean recycler = false;
            boolean powerBank = false;
            EntityItem reyclerEntity = null;
            EntityItem bankEntity = null;

            for (EntityItem itemEntity : worldIn.getEntitiesWithinAABB(EntityItem.class, aabb)) {
               Item testItem = itemEntity.getItem().getItem();
               if (testItem == ItemInit.clovinitePowerBank && !powerBank) {
                  if (itemEntity.getItem().getCount() >= 10) {
                     bankEntity = itemEntity;
                     powerBank = true;
                  }
               } else if (testItem == ItemInit.electronRecycler && !recycler && itemEntity.getItem().getCount() >= 20) {
                  reyclerEntity = itemEntity;
                  recycler = true;
               }
            }

            if (recycler && powerBank) {
               EntityItem hubItem = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.clovinitePowerHub)
               );
               hubItem.motionX = 0.0;
               hubItem.motionY = 0.0;
               hubItem.motionZ = 0.0;
               worldIn.spawnEntity(hubItem);
               worldIn.playSound(null, pos.up(), SoundInit.SPECIAL_CRAFT, SoundCategory.BLOCKS, 2.0F, 1.0F);
               bankEntity.getItem().shrink(10);
               reyclerEntity.getItem().shrink(20);

               for (BlockPos rep : rememberPos) {
                  worldIn.setBlockState(rep, BlockInit.hyperGeneratorUnpowered.getDefaultState());
               }
            }
         }
      }
   }
}
