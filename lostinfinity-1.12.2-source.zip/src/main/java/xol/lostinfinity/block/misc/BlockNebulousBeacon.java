package xol.lostinfinity.block.misc;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.block.tileentity.TileEntityNebulousBeacon;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;

public class BlockNebulousBeacon extends BlockBasicGui implements ITileEntityProvider {
   private TileEntityNebulousBeacon tileEntity;

   public BlockNebulousBeacon(String name) {
      super(name, Material.ROCK, TabsInit.TAB_BLOCKS);
   }

   public BlockNebulousBeacon(String name, Material material, CreativeTabs tab) {
      super(name, material, tab);
   }

   public TileEntity createTileEntity(World worldIn, IBlockState state) {
      this.tileEntity = new TileEntityNebulousBeacon();
      return this.tileEntity;
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.NEBULOUS_BEACON.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Light_Purple + "When placed, this beacon will charge up an astral generator.");
      tooltip.add(TextFmt.Dark_Purple + "Nebulous Enemies will detect the beacon and attack it.");
      tooltip.add(TextFmt.Gray + "Protect the beacon until it is fully charged to receive the generator.");
   }

   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
      if (this.hasTileEntity(state)) {
         TileEntity brokenTileEntity = worldIn.getTileEntity(pos);
         if (brokenTileEntity instanceof TileEntityNebulousBeacon) {
            worldIn.removeTileEntity(pos);
         }
      }
   }

   public void onBlockPlacedBy(World worldIn, BlockPos pos, IBlockState state, EntityLivingBase placer, ItemStack stack) {
      if (worldIn.isRemote) {
         placer.sendMessage(new TextComponentString(TextFmt.Light_Purple + "The beacon has been placed. Prepare your defenses."));
      } else {
         worldIn.playSound(null, pos.getX(), pos.getY(), pos.getZ(), SoundInit.IMPENDING_DOOM, SoundCategory.PLAYERS, 3.0F, 1.0F);
      }
   }
}
