package xol.lostinfinity.block.misc;

import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.util.damagesource.DeathMessage;

public class BlockNeoshocker extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 2);

   public BlockNeoshocker(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public IBlockState getStateWithAmount(int amount) {
      return this.getDefaultState().withProperty(AMOUNT, amount);
   }

   public void onEntityWalk(World worldIn, BlockPos pos, Entity entityIn) {
      super.onEntityWalk(worldIn, pos, entityIn);
      if (!worldIn.isRemote && entityIn instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)entityIn;
         int shockValue = this.getMetaFromState(worldIn.getBlockState(pos));
         if (shockValue == 2 && !player.isCreative() && player.ticksExisted % 3 == 0 && player.getHealth() > 0.0F) {
            player.setHealth(player.getHealth() - player.getMaxHealth() / 4.0F);
            if (player.getHealth() <= 0.0F) {
               DeathMessage.broadcastDeathMessage(player.getServer(), TextFmt.Red + player.getName() + " was electrocuted.");
            }
         }
      }
   }
}
