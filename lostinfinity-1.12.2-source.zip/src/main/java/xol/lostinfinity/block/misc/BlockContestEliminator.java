package xol.lostinfinity.block.misc;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;

public class BlockContestEliminator extends BlockBasicGlass {
   public BlockContestEliminator(String name) {
      super(name);
   }

   public void onEntityWalk(World worldIn, BlockPos pos, Entity entityIn) {
      if (!worldIn.isRemote) {
         entityIn.setPositionAndUpdate(entityIn.posX, entityIn.posY + 20.0, entityIn.posZ);
      }
   }
}
