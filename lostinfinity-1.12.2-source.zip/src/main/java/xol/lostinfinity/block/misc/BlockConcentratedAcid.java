package xol.lostinfinity.block.misc;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fluids.FluidRegistry;
import net.minecraftforge.fluids.FluidUtil;
import net.minecraftforge.fml.common.eventhandler.Event.Result;
import xol.lostinfinity.block.basic.BlockBasicFluid;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.util.damagesource.LostDamageSources;
import xol.lostinfinity.util.data.IMaxAttack;

public class BlockConcentratedAcid extends BlockBasicFluid implements IMaxAttack {
   public BlockConcentratedAcid(String name, Fluid fluid, Material material) {
      super(name, fluid, material);
      BlockInit.BLOCKS.add(this);
   }

   public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn) {
      boolean isImmuneToAcid = false;
      if (!isImmuneToAcid && entityIn instanceof EntityLivingBase) {
         EntityLivingBase e = (EntityLivingBase)entityIn;
         if (entityIn instanceof EntityPlayer && ((EntityPlayer)entityIn).isCreative()) {
            return;
         }

         e.attackEntityFrom(LostDamageSources.CONCENTRATED_ACID.source, e.getMaxHealth() / 3.0F);
      }
   }

   @Override
   public void handleFill(FillBucketEvent event, IBlockState bs) {
      boolean result = false;
      if (((BlockBasicFluid)bs.getBlock()).equals(this)) {
         if (!event.getWorld().getBiome(event.getTarget().getBlockPos()).equals(DimensionInit.biomeCelestialArena)) {
            event.getWorld().setBlockState(event.getTarget().getBlockPos(), Blocks.AIR.getDefaultState());
         }

         event.setFilledBucket(FluidUtil.getFilledBucket(FluidRegistry.getFluidStack(this.fluidName, 1000)));
         event.setResult(Result.ALLOW);
         result = true;
      }

      event.setResult(result ? Result.ALLOW : Result.DENY);
   }
}
