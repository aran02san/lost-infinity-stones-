package xol.lostinfinity.block.misc;

import java.util.ArrayList;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;
import xol.lostinfinity.init.BlockInit;

public class BlockArchlumioGatePass extends BlockBasicGlass {
   public BlockArchlumioGatePass(String name) {
      super(name);
      this.setLightLevel(1.0F);
      this.setTickRandomly(true);
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
      return NULL_AABB;
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      this.closeGate(worldIn, pos, null);
      super.updateTick(worldIn, pos, state, rand);
   }

   public void closeGate(World worldIn, BlockPos pos, ArrayList<BlockPos> visited) {
      if (visited == null) {
         visited = new ArrayList<>();
      }

      if (!visited.contains(pos)) {
         visited.add(pos);
         worldIn.setBlockState(pos, BlockInit.archlumioGate.getDefaultState());

         for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
               for (int k = -1; k <= 1; k++) {
                  if (i != 0 || j != 0 || k != 0) {
                     BlockPos check = pos.add(i, j, k);
                     Block block = worldIn.getBlockState(check).getBlock();
                     if (block.equals(BlockInit.archlumioGatePass)) {
                        ((BlockArchlumioGatePass)block).closeGate(worldIn, check, visited);
                     }
                  }
               }
            }
         }
      }
   }
}
