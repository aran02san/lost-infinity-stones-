package xol.lostinfinity.block.misc;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockEmberslagDeposit extends BlockBasic {
   public BlockEmberslagDeposit(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      worldIn.setBlockState(pos.up(), BlockInit.emberslag.getDefaultState());
   }
}
