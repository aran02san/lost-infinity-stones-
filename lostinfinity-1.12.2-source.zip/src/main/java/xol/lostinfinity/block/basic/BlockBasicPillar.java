package xol.lostinfinity.block.basic;

import net.minecraft.block.BlockRotatedPillar;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemBlock;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;

public class BlockBasicPillar extends BlockRotatedPillar {
   public BlockBasicPillar(String name) {
      this(name, Material.ROCK);
   }

   public BlockBasicPillar(String name, Material material) {
      this(name, material, TabsInit.TAB_BLOCKS);
   }

   public BlockBasicPillar(String name, Material material, CreativeTabs tab) {
      super(material);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(60.0F);
      this.setResistance(60.0F);
      this.setCreativeTab(tab);
      this.setSoundType(SoundType.STONE);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }
}
