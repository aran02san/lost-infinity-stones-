package xol.lostinfinity.block.basic;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;

public class BlockStarforgeOre extends BlockBasic {
   public final boolean isDepletedType;
   private Item correspondingDrop;

   public BlockStarforgeOre(String name, boolean depleted) {
      super(name);
      this.isDepletedType = depleted;
      this.setTickRandomly(depleted);
   }

   public BlockStarforgeOre(String name) {
      this(name, false);
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      worldIn.setBlockState(pos, BlockInit.getRandomOre(worldIn).getDefaultState());
   }

   public void getDrops(NonNullList<ItemStack> drops, IBlockAccess world, BlockPos pos, IBlockState state, int fortune) {
      drops.clear();
      drops.add(new ItemStack(this.correspondingDrop));
   }

   public BlockStarforgeOre setCorrespondingItem(Item item) {
      this.correspondingDrop = item;
      return this;
   }
}
