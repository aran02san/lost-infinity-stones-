package xol.lostinfinity.block.basic;

import net.minecraft.block.Block;
import net.minecraft.block.BlockCrops;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.TabsInit;

public class BlockBasicCrop extends BlockCrops {
   private Item seed = null;
   private Item crop = null;
   private Block soilBlock = null;

   public BlockBasicCrop(String name) {
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      BlockInit.BLOCKS.add(this);
   }

   public void setSeedCropSoil(Item seedIn, Item cropIn, Block block) {
      this.seed = seedIn;
      this.crop = cropIn;
      this.soilBlock = block;
   }

   protected Item getSeed() {
      return this.seed;
   }

   protected Item getCrop() {
      return this.crop;
   }

   public boolean canBlockStay(World worldIn, BlockPos pos, IBlockState state) {
      return worldIn.getBlockState(pos.down()).getBlock() == this.soilBlock;
   }

   public int getCropAge(IBlockState state) {
      return (Integer)state.getValue(this.getAgeProperty());
   }
}
