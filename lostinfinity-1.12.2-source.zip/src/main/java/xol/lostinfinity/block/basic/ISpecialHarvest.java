package xol.lostinfinity.block.basic;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public interface ISpecialHarvest {
   Item getHarvestResult(World var1, BlockPos var2);

   Item getToolNeeded();

   void worldHarvestEffect(World var1, BlockPos var2, EntityPlayer var3);

   void failedHarvest(World var1, BlockPos var2, EntityPlayer var3);

   boolean isHarvestable(World var1, BlockPos var2, EntityPlayer var3);
}
