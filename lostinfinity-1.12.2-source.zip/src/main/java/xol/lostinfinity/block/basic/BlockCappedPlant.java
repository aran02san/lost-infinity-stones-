package xol.lostinfinity.block.basic;

import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemHoe;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BlockCappedPlant extends BlockBasicPlant {
   public static final PropertyBool ACTIVE = PropertyBool.create("active");

   public BlockCappedPlant(String name) {
      super(name, Material.PLANTS);
      this.setSoundType(SoundType.PLANT);
      this.setDefaultState(this.blockState.getBaseState().withProperty(ACTIVE, false));
   }

   public IBlockState getStateFromMeta(int meta) {
      switch (meta) {
         case 0:
            return this.getDefaultState().withProperty(ACTIVE, false);
         case 1:
            return this.getDefaultState().withProperty(ACTIVE, true);
         default:
            return this.getDefaultState();
      }
   }

   public int getMetaFromState(IBlockState state) {
      if (state.equals(this.getDefaultState().withProperty(ACTIVE, false))) {
         return 0;
      } else {
         return state.equals(this.getDefaultState().withProperty(ACTIVE, true)) ? 1 : 0;
      }
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{ACTIVE});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote && playerIn.getHeldItem(hand).getItem() instanceof ItemHoe) {
         if (this.getMetaFromState(state) == 0) {
            worldIn.setBlockState(pos, this.getStateFromMeta(1));
         } else {
            worldIn.setBlockState(pos, this.getStateFromMeta(0));
         }

         return true;
      } else {
         return false;
      }
   }
}
