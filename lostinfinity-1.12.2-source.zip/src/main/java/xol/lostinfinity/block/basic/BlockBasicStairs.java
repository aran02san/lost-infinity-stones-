package xol.lostinfinity.block.basic;

import net.minecraft.block.BlockStairs;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.ItemBlock;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;

public class BlockBasicStairs extends BlockStairs {
   public BlockBasicStairs(String name, float hardness, IBlockState modelState) {
      super(modelState);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(hardness);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.useNeighborBrightness = true;
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }
}
