package xol.lostinfinity.block.basic;

import javax.annotation.Nonnull;
import net.minecraft.block.Block;
import net.minecraft.block.BlockMobSpawner;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.item.ItemBlock;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.LazyLoadBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.ForgeRegistries;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.util.load.CustomLazyLoad;

public class BlockBasicSpawner extends BlockMobSpawner {
   protected String mobName;
   private final LazyLoadBase<ITileEntityProvider> spawnerReference;

   public BlockBasicSpawner(String name, String mobName) {
      this.mobName = mobName;
      this.setUnlocalizedName(name);
      this.setRegistryName("lostinfinity", name);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setHardness(5.0F);
      this.setTickRandomly(true);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
      this.spawnerReference = new CustomLazyLoad<>(() -> {
         Block spawner = (Block)ForgeRegistries.BLOCKS.getValue(new ResourceLocation("mob_spawner"));
         return spawner instanceof ITileEntityProvider ? (ITileEntityProvider)spawner : null;
      });
   }

   public TileEntity createNewTileEntity(World world, int par1) {
      TileEntity spawner = null;
      ITileEntityProvider entityProvider = (ITileEntityProvider)this.spawnerReference.getValue();
      if (entityProvider != null) {
         spawner = entityProvider.createNewTileEntity(world, par1);
         if (spawner != null) {
            this.insertModData(spawner);
         }
      }

      return spawner;
   }

   private void insertModData(@Nonnull TileEntity spawner) {
      NBTTagCompound spawnerNBT = spawner.writeToNBT(new NBTTagCompound());
      spawnerNBT.setString("SpawnPotentials", this.mobName);
      NBTTagCompound compound2 = new NBTTagCompound();
      compound2.setString("id", "lostinfinity:" + this.mobName);
      spawnerNBT.setTag("SpawnData", compound2);
      spawner.readFromNBT(spawnerNBT);
      spawner.markDirty();
   }
}
