package xol.lostinfinity.block.basic;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public interface ITargetable {
   void targetedResult(World var1, EntityPlayer var2, BlockPos var3);
}
