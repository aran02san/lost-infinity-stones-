package xol.lostinfinity.block.basic;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fluids.BlockFluidBase;

public class BlockBasicMoistured extends BlockBasic {
   private Block replacementBlock = null;
   private boolean requiresMoisture = false;
   private BlockFluidBase mositureLiquid = null;

   public BlockBasicMoistured(String name, boolean moisture) {
      super(name);
      this.setTickRandomly(true);
      this.requiresMoisture = moisture;
   }

   public void setReplacementAndLiquid(Block replace, BlockFluidBase liquid) {
      this.replacementBlock = replace;
      this.mositureLiquid = liquid;
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      boolean hasMoisture = false;
      if (worldIn.getBlockState(pos.down()).getBlock() == this.mositureLiquid) {
         hasMoisture = true;
      } else {
         for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
               if (worldIn.getBlockState(pos.add(x, 0, z)).getBlock() == this.mositureLiquid) {
                  hasMoisture = true;
               }
            }
         }
      }

      if (hasMoisture && !this.requiresMoisture || !hasMoisture && this.requiresMoisture) {
         worldIn.setBlockState(pos, this.replacementBlock.getDefaultState());
      }
   }
}
