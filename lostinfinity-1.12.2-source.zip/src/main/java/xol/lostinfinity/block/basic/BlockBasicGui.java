package xol.lostinfinity.block.basic;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.init.TabsInit;

public class BlockBasicGui extends BlockBasic {
   private int guiID;

   public BlockBasicGui(String name, int id) {
      this(name, Material.IRON, TabsInit.TAB_STARFORGE);
      this.guiID = id;
   }

   public BlockBasicGui(String name, Material material, CreativeTabs tab) {
      super(name, material, tab);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (this.guiID > 0) {
         playerIn.openGui(lostinfinity.instance, this.guiID, worldIn, pos.getX(), pos.getY(), pos.getZ());
      }

      return true;
   }
}
