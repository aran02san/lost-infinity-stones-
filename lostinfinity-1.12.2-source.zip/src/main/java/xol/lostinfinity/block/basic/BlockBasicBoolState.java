package xol.lostinfinity.block.basic;

import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;

public class BlockBasicBoolState extends BlockBasic {
   public static final PropertyBool ACTIVE = PropertyBool.create("active");

   public BlockBasicBoolState(String name) {
      super(name);
      this.setDefaultState(this.blockState.getBaseState().withProperty(ACTIVE, false));
   }

   public IBlockState getStateFromMeta(int meta) {
      switch (meta) {
         case 0:
            return this.getDefaultState().withProperty(ACTIVE, false);
         case 1:
            return this.getDefaultState().withProperty(ACTIVE, true);
         default:
            return this.getDefaultState();
      }
   }

   public int getMetaFromState(IBlockState state) {
      if (state.equals(this.getDefaultState().withProperty(ACTIVE, false))) {
         return 0;
      } else {
         return state.equals(this.getDefaultState().withProperty(ACTIVE, true)) ? 1 : 0;
      }
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{ACTIVE});
   }
}
