package xol.lostinfinity.block.basic;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.fluids.BlockFluidClassic;
import net.minecraftforge.fluids.Fluid;
import net.minecraftforge.fml.common.eventhandler.Event.Result;

public class BlockBasicFluid extends BlockFluidClassic {
   public BlockBasicFluid(String name, Fluid fluid, Material material) {
      super(fluid, material);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
   }

   public EnumBlockRenderType getRenderType(IBlockState state) {
      return EnumBlockRenderType.MODEL;
   }

   public void handleFill(FillBucketEvent event, IBlockState bs) {
      if (((BlockBasicFluid)bs.getBlock()).equals(this)) {
         event.getWorld().setBlockState(event.getTarget().getBlockPos(), Blocks.AIR.getDefaultState());
         event.setResult(Result.ALLOW);
      } else {
         event.setResult(Result.DENY);
      }
   }
}
