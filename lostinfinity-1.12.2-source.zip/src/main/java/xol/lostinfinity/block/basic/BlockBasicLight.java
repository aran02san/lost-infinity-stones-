package xol.lostinfinity.block.basic;

import net.minecraft.block.material.Material;

public class BlockBasicLight extends BlockBasic {
   public BlockBasicLight(String name) {
      super(name, Material.REDSTONE_LIGHT);
      this.setLightLevel(1.0F);
   }
}
