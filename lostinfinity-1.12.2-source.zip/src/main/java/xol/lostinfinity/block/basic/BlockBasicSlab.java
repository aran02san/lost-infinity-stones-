package xol.lostinfinity.block.basic;

import java.util.Random;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockSlab.EnumBlockHalf;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyEnum;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IStringSerializable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;

public class BlockBasicSlab extends BlockSlab {
   public static final PropertyEnum<BlockBasicSlab.Variant> VARIANT = PropertyEnum.create("variant", BlockBasicSlab.Variant.class);
   public BlockBasicSlab mySlab;

   public BlockBasicSlab(String name, Material Material) {
      super(Material);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(60.0F);
      this.setResistance(60.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      IBlockState iblockstate = this.blockState.getBaseState();
      if (!this.isDouble()) {
         iblockstate = iblockstate.withProperty(HALF, EnumBlockHalf.BOTTOM);
         ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
      }

      this.setDefaultState(iblockstate.withProperty(VARIANT, BlockBasicSlab.Variant.DEFAULT));
      BlockInit.BLOCKS.add(this);
   }

   public void setMySlab(BlockBasicSlab slab) {
      this.mySlab = slab;
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return Item.getItemFromBlock(this.mySlab);
   }

   public ItemStack getItem(World worldIn, BlockPos pos, IBlockState state) {
      return new ItemStack(this.mySlab);
   }

   public IBlockState getStateFromMeta(int meta) {
      IBlockState iblockstate = this.getDefaultState().withProperty(VARIANT, BlockBasicSlab.Variant.DEFAULT);
      if (!this.isDouble()) {
         iblockstate = iblockstate.withProperty(HALF, (meta & 8) == 0 ? EnumBlockHalf.BOTTOM : EnumBlockHalf.TOP);
      }

      return iblockstate;
   }

   public int getMetaFromState(IBlockState state) {
      int i = 0;
      if (!this.isDouble() && state.getValue(HALF) == EnumBlockHalf.TOP) {
         i |= 8;
      }

      return i;
   }

   protected BlockStateContainer createBlockState() {
      return this.isDouble()
         ? new BlockStateContainer(this, new IProperty[]{VARIANT})
         : new BlockStateContainer(this, new IProperty[]{HALF, VARIANT});
   }

   public String getUnlocalizedName(int meta) {
      return super.getUnlocalizedName();
   }

   public IProperty<?> getVariantProperty() {
      return VARIANT;
   }

   public Comparable<?> getTypeForItem(ItemStack stack) {
      return BlockBasicSlab.Variant.DEFAULT;
   }

   public boolean isDouble() {
      IBlockState iblockstate = this.blockState.getBaseState();
      return this.isDouble();
   }

   public static class Double extends BlockBasicSlab {
      public Double(String name, Material material) {
         super(name, material);
      }

      @Override
      public boolean isDouble() {
         return true;
      }
   }

   public static class Half extends BlockBasicSlab {
      public Half(String name, Material material) {
         super(name, material);
      }

      @Override
      public boolean isDouble() {
         return false;
      }
   }

   public static enum Variant implements IStringSerializable {
      DEFAULT;

      public String getName() {
         return "default";
      }
   }
}
