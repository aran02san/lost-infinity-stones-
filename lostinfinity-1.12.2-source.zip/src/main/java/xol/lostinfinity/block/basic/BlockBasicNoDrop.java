package xol.lostinfinity.block.basic;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;

public class BlockBasicNoDrop extends BlockBasic {
   public BlockBasicNoDrop(String name) {
      super(name);
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return Items.AIR;
   }
}
