package xol.lostinfinity.block.tileentity;

import java.util.UUID;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;

public class TileEntityGenerator extends TileEntity {
   private UUID myPlacer = null;

   public void readFromNBT(NBTTagCompound compound) {
      if (compound != null && compound.hasUniqueId("teplace")) {
         this.myPlacer = compound.getUniqueId("teplace");
      }

      super.readFromNBT(compound);
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      if (compound == null) {
         compound = new NBTTagCompound();
      }

      UUID uuid = this.myPlacer == null ? UUID.fromString("00000000-0000-0000-0000-000000000000") : this.myPlacer;
      compound.setUniqueId("teplace", uuid);
      return super.writeToNBT(compound);
   }

   public void setMyPlacer(UUID the_id) {
      this.myPlacer = the_id;
      this.markDirty();
   }

   public UUID getMyPlacer() {
      return this.myPlacer;
   }
}
