package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import xol.lostinfinity.init.BlockInit;

public class TileEntityAlignmentDialGame extends TileEntity implements ITickable {
   private boolean active = false;
   private ArrayList<ArrayList<BlockPos>> rings = null;
   private boolean[] ringStates = null;
   private int dir = 0;
   private int timer = 0;
   private static final int spinTime = 1;
   private int ringCount = 0;

   public void update() {
      if (this.active && !this.world.isRemote) {
         if (this.timer <= 0 && this.ringStates != null) {
            this.timer = 1;

            for (int i = 0; i < this.ringStates.length; i++) {
               if (this.ringStates[i]) {
                  this.rotateRing(i);
               }
            }
         } else {
            this.timer--;
         }
      }
   }

   public void toggleRing(BlockPos pos) {
      int i = Math.max(
            Math.abs(pos.getX() - this.getPos().getX()), Math.abs(pos.getZ() - this.getPos().getZ())
         )
         - 1;
      if (this.ringStates != null && this.ringStates.length >= i - 1) {
         this.ringStates[i] = !this.ringStates[i];
      }
   }

   private void rotateRing(int i) {
      if (this.rings != null) {
         ArrayList<BlockPos> ring = this.rings.get(i);
         BlockPos lit = null;

         for (BlockPos pos : ring) {
            if (this.world.getBlockState(pos).equals(BlockInit.alignmentTile.getStateFromMeta(1))) {
               lit = pos;
               break;
            }
         }

         if (lit != null) {
            int dist = i + 1;
            Vec3i dir = null;
            int x = lit.getX() - this.getPos().getX();
            int z = lit.getZ() - this.getPos().getZ();
            if (x == dist && z > -dist) {
               dir = new Vec3i(0, 0, -1);
            } else if (x == -dist && z < dist) {
               dir = new Vec3i(0, 0, 1);
            } else if (z == dist && x < dist) {
               dir = new Vec3i(1, 0, 0);
            } else if (z == -dist && x > -dist) {
               dir = new Vec3i(-1, 0, 0);
            }

            if (dir != null) {
               BlockPos check = lit.add(dir);
               if (ring.contains(check)) {
                  this.world.setBlockState(check, BlockInit.alignmentTile.getStateFromMeta(1));
                  this.world.setBlockState(lit, BlockInit.alignmentTile.getStateFromMeta(0));
               }
            }
         }
      }
   }

   public int getRingCount() {
      return this.ringCount;
   }

   public String getDir() {
      switch (this.dir) {
         case 0:
            return "North";
         case 1:
            return "East";
         case 2:
            return "West";
         case 3:
            return "South";
         default:
            return "North";
      }
   }

   public void reset() {
      int ringCount = 0;
      this.rings = new ArrayList<>();
      boolean foundRings = false;

      while (!foundRings) {
         int dist = ringCount + 1;
         ArrayList<BlockPos> ring = new ArrayList<>();

         label58:
         for (int i = -dist; i <= dist; i++) {
            for (int j = -dist; j <= dist; j++) {
               BlockPos check = this.getPos().add(i, 0, j);
               int ringNum = Math.max(
                  Math.abs(check.getX() - this.getPos().getX()),
                  Math.abs(check.getZ() - this.getPos().getZ())
               );
               if ((i != 0 || j != 0) && ringNum == dist) {
                  if (!this.world.getBlockState(check).getBlock().equals(BlockInit.alignmentTile)) {
                     foundRings = true;
                     break label58;
                  }

                  ring.add(check);
                  this.world.setBlockState(check, BlockInit.alignmentTile.getStateFromMeta(0));
               }
            }
         }

         if (!ring.isEmpty()) {
            this.rings.add(ring);
            ringCount++;
         }
      }

      this.ringCount = ringCount;
      if (this.ringCount > 0) {
         this.ringStates = new boolean[ringCount];

         for (ArrayList<BlockPos> ringPositions : this.rings) {
            int rand = this.world.rand.nextInt(ringPositions.size());
            this.world.setBlockState(ringPositions.get(rand), BlockInit.alignmentTile.getStateFromMeta(1));
         }

         this.active = true;
         this.dir = this.world.rand.nextInt(4);
      }
   }
}
