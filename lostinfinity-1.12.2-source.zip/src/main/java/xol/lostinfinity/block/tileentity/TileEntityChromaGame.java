package xol.lostinfinity.block.tileentity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;

public class TileEntityChromaGame extends TileEntity implements ITickable {
   private EntityPlayer first = null;
   private EntityPlayer second = null;

   public void update() {
   }

   public void setPlayers(EntityPlayer first, EntityPlayer second) {
      this.first = first;
      this.second = second;
   }

   public boolean isFirst(EntityPlayer check) {
      return this.first != null && check.equals(this.first);
   }

   public boolean isSecond(EntityPlayer check) {
      return this.second != null && check.equals(this.second);
   }

   public EntityPlayer getFirst() {
      return this.first;
   }

   public EntityPlayer getSecond() {
      return this.second;
   }
}
