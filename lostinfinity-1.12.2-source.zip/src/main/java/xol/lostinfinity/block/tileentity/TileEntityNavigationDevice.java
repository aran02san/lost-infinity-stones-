package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityNavigationDevice extends TileEntity implements ITickable {
   public boolean active = false;
   private Vec3i upDir = null;
   private Vec3i rightDir = null;
   private BlockPos cornerPos = null;
   private ArrayList<BlockPos> sequencePositions = null;
   private int index = 0;
   private int rows = 0;
   private int columns = 0;
   private static final int numArrows = 8;
   private int arrowTimer = 25;
   private int timer = 0;
   private static final Vec3i offset = new Vec3i(0, 0, 0);
   private BlockPos[][] grid = (BlockPos[][])null;
   ArrayList<Integer> sequence = null;

   public void activate() {
      this.active = true;
      if (!this.world.isRemote) {
         this.startGame();
      }
   }

   private void findDirs() {
      BlockPos ref = this.getPos().add(offset);
      if (this.world.getBlockState(ref.add(-1, 0, 0)).getBlock() == BlockInit.navigationNodule) {
         this.upDir = new Vec3i(1, 0, 0);
         this.rightDir = new Vec3i(0, 0, 1);
      } else if (this.world.getBlockState(ref.add(1, 0, 0)).getBlock() == BlockInit.navigationNodule) {
         this.upDir = new Vec3i(-1, 0, 0);
         this.rightDir = new Vec3i(0, 0, -1);
      } else if (this.world.getBlockState(ref.add(0, 0, 1)).getBlock() == BlockInit.navigationNodule) {
         this.upDir = new Vec3i(0, 0, -1);
         this.rightDir = new Vec3i(1, 0, 0);
      } else if (this.world.getBlockState(ref.add(0, 0, -1)).getBlock() == BlockInit.navigationNodule) {
         this.upDir = new Vec3i(0, 0, 1);
         this.rightDir = new Vec3i(-1, 0, 0);
      }
   }

   private void startGame() {
      this.findDirs();
      BlockPos ref = this.getPos().add(offset);
      BlockPos cur = ref.subtract(this.upDir);

      int upCount;
      for (upCount = 0; this.world.getBlockState(cur).getBlock() == BlockInit.navigationNodule; upCount++) {
         cur = cur.subtract(this.upDir);
      }

      cur = cur.add(this.upDir);

      while (this.world.getBlockState(cur).getBlock() == BlockInit.navigationNodule) {
         cur = cur.subtract(this.rightDir);
      }

      cur = cur.add(this.rightDir);
      this.cornerPos = cur;
      BlockPos temp = this.cornerPos.add(this.rightDir);

      int rightCount;
      for (rightCount = 0; this.world.getBlockState(temp).getBlock() == BlockInit.navigationNodule; rightCount++) {
         temp = temp.add(this.rightDir);
      }

      this.grid = new BlockPos[rightCount][upCount];
      this.columns = rightCount;
      this.rows = upCount;

      for (int i = 0; i < rightCount; i++) {
         for (int j = 0; j < upCount; j++) {
            BlockPos gridPos = this.cornerPos
               .add(
                  this.rightDir.getX() * i + this.upDir.getX() * j, 0, this.rightDir.getZ() * i + this.upDir.getZ() * j
               );
            this.grid[i][j] = gridPos;
         }
      }

      int randCol = this.world.rand.nextInt(this.columns);
      int randRow = this.world.rand.nextInt(this.rows);
      BlockPos startPos = this.getGridPos(randCol, randRow);
      this.world.setBlockState(startPos, BlockInit.navigationNodule.getStateFromMeta(1));
      if (startPos != null) {
         this.sequencePositions = new ArrayList<>();
         this.sequencePositions.add(startPos);
         this.sequence = new ArrayList<>();
         BlockPos curPos = startPos;

         for (int i = 0; i < 8; i++) {
            int dirNum = this.world.rand.nextInt(4);
            int colorNum = this.world.rand.nextInt(3);
            Vec3i toAdd = this.getDir(dirNum);
            int iterations = 0;
            boolean noDir = false;
            BlockPos checkPos = curPos.add(toAdd);

            while (this.sequencePositions.contains(checkPos) || this.world.getBlockState(checkPos).getBlock() != BlockInit.navigationNodule) {
               int newNum = this.world.rand.nextInt(4);

               while (newNum == dirNum) {
                  newNum = this.world.rand.nextInt(4);
               }

               dirNum = newNum;
               toAdd = this.getDir(newNum);
               checkPos = curPos.add(toAdd);
               if (++iterations > 5) {
                  noDir = true;
                  break;
               }
            }

            if (noDir) {
               break;
            }

            int metaNum = dirNum + colorNum * 4 + 1;
            this.sequence.add(metaNum);
            this.sequencePositions.add(checkPos);
            curPos = checkPos;
         }

         this.index = 0;
         this.timer = 0;
      }
   }

   private Vec3i getDir(int dirNum) {
      Vec3i toAdd;
      switch (dirNum) {
         case 1:
            toAdd = new Vec3i(-this.rightDir.getX(), 0, -this.rightDir.getZ());
            break;
         case 2:
            toAdd = new Vec3i(-this.upDir.getX(), 0, -this.upDir.getZ());
            break;
         case 3:
            toAdd = this.rightDir;
            break;
         default:
            toAdd = this.upDir;
      }

      return toAdd;
   }

   private BlockPos getGridPos(int col, int row) {
      return this.grid != null && col >= 0 && col < this.grid.length && row >= 0 && row < this.grid[col].length ? this.grid[col][row] : null;
   }

   public boolean isActive() {
      return this.active;
   }

   public void update() {
      if (!this.world.isRemote) {
         if (this.sequence == null || this.index >= this.sequence.size()) {
            this.active = true;
         } else if (this.timer == this.arrowTimer) {
            int meta = this.sequence.get(this.index);
            this.world.setBlockState(this.getPos(), BlockInit.navigationDevice.getStateFromMeta(meta));
            this.world.setTileEntity(this.pos, this);
            this.tileEntityInvalid = false;
            this.world.playSound(null, this.pos, SoundInit.GAME_DING, SoundCategory.BLOCKS, 1.0F, 1.0F);
            this.index++;
            this.timer = 0;
         } else {
            this.timer++;
         }
      }
   }

   public void checkCompletion(EntityPlayer playerIn) {
      this.active = false;
      if (!this.world.isRemote) {
         boolean foundAll = true;
         if (this.sequencePositions != null && !this.sequencePositions.isEmpty()) {
            this.world.setBlockState(this.sequencePositions.get(0), BlockInit.navigationNodule.getStateFromMeta(0));
            this.sequencePositions.remove(0);
            if (this.sequence != null && this.sequencePositions.size() == this.sequence.size()) {
               for (int i = 0; i < this.sequence.size(); i++) {
                  int meta = (this.sequence.get(i) - 1) / 4;
                  BlockPos seqPos = this.sequencePositions.get(i);
                  IBlockState state = this.world.getBlockState(seqPos);
                  Block block = state.getBlock();
                  if (block != BlockInit.navigationNodule) {
                     foundAll = false;
                     break;
                  }

                  int blockMeta = block.getMetaFromState(state) - 1;
                  if (blockMeta != meta) {
                     foundAll = false;
                     break;
                  }
               }
            }
         } else {
            foundAll = false;
         }

         this.reset();
         if (foundAll) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Green + "Completed the navigation sequence! Here is your reward!"));
            playerIn.addItemStackToInventory(new ItemStack(ItemInit.mechanicalSextant, 1));
         } else {
            playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Failed to complete the sequence. Try again"));
         }
      }
   }

   public boolean shouldRefresh(World world, BlockPos pos, IBlockState oldState, IBlockState newSate) {
      return false;
   }

   private void reset() {
      this.world.setBlockState(this.getPos(), BlockInit.navigationDevice.getStateFromMeta(0));
      this.tileEntityInvalid = false;

      for (int i = -1; i < this.columns + 1; i++) {
         for (int j = -1; j < this.rows + 1; j++) {
            BlockPos checkPos = this.cornerPos
               .add(
                  this.rightDir.getX() * i + this.upDir.getX() * j, 0, this.rightDir.getZ() * i + this.upDir.getZ() * j
               );
            if (this.world.getBlockState(checkPos).getBlock() == BlockInit.navigationNodule) {
               this.world.setBlockState(checkPos, BlockInit.navigationNodule.getStateFromMeta(0));
            }
         }
      }

      this.grid = (BlockPos[][])null;
      this.columns = 0;
      this.rows = 0;
      this.active = false;
      this.timer = 0;
      this.sequence = null;
      this.sequencePositions = null;
   }
}
