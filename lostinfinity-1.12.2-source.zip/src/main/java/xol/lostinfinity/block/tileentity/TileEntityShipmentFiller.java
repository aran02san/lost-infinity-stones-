package xol.lostinfinity.block.tileentity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import xol.lostinfinity.item.misc.ItemShipmentBox;
import xol.lostinfinity.mob.entity.misc.EntitySupplyTrader;

public class TileEntityShipmentFiller extends TileEntity implements IInventory, ITickable {
   private NonNullList<ItemStack> inventory = NonNullList.withSize(30, ItemStack.EMPTY);

   public void update() {
      for (int i = 2; i < this.inventory.size(); i++) {
         if (!((ItemStack)this.inventory.get(i)).isEmpty()) {
            this.inventory.set(i, ItemStack.EMPTY);
         }
      }

      ItemStack inputStack = (ItemStack)this.inventory.get(0);
      ItemStack boxStack = (ItemStack)this.inventory.get(1);
      Item boxItem = boxStack.getItem();
      if (boxItem instanceof ItemShipmentBox) {
         if (!this.world.isRemote && !boxStack.hasTagCompound()) {
            boxStack.setTagCompound(new NBTTagCompound());
         }

         if (!inputStack.isEmpty()) {
            int[] curIDs = boxStack.getTagCompound().getIntArray("itemids");
            int[] newIDs = new int[curIDs.length + 1];

            for (int j = 0; j < curIDs.length; j++) {
               newIDs[j] = curIDs[j];
            }

            ItemStack[] shipmentItems = ItemShipmentBox.getItemArray();
            boolean found = false;

            for (int ix = 0; ix < shipmentItems.length; ix++) {
               if (shipmentItems[ix].isItemEqual(inputStack)) {
                  newIDs[curIDs.length] = ix;
                  int oldWeight = boxStack.getTagCompound().getInteger("weight");
                  boxStack.getTagCompound().setInteger("weight", ItemShipmentBox.getItemWeight(inputStack.getItem()) + oldWeight);
                  found = true;
                  break;
               }
            }

            if (found) {
               boxStack.getTagCompound().setIntArray("itemids", newIDs);
            }

            this.removeStackFromSlot(0);
         }

         int[] itemIds = boxStack.getTagCompound().getIntArray("itemids");

         for (int ixx = 0; ixx < itemIds.length; ixx++) {
            ItemStack stack = ItemShipmentBox.getItemArray()[itemIds[ixx]];
            if (!stack.isEmpty() && ixx + 2 < this.inventory.size() && ((ItemStack)this.inventory.get(ixx + 2)).isEmpty()) {
               this.inventory.set(ixx + 2, stack);
            }
         }
      }
   }

   public int getField(int id) {
      return 0;
   }

   public void setField(int id, int value) {
   }

   public int getFieldCount() {
      return 0;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      ItemStackHelper.loadAllItems(compound, this.inventory);
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      this.inventory.set(0, ItemStack.EMPTY);

      for (int i = 2; i < this.inventory.size(); i++) {
         this.inventory.set(i, ItemStack.EMPTY);
      }

      ItemStackHelper.saveAllItems(compound, this.inventory);
      return super.writeToNBT(compound);
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      return this.inventory.isEmpty();
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }
   }

   public int getInventoryStackLimit() {
      return 1;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return this.world.getTileEntity(this.pos) != this
         ? false
         : player.getDistanceSq(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5)
            <= 64.0;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      switch (index) {
         case 0:
            if (EntitySupplyTrader.SupplyTraderRecipe.isItemInRecipe(stack.getItem())) {
               return true;
            }
            break;
         case 1:
            if (stack.getItem() instanceof ItemShipmentBox) {
               return true;
            }
      }

      return false;
   }

   public void clear() {
   }

   public String getName() {
      return "tile.shipment_filler";
   }

   public boolean hasCustomName() {
      return false;
   }

   public void dropInventory() {
      this.inventory.set(0, ItemStack.EMPTY);

      for (int i = 2; i < this.inventory.size(); i++) {
         this.inventory.set(i, ItemStack.EMPTY);
      }

      InventoryHelper.dropInventoryItems(this.world, this.pos, this);
   }
}
