package xol.lostinfinity.block.tileentity;

import javax.annotation.Nullable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.MathHelper;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.starforge.EntityDusker;

public class TileEntityCompressionTable extends TileEntity implements IInventory, ITickable {
   public NonNullList<ItemStack> compressionItemStacks = NonNullList.withSize(3, ItemStack.EMPTY);
   private int progress = -1;
   private static final byte PROGRESS = 0;

   public TileEntityCompressionTable() {
      this.compressionItemStacks = NonNullList.withSize(3, ItemStack.EMPTY);
      this.clear();
   }

   public void readFromNBT(NBTTagCompound compound) {
      byte NBT_TYPE_COMPOUND = 10;
      NBTTagList dataForSlots = compound.getTagList("Items", 10);
      this.compressionItemStacks = NonNullList.withSize(3, ItemStack.EMPTY);

      for (int i = 0; i < dataForSlots.tagCount(); i++) {
         NBTTagCompound dataForSlot = dataForSlots.getCompoundTagAt(i);
         byte slotNumber = dataForSlot.getByte("Slot");
         if (slotNumber >= 0 && slotNumber < this.compressionItemStacks.size()) {
            this.compressionItemStacks.set(slotNumber, new ItemStack(dataForSlot));
         }
      }

      this.progress = compound.getInteger("Progress");
      super.readFromNBT(compound);
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      NBTTagList dataForSlots = new NBTTagList();

      for (int i = 0; i < this.compressionItemStacks.size(); i++) {
         if (!((ItemStack)this.compressionItemStacks.get(i)).isEmpty()) {
            NBTTagCompound dataForSlot = new NBTTagCompound();
            dataForSlot.setByte("Slot", (byte)i);
            ((ItemStack)this.compressionItemStacks.get(i)).writeToNBT(dataForSlot);
            dataForSlots.appendTag(dataForSlot);
         }
      }

      compound.setTag("Items", dataForSlots);
      compound.setInteger("Progress", this.progress);
      return super.writeToNBT(compound);
   }

   public int updateProgress(int increment) {
      this.progress = Math.min(this.progress + increment, 500);
      this.markDirty();
      return this.progress;
   }

   public void updateSlot(int index, ItemStack itemStack) {
      this.compressionItemStacks.set(index, itemStack);
      this.markDirty();
   }

   public int getProgress() {
      return this.progress;
   }

   public int setProgress(int newValue) {
      this.progress = newValue;
      this.markDirty();
      return this.progress;
   }

   public double getProgressAsFraction() {
      return MathHelper.clamp(this.getProgress() >= 0 ? this.getProgress() / 500.0 : 0.0, 0.0, 1.0);
   }

   public ItemStack getResult() {
      return (ItemStack)this.compressionItemStacks.get(2);
   }

   public void update() {
      boolean flag = this.progress > -1;
      boolean flag1 = false;
      if (flag) {
         this.progress++;
      }

      if (!this.world.isRemote) {
         ItemStack itemstack = (ItemStack)this.compressionItemStacks.get(0);
         if ((flag || !itemstack.isEmpty()) && this.canProgress()) {
            if (this.progress % 100 == 0 && this.progress < 500) {
               EntityDusker dusker = new EntityDusker(this.world);
               dusker.setPosition(this.pos.getX(), this.pos.getY() + 13, this.pos.getZ());
               this.world.spawnEntity(dusker);
            }

            if (this.progress == -1 && this.canProgress()) {
               this.progress = 0;
               this.compressionItemStacks.set(2, itemstack.copy());
               flag1 = true;
            }

            if (this.progress >= 500 && this.canProgress()) {
               this.compressItem();
               this.progress = -1;
               flag1 = true;
            }
         }

         if (!this.canProgress()) {
            if (this.progress != -1) {
               this.progress = -1;
            }

            flag1 = true;
         }
      }

      if (flag1) {
         this.markDirty();
      }
   }

   public ItemStack getResultFor(ItemStack iteminput1) {
      ItemStack result = ItemStack.EMPTY;
      if (iteminput1.getItem().equals(ItemInit.astralliumIngot)) {
         result = new ItemStack(ItemInit.astralliumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.crystoniumIngot)) {
         result = new ItemStack(ItemInit.crystoniumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.detheriumIngot)) {
         result = new ItemStack(ItemInit.detheriumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.emberiumIngot)) {
         result = new ItemStack(ItemInit.emberiumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.hextoriumIngot)) {
         result = new ItemStack(ItemInit.hextoriumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.incadiumIngot)) {
         result = new ItemStack(ItemInit.incadiumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.kylaxiumIngot)) {
         result = new ItemStack(ItemInit.kylaxiumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.noxeriumIngot)) {
         result = new ItemStack(ItemInit.noxeriumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.olysiumIngot)) {
         result = new ItemStack(ItemInit.olysiumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.velloriumIngot)) {
         result = new ItemStack(ItemInit.velloriumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.xeroviumIngot)) {
         result = new ItemStack(ItemInit.xeroviumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.phytrosiumIngot)) {
         result = new ItemStack(ItemInit.phytrosiumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.kyvoriumIngot)) {
         result = new ItemStack(ItemInit.kyvoriumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.biosynthiumIngot)) {
         result = new ItemStack(ItemInit.biosynthiumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.maliciumIngot)) {
         result = new ItemStack(ItemInit.maliciumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.etheriumIngot)) {
         result = new ItemStack(ItemInit.etheriumCondensed);
      } else if (iteminput1.getItem().equals(ItemInit.polariumIngot)) {
         result = new ItemStack(ItemInit.polariumCondensed);
      }

      return result;
   }

   private void compressItem() {
      ItemStack result = this.getResultFor((ItemStack)this.compressionItemStacks.get(0));
      this.compressionItemStacks.set(2, ItemStack.EMPTY);
      ItemStack output = (ItemStack)this.compressionItemStacks.get(1);
      boolean yes = true;
      if (output.isEmpty()) {
         this.compressionItemStacks.set(1, result.copy());
      } else if (output.getItem() == result.getItem()) {
         output.grow(1);
      } else {
         yes = false;
      }

      if (yes) {
         ((ItemStack)this.compressionItemStacks.get(0)).shrink(25);
         if (!this.world.isRemote) {
            this.world.playEvent(1030, this.pos, 0);
         }
      }
   }

   public boolean canProgress() {
      return !((ItemStack)this.compressionItemStacks.get(0)).isEmpty() && ((ItemStack)this.compressionItemStacks.get(0)).getCount() >= 25;
   }

   @Nullable
   public SPacketUpdateTileEntity getUpdatePacket() {
      NBTTagCompound updateTag = this.getUpdateTag();
      int METADATA = 0;
      return new SPacketUpdateTileEntity(this.pos, 0, updateTag);
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity packet) {
      NBTTagCompound updateTag = packet.getNbtCompound();
      this.handleUpdateTag(updateTag);
   }

   public NBTTagCompound getUpdateTag() {
      NBTTagCompound nbtTagCompound = new NBTTagCompound();
      this.writeToNBT(nbtTagCompound);
      return nbtTagCompound;
   }

   public void handleUpdateTag(NBTTagCompound tag) {
      this.readFromNBT(tag);
   }

   public int getField(int id) {
      if (id == 0) {
         return this.progress;
      } else {
         System.err.println("Invalid field ID in TileEntityCompressionTable#getField:" + id);
         return 0;
      }
   }

   public void setField(int id, int value) {
      if (id == 0) {
         this.progress = value;
      } else {
         System.err.println("Invalid field ID in TileEntityCompressionTable#setField:" + id);
      }
   }

   public int getFieldCount() {
      return 1;
   }

   public void clear() {
      this.compressionItemStacks = NonNullList.withSize(3, ItemStack.EMPTY);
   }

   public boolean isItemValidForSlot(int slotIndex, ItemStack itemstack) {
      return true;
   }

   public int getSizeInventory() {
      return this.compressionItemStacks.size();
   }

   public boolean isEmpty() {
      return this.compressionItemStacks.stream().allMatch(it -> it.isEmpty());
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.compressionItemStacks.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.compressionItemStacks, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.compressionItemStacks, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      ItemStack itemstack = (ItemStack)this.compressionItemStacks.get(index);
      boolean flag = !stack.isEmpty() && stack.isItemEqual(itemstack) && ItemStack.areItemStackTagsEqual(stack, itemstack);
      this.compressionItemStacks.set(index, stack);
      if (stack.getCount() > this.getInventoryStackLimit()) {
         stack.setCount(this.getInventoryStackLimit());
      }

      if (index == 0 && !flag) {
         this.progress = 0;
         this.markDirty();
      }
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      if (this.world.getTileEntity(this.pos) != this) {
         return false;
      } else {
         double X_CENTRE_OFFSET = 0.5;
         double Y_CENTRE_OFFSET = 0.5;
         double Z_CENTRE_OFFSET = 0.5;
         double MAXIMUM_DISTANCE_SQ = 64.0;
         return player.getDistanceSq(
               this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5
            )
            < 64.0;
      }
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public String getName() {
      return null;
   }

   public boolean hasCustomName() {
      return false;
   }
}
