package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import xol.lostinfinity.dimension.data.PowerColliderGrid;
import xol.lostinfinity.dimension.data.PowerColliderNode;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityPowerCollider extends TileEntity implements ITickable {
   private static final int dimension = 25;
   private static final Vec3i offset = new Vec3i(0, 0, 0);
   private Vec3i upDir = new Vec3i(0, 0, 1);
   private Vec3i leftDir = new Vec3i(1, 0, 0);
   private ArrayList<BlockPos> tiles = new ArrayList<>();
   private boolean game = false;
   private static final int numTicks = 3;
   private static final int numPaths = 2;
   private static final int minLength = 25;
   private BlockPos ref = null;
   private ArrayList<ArrayList<PowerColliderNode>> tracks = null;
   private int[] trackIndices = null;
   private PowerColliderGrid grid = null;
   private boolean[] trackActive = null;
   private boolean wonLast = false;

   public void setUpDir(Vec3i upDir) {
      this.upDir = upDir;
   }

   public void setLeftDir(Vec3i leftDir) {
      this.leftDir = leftDir;
   }

   private Vec3i findTileDir(BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(-1, 0, -1));
      dirs.add(new Vec3i(1, 0, -1));

      for (Vec3i dir : dirs) {
         if (this.world.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.powerColliderTrack)) {
            return dir;
         }
      }

      return null;
   }

   public void reset() {
      this.tiles.clear();
      BlockPos ref = this.pos.add(offset);
      Vec3i dir = new Vec3i(-1, 0, 1);
      Vec3i upDir = new Vec3i(0, 0, 1);
      Vec3i leftDir = new Vec3i(-1, 0, 0);
      ref = ref.add(dir);
      this.ref = ref;
      int leftCount = 25;
      int upCount = 25;
      this.grid = new PowerColliderGrid(leftCount, upCount, 25, 2);
      this.tracks = this.grid.getPaths();
      if (this.tracks != null && this.tracks.size() >= 1) {
         this.trackIndices = new int[this.tracks.size()];
         this.trackActive = new boolean[this.tracks.size()];

         for (int k = 0; k < this.trackIndices.length; k++) {
            this.trackIndices[k] = this.tracks.get(k).size() - 1;
            this.trackActive[k] = false;
         }

         for (int i = 0; i < upCount; i++) {
            for (int j = 0; j < leftCount; j++) {
               BlockPos tile = ref.add(
                  upDir.getX() * i + leftDir.getX() * j, 0, upDir.getZ() * i + leftDir.getZ() * j
               );
               PowerColliderNode node = this.grid.getNodeAtLocation(i, j);
               boolean isTrack = false;
               boolean start = false;
               boolean end = false;
               if (node != null) {
                  for (ArrayList<PowerColliderNode> track : this.tracks) {
                     if (track.contains(node)) {
                        if (track.indexOf(node) == track.size() - 1) {
                           start = true;
                        }

                        if (track.indexOf(node) == 0) {
                           end = true;
                        }

                        isTrack = true;
                        break;
                     }
                  }
               }

               if (isTrack) {
                  if (start) {
                     this.world.setBlockState(tile, BlockInit.powerColliderTrack.getStateFromMeta(1));
                  } else if (end) {
                     this.world.setBlockState(tile, BlockInit.powerColliderTrack.getStateFromMeta(2));
                  } else {
                     this.world.setBlockState(tile, BlockInit.powerColliderTrack.getStateFromMeta(0));
                  }
               } else {
                  this.world.setBlockState(tile, BlockInit.neosteelBlack.getDefaultState());
               }

               this.tiles.add(tile);
            }
         }

         this.upDir = upDir;
         this.leftDir = leftDir;
         this.game = true;
         this.world.playSound(null, this.pos, SoundInit.MANUFACTURE_MACHINE, SoundCategory.BLOCKS, 1.0F, 1.0F);
      }
   }

   public void setTiles(ArrayList<BlockPos> tiles) {
      this.tiles = tiles;
   }

   public void update() {
      if (!this.world.isRemote && this.world.getTotalWorldTime() % 3L == 0L && this.game && this.trackActive != null) {
         int count = 0;
         if (this.wonLast) {
            count++;
            this.wonLast = false;
         }

         for (int i = 0; i < this.trackActive.length; i++) {
            if (this.trackActive[i]) {
               ArrayList<PowerColliderNode> track = this.tracks.get(i);
               int index = this.trackIndices[i];
               PowerColliderNode trackNode = track.get(index);
               BlockPos trackPos = this.ref
                  .add(
                     this.upDir.getX() * trackNode.getX() + this.leftDir.getX() * trackNode.getZ(),
                     0,
                     this.upDir.getZ() * trackNode.getX() + this.leftDir.getZ() * trackNode.getZ()
                  );
               if (index > 0) {
                  this.world.setBlockState(trackPos, BlockInit.powerColliderTrack.getStateFromMeta(0));
                  this.trackIndices[i] = index - 1;
                  trackNode = track.get(index - 1);
                  trackPos = this.ref
                     .add(
                        this.upDir.getX() * trackNode.getX() + this.leftDir.getX() * trackNode.getZ(),
                        0,
                        this.upDir.getZ() * trackNode.getX() + this.leftDir.getZ() * trackNode.getZ()
                     );
                  this.world.setBlockState(trackPos, BlockInit.powerColliderTrack.getStateFromMeta(1));
               } else {
                  this.world.setBlockState(trackPos, BlockInit.powerColliderTrack.getStateFromMeta(2));
                  this.trackIndices[i] = track.size() - 1;
                  trackNode = track.get(track.size() - 1);
                  trackPos = this.ref
                     .add(
                        this.upDir.getX() * trackNode.getX() + this.leftDir.getX() * trackNode.getZ(),
                        0,
                        this.upDir.getZ() * trackNode.getX() + this.leftDir.getZ() * trackNode.getZ()
                     );
                  this.world.setBlockState(trackPos, BlockInit.powerColliderTrack.getStateFromMeta(1));
                  this.trackActive[i] = false;
                  count++;
                  this.wonLast = true;
               }
            }
         }

         if (count == 2) {
            EntityItem item = new EntityItem(
               this.world,
               this.pos.getX(),
               this.pos.getY() + 2,
               this.pos.getZ(),
               new ItemStack(ItemInit.powerClamp, 1)
            );
            item.motionX = 0.0;
            item.motionY = 0.0;
            item.motionZ = 0.0;
            this.world.spawnEntity(item);
            this.game = false;
         }
      }
   }

   public void light(BlockPos pos) {
      if (this.game && this.ref != null && this.grid != null) {
         int i = 0;
         int j = 0;
         if (this.upDir.getX() == 0) {
            i = Math.abs(pos.getZ() - this.ref.getZ());
            j = Math.abs(pos.getX() - this.ref.getX());
         } else {
            j = Math.abs(pos.getZ() - this.ref.getZ());
            i = Math.abs(pos.getX() - this.ref.getX());
         }

         PowerColliderNode node = this.grid.getNodeAtLocation(i, j);
         if (node != null && this.trackIndices != null && this.trackActive != null) {
            for (int k = 0; k < this.trackIndices.length; k++) {
               ArrayList<PowerColliderNode> track = this.tracks.get(k);
               int index = this.trackIndices[k];
               if (index == track.size() - 1) {
                  this.world
                     .playSound(null, pos, SoundInit.GENERIC_UI_1, SoundCategory.BLOCKS, 1.0F, 0.8F * this.world.rand.nextFloat() * 0.4F);
                  PowerColliderNode trackNode = track.get(index);
                  BlockPos trackPos = this.ref
                     .add(
                        this.upDir.getX() * trackNode.getX() + this.leftDir.getX() * trackNode.getZ(),
                        0,
                        this.upDir.getZ() * trackNode.getX() + this.leftDir.getZ() * trackNode.getZ()
                     );
                  if (trackPos.equals(pos)) {
                     this.trackActive[k] = true;
                     break;
                  }
               }
            }
         }
      }
   }
}
