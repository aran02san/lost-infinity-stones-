package xol.lostinfinity.block.tileentity.render;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import xol.lostinfinity.block.tileentity.TileEntityEternalBeacon;
import xol.lostinfinity.util.math.LMath;

public class RenderEternalBeacon extends TileEntitySpecialRenderer<TileEntityEternalBeacon> {
   private static final ResourceLocation TEXTURE = new ResourceLocation("lostinfinity:textures/particles/eternal_beacon_beam.png");

   public void render(TileEntityEternalBeacon te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      if (te.getTickRemaining() > 0) {
         GlStateManager.disableCull();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(770, 1);
         this.enableMaxLighting();
         this.bindTexture(TEXTURE);
         Tessellator tessellator = Tessellator.getInstance();
         BufferBuilder bufferbuilder = tessellator.getBuffer();
         GlStateManager.pushMatrix();
         GlStateManager.translate(x + 0.5, y, z + 0.5);
         float seg = 24.0F;
         float offset = (te.getActiveTick() - 1 + partialTicks) * 0.25F * (float) (Math.PI / 180.0);
         float delta = 360.0F / seg * (float) (Math.PI / 180.0);
         float radius = te.getRadius();
         double height = -1.0;

         for (int i = 0; i < seg; i++) {
            double x1 = MathHelper.sin(offset + i * delta) * radius;
            double z1 = MathHelper.cos(offset + i * delta) * radius;
            double x2 = MathHelper.sin(offset + (i + 1) * delta) * radius;
            double z2 = MathHelper.cos(offset + (i + 1) * delta) * radius;
            if (height < 0.0) {
               height = LMath.fastLength(x2 - x1, 0.0, z2 - z1);
            }

            for (float j = -16.0F; j < 256.0F; j = (float)(j + height)) {
               float r = MathHelper.clamp((256.0F - j) / 256.0F, 0.0F, 1.0F);
               GlStateManager.color(1.0F, 1.0F, 1.0F, r);
               bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
               bufferbuilder.pos(x2, j, z2).tex(1.0, 0.0).endVertex();
               bufferbuilder.pos(x1, j, z1).tex(0.0, 0.0).endVertex();
               bufferbuilder.pos(x1, j + height, z1).tex(0.0, 1.0).endVertex();
               bufferbuilder.pos(x2, j + height, z2).tex(1.0, 1.0).endVertex();
               tessellator.draw();
            }
         }

         GlStateManager.popMatrix();
         GlStateManager.enableCull();
         GlStateManager.disableBlend();
      }
   }

   public boolean isGlobalRenderer(TileEntityEternalBeacon te) {
      return true;
   }

   private void enableMaxLighting() {
      GlStateManager.disableLighting();
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
   }
}
