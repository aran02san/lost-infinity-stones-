package xol.lostinfinity.block.tileentity;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;

public class TileEntityGearbox extends TileEntity implements IMachine, ITickable {
   private int[] pegPositions = new int[6];
   private int[] gears = new int[6];
   private int[] placedGears = new int[6];
   private boolean active = false;
   private int ticks = 0;

   @Override
   public boolean getPowered() {
      for (IMachine machine : this.getConnectedMachines(this, null)) {
         if (machine instanceof TileEntityCombustionEngine) {
            return machine.getPowered();
         }
      }

      return false;
   }

   public void setActive(boolean active) {
      if (!this.active && active) {
         this.world.playSound(null, this.getPos(), SoundEvents.BLOCK_ANVIL_PLACE, SoundCategory.BLOCKS, 1.5F, 1.0F);
      }

      this.active = active;
   }

   public int[] getPlacedGears() {
      return this.placedGears;
   }

   public void setPlacedGears(int[] placedGears) {
      this.placedGears = placedGears;
   }

   public void update() {
      if (this.world.isRemote && this.pegPositions[1] == 0) {
         this.pegPositions[0] = 0;
         int curPos = 0;
         int curGear = 0;

         for (int i = 0; i < this.gears.length; i++) {
            if (curGear == 0) {
               curGear = this.world.rand.nextInt(5) + 2;
               this.gears[0] = curGear;
            } else {
               int newGear = this.world.rand.nextInt(5) + 2;
               this.gears[i] = newGear;
               curPos += newGear + curGear + 1;
               curGear = newGear;
               this.pegPositions[i] = curPos;
            }
         }
      }

      if (!this.world.isRemote) {
         this.ticks++;
         if (this.ticks % 10 == 0) {
            this.doBlockUpdate();
         }
      }
   }

   public int[] getGears() {
      return this.gears;
   }

   public int[] getPegPositions() {
      return this.pegPositions;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.active = compound.getBoolean("active");
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      compound.setBoolean("active", this.active);
      return super.writeToNBT(compound);
   }

   public boolean getActive() {
      return this.active;
   }

   @Nullable
   public SPacketUpdateTileEntity getUpdatePacket() {
      return new SPacketUpdateTileEntity(this.getPos(), 0, this.getUpdateTag());
   }

   public NBTTagCompound getUpdateTag() {
      return this.writeToNBT(new NBTTagCompound());
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
      this.handleUpdateTag(pkt.getNbtCompound());
   }

   private void doBlockUpdate() {
      IBlockState state = this.world.getBlockState(this.getPos());
      this.world.notifyBlockUpdate(this.getPos(), state, state, 3);
   }
}
