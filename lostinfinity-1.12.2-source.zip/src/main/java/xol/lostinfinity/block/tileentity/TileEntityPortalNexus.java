package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.BlockInit;

public class TileEntityPortalNexus extends TileEntity implements ITickable {
   private boolean active = false;
   private ArrayList<BlockPos> nodePositions = null;
   private double growth = 0.05;
   private static final double maxGrowth = 20.0;
   private static final double growthSpeed = 0.1;
   private float rotation = 0.0F;
   private static final double rotationSpeed = 0.2F;

   public void update() {
      if (this.world.getBlockState(this.getPos()).equals(BlockInit.portalNexus.getStateFromMeta(1))) {
         this.active = true;
      } else {
         this.active = false;
         this.growth = 0.05;
         this.rotation = 0.0F;
      }

      this.rotation = (float)(this.rotation + 0.2F);
      if (this.growth <= 20.0) {
         this.growth += 0.1;
      }
   }

   public boolean isActive() {
      return this.active;
   }

   public boolean shouldRenderInPass(int pass) {
      return true;
   }

   public AxisAlignedBB getRenderBoundingBox() {
      return INFINITE_EXTENT_AABB;
   }

   @SideOnly(Side.CLIENT)
   public double getMaxRenderDistanceSquared() {
      return 65536.0;
   }

   public void addNodePos(BlockPos pos) {
      if (this.nodePositions == null) {
         this.nodePositions = new ArrayList<>();
      }

      if (!this.nodePositions.contains(pos)) {
         this.nodePositions.add(pos);
      }

      if (this.nodePositions.size() >= 4) {
         this.world.setBlockState(this.getPos(), BlockInit.portalNexus.getStateFromMeta(1));
      }
   }

   public double getGrowth() {
      return this.growth;
   }

   public float getRotation() {
      return this.rotation;
   }
}
