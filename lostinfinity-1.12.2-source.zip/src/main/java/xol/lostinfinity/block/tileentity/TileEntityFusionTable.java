package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.common.packets.serverbound.PacketFusionTable;
import xol.lostinfinity.init.ItemInit;

public class TileEntityFusionTable extends TileEntity implements IInventory, ITickable {
   private static final boolean DEBUG = false;
   public static final int BOARD_ROWS = 4;
   public static final int BOARD_COLUMNS = 6;
   public static final int BOARD_SIZE = 24;
   private NonNullList<ItemStack> inventory = NonNullList.withSize(3, ItemStack.EMPTY);
   private List<TileEntityFusionTable.BoardPiece> board = new ArrayList<>();
   private List<Integer> upcomingPieces = new ArrayList<>();
   private int progress = 0;

   public void update() {
      int weight = 0;

      for (TileEntityFusionTable.BoardPiece piece : this.board) {
         weight += piece.getShapeId();
      }

      if (weight > 0) {
         if (this.world.isRemote) {
            this.checkMatches();
         }

         if (this.progress == 6) {
            this.fuseCraft();
            return;
         }
      }

      if ((
            ((ItemStack)this.inventory.get(0)).getItem().equals(ItemInit.ioniteBar)
               || ((ItemStack)this.inventory.get(0)).getItem().equals(ItemInit.inverseMagnecronite)
         )
         && (
            ((ItemStack)this.inventory.get(1)).getItem().equals(ItemInit.ioniteBar)
               || ((ItemStack)this.inventory.get(1)).getItem().equals(ItemInit.inverseMagnecronite)
         )
         && weight <= 0) {
         if (this.world.isRemote) {
            this.fillBoard();
            this.fillUpcomingPieces();
         }
      } else if ((((ItemStack)this.inventory.get(0)).isEmpty() || ((ItemStack)this.inventory.get(1)).isEmpty() && weight > 0)
         && this.world.isRemote) {
         this.resetBoard();
      }
   }

   public int getField(int id) {
      if (this.upcomingPieces.isEmpty() || this.board.isEmpty()) {
         return 0;
      } else if (id >= 0 && id < 24) {
         return this.board.get(id).getShapeId();
      } else if (id == 24) {
         return this.upcomingPieces.get(0);
      } else if (id == 25) {
         return this.upcomingPieces.get(1);
      } else {
         return id == 27 ? this.progress : 0;
      }
   }

   public void setField(int id, int value) {
      if (!this.world.isRemote && this.board.isEmpty()) {
         for (int i = 0; i < 24; i++) {
            this.board.add(new TileEntityFusionTable.BoardPiece(0, 0, 0));
         }

         if (this.upcomingPieces.isEmpty()) {
            this.upcomingPieces.add(0);
            this.upcomingPieces.add(0);
         }
      }

      if (id >= 0 && id < 24) {
         this.board.get(id).setShapeId(value);
      } else if (id == 24) {
         this.upcomingPieces.set(0, value);
      } else if (id == 25) {
         this.upcomingPieces.set(1, value);
      } else if (id == 27) {
         this.progress = value;
      }
   }

   @SideOnly(Side.CLIENT)
   private void resetBoard() {
      this.board.clear();
      this.upcomingPieces.clear();

      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 6; j++) {
            this.board.add(new TileEntityFusionTable.BoardPiece(i, j, 0));
         }
      }

      this.upcomingPieces.add(0);
      this.upcomingPieces.add(0);
      this.progress = 0;

      for (int i = 0; i < 24; i++) {
         lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), this.getField(i), i));
      }

      lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), this.getField(24), 24));
      lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), this.getField(25), 25));
      lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), this.getField(27), 27));
   }

   @SideOnly(Side.CLIENT)
   private void fillBoard() {
      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 6; j++) {
            this.board.add(new TileEntityFusionTable.BoardPiece(i, j, 0));
         }
      }

      int weight = 0;

      for (int i = 0; i < 4; i++) {
         for (int j = 0; j < 6; j++) {
            int shapeId = new Random().nextInt(12) + 1;
            int boardIndex = i * 6 + j;
            if (shapeId > 0 && shapeId < 6) {
               weight++;
            } else {
               weight--;
            }

            this.board.set(boardIndex, new TileEntityFusionTable.BoardPiece(i, j, shapeId));
         }

         new Random().nextInt(12);
      }

      if (weight != -4) {
         this.resetBoard();
         this.fillBoard();
      }

      for (int i = 0; i < 24; i++) {
         lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), this.getField(i), i));
      }
   }

   @SideOnly(Side.CLIENT)
   private void fillUpcomingPieces() {
      this.upcomingPieces.add(0);
      this.upcomingPieces.add(0);

      for (int i = 0; i < 2; i++) {
         int shapeId = new Random().nextInt(5) + 1;
         this.upcomingPieces.set(i, shapeId);
      }

      lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), this.getField(24), 24));
      lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), this.getField(25), 25));
   }

   @SideOnly(Side.CLIENT)
   public void checkMatches() {
      if (!this.board.isEmpty() && !this.upcomingPieces.isEmpty()) {
         for (int i = 1; i <= 24; i++) {
            if (i % 6 != 0) {
               if (i >= 19) {
                  break;
               }

               int currentPiece = this.board.get(i - 1).getShapeId();
               int nextPiece = this.board.get(i).getShapeId();
               int pieceBelow = this.board.get(i + 5).getShapeId();
               int pieceBelowNext = this.board.get(i + 6).getShapeId();
               if (currentPiece == nextPiece && currentPiece == pieceBelow && currentPiece == pieceBelowNext && currentPiece != 0) {
                  if (this.world.isRemote) {
                     int clientProg = this.progress + 1;
                     this.shuffleBoard();
                     lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), clientProg, 27));
                  }

                  return;
               }
            }
         }

         for (int ix = 0; ix < 24; ix++) {
            if (this.board.get(ix).getShapeId() <= 0 || this.board.get(ix).getShapeId() >= 6) {
               return;
            }

            if (ix == 23 && this.world.isRemote) {
               this.shuffleBoard();
               int clientProg = 0;
               lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketFusionTable(this.getPos(), clientProg, 27));
            }
         }
      }
   }

   @SideOnly(Side.CLIENT)
   private void shuffleBoard() {
      this.resetBoard();
      this.fillBoard();
      this.fillUpcomingPieces();
   }

   private void fuseCraft() {
      if (this.world.isRemote) {
         this.shuffleBoard();
      } else {
         ItemStack input1 = (ItemStack)this.inventory.get(0);
         ItemStack input2 = (ItemStack)this.inventory.get(1);
         this.progress = 0;
         ItemStack output;
         if (((ItemStack)this.inventory.get(2)).isEmpty()) {
            output = new ItemStack(ItemInit.polyionite, 1);
         } else {
            output = (ItemStack)this.inventory.get(2);
            output.setCount(output.getCount() + 1);
         }

         input1.setCount(input1.getCount() - 1);
         input2.setCount(input2.getCount() - 1);
         this.inventory.set(0, input1);
         this.inventory.set(1, input2);
         this.inventory.set(2, output);
      }

      this.markDirty();
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      for (ItemStack stack : this.inventory) {
         if (!stack.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return this.world.getTileEntity(this.pos) != this
         ? false
         : player.getDistanceSq(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5)
            <= 64.0;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      return false;
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setInteger("progress", this.progress);
      ItemStackHelper.saveAllItems(compound, this.inventory);
      if (this.board.size() > 0) {
         for (int i = 0; i < 24; i++) {
            compound.setInteger("board" + i, this.board.get(i).getShapeId());
         }

         compound.setInteger("upcomingPieces0", this.upcomingPieces.get(0));
         compound.setInteger("upcomingPieces1", this.upcomingPieces.get(1));
      }

      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.progress = compound.getInteger("progress");
      ItemStackHelper.loadAllItems(compound, this.inventory);

      for (int i = 0; i < 24; i++) {
         this.board.add(new TileEntityFusionTable.BoardPiece(i / 6, i % 6, compound.getInteger("board" + i)));
      }

      this.upcomingPieces.add(compound.getInteger("upcomingPieces0"));
      this.upcomingPieces.add(compound.getInteger("upcomingPieces1"));
   }

   public int getFieldCount() {
      return 27;
   }

   public void clear() {
      this.inventory.clear();
   }

   public String getName() {
      return "tile.fusion_table";
   }

   public boolean hasCustomName() {
      return false;
   }

   public class BoardPiece {
      private final int row;
      private final int column;
      private int shapeId;

      public BoardPiece(int row, int column, int shapeId) {
         this.row = row;
         this.column = column;
         this.shapeId = shapeId;
      }

      public int getRow() {
         return this.row;
      }

      public int getColumn() {
         return this.column;
      }

      public int getShapeId() {
         return this.shapeId;
      }

      public void setShapeId(int shapeId) {
         this.shapeId = shapeId;
      }

      @Override
      public String toString() {
         return "Row: " + this.row + " Column: " + this.column + " ShapeId: " + this.shapeId;
      }
   }

   public static enum Shapes {
      SQUARE(1, 0, 166),
      VERTICAL_RECTANGLE(2, 12, 166),
      DIAGONAL_RECTANGLE(3, 24, 166),
      TRIANGLE(4, 36, 166),
      HORIZONTAL_RECTANGLE(5, 48, 166);

      private final int id;
      private final int pixelX;
      private final int pixelY;

      private Shapes(int id, int pixelX, int pixelY) {
         this.id = id;
         this.pixelX = pixelX;
         this.pixelY = pixelY;
      }

      public int getId() {
         return this.id;
      }

      public int getPixelX() {
         return this.pixelX;
      }

      public int getPixelY() {
         return this.pixelY;
      }

      public static TileEntityFusionTable.Shapes getShapeFromId(int id) {
         for (TileEntityFusionTable.Shapes shape : values()) {
            if (shape.getId() == id) {
               return shape;
            }
         }

         return null;
      }
   }
}
