package xol.lostinfinity.block.tileentity.render;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Rotations;
import net.minecraft.util.math.Vec3d;
import xol.lostinfinity.block.tileentity.TileEntityTeslaTower;
import xol.lostinfinity.util.math.LMath;

public class RenderTeslaTower extends TileEntitySpecialRenderer<TileEntityTeslaTower> {
   public static final ResourceLocation TEXTURE_LIGHTNING_BOLT_YELLOW = new ResourceLocation("lostinfinity:textures/particles/lightning_bolt.png");
   public static final ResourceLocation TEXTURE_LIGHTNING_BOLT_BRIGHT = new ResourceLocation("lostinfinity:textures/particles/lightning_bolt_bright.png");
   public static final ResourceLocation TEXTURE_LIGHTNING_BOLT_BLUE = new ResourceLocation("lostinfinity:textures/particles/lightning_bolt_blue.png");

   public void render(TileEntityTeslaTower te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      if (te.isActive()) {
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(770, 771);
         this.enableMaxLighting();
         if (te.getTickExisted() % (te.getRandom1() + 1) == 0) {
            if (te.getRandom1() <= 10) {
               GlStateManager.disableBlend();
               return;
            }

            GlStateManager.blendFunc(770, 1);
         }

         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         this.bindTextureForTE(te);
         Tessellator tessellator = Tessellator.getInstance();
         BufferBuilder bufferbuilder = tessellator.getBuffer();
         GlStateManager.pushMatrix();
         GlStateManager.translate(x + 0.5, y + 0.5, z + 0.5);

         for (BlockPos pos : te.getConnected()) {
            GlStateManager.pushMatrix();
            float offset = te.getTickExisted() % (te.getRandom1() + 1) == 0 ? te.getRandom3() - 0.5F : 0.0F;
            double targetX = pos.getX() - te.getPos().getX();
            double targetY = pos.getY() - te.getPos().getY();
            double targetZ = pos.getZ() - te.getPos().getZ();
            Vec3d delta = new Vec3d(targetX, targetY, targetZ);
            Rotations rotations = LMath.toPitchYaw(delta);
            GlStateManager.rotate(rotations.getY(), 0.0F, -1.0F, 0.0F);
            GlStateManager.rotate(rotations.getX(), 1.0F, 0.0F, 0.0F);
            double length = LMath.fastLength(delta);

            for (int i = 0; i < length - 1.0; i++) {
               bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
               bufferbuilder.pos(0.01, -0.5, offset + i).tex(1.0, 0.0).endVertex();
               bufferbuilder.pos(0.01, -0.5, offset + i + 1.0F).tex(0.0, 0.0).endVertex();
               bufferbuilder.pos(0.01, 0.5, offset + i + 1.0F).tex(0.0, 1.0).endVertex();
               bufferbuilder.pos(0.01, 0.5, offset + i).tex(1.0, 1.0).endVertex();
               tessellator.draw();
            }

            double fraction = length % 1.0;
            double last = length - fraction;
            bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
            bufferbuilder.pos(0.01, -0.5, offset + last).tex(fraction, 0.0).endVertex();
            bufferbuilder.pos(0.01, -0.5, offset + last + fraction).tex(0.0, 0.0).endVertex();
            bufferbuilder.pos(0.01, 0.5, offset + last + fraction).tex(0.0, 1.0).endVertex();
            bufferbuilder.pos(0.01, 0.5, offset + last).tex(fraction, 1.0).endVertex();
            tessellator.draw();
            GlStateManager.popMatrix();
         }

         GlStateManager.popMatrix();
         GlStateManager.disableBlend();
      }
   }

   public boolean isGlobalRenderer(TileEntityTeslaTower te) {
      return true;
   }

   private void bindTextureForTE(TileEntityTeslaTower te) {
      int remainder = te.getTickExisted() % (te.getRandom2() + 1);
      switch (remainder) {
         case 0:
            this.bindTexture(TEXTURE_LIGHTNING_BOLT_BRIGHT);
            break;
         case 1:
            this.bindTexture(TEXTURE_LIGHTNING_BOLT_BLUE);
            break;
         default:
            this.bindTexture(TEXTURE_LIGHTNING_BOLT_YELLOW);
      }
   }

   private void enableMaxLighting() {
      GlStateManager.disableLighting();
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
   }
}
