package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;

public interface IMachine {
   default ArrayList<IMachine> getConnectedMachines(TileEntity te, ArrayList<IMachine> machines) {
      if (machines == null) {
         machines = new ArrayList<>();
      }

      if (machines.contains(this)) {
         return machines;
      } else {
         machines.add(this);

         for (BlockPos checkPos : BlockPos.getAllInBox(te.getPos().add(-1, -1, -1), te.getPos().add(1, 1, 1))) {
            if (!checkPos.equals(te.getPos())) {
               TileEntity checkTe = te.getWorld().getTileEntity(checkPos);
               if (checkTe != null && checkTe instanceof IMachine) {
                  IMachine newMachine = (IMachine)checkTe;
                  if (!machines.contains(newMachine)) {
                     machines.addAll(newMachine.getConnectedMachines(checkTe, machines));
                  }
               }
            }
         }

         return machines;
      }
   }

   default boolean getPowered() {
      return false;
   }
}
