package xol.lostinfinity.block.tileentity.render;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import xol.lostinfinity.block.tileentity.TileEntityPortalNexus;
import xol.lostinfinity.init.BlockInit;

public class RenderPortalNexus extends TileEntitySpecialRenderer<TileEntityPortalNexus> {
   public static final ResourceLocation TEXTURE_SUMMONING_PORTAL = new ResourceLocation("lostinfinity:textures/particles/summoning_portal.png");

   public void render(TileEntityPortalNexus te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      IBlockState state = te.getWorld().getBlockState(te.getPos());
      Block block = state.getBlock();
      if (!block.equals(BlockInit.portalNode) || state == BlockInit.portalNode.getStateFromMeta(1)) {
         double targetHeight = 1.0;
         this.bindTexture(TEXTURE_SUMMONING_PORTAL);
         Tessellator tessellator = Tessellator.getInstance();
         BufferBuilder bufferbuilder = tessellator.getBuffer();
         GlStateManager.disableCull();
         GlStateManager.enableAlpha();
         GlStateManager.enableBlend();
         GlStateManager.alphaFunc(516, 0.3F);
         bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
         double growth = te.getGrowth();
         float rotation = te.getRotation();
         double xPos = x + 0.5;
         double yPos = y + 0.1F;
         double zPos = z + 0.5;
         Vec3d dirRight = new Vec3d(1.0, 0.0, 0.0);
         dirRight = dirRight.rotateYaw(rotation);
         Vec3d dirForward = new Vec3d(0.0, 0.0, 1.0);
         dirForward = dirForward.rotateYaw(rotation);
         bufferbuilder.pos(
               -0.5 * growth * dirRight.x + 0.5 * growth * dirForward.x + xPos,
               targetHeight + yPos,
               -0.5 * growth * dirRight.z + 0.5 * growth * dirForward.z + zPos
            )
            .tex(0.0, 1.0)
            .endVertex();
         bufferbuilder.pos(
               -0.5 * growth * dirRight.x - 0.5 * growth * dirForward.x + xPos,
               targetHeight + yPos,
               -0.5 * growth * dirRight.z - 0.5 * growth * dirForward.z + zPos
            )
            .tex(0.0, 0.0)
            .endVertex();
         bufferbuilder.pos(
               0.5 * growth * dirRight.x - 0.5 * growth * dirForward.x + xPos,
               targetHeight + yPos,
               0.5 * growth * dirRight.z - 0.5 * growth * dirForward.z + zPos
            )
            .tex(1.0, 0.0)
            .endVertex();
         bufferbuilder.pos(
               0.5 * growth * dirRight.x + 0.5 * growth * dirForward.x + xPos,
               targetHeight + yPos,
               0.5 * growth * dirRight.z + 0.5 * growth * dirForward.z + zPos
            )
            .tex(1.0, 1.0)
            .endVertex();
         tessellator.draw();
         GlStateManager.enableCull();
         GlStateManager.disableBlend();
      }
   }
}
