package xol.lostinfinity.block.tileentity;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.misc.BlockCthulhuSpawner;
import xol.lostinfinity.init.ItemInit;

public class TileEntityCthulhuSpawner extends TileEntity implements ITickable, IInventory {
   public boolean spawned = false;
   private NonNullList<ItemStack> inventory = NonNullList.withSize(1, ItemStack.EMPTY);
   private EnumFacing facing;
   private int burnTime;
   private int currentBurnTime;

   public void update() {
      boolean burning = this.isBurning();
      boolean sync = false;
      if (this.isBurning()) {
         this.burnTime--;
      }

      if (!this.world.isRemote) {
         if (this.canSpawn() && this.facing == EnumFacing.NORTH) {
            this.spawned = BlockCthulhuSpawner.spawnCthulhu(this.world, this.pos);
         }

         ItemStack fuel = (ItemStack)this.inventory.get(0);
         if ((this.isBurning() || !fuel.isEmpty()) && !this.isBurning() && this.spawned) {
            this.burnTime = getItemBurnTime(fuel);
            this.currentBurnTime = this.burnTime;
            if (this.isBurning()) {
               sync = true;
               if (!fuel.isEmpty()) {
                  Item item = fuel.getItem();
                  fuel.shrink(1);
                  if (fuel.isEmpty()) {
                     ItemStack itemContainer = item.getContainerItem(fuel);
                     this.inventory.set(0, itemContainer);
                  }
               }
            }
         }

         if (burning != this.isBurning()) {
            sync = true;
            if (this.spawned && !this.isBurning()) {
               this.spawned = false;
            }
         }
      }

      if (sync) {
         this.markDirty();
         this.doBlockUpdate();
      }
   }

   public boolean isBurning() {
      return this.burnTime > 0;
   }

   public boolean canSpawn() {
      return !this.spawned && this.getStackInSlot(0).getCount() >= 2;
   }

   private static int getItemBurnTime(ItemStack fuel) {
      if (fuel.isEmpty()) {
         return 0;
      } else {
         return fuel.getItem() == ItemInit.eternoCell ? 300 : 0;
      }
   }

   public static boolean isItemFuel(ItemStack fuel) {
      return getItemBurnTime(fuel) > 0;
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      return false;
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      ItemStack itemstack = (ItemStack)this.inventory.get(index);
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }

      boolean same = stack.isEmpty() || !stack.isItemEqual(itemstack) || !ItemStack.areItemStackTagsEqual(stack, itemstack);
      if (index == 0 && same) {
         this.markDirty();
      }
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return this.world.getTileEntity(this.pos) == this
         && player.getDistanceSq(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5)
            <= 64.0;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      return index == 0 ? isItemFuel(stack) : false;
   }

   public int getField(int id) {
      switch (id) {
         case 0:
            return this.burnTime;
         case 1:
            return this.currentBurnTime;
         default:
            return 0;
      }
   }

   public void setField(int id, int value) {
      switch (id) {
         case 0:
            this.burnTime = value;
            break;
         case 1:
            this.currentBurnTime = value;
      }
   }

   public int getFieldCount() {
      return 2;
   }

   public void clear() {
      this.inventory.clear();
   }

   public String getName() {
      return "tile.cthulhu_spawner";
   }

   public boolean hasCustomName() {
      return false;
   }

   public EnumFacing getFacing() {
      return BlockCthulhuSpawner.getFacing(this.world, this.pos);
   }

   @SideOnly(Side.CLIENT)
   public AxisAlignedBB getRenderBoundingBox() {
      return INFINITE_EXTENT_AABB;
   }

   public void onLoad() {
      this.facing = this.getFacing();
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setInteger("BurnTime", (short)this.burnTime);
      compound.setBoolean("Spawned", this.spawned);
      ItemStackHelper.saveAllItems(compound, this.inventory);
      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.inventory = NonNullList.withSize(this.getSizeInventory(), ItemStack.EMPTY);
      ItemStackHelper.loadAllItems(compound, this.inventory);
      this.burnTime = compound.getInteger("BurnTime");
      this.currentBurnTime = getItemBurnTime((ItemStack)this.inventory.get(0));
      this.spawned = compound.getBoolean("Spawned");
   }

   public NBTTagCompound getUpdateTag() {
      return this.writeToNBT(new NBTTagCompound());
   }

   @Nullable
   public SPacketUpdateTileEntity getUpdatePacket() {
      return new SPacketUpdateTileEntity(this.pos, 0, this.getUpdateTag());
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
      this.readFromNBT(pkt.getNbtCompound());
   }

   public void doBlockUpdate() {
      IBlockState blockState = this.world.getBlockState(this.getPos());
      this.world.notifyBlockUpdate(this.getPos(), blockState, blockState, 3);
   }
}
