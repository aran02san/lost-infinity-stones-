package xol.lostinfinity.block.tileentity;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class TileEntityEternalBeacon extends TileEntityGenerator implements ITickable {
   private int tickRemaining;
   private int activeTick;
   private int radius;

   public void update() {
      this.activeTick++;
      if (this.tickRemaining > 0) {
         this.tickRemaining--;
      }
   }

   public int getTickRemaining() {
      return this.tickRemaining;
   }

   public int getActiveTick() {
      return this.activeTick;
   }

   public void setTickRemaining(int tickRemaining) {
      this.tickRemaining = tickRemaining;
   }

   public int getRadius() {
      return this.radius;
   }

   public void setRadius(int radius) {
      this.radius = radius;
   }

   @SideOnly(Side.CLIENT)
   public AxisAlignedBB getRenderBoundingBox() {
      return INFINITE_EXTENT_AABB;
   }

   @SideOnly(Side.CLIENT)
   public double getMaxRenderDistanceSquared() {
      return 65536.0;
   }

   @Nullable
   public SPacketUpdateTileEntity getUpdatePacket() {
      return new SPacketUpdateTileEntity(this.pos, 0, this.getUpdateTag());
   }

   public NBTTagCompound getUpdateTag() {
      NBTTagCompound compound = new NBTTagCompound();
      compound.setInteger("tick", this.tickRemaining);
      compound.setInteger("radius", this.radius);
      return compound;
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
      this.handleUpdateTag(pkt.getNbtCompound());
   }

   public void handleUpdateTag(NBTTagCompound tag) {
      this.tickRemaining = tag.getInteger("tick");
      this.radius = tag.getInteger("radius");
   }

   public void doBlockUpdate() {
      IBlockState blockState = this.world.getBlockState(this.getPos());
      this.world.notifyBlockUpdate(this.getPos(), blockState, blockState, 3);
   }
}
