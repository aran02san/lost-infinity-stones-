package xol.lostinfinity.block.tileentity;

import java.util.UUID;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.crafting.BlockNicroniumInfuser;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.recipes.NicroniumInfuserRecipes;

public class TileEntityNicroniumInfuser extends TileEntity implements IInventory, ITickable {
   private NonNullList<ItemStack> inventory = NonNullList.withSize(3, ItemStack.EMPTY);
   private int burnTime;
   private int currentBurnTime;
   private int cookTime;
   private int totalCookTime;
   private UUID placer = null;

   public String getName() {
      return "tile.nicronium_infuser";
   }

   public boolean hasCustomName() {
      return false;
   }

   public void update() {
      boolean burning = this.isBurning();
      boolean sync = false;
      if (this.isBurning()) {
         this.burnTime--;
         if (!this.world.isRemote && this.burnTime % 40 == 0) {
            this.world
               .playSound(null, this.getPos(), SoundInit.INFUSER, SoundCategory.BLOCKS, 1.5F, 0.5F + this.world.rand.nextFloat());
         }
      }

      if (!this.world.isRemote) {
         ItemStack input = (ItemStack)this.inventory.get(0);
         ItemStack fuel = (ItemStack)this.inventory.get(1);
         if (this.isBurning() || !fuel.isEmpty() && !input.isEmpty()) {
            if (!this.isBurning() && this.canSmelt()) {
               this.burnTime = getItemBurnTime(fuel);
               this.currentBurnTime = this.burnTime;
               if (this.isBurning()) {
                  sync = true;
                  if (!fuel.isEmpty()) {
                     Item item = fuel.getItem();
                     fuel.shrink(1);
                     if (fuel.isEmpty()) {
                        ItemStack itemContainer = item.getContainerItem(fuel);
                        this.inventory.set(1, itemContainer);
                     }
                  }
               }
            }

            if (this.isBurning() && this.canSmelt()) {
               this.cookTime++;
               BlockPos pos = this.getPos();
               if (this.placer != null) {
                  for (EntityPlayerMP playerMP : this.world.getMinecraftServer().getPlayerList().getPlayers()) {
                     if (playerMP.world.equals(this.world)
                        && !playerMP.getUniqueID().equals(this.placer)
                        && playerMP.getDistance(
                              this.getPos().getX(), this.getPos().getY(), this.getPos().getZ()
                           )
                           < 500.0) {
                        playerMP.addPotionEffect(new PotionEffect(PotionInit.INTANGIBLE, 200, 0));
                     }
                  }
               }

               if (this.cookTime >= this.totalCookTime) {
                  this.cookTime = 0;
                  this.totalCookTime = this.getCookTime((ItemStack)this.inventory.get(0));
                  this.smeltItem();
                  sync = true;
               }
            } else {
               this.cookTime = 0;
            }
         } else if (!this.isBurning() && this.cookTime > 0) {
            this.cookTime = MathHelper.clamp(this.cookTime - 2, 0, this.totalCookTime);
         }

         if (burning != this.isBurning()) {
            sync = true;
            BlockNicroniumInfuser.setState(this.isBurning(), this.world, this.pos);
         }
      }

      if (sync) {
         this.markDirty();
      }
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      for (ItemStack stack : this.inventory) {
         if (!stack.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      ItemStack itemstack = (ItemStack)this.inventory.get(index);
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }

      boolean same = stack.isEmpty() || !stack.isItemEqual(itemstack) || !ItemStack.areItemStackTagsEqual(stack, itemstack);
      if (index == 0 && same) {
         this.totalCookTime = this.getCookTime(stack);
         this.cookTime = 0;
         this.markDirty();
      }
   }

   private boolean canSmelt() {
      ItemStack input = (ItemStack)this.inventory.get(0);
      ItemStack fuel = (ItemStack)this.inventory.get(1);
      if (!input.isEmpty() && !fuel.isEmpty()) {
         ItemStack result = NicroniumInfuserRecipes.getResult(input);
         if (result != null && !result.isEmpty()) {
            ItemStack output = (ItemStack)this.inventory.get(2);
            if (output.isEmpty()) {
               return true;
            } else if (!output.isItemEqual(result)) {
               return false;
            } else {
               int count = output.getCount() + result.getCount();
               return count <= this.getInventoryStackLimit() && count <= output.getMaxStackSize();
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public void smeltItem() {
      if (this.canSmelt()) {
         ItemStack input = (ItemStack)this.inventory.get(0);
         ItemStack fuel = (ItemStack)this.inventory.get(1);
         ItemStack result = NicroniumInfuserRecipes.getResult(input);
         ItemStack output = (ItemStack)this.inventory.get(2);
         if (output.isEmpty()) {
            this.inventory.set(2, result.copy());
         } else if (output.getItem() == result.getItem()) {
            output.grow(result.getCount());
         }

         input.shrink(1);
      }
   }

   private int getCookTime(ItemStack stack) {
      return 1500;
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setInteger("BurnTime", (short)this.burnTime);
      compound.setInteger("CookTime", (short)this.cookTime);
      compound.setInteger("TotalCookTime", (short)this.totalCookTime);
      if (this.placer != null) {
         compound.setUniqueId("Placer", this.placer);
      }

      ItemStackHelper.saveAllItems(compound, this.inventory);
      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.inventory = NonNullList.withSize(this.getSizeInventory(), ItemStack.EMPTY);
      ItemStackHelper.loadAllItems(compound, this.inventory);
      this.burnTime = compound.getInteger("BurnTime");
      this.cookTime = compound.getInteger("CookTime");
      this.totalCookTime = compound.getInteger("TotalCookTime");
      this.placer = compound.getUniqueId("Placer");
      this.currentBurnTime = getItemBurnTime((ItemStack)this.inventory.get(1));
   }

   public boolean isBurning() {
      return this.burnTime > 0;
   }

   @SideOnly(Side.CLIENT)
   public static boolean isBurning(IInventory inventory) {
      return inventory.getField(0) > 0;
   }

   private static int getItemBurnTime(ItemStack fuel) {
      if (fuel.isEmpty()) {
         return 0;
      } else {
         return fuel.getItem() == ItemInit.powerfulPolarcronite ? 1000 : 0;
      }
   }

   public static boolean isItemFuel(ItemStack fuel) {
      return getItemBurnTime(fuel) > 0;
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return this.world.getTileEntity(this.pos) != this
         ? false
         : player.getDistanceSq(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5)
            <= 64.0;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      if (index >= 2) {
         return false;
      } else {
         return index == 2 ? isItemFuel(stack) : true;
      }
   }

   public int getGuiID() {
      return GuiHandler.RegisteredGuis.NICRONIUM_INFUSER.getId();
   }

   public int getField(int id) {
      switch (id) {
         case 0:
            return this.burnTime;
         case 1:
            return this.currentBurnTime;
         case 2:
            return this.cookTime;
         case 3:
            return this.totalCookTime;
         default:
            return 0;
      }
   }

   public void setField(int id, int value) {
      switch (id) {
         case 0:
            this.burnTime = value;
            break;
         case 1:
            this.currentBurnTime = value;
            break;
         case 2:
            this.cookTime = value;
            break;
         case 3:
            this.totalCookTime = value;
      }
   }

   public int getFieldCount() {
      return 4;
   }

   public void clear() {
      this.inventory.clear();
   }

   public void setPlacer(EntityPlayer placer) {
      this.placer = placer.getUniqueID();
   }
}
