package xol.lostinfinity.block.tileentity;

import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.BlockInit;

public class TileEntityPortalNode extends TileEntity implements ITickable {
   private boolean active = false;
   private BlockPos nexusPos = null;

   public void update() {
      if (!this.world.isRemote) {
         if (this.world.getBlockState(this.getPos()).equals(BlockInit.portalNode.getStateFromMeta(1))) {
            this.active = true;
         } else {
            this.active = false;
         }
      }
   }

   public boolean isActive() {
      return this.active;
   }

   public boolean shouldRenderInPass(int pass) {
      return true;
   }

   public AxisAlignedBB getRenderBoundingBox() {
      return INFINITE_EXTENT_AABB;
   }

   @SideOnly(Side.CLIENT)
   public double getMaxRenderDistanceSquared() {
      return 65536.0;
   }

   public BlockPos getNexusPos() {
      return this.nexusPos;
   }

   public void setNexusPos(BlockPos nexusPos) {
      this.nexusPos = nexusPos;
   }
}
