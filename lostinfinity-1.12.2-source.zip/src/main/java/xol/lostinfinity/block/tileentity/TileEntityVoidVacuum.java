package xol.lostinfinity.block.tileentity;

import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.ParticleInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.util.damagesource.DeathMessage;
import xol.lostinfinity.util.data.CustomParticleConfig;
import xol.lostinfinity.util.fx.IParticleSpawner;

public class TileEntityVoidVacuum extends TileEntity implements ITickable {
   boolean active = false;
   EntityLivingBase target = null;
   boolean hasPulled = false;

   public void resetPulled() {
      this.hasPulled = false;
   }

   public void setTarget(EntityLivingBase target) {
      this.target = target;
   }

   public EntityLivingBase getTarget() {
      return this.target;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public boolean getActive() {
      return this.active;
   }

   public boolean shouldRenderInPass(int pass) {
      return true;
   }

   public AxisAlignedBB getRenderBoundingBox() {
      return INFINITE_EXTENT_AABB;
   }

   @SideOnly(Side.CLIENT)
   public double getMaxRenderDistanceSquared() {
      return 65536.0;
   }

   public void update() {
      if (!this.world.isRemote) {
         this.world
            .notifyBlockUpdate(
               this.getPos(), this.world.getBlockState(this.getPos()), this.world.getBlockState(this.getPos()), 2
            );
         if (this.active && !this.hasPulled && this.target != null) {
            Vec3d vecPos = new Vec3d(this.getPos().getX(), this.getPos().getY(), this.getPos().getZ());
            double dist = this.target.getPositionVector().distanceTo(vecPos);
            if (dist < 1.5) {
               this.hasPulled = true;
               this.active = false;
               this.target.setHealth(0.0F);
               DeathMessage.broadcastDeathMessage(this.target.getServer(), TextFmt.Red + this.target.getName() + " was sucked into the void.");
               this.target = null;
               EntityItem bone = new EntityItem(
                  this.world,
                  this.pos.getX(),
                  this.pos.getY() + 1,
                  this.pos.getZ(),
                  new ItemStack(ItemInit.voidsplitBone)
               );
               bone.motionX = 0.0;
               bone.motionY = 0.0;
               bone.motionZ = 0.0;
               this.world.spawnEntity(bone);
               CustomParticleConfig config1 = new CustomParticleConfig();
               config1.createInstance().setParticle(ParticleInit.CORRUPTION_MAGIC).setSpread(4.0, 1.0, 4.0).setCount(10).setIgnoreRange(true);
               IParticleSpawner.spawnParticle(
                  this.world,
                  config1,
                  (double)this.pos.getX(),
                  (double)(this.pos.getY() + 1),
                  (double)this.pos.getZ()
               );
               this.world.playSound(null, this.pos, SoundInit.ELECTRIC_WOOSH, SoundCategory.BLOCKS, 1.5F, 1.0F);
            } else {
               Vec3d pullDir = vecPos.subtract(this.target.getPositionVector());
               pullDir = pullDir.normalize();
               this.target.addVelocity(pullDir.x / 5.0, pullDir.y / 5.0 + 0.1F, pullDir.z / 5.0);
               this.target.velocityChanged = true;
            }
         }
      }
   }

   public NBTTagCompound getUpdateTag() {
      NBTTagCompound compound = super.getUpdateTag();
      if (this.target != null) {
         compound.setUniqueId("PlayerID", this.target.getUniqueID());
      } else {
         compound.removeTag("PlayerID");
      }

      return compound;
   }

   public void handleUpdateTag(NBTTagCompound tag) {
      if (tag.hasUniqueId("PlayerID") && tag.getUniqueId("PlayerID") != null) {
         this.target = this.entityByID(tag.getUniqueId("PlayerID"));
         if (this.target != null && !this.target.isDead) {
            this.active = true;
         } else {
            System.out.println("failed");
            this.active = false;
         }
      } else {
         this.active = false;
      }

      super.handleUpdateTag(tag);
   }

   public SPacketUpdateTileEntity getUpdatePacket() {
      return new SPacketUpdateTileEntity(this.getPos(), 1, this.getUpdateTag());
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
      this.handleUpdateTag(pkt.getNbtCompound());
   }

   private EntityLivingBase entityByID(UUID id) {
      for (Entity e : this.world.getLoadedEntityList()) {
         if (e.getUniqueID().equals(id) && e instanceof EntityLivingBase) {
            return (EntityLivingBase)e;
         }
      }

      return null;
   }
}
