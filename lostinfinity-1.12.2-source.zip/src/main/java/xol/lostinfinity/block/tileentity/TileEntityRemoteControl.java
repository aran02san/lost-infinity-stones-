package xol.lostinfinity.block.tileentity;

import java.util.UUID;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import xol.lostinfinity.item.basics.ItemRemoteControl;

public class TileEntityRemoteControl extends TileEntity implements ITickable {
   boolean active = false;
   private ItemRemoteControl controller = null;
   private int ticksExited = 0;
   private UUID placer = null;

   public void setController(ItemRemoteControl controller) {
      this.controller = controller;
   }

   public ItemRemoteControl getController() {
      return this.controller;
   }

   public void setActive(boolean active) {
      this.active = active;
   }

   public boolean getActive() {
      return this.active;
   }

   public int getExisted() {
      return this.ticksExited;
   }

   public void setPlacer(EntityPlayer placer) {
      this.placer = placer.getUniqueID();
      this.markDirty();
   }

   public UUID getPlacerID() {
      return this.placer;
   }

   public void update() {
      this.ticksExited++;
      if (!this.world.isRemote) {
         this.world
            .notifyBlockUpdate(
               this.getPos(), this.world.getBlockState(this.getPos()), this.world.getBlockState(this.getPos()), 2
            );
         if (this.active && this.controller != null && this.placer != null) {
            EntityPlayer play = this.world.getPlayerEntityByUUID(this.placer);
            if (play != null) {
               this.controller.tickEffect(this, this.world, this.getPos(), play);
            }
         }
      }
   }

   public NBTTagCompound getUpdateTag() {
      NBTTagCompound compound = super.getUpdateTag();
      compound.setBoolean("Active", this.active);
      return compound;
   }

   public void handleUpdateTag(NBTTagCompound tag) {
      if (tag.hasKey("Active")) {
         this.active = tag.getBoolean("Active");
      }

      super.handleUpdateTag(tag);
   }

   public void readFromNBT(NBTTagCompound compound) {
      if (compound != null && compound.hasUniqueId("teplace")) {
         this.placer = compound.getUniqueId("teplace");
      }

      if (compound != null && compound.hasKey("isactive")) {
         this.active = compound.getBoolean("isactive");
         compound.removeTag("isactive");
      }

      super.readFromNBT(compound);
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      if (compound == null) {
         compound = new NBTTagCompound();
      }

      compound.setBoolean("isactive", this.active);
      UUID uuid = this.placer == null ? UUID.fromString("00000000-0000-0000-0000-000000000000") : this.placer;
      compound.setUniqueId("teplace", uuid);
      return super.writeToNBT(compound);
   }

   public SPacketUpdateTileEntity getUpdatePacket() {
      return new SPacketUpdateTileEntity(this.getPos(), 1, this.getUpdateTag());
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
      this.handleUpdateTag(pkt.getNbtCompound());
   }
}
