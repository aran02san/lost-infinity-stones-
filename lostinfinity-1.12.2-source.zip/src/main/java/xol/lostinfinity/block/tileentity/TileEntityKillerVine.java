package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IEntityOwnable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import xol.lostinfinity.block.misc.BlockKillerVine;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.base.EntityImmaterial;
import xol.lostinfinity.util.data.IMaxAttack;

public class TileEntityKillerVine extends TileEntity implements ITickable, IMaxAttack {
   private int ticks = 0;
   private boolean killer = false;
   private UUID placer = null;
   private ArrayList<TileEntityKillerVine.VineNode> nodes = new ArrayList<>();

   public void update() {
      this.ticks++;
      if (this.killer) {
         int radius = 15;

         for (EntityLivingBase entity : this.world
            .getEntitiesWithinAABB(
               EntityLivingBase.class,
               new AxisAlignedBB(this.pos.add(-radius, -1, -radius), this.pos.add(radius, radius, radius))
            )) {
            if (entity != null
               && !entity.isDead
               && !(entity instanceof EntityImmaterial)
               && (this.placer == null || !this.placer.equals(entity.getUniqueID()))
               && (
                  !(entity instanceof IEntityOwnable)
                     || ((IEntityOwnable)entity).getOwnerId() == null
                     || !((IEntityOwnable)entity).getOwnerId().equals(this.placer)
               )) {
               ArrayList<TileEntityKillerVine.VineNode> toRemove = new ArrayList<>();
               boolean found = false;
               int growth = 0;

               for (TileEntityKillerVine.VineNode node : this.nodes) {
                  if (node.getEntity() != null && !node.getEntity().isDead) {
                     if (node.getEntity() == entity) {
                        node.grow();
                        growth = node.getGrowth();
                        found = true;
                        break;
                     }
                  } else {
                     toRemove.add(node);
                  }
               }

               this.nodes.removeAll(toRemove);
               if (!found) {
                  this.nodes.add(new TileEntityKillerVine.VineNode(entity));
               }

               if (!this.world.isRemote && growth >= 20) {
                  double xDiff = -entity.posX + (this.pos.getX() + 0.5);
                  double yDiff = -entity.posY + (this.pos.getY() + 1.0);
                  double zDiff = -entity.posZ + (this.pos.getZ() + 0.5);
                  Vec3d pullDir = new Vec3d(xDiff, yDiff, zDiff);
                  pullDir = pullDir.normalize();
                  double dist = entity.getPositionVector()
                     .distanceTo(new Vec3d(this.pos.getX(), this.pos.getY(), this.pos.getZ()));
                  if (dist > 10.0) {
                     entity.addVelocity(pullDir.x / 3.0, pullDir.y / 3.0 + 0.05, pullDir.z / 3.0);
                  } else {
                     entity.addVelocity(pullDir.x / 10.0, pullDir.y / 10.0 + 0.05, pullDir.z / 10.0);
                     if (dist < 3.0) {
                        if (this.placer != null) {
                           EntityPlayer placerPlayer = this.world.getPlayerEntityByUUID(this.placer);
                           if (placerPlayer != null) {
                              boolean killed = IMaxAttack.dealTrueDamage(placerPlayer, entity, entity.getMaxHealth() * 0.1F).wasTargetKilled();
                              if (killed && entity instanceof EntityPlayer) {
                                 placerPlayer.addItemStackToInventory(new ItemStack(ItemInit.entangledHeart));
                              }
                           }
                        } else {
                           IMaxAttack.dealPotionDamage(entity, entity.getMaxHealth() * 0.1F);
                        }
                     }
                  }

                  entity.velocityChanged = true;
               }
            }
         }
      }

      if (!this.world.isRemote) {
         if (this.placer == null) {
            EntityPlayer placerEntity = this.world
               .getClosestPlayer(this.pos.getX(), this.pos.getY(), this.pos.getZ(), 10.0, false);
            if (placerEntity != null) {
               this.placer = placerEntity.getUniqueID();
            }
         }

         if (this.ticks % 10 == 0) {
            this.doBlockUpdate();
            if (!this.killer && ((BlockKillerVine)BlockInit.killerVine).getCropAge(this.world.getBlockState(this.pos)) == 7) {
               this.killer = true;
            }
         }
      }
   }

   public boolean isKiller() {
      return this.killer;
   }

   public ArrayList<TileEntityKillerVine.VineNode> getNodes() {
      return this.nodes;
   }

   public UUID getPlacer() {
      return this.getPlacer();
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setBoolean("killer", this.killer);
      if (this.placer != null) {
         compound.setUniqueId("Placer", this.placer);
      }

      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.killer = compound.getBoolean("killer");
      this.placer = compound.getUniqueId("Placer");
   }

   @Nullable
   public SPacketUpdateTileEntity getUpdatePacket() {
      return new SPacketUpdateTileEntity(this.getPos(), 0, this.getUpdateTag());
   }

   public NBTTagCompound getUpdateTag() {
      return this.writeToNBT(new NBTTagCompound());
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
      this.handleUpdateTag(pkt.getNbtCompound());
   }

   protected void doBlockUpdate() {
      IBlockState state = this.world.getBlockState(this.getPos());
      this.world.notifyBlockUpdate(this.getPos(), state, state, 3);
   }

   public boolean shouldRefresh(World world, BlockPos pos, IBlockState oldState, IBlockState newSate) {
      return world.getBlockState(pos).getBlock() != BlockInit.killerVine;
   }

   public void setPlacer(EntityPlayer placer) {
      this.placer = placer.getUniqueID();
   }

   public class VineNode {
      private EntityLivingBase entity;
      private int growth;

      public VineNode(EntityLivingBase entity) {
         this.entity = entity;
         this.growth = 0;
      }

      public EntityLivingBase getEntity() {
         return this.entity;
      }

      public int getGrowth() {
         return this.growth;
      }

      public void grow() {
         this.growth++;
      }
   }
}
