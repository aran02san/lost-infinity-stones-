package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityMelodicSequencer extends TileEntity implements ITickable {
   ArrayList<SoundEvent> notes = null;
   ArrayList<Integer> sequence = new ArrayList<>();
   private boolean roundStart = false;
   private static int finalRound = 2;
   private int remainingFails = 0;
   private int round = 0;
   private int sequenceIndex = 0;
   private int noteTimer = 30;
   private int roundDelay = 0;
   private int time = 0;
   private EntityPlayer player = null;
   private boolean finishedRound = true;
   private int playerSequenceIndex = 0;
   private boolean game = false;

   public void update() {
      if (this.game && this.notes != null && this.notes.size() == 5 && this.roundStart && this.finishedRound) {
         if (this.roundDelay > 0) {
            this.roundDelay--;
         } else if (this.time < this.noteTimer) {
            this.time++;
         } else {
            this.time = 0;
            this.world
               .playSound(null, this.pos, this.notes.get(this.sequence.get(this.sequenceIndex)), SoundCategory.BLOCKS, 0.8F, 1.0F);
            this.sequenceIndex++;
            if (this.sequenceIndex == this.sequence.size()) {
               this.sequenceIndex = 0;
               this.roundStart = false;
               this.finishedRound = false;
            }
         }
      }
   }

   public boolean playNote(int meta, BlockPos pos, EntityPlayer player) {
      this.player = player;
      if (!this.roundStart && this.notes != null && this.notes.size() > meta) {
         this.world.playSound(null, this.pos, this.notes.get(meta), SoundCategory.BLOCKS, 0.8F, 1.0F);
         if (meta == this.sequence.get(this.playerSequenceIndex)) {
            this.playerSequenceIndex++;
            if (this.playerSequenceIndex == this.sequence.size()) {
               this.roundUp();
            }
         } else if (this.remainingFails > 0) {
            this.remainingFails--;
            this.playerSequenceIndex = 0;
            player.sendMessage(new TextComponentString(this.remainingFails + 1 + " fails remaining. Try again!"));
         } else {
            player.sendMessage(new TextComponentString("Failed sequence. No attempts remaining"));
            this.game = false;
         }

         return true;
      } else {
         return false;
      }
   }

   private void roundUp() {
      this.finishedRound = true;
      if (this.round < finalRound) {
         if (this.player != null) {
            this.player.sendMessage(new TextComponentString("Round complete! Repeat the next sequence."));
         }

         this.round++;
         this.generateSequence();
         this.roundStart = true;
         this.roundDelay = 40;
         this.playerSequenceIndex = 0;
         this.noteTimer -= 4;
      } else {
         if (this.player != null) {
            this.player.sendMessage(new TextComponentString("All sequences complete! The disc has been configured."));
         }

         this.game = false;
         this.notes = null;
         EntityItem reward = new EntityItem(
            this.world,
            this.pos.getX(),
            this.pos.getY() + 1,
            this.pos.getZ(),
            new ItemStack(ItemInit.audioSynchronizedDisc, 1)
         );
         reward.motionX = 0.0;
         reward.motionY = 0.0;
         reward.motionZ = 0.0;
         this.world.spawnEntity(reward);
      }
   }

   public static ArrayList<SoundEvent> getNotes() {
      ArrayList<SoundEvent> noteList = new ArrayList<>();
      noteList.add(SoundInit.NOTE_TYPE_1);
      noteList.add(SoundInit.NOTE_TYPE_2);
      noteList.add(SoundInit.NOTE_TYPE_3);
      noteList.add(SoundInit.NOTE_TYPE_4);
      noteList.add(SoundInit.NOTE_TYPE_5);
      return noteList;
   }

   private void initSounds() {
      this.notes = getNotes();
   }

   public void startGame() {
      this.remainingFails = 5;
      this.game = true;
      this.finishedRound = true;
      this.round = 0;
      this.playerSequenceIndex = 0;
      this.roundStart = true;
      this.noteTimer = 30;
      this.initSounds();
      this.generateSequence();
   }

   private void generateSequence() {
      if (this.notes != null) {
         this.sequence.clear();
         int length = this.round * 1 + 3;

         for (int i = 0; i < length; i++) {
            int randSound = this.world.rand.nextInt(this.notes.size());
            this.sequence.add(randSound);
         }
      }
   }
}
