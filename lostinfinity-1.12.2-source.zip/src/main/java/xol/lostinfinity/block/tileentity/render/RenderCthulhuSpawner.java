package xol.lostinfinity.block.tileentity.render;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import xol.lostinfinity.block.tileentity.TileEntityCthulhuSpawner;

public class RenderCthulhuSpawner extends TileEntitySpecialRenderer<TileEntityCthulhuSpawner> {
   private static final ResourceLocation TEXTURE = new ResourceLocation("lostinfinity:textures/particles/cthulhu/spawner_beam.png");

   public void render(TileEntityCthulhuSpawner te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      if (te.isBurning()) {
         GlStateManager.pushMatrix();
         GlStateManager.disableCull();
         GlStateManager.enableBlend();
         GlStateManager.blendFunc(770, 771);
         GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
         GlStateManager.translate(x + 0.5, y + 0.5, z + 0.5);
         this.enableMaxLighting();
         this.bindTexture(TEXTURE);
         Tessellator tessellator = Tessellator.getInstance();
         BufferBuilder bufferbuilder = tessellator.getBuffer();

         for (int i = 1; i <= 30; i++) {
            switch (te.getFacing()) {
               case NORTH:
                  bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
                  bufferbuilder.pos(0.0, -0.5, -(i - 1)).tex(1.0, 0.0).endVertex();
                  bufferbuilder.pos(0.0, -0.5, -i).tex(0.0, 0.0).endVertex();
                  bufferbuilder.pos(0.0, 0.5, -i).tex(0.0, 1.0).endVertex();
                  bufferbuilder.pos(0.0, 0.5, -(i - 1)).tex(1.0, 1.0).endVertex();
                  tessellator.draw();
                  break;
               case EAST:
                  bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
                  bufferbuilder.pos(i - 1, -0.5, 0.0).tex(1.0, 0.0).endVertex();
                  bufferbuilder.pos(i, -0.5, 0.0).tex(0.0, 0.0).endVertex();
                  bufferbuilder.pos(i, 0.5, 0.0).tex(0.0, 1.0).endVertex();
                  bufferbuilder.pos(i - 1, 0.5, 0.0).tex(1.0, 1.0).endVertex();
                  tessellator.draw();
                  break;
               case SOUTH:
                  bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
                  bufferbuilder.pos(0.0, -0.5, i - 1).tex(1.0, 0.0).endVertex();
                  bufferbuilder.pos(0.0, -0.5, i).tex(0.0, 0.0).endVertex();
                  bufferbuilder.pos(0.0, 0.5, i).tex(0.0, 1.0).endVertex();
                  bufferbuilder.pos(0.0, 0.5, i - 1).tex(1.0, 1.0).endVertex();
                  tessellator.draw();
                  break;
               case WEST:
                  bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
                  bufferbuilder.pos(-(i - 1), -0.5, 0.0).tex(1.0, 0.0).endVertex();
                  bufferbuilder.pos(-i, -0.5, 0.0).tex(0.0, 0.0).endVertex();
                  bufferbuilder.pos(-i, 0.5, 0.0).tex(0.0, 1.0).endVertex();
                  bufferbuilder.pos(-(i - 1), 0.5, 0.0).tex(1.0, 1.0).endVertex();
                  tessellator.draw();
            }
         }

         GlStateManager.popMatrix();
         GlStateManager.enableLighting();
         GlStateManager.disableBlend();
         GlStateManager.enableCull();
      }
   }

   public boolean isGlobalRenderer(TileEntityCthulhuSpawner te) {
      return true;
   }

   private void enableMaxLighting() {
      GlStateManager.disableLighting();
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
   }
}
