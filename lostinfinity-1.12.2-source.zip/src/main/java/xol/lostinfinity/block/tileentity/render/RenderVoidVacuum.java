package xol.lostinfinity.block.tileentity.render;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.Vec3d;
import xol.lostinfinity.block.tileentity.TileEntityVoidVacuum;
import xol.lostinfinity.init.BlockInit;

public class RenderVoidVacuum extends TileEntitySpecialRenderer<TileEntityVoidVacuum> {
   public static final ResourceLocation TEXTURE_ELASTIC_STRING = new ResourceLocation("lostinfinity:textures/particles/elastic_thread.png");

   public void render(TileEntityVoidVacuum te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      if (te.getActive()) {
         IBlockState state = te.getWorld().getBlockState(te.getPos());
         Block block = state.getBlock();
         if (!block.equals(BlockInit.voidVacuum)) {
            return;
         }

         EntityLivingBase target = te.getTarget();
         if (target == null || target.isDead) {
            return;
         }

         Vec3d pos = new Vec3d(te.getPos().getX(), te.getPos().getY(), te.getPos().getZ());
         Vec3d playerVec = target.getPositionVector();
         this.bindTexture(TEXTURE_ELASTIC_STRING);
         Tessellator tessellator = Tessellator.getInstance();
         BufferBuilder bufferbuilder = tessellator.getBuffer();
         GlStateManager.disableCull();
         GlStateManager.enableAlpha();
         GlStateManager.disableLighting();
         int bright = 240;
         int brightX = bright % 65536;
         int brightY = bright / 65536;
         OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, brightX, brightY);
         GlStateManager.enableBlend();
         GlStateManager.alphaFunc(516, 0.3F);
         bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
         double dist = pos.distanceTo(playerVec);
         Vec3d dir = playerVec.subtract(pos);
         dir = dir.normalize();
         float segmentHeight = 2.0F;
         float segmentLength = 1.0F;

         for (int i = 0; i < (int)Math.floor(dist / segmentLength); i++) {
            double xPos = x + 0.5 + dir.x * i * segmentLength;
            double yPos = y + dir.y * i * segmentLength;
            double zPos = z + 0.5 + dir.z * i * segmentLength;
            bufferbuilder.pos(xPos, yPos + segmentHeight, zPos).tex(0.0, 1.0).endVertex();
            bufferbuilder.pos(xPos, yPos, zPos).tex(0.0, 0.0).endVertex();
            bufferbuilder.pos(
                  xPos + segmentLength * dir.x, yPos + segmentLength * dir.y, zPos + segmentLength * dir.z
               )
               .tex(1.0, 0.0)
               .endVertex();
            bufferbuilder.pos(
                  xPos + segmentLength * dir.x, yPos + segmentHeight + segmentLength * dir.y, zPos + segmentLength * dir.z
               )
               .tex(1.0, 1.0)
               .endVertex();
         }

         tessellator.draw();
         GlStateManager.enableLighting();
         GlStateManager.enableCull();
         GlStateManager.disableBlend();
      }
   }
}
