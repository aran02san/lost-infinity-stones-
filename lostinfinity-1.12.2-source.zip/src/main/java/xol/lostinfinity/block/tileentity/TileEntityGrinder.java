package xol.lostinfinity.block.tileentity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundCategory;
import xol.lostinfinity.block.crafting.BlockGrinder;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityGrinder extends TileEntity implements IInventory, ITickable, IMachine {
   private NonNullList<ItemStack> inventory = NonNullList.withSize(2, ItemStack.EMPTY);
   private int failTimer = 0;

   public void update() {
      ItemStack input = (ItemStack)this.inventory.get(0);
      int inputCount = input.getCount();
      if (input.getItem().getUnlocalizedName().equalsIgnoreCase("item.sunstone")
         && inputCount >= 5
         && ((ItemStack)this.inventory.get(1)).getCount() <= 64
         && this.getPowered()) {
         if (!this.world.isRemote) {
            BlockGrinder.setState(true, this.world, this.pos);
         }
      } else if (!this.world.isRemote) {
         BlockGrinder.setState(false, this.world, this.pos);
      }
   }

   @Override
   public boolean getPowered() {
      for (IMachine machine : this.getConnectedMachines(this, null)) {
         if (machine instanceof TileEntityGearbox) {
            return ((TileEntityGearbox)machine).getActive();
         }
      }

      return false;
   }

   public void failGrind() {
      if (this.failTimer > 0) {
         this.failTimer--;
      } else {
         this.failTimer = 30;
         ItemStack input = (ItemStack)this.inventory.get(0);
         int inputCount = input.getCount();
         this.world.playSound(null, this.pos, SoundInit.GENERIC_UI_4, SoundCategory.BLOCKS, 1.0F, 1.0F);
         input.setCount(inputCount - 1);
         this.markDirty();
      }
   }

   public void grind() {
      ItemStack input = (ItemStack)this.inventory.get(0);
      int inputCount = input.getCount();
      this.setField(0, 0);
      ItemStack output;
      if (((ItemStack)this.inventory.get(1)).isEmpty()) {
         output = new ItemStack(ItemInit.sunstoneDust, 1);
      } else {
         output = (ItemStack)this.inventory.get(1);
         output.setCount(output.getCount() + 1);
      }

      this.inventory.set(1, output);
      input.setCount(inputCount - 1);
      this.world.playSound(null, this.pos, SoundInit.WELDING, SoundCategory.BLOCKS, 1.0F, 3.0F);
      this.markDirty();
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      for (ItemStack stack : this.inventory) {
         if (!stack.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return this.world.getTileEntity(this.pos) != this
         ? false
         : player.getDistanceSq(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5)
            <= 64.0;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      return false;
   }

   public void clear() {
      this.inventory.clear();
   }

   public String getName() {
      return "tile.grinder";
   }

   public boolean hasCustomName() {
      return false;
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      ItemStackHelper.saveAllItems(compound, this.inventory);
      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.inventory = NonNullList.withSize(this.getSizeInventory(), ItemStack.EMPTY);
      ItemStackHelper.loadAllItems(compound, this.inventory);
   }

   public int getGuiID() {
      return GuiHandler.RegisteredGuis.GRINDER.getId();
   }

   public int getField(int id) {
      return 0;
   }

   public void setField(int id, int value) {
   }

   public int getFieldCount() {
      return 0;
   }
}
