package xol.lostinfinity.block.tileentity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundCategory;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.recipes.ChemistryRecipes;

public class TileEntityChemistryTable extends TileEntity implements IInventory, ITickable {
   private NonNullList<ItemStack> inventory = NonNullList.withSize(4, ItemStack.EMPTY);
   private int mix0;
   private int mix1;
   private int mix2;
   private int mix3;
   private int mix4;
   private int mix5;
   private int mix6;
   private int mix7;
   private int mix8;
   private int currentMixLevel;

   public void update() {
      if (!this.world.isRemote) {
         ItemStack result = ChemistryRecipes.getResult(
            this.getStackInSlot(this.mix0),
            this.getStackInSlot(this.mix1),
            this.getStackInSlot(this.mix2),
            this.getStackInSlot(this.mix3),
            this.getStackInSlot(this.mix4),
            this.getStackInSlot(this.mix5),
            this.getStackInSlot(this.mix6),
            this.getStackInSlot(this.mix7),
            this.getStackInSlot(this.mix8)
         );
         if (result != null && this.currentMixLevel == 9 && this.getStackInSlot(3).isEmpty()) {
            this.decrStackSize(this.mix0, 1);
            this.decrStackSize(this.mix1, 1);
            this.decrStackSize(this.mix2, 1);
            this.setInventorySlotContents(3, result);
            this.mix0 = 0;
            this.mix1 = 0;
            this.mix2 = 0;
            this.mix3 = 0;
            this.mix4 = 0;
            this.mix5 = 0;
            this.mix6 = 0;
            this.mix7 = 0;
            this.mix8 = 0;
            this.currentMixLevel = 0;
            this.world
               .playSound(
                  null,
                  this.getPos(),
                  SoundInit.CHEMICAL_MIXING,
                  SoundCategory.BLOCKS,
                  1.5F,
                  0.7F + this.world.rand.nextFloat() * 0.6F
               );
         }
      }
   }

   public int getField(int id) {
      switch (id) {
         case 0:
            return this.mix0;
         case 1:
            return this.mix1;
         case 2:
            return this.mix2;
         case 3:
            return this.mix3;
         case 4:
            return this.mix4;
         case 5:
            return this.mix5;
         case 6:
            return this.mix6;
         case 7:
            return this.mix7;
         case 8:
            return this.mix8;
         case 9:
            return this.currentMixLevel;
         default:
            return 0;
      }
   }

   public void setField(int id, int value) {
      switch (id) {
         case 0:
            this.mix0 = value;
            break;
         case 1:
            this.mix1 = value;
            break;
         case 2:
            this.mix2 = value;
            break;
         case 3:
            this.mix3 = value;
            break;
         case 4:
            this.mix4 = value;
            break;
         case 5:
            this.mix5 = value;
            break;
         case 6:
            this.mix6 = value;
            break;
         case 7:
            this.mix7 = value;
            break;
         case 8:
            this.mix8 = value;
            break;
         case 9:
            this.currentMixLevel = value;
      }
   }

   public int getFieldCount() {
      return 10;
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      return this.inventory.isEmpty();
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return true;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      return true;
   }

   public void clear() {
   }

   public String getName() {
      return "tile.chemistry_table";
   }

   public boolean hasCustomName() {
      return false;
   }
}
