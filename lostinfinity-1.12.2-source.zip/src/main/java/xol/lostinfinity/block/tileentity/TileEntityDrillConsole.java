package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextComponentString;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class TileEntityDrillConsole extends TileEntity {
   private boolean active = false;
   private static final Vec3i forwardDir = new Vec3i(-1, 0, 0);
   private static final Vec3i rightDir = new Vec3i(0, 0, -1);
   private ArrayList<BlockPos> horizontalBeam = new ArrayList<>();
   private ArrayList<BlockPos> verticalBeam = new ArrayList<>();
   private BlockPos drillPos = null;
   private int drillHeight = 0;
   private boolean drilling = false;

   public void adjustDrill(boolean down) {
      Block drillBeamBlock = BlockInit.drillShaft;
      Block drillHeadBlock = BlockInit.drillHead;
      Block oreBlock = BlockInit.lucientOre;
      BlockPos drillHeadPos = this.drillPos.add(0, -this.drillHeight, 0);
      boolean didMine = false;
      if (down) {
         if (this.world.isAirBlock(drillHeadPos.down())) {
            this.drillHeight++;
         } else {
            didMine = true;
            BlockPos checkPos = drillHeadPos.down();
            IBlockState state = this.world.getBlockState(checkPos);
            if (state.getBlock() == oreBlock && oreBlock.getMetaFromState(state) == 1) {
               this.world.setBlockState(checkPos, oreBlock.getStateFromMeta(0));
               this.drillHeight++;
               BlockPos funnelPos = GalaxyCoordinates.lucientOreFunnelPos();
               EntityItem item = new EntityItem(
                  this.world, funnelPos.getX(), funnelPos.getY() + 1, funnelPos.getZ(), new ItemStack(ItemInit.lucient, 1)
               );
               item.motionX = 0.0;
               item.motionZ = 0.0;
               item.motionY = 0.0;
               this.world.spawnEntity(item);
               this.world.playSound(null, drillHeadPos, SoundInit.MACHINE_CRAFT, SoundCategory.MASTER, 1.0F, 1.0F);
            }
         }
      } else if (this.drillHeight > 0) {
         if (this.world.getBlockState(this.drillPos.add(0, -this.drillHeight, 0)).getBlock() == drillHeadBlock) {
            this.world.setBlockToAir(this.drillPos.add(0, -this.drillHeight, 0));
         }

         this.drillHeight--;
      }

      for (int i = 0; i <= this.drillHeight; i++) {
         BlockPos beamPos = this.drillPos.add(0, -i, 0);
         if (i == this.drillHeight) {
            if (!didMine) {
               this.world.setBlockState(beamPos, drillHeadBlock.getDefaultState());
            }
         } else {
            this.world.setBlockState(beamPos, drillBeamBlock.getDefaultState());
         }
      }
   }

   public void activateDrill(EntityPlayer player) {
      if (!this.world.isRemote && !this.drilling) {
         Block beamBlock = BlockInit.drillBeam;
         IBlockState drillHeadState = BlockInit.drillHead.getDefaultState();
         this.active = true;
         player.sendMessage(new TextComponentString(TextFmt.Green + "Maneuver the drill to mine the ores!"));
         AxisAlignedBB drillBB = GalaxyCoordinates.lucientDrillAABB();
         this.horizontalBeam.clear();
         this.verticalBeam.clear();

         for (int i = (int)drillBB.minX; i <= (int)drillBB.maxX; i++) {
            BlockPos checkPos = new BlockPos(i, drillBB.maxY, drillBB.minZ);
            if (this.world.getBlockState(checkPos).getBlock() == beamBlock) {
               for (int k = (int)drillBB.minZ; k <= (int)drillBB.maxZ; k++) {
                  BlockPos beamPos = new BlockPos(i, drillBB.maxY, k);
                  this.horizontalBeam.add(beamPos);
               }
            }
         }

         for (int ix = (int)drillBB.minZ; ix <= (int)drillBB.maxZ; ix++) {
            BlockPos checkPos = new BlockPos(drillBB.minX, drillBB.maxY, ix);
            if (this.world.getBlockState(checkPos).getBlock() == beamBlock) {
               for (int k = (int)drillBB.minX; k <= (int)drillBB.maxX; k++) {
                  BlockPos beamPos = new BlockPos(k, drillBB.maxY, ix);
                  this.verticalBeam.add(beamPos);
               }
            }
         }

         for (BlockPos pos : this.horizontalBeam) {
            if (this.verticalBeam.contains(pos)) {
               this.drillPos = pos.down();
               this.world.setBlockState(this.drillPos, drillHeadState);
               break;
            }
         }
      }
   }

   public void moveDrill(int i) {
      if (this.active) {
         if (i == 4) {
            this.adjustDrill(false);
            return;
         }

         if (i == 5) {
            this.adjustDrill(true);
            return;
         }

         if (this.drillHeight == 0
            && this.horizontalBeam != null
            && !this.horizontalBeam.isEmpty()
            && this.verticalBeam != null
            && !this.verticalBeam.isEmpty()) {
            AxisAlignedBB drillBB = GalaxyCoordinates.lucientDrillAABB();
            boolean horizontal = false;
            Vec3i dir;
            switch (i) {
               case 1:
                  dir = rightDir;
                  break;
               case 2:
                  horizontal = true;
                  dir = new Vec3i(-forwardDir.getX(), 0, -forwardDir.getZ());
                  break;
               case 3:
                  dir = new Vec3i(-rightDir.getX(), 0, -rightDir.getZ());
                  break;
               default:
                  horizontal = true;
                  dir = forwardDir;
            }

            BlockPos testPos;
            if (horizontal) {
               testPos = this.horizontalBeam.get(0);
            } else {
               testPos = this.verticalBeam.get(0);
            }

            if (testPos.getX() + dir.getX() <= (int)drillBB.maxX
               && testPos.getX() + dir.getX() >= (int)drillBB.minX
               && testPos.getZ() + dir.getZ() <= drillBB.maxZ
               && testPos.getZ() + dir.getZ() >= drillBB.minZ) {
               IBlockState beamState = BlockInit.drillBeam.getDefaultState();
               IBlockState drillHeadState = BlockInit.drillHead.getDefaultState();
               if (this.drillPos != null) {
                  this.world.setBlockToAir(this.drillPos);
               }

               ArrayList<BlockPos> newBeam = new ArrayList<>();
               if (horizontal) {
                  for (BlockPos pos : this.horizontalBeam) {
                     if (!this.verticalBeam.contains(pos)) {
                        this.world.setBlockToAir(pos);
                     }

                     BlockPos newPos = pos.add(dir);
                     newBeam.add(newPos);
                     this.world.setBlockState(newPos, beamState);
                  }

                  this.horizontalBeam.clear();
                  this.horizontalBeam.addAll(newBeam);
               } else {
                  for (BlockPos pos : this.verticalBeam) {
                     if (!this.horizontalBeam.contains(pos)) {
                        this.world.setBlockToAir(pos);
                     }

                     BlockPos newPos = pos.add(dir);
                     newBeam.add(newPos);
                     this.world.setBlockState(newPos, beamState);
                  }

                  this.verticalBeam.clear();
                  this.verticalBeam.addAll(newBeam);
               }

               for (BlockPos pos : this.horizontalBeam) {
                  if (this.verticalBeam.contains(pos)) {
                     this.drillPos = pos.down();
                     this.world.setBlockState(this.drillPos, drillHeadState);
                     break;
                  }
               }
            }
         }
      }
   }
}
