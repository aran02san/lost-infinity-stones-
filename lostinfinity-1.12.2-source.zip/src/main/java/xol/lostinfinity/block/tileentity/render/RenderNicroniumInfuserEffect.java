package xol.lostinfinity.block.tileentity.render;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import xol.lostinfinity.block.crafting.BlockNicroniumInfuser;
import xol.lostinfinity.block.tileentity.TileEntityNicroniumInfuser;
import xol.lostinfinity.init.BlockInit;

public class RenderNicroniumInfuserEffect extends TileEntitySpecialRenderer<TileEntityNicroniumInfuser> {
   public static final ResourceLocation TEXTURE_NICRONIUM_RING = new ResourceLocation("lostinfinity:textures/particles/nicronium_ring.png");

   public void render(TileEntityNicroniumInfuser te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      IBlockState state = te.getWorld().getBlockState(te.getPos());
      Block block = state.getBlock();
      if (!block.equals(BlockInit.nicroniumInfuser) || state == ((BlockNicroniumInfuser)BlockInit.nicroniumInfuser).getStateFromMeta(1)) {
         double targetHeight = 1.0;
         this.bindTexture(TEXTURE_NICRONIUM_RING);
         Tessellator tessellator = Tessellator.getInstance();
         BufferBuilder bufferbuilder = tessellator.getBuffer();
         GlStateManager.disableCull();
         GlStateManager.enableAlpha();
         float growth = 0.5F;
         GlStateManager.enableBlend();
         GlStateManager.alphaFunc(516, 0.3F);
         float a = 1.0F;
         growth = 0.1F + (float)(te.getWorld().getTotalWorldTime() % 40L) * 0.3F;
         a = 1.0F - (float)(te.getWorld().getTotalWorldTime() % 40L) * 0.022224F;
         if (a <= 0.0F) {
            a = 0.0F;
         }

         GlStateManager.color(1.0F, 1.0F, 1.0F, a);
         bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
         double xPos = x + 0.5;
         double yPos = y + 0.1F;
         double zPos = z + 0.5;
         bufferbuilder.pos(-0.5F * growth + xPos, targetHeight + yPos, 0.5F * growth + zPos).tex(0.0, 1.0).endVertex();
         bufferbuilder.pos(-0.5F * growth + xPos, targetHeight + yPos, -0.5F * growth + zPos).tex(0.0, 0.0).endVertex();
         bufferbuilder.pos(0.5F * growth + xPos, targetHeight + yPos, -0.5F * growth + zPos).tex(1.0, 0.0).endVertex();
         bufferbuilder.pos(0.5F * growth + xPos, targetHeight + yPos, 0.5F * growth + zPos).tex(1.0, 1.0).endVertex();
         tessellator.draw();
         GlStateManager.enableCull();
         GlStateManager.disableBlend();
      }
   }
}
