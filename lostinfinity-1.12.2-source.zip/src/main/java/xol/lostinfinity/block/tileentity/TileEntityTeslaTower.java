package xol.lostinfinity.block.tileentity;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.util.data.CustomRayTraceResult;
import xol.lostinfinity.util.data.IMaxAttack;
import xol.lostinfinity.util.data.RayTraceBuilder;
import xol.lostinfinity.util.math.LMath;

public class TileEntityTeslaTower extends TileEntity implements ITickable {
   private static final double RANGE = 40.0;
   private final Set<BlockPos> others = new HashSet<>();
   private final Set<BlockPos> connected = new HashSet<>();
   private int towerId;
   private UUID owner;
   private boolean active;
   private int tickExisted;
   private boolean pendingUpdate;
   private int random1;
   private int random2;
   private float random3;

   public void update() {
      if (this.tickExisted == 1200) {
         this.world.setBlockToAir(this.getPos());
      } else {
         if (this.shouldRefresh()) {
            this.pendingUpdate = false;
            this.updateConnected();
         }

         if (!this.world.isRemote && this.tickExisted % 5 == 0 && this.active) {
            this.zapEntities();
         }

         this.tickExisted++;
         this.random1 = this.world.rand.nextInt(19);
         this.random2 = this.world.rand.nextInt(7);
         this.random3 = this.world.rand.nextFloat();
      }
   }

   public void setTowerId(int towerId) {
      this.towerId = towerId;
   }

   public int getTowerId() {
      return this.towerId;
   }

   public int getRandom1() {
      return this.random1;
   }

   public int getRandom2() {
      return this.random2;
   }

   public float getRandom3() {
      return this.random3;
   }

   public void setOwner(UUID owner) {
      this.owner = owner;
   }

   public void setOthers(Set<BlockPos> set) {
      this.others.clear();
      this.others.addAll(set);
      this.others.remove(this.getPos());
      this.updateConnected();
   }

   public void setActive(boolean state) {
      this.active = state;
      if (this.active) {
         this.world.playSound(null, this.pos, SoundInit.ELECTRIC_SHOCK, SoundCategory.BLOCKS, 1.0F, 1.0F);
      }
   }

   public boolean isActive() {
      return this.active;
   }

   public void doBlockUpdate() {
      IBlockState blockState = this.world.getBlockState(this.getPos());
      this.world.notifyBlockUpdate(this.getPos(), blockState, blockState, 3);
   }

   public Set<BlockPos> getConnected() {
      return this.connected;
   }

   public int getTickExisted() {
      return this.tickExisted;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.towerId = compound.getInteger("tower_id");
      this.tickExisted = compound.getInteger("age");
      this.owner = compound.getUniqueId("owner");
      this.active = compound.getBoolean("active");
      this.readOthers(compound);
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setInteger("tower_id", this.towerId);
      compound.setInteger("age", this.tickExisted);
      if (this.owner != null) {
         compound.setUniqueId("owner", this.owner);
      }

      compound.setBoolean("active", this.active);
      this.writeOthers(compound);
      return compound;
   }

   @SideOnly(Side.CLIENT)
   public AxisAlignedBB getRenderBoundingBox() {
      return INFINITE_EXTENT_AABB;
   }

   private boolean shouldRefresh() {
      for (BlockPos pos : this.connected) {
         if (this.world.getBlockState(pos) != BlockInit.teslaTower.getDefaultState()) {
            return true;
         }
      }

      return this.pendingUpdate || this.tickExisted % 100 == 0;
   }

   private void updateConnected() {
      this.connected.clear();

      for (BlockPos pos : this.others) {
         if (pos.distanceSq(this.getPos()) <= 1600.0 && this.world.getTileEntity(pos) instanceof TileEntityTeslaTower) {
            this.connected.add(pos);
         }
      }
   }

   private void zapEntities() {
      EntityPlayer player = null;
      if (this.owner != null) {
         player = this.world.getPlayerEntityByUUID(this.owner);
      }

      for (BlockPos other : this.connected) {
         Vec3d loc = new Vec3d(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5);
         Vec3d dir = LMath.fastNormalize(
            new Vec3d(
               other.getX() - this.pos.getX(),
               other.getY() - this.pos.getY(),
               other.getZ() - this.pos.getZ()
            )
         );
         CustomRayTraceResult result = RayTraceBuilder.entity(EntityLivingBase.class, 40)
            .maxEntity(0)
            .trace(this.world, null, loc.add(dir), dir);
         if (result != null) {
            for (Entity entity : result.getResultEntities()) {
               if (entity instanceof EntityLivingBase && entity != player) {
                  IMaxAttack.dealTrueDamage(player, (EntityLivingBase)entity, ((EntityLivingBase)entity).getMaxHealth() * 0.05F);
               }
            }
         }
      }
   }

   private void readOthers(NBTTagCompound compound) {
      this.others.clear();

      for (int id = 0; compound.hasKey("pos_x_" + id); id++) {
         this.others.add(new BlockPos(compound.getInteger("pos_x_" + id), compound.getInteger("pos_y_" + id), compound.getInteger("pos_z_" + id)));
      }
   }

   private void writeOthers(NBTTagCompound compound) {
      int i = 0;

      for (BlockPos pos : this.others) {
         compound.setInteger("pos_x_" + i, pos.getX());
         compound.setInteger("pos_y_" + i, pos.getY());
         compound.setInteger("pos_z_" + i, pos.getZ());
         i++;
      }
   }

   public NBTTagCompound getUpdateTag() {
      return this.writeToNBT(new NBTTagCompound());
   }

   @Nullable
   public SPacketUpdateTileEntity getUpdatePacket() {
      return new SPacketUpdateTileEntity(this.pos, 0, this.getUpdateTag());
   }

   public void onDataPacket(NetworkManager net, SPacketUpdateTileEntity pkt) {
      this.readFromNBT(pkt.getNbtCompound());
      this.updateConnected();
   }
}
