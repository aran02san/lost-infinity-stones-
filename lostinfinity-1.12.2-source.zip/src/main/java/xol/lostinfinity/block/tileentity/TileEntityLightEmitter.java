package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.activator.BlockLightEmitter;
import xol.lostinfinity.block.activator.BlockLightReflector;
import xol.lostinfinity.block.misc.BlockLightReceiver;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.common.packets.serverbound.PacketLightReceiver;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class TileEntityLightEmitter extends TileEntity implements ITickable {
   private Vec3i dirUp = new Vec3i(0, 0, 1);
   private Vec3i dirLeft = new Vec3i(1, 0, 0);
   private BlockPos finalBlock;
   private boolean complete;
   private ArrayList<Vec3d> dirs;
   private ArrayList<Vec3d> reflectors;
   private Vec3d startPos;
   private Vec3d stopPos;

   public void update() {
      if (!this.world.isRemote) {
         TileEntityLightEmitter tileEntity = (TileEntityLightEmitter)this.world.getTileEntity(this.getPos());
         AxisAlignedBB mazeAABB = tileEntity.getLightMazeAABB();
         this.finalBlock = GalaxyCoordinates.getLightReceiver();
         if (this.finalBlock != null) {
            int radius = 20;

            for (int i = -radius; i < radius; i++) {
               for (int j = -radius; j < radius; j++) {
                  for (int k = -radius; k < radius; k++) {
                     BlockPos checkPos = new BlockPos(
                        this.finalBlock.getX() + i, this.finalBlock.getY() + j, this.finalBlock.getZ() + k
                     );
                     Block checkBlock = this.world.getBlockState(checkPos).getBlock();
                     if (checkBlock.equals(BlockInit.lightReceiver)) {
                        if (this.isComplete()) {
                           ((BlockLightReceiver)checkBlock).openGate(this.world, checkPos);
                        } else {
                           ((BlockLightReceiver)checkBlock).closeGate(this.world, checkPos);
                        }

                        return;
                     }
                  }
               }
            }
         }
      } else {
         this.complete = false;
         IBlockState emitterState = this.world.getBlockState(this.getPos());
         BlockLightEmitter emitterBlock = (BlockLightEmitter)this.world.getBlockState(this.getPos()).getBlock();
         TileEntityLightEmitter tileEntity = (TileEntityLightEmitter)this.world.getTileEntity(this.getPos());
         AxisAlignedBB mazeAABB = tileEntity.getLightMazeAABB();
         this.finalBlock = GalaxyCoordinates.getLightReceiver();
         Vec3d emitterDir = emitterBlock.getBeamDir(emitterState);
         this.startPos = new Vec3d(this.getPos().getX(), this.getPos().getY(), this.getPos().getZ());
         this.reflectors = new ArrayList<>();
         this.reflectors.add(this.startPos);
         this.dirs = new ArrayList<>();
         this.dirs.add(emitterDir);
         boolean flag = true;
         int count = 0;

         while (flag) {
            Vec3d dir = this.dirs.get(count);
            Vec3d nextPos = this.reflectors.get(count).add(dir);

            for (int dist = 0;
               this.world.isAirBlock(new BlockPos(nextPos.x, nextPos.y, nextPos.z)) && dist < 30;
               dist++
            ) {
               nextPos = nextPos.add(dir);
            }

            IBlockState nextState = this.world.getBlockState(new BlockPos(nextPos.x, nextPos.y, nextPos.z));
            Block nextBlock = nextState.getBlock();
            if (nextBlock instanceof BlockLightReflector) {
               ArrayList<Vec3d> beamDirs = ((BlockLightReflector)nextBlock).getBeamDirs(nextState);
               Vec3d dirReverse = new Vec3d(-1.0 * dir.x, -1.0 * dir.y, -1.0 * dir.z);
               if (beamDirs.contains(dirReverse)) {
                  boolean finalFlag = false;
                  IBlockState finalState = this.world.getBlockState(new BlockPos(nextPos.x, nextPos.y, nextPos.z));
                  if (finalState.getBlock() == BlockInit.lightReflector) {
                     BlockLightReflector finalReflector = (BlockLightReflector)finalState.getBlock();
                     finalFlag = finalReflector.getStateWithFacing(EnumFacing.SOUTH) == finalState;
                  }

                  if (new BlockPos(nextPos.x, nextPos.y, nextPos.z).equals(this.finalBlock) && finalFlag) {
                     this.complete = true;
                     this.reflectors.add(nextPos);
                     flag = false;
                     break;
                  }

                  this.reflectors.add(nextPos);
                  beamDirs.remove(dirReverse);
                  this.dirs.add(beamDirs.get(0));
                  count++;
               } else {
                  this.reflectors.add(this.stopPos);
                  this.stopPos = nextPos;
                  flag = false;
               }
            } else {
               if (this.reflectors.size() > 1) {
                  this.reflectors.add(this.stopPos);
               }

               this.stopPos = nextPos;
               flag = false;
            }
         }

         lostinfinity.instance
            .packetHandler
            .sendServerBasicPacket(
               new PacketLightReceiver(
                  this.complete, this.getPos().getX(), this.getPos().getY(), this.getPos().getZ()
               )
            );
      }
   }

   public boolean shouldRenderInPass(int pass) {
      return true;
   }

   public AxisAlignedBB getRenderBoundingBox() {
      return INFINITE_EXTENT_AABB;
   }

   @SideOnly(Side.CLIENT)
   public double getMaxRenderDistanceSquared() {
      return 65536.0;
   }

   public AxisAlignedBB getLightMazeAABB() {
      int x = this.getPos().getX();
      int y = this.getPos().getY();
      int z = this.getPos().getZ();
      return new AxisAlignedBB(
         x,
         y,
         z,
         x + this.dirUp.getX() * 10 + this.dirLeft.getX() * 10,
         y,
         z + this.dirUp.getZ() * 10 + this.dirLeft.getZ() * 10
      );
   }

   private void generateLightMaze() {
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      if (this.finalBlock != null) {
         compound.setInteger("FinalX", (short)this.finalBlock.getX());
         compound.setInteger("FinalY", (short)this.finalBlock.getY());
         compound.setInteger("FinalZ", (short)this.finalBlock.getZ());
      }

      compound.setBoolean("Complete", this.complete);
      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      if (compound.hasKey("FinalX")) {
         this.finalBlock = new BlockPos(compound.getInteger("FinalX"), compound.getInteger("FinalY"), compound.getInteger("FinalZ"));
      }

      this.complete = compound.getBoolean("Complete");
   }

   public Vec3d getStartPos() {
      return this.startPos;
   }

   public Vec3d getStopPos() {
      return this.stopPos;
   }

   public ArrayList<Vec3d> getReflectors() {
      return this.reflectors != null ? this.reflectors : new ArrayList<>();
   }

   public boolean isComplete() {
      return this.complete;
   }

   public void setComplete(boolean complete) {
      this.complete = complete;
   }
}
