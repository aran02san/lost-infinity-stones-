package xol.lostinfinity.block.tileentity.render;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import xol.lostinfinity.block.tileentity.TileEntityKillerVine;

public class RenderKillerVine extends TileEntitySpecialRenderer<TileEntityKillerVine> {
   public static final ResourceLocation TEXTURE_VINE = new ResourceLocation("lostinfinity:textures/particles/killer_vine.png");

   public void render(TileEntityKillerVine te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      if (te.isKiller()) {
         GlStateManager.disableBlend();
         GlStateManager.enableAlpha();
         GlStateManager.disableCull();
         this.enableMaxLighting();
         this.bindTexture(TEXTURE_VINE);
         Tessellator tessellator = Tessellator.getInstance();
         BufferBuilder bufferbuilder = tessellator.getBuffer();
         Vec3d playerPos = null;

         for (TileEntityKillerVine.VineNode node : te.getNodes()) {
            EntityLivingBase entity = node.getEntity();
            Vec3d pos = new Vec3d(
                  MathHelper.clampedLerp(entity.prevPosX, entity.posX, partialTicks),
                  MathHelper.clampedLerp(entity.prevPosY, entity.posY, partialTicks),
                  MathHelper.clampedLerp(entity.prevPosZ, entity.posZ, partialTicks)
               )
               .addVector(-0.5, entity.height / 2.0F - 0.5, -0.5);
            bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
            Vec3d tePos = new Vec3d(te.getPos().getX(), te.getPos().getY(), te.getPos().getZ());
            double dist = pos.distanceTo(tePos);
            Vec3d dir = pos.subtract(tePos);
            dir = dir.normalize();
            float segmentHeight = 0.5F;
            float segmentLength = 1.0F;

            for (int i = 0; i < (int)Math.floor(dist * Math.min(node.getGrowth() / 20.0, 1.0) / segmentLength); i++) {
               double xPos = x + 0.5 + dir.x * i * segmentLength;
               double yPos = y + dir.y * i * segmentLength + 0.5;
               double zPos = z + 0.5 + dir.z * i * segmentLength;
               bufferbuilder.pos(xPos, yPos + segmentHeight, zPos).tex(0.0, 1.0).endVertex();
               bufferbuilder.pos(xPos, yPos, zPos).tex(0.0, 0.0).endVertex();
               bufferbuilder.pos(
                     xPos + segmentLength * dir.x, yPos + segmentLength * dir.y, zPos + segmentLength * dir.z
                  )
                  .tex(1.0, 0.0)
                  .endVertex();
               bufferbuilder.pos(
                     xPos + segmentLength * dir.x,
                     yPos + segmentHeight + segmentLength * dir.y,
                     zPos + segmentLength * dir.z
                  )
                  .tex(1.0, 1.0)
                  .endVertex();
            }

            tessellator.draw();
         }

         GlStateManager.enableBlend();
         GlStateManager.disableAlpha();
         GlStateManager.enableCull();
      }
   }

   public boolean isGlobalRenderer(TileEntityKillerVine te) {
      return true;
   }

   private void enableMaxLighting() {
      GlStateManager.disableLighting();
      OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240.0F, 240.0F);
   }
}
