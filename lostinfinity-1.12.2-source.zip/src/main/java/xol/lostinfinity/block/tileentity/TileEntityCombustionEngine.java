package xol.lostinfinity.block.tileentity;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.misc.BlockCombustionEngine;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.ItemInit;

public class TileEntityCombustionEngine extends TileEntity implements IMachine, ITickable, IInventory {
   private NonNullList<ItemStack> inventory = NonNullList.withSize(1, ItemStack.EMPTY);
   private int burnTime;
   private int currentBurnTime;

   public String getName() {
      return "tile.combustion_engine";
   }

   public boolean hasCustomName() {
      return false;
   }

   private double getROD(int multi) {
      return (-0.5 + this.world.rand.nextDouble()) * multi;
   }

   public void update() {
      boolean burning = this.isBurning();
      boolean sync = false;
      if (this.isBurning()) {
         this.burnTime--;
      }

      if (!this.world.isRemote) {
         ItemStack fuel = (ItemStack)this.inventory.get(0);
         if ((this.isBurning() || !fuel.isEmpty()) && !this.isBurning() && this.canSmelt()) {
            this.burnTime = getItemBurnTime(fuel);
            this.currentBurnTime = this.burnTime;
            if (this.isBurning()) {
               sync = true;
               if (!fuel.isEmpty()) {
                  Item item = fuel.getItem();
                  fuel.shrink(1);
                  if (fuel.isEmpty()) {
                     ItemStack itemContainer = item.getContainerItem(fuel);
                     this.inventory.set(0, itemContainer);
                  }
               }
            }
         }

         if (burning != this.isBurning()) {
            sync = true;
            BlockCombustionEngine.setState(this.isBurning(), this.world, this.pos);
         }
      }

      if (sync) {
         this.markDirty();
      }
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      for (ItemStack stack : this.inventory) {
         if (!stack.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      ItemStack itemstack = (ItemStack)this.inventory.get(index);
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }

      boolean same = stack.isEmpty() || !stack.isItemEqual(itemstack) || !ItemStack.areItemStackTagsEqual(stack, itemstack);
      if (index == 0 && same) {
         this.markDirty();
      }
   }

   private boolean canSmelt() {
      ItemStack fuel = (ItemStack)this.inventory.get(0);
      return !fuel.isEmpty();
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setInteger("BurnTime", (short)this.burnTime);
      ItemStackHelper.saveAllItems(compound, this.inventory);
      return compound;
   }

   @Override
   public boolean getPowered() {
      return this.isBurning();
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.inventory = NonNullList.withSize(this.getSizeInventory(), ItemStack.EMPTY);
      ItemStackHelper.loadAllItems(compound, this.inventory);
      this.burnTime = compound.getInteger("BurnTime");
      this.currentBurnTime = getItemBurnTime((ItemStack)this.inventory.get(0));
   }

   public boolean isBurning() {
      return this.burnTime > 0;
   }

   @SideOnly(Side.CLIENT)
   public static boolean isBurning(IInventory inventory) {
      return inventory.getField(0) > 0;
   }

   private static int getItemBurnTime(ItemStack fuel) {
      if (fuel.isEmpty()) {
         return 0;
      } else {
         return fuel.getItem() == ItemInit.sparkPlug ? 200 : 0;
      }
   }

   public static boolean isItemFuel(ItemStack fuel) {
      return getItemBurnTime(fuel) > 0;
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return this.world.getTileEntity(this.pos) != this
         ? false
         : player.getDistanceSq(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5)
            <= 64.0;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      if (index >= 1) {
         return false;
      } else {
         return index == 0 ? isItemFuel(stack) : true;
      }
   }

   public int getGuiID() {
      return GuiHandler.RegisteredGuis.COMBUSTION_ENGINE.getId();
   }

   public int getField(int id) {
      switch (id) {
         case 0:
            return this.burnTime;
         case 1:
            return this.currentBurnTime;
         default:
            return 0;
      }
   }

   public void setField(int id, int value) {
      switch (id) {
         case 0:
            this.burnTime = value;
            break;
         case 1:
            this.currentBurnTime = value;
      }
   }

   public int getFieldCount() {
      return 2;
   }

   public void clear() {
      this.inventory.clear();
   }
}
