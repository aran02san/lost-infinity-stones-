package xol.lostinfinity.block.tileentity.render;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.tileentity.TileEntitySpecialRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import xol.lostinfinity.block.activator.BlockPortalNode;
import xol.lostinfinity.block.tileentity.TileEntityPortalNexus;
import xol.lostinfinity.block.tileentity.TileEntityPortalNode;
import xol.lostinfinity.init.BlockInit;

public class RenderPortalNodeEffect extends TileEntitySpecialRenderer<TileEntityPortalNode> {
   public static final ResourceLocation TEXTURE_PORTAL_BEAM = new ResourceLocation("lostinfinity:textures/particles/portal_beam.png");

   public void render(TileEntityPortalNode te, double x, double y, double z, float partialTicks, int destroyStage, float alpha) {
      IBlockState state = te.getWorld().getBlockState(te.getPos());
      Block block = state.getBlock();
      if (!block.equals(BlockInit.portalNode) || state == ((BlockPortalNode)BlockInit.portalNode).getStateFromMeta(1)) {
         BlockPos nexusPos = te.getNexusPos();
         if (nexusPos != null) {
            TileEntityPortalNexus nexus = (TileEntityPortalNexus)te.getWorld().getTileEntity(nexusPos);
            if (nexus != null) {
               Vec3d nexusVec = new Vec3d(te.getNexusPos().getX() + 0.5, te.getNexusPos().getY(), te.getNexusPos().getZ() + 0.5);
               Vec3d pos = new Vec3d(te.getPos().getX(), te.getPos().getY(), te.getPos().getZ());
               this.bindTexture(TEXTURE_PORTAL_BEAM);
               Tessellator tessellator = Tessellator.getInstance();
               BufferBuilder bufferbuilder = tessellator.getBuffer();
               GlStateManager.disableCull();
               GlStateManager.enableAlpha();
               GlStateManager.enableBlend();
               GlStateManager.alphaFunc(516, 0.3F);
               bufferbuilder.begin(7, DefaultVertexFormats.POSITION_TEX);
               double dist = pos.distanceTo(nexusVec);
               Vec3d dir = nexusVec.subtract(pos);
               dir = dir.normalize();
               float segmentHeight = 2.0F;
               float segmentLength = 1.0F;
               double growth = nexus.getGrowth();

               for (int i = 0; i < (int)Math.floor((dist - growth / 2.0) / segmentLength); i++) {
                  double xPos = x + dir.x * i * segmentLength;
                  double yPos = y + dir.y * i * segmentLength;
                  double zPos = z + dir.z * i * segmentLength;
                  bufferbuilder.pos(xPos, yPos + segmentHeight, zPos).tex(0.0, 1.0).endVertex();
                  bufferbuilder.pos(xPos, yPos, zPos).tex(0.0, 0.0).endVertex();
                  bufferbuilder.pos(
                        xPos + segmentLength * dir.x, yPos + segmentLength * dir.y, zPos + segmentLength * dir.z
                     )
                     .tex(1.0, 0.0)
                     .endVertex();
                  bufferbuilder.pos(
                        xPos + segmentLength * dir.x,
                        yPos + segmentHeight + segmentLength * dir.y,
                        zPos + segmentLength * dir.z
                     )
                     .tex(1.0, 1.0)
                     .endVertex();
               }

               tessellator.draw();
               GlStateManager.enableCull();
               GlStateManager.disableBlend();
            }
         }
      }
   }
}
