package xol.lostinfinity.block.tileentity;

import java.util.List;
import java.util.Random;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.mob.entity.nebula.EntityNebulaGiant;
import xol.lostinfinity.mob.entity.nebula.EntityNebulaGrunt;
import xol.lostinfinity.mob.entity.nebula.EntityNebulaWizard;
import xol.lostinfinity.util.fx.IParticleSpawner;

public class TileEntityNebulousBeacon extends TileEntity implements IInventory, ITickable {
   private static final int RANGE = 3;
   public static final int HEALTH_MAX = 100;
   public static final int DURATION_MAX = 4800;
   private Random rand = new Random();
   private int health = 100;
   private int duration = 0;

   public void update() {
      if (!this.world.isRemote) {
         if (this.health <= 0) {
            this.world.destroyBlock(this.pos, false);
            this.world.removeTileEntity(this.pos);
            this.world.playSound(null, this.pos, SoundEvents.ENTITY_ZOMBIE_BREAK_DOOR_WOOD, SoundCategory.BLOCKS, 1.0F, 1.0F);
            return;
         }

         this.duration++;
         this.trySpawnMob();
         this.checkIfDamaged();
         if (this.duration % 160 == 0) {
            this.world
               .playSound(null, this.pos, SoundInit.NEBULOUS_BEACON, SoundCategory.BLOCKS, 1.5F, 0.8F + this.rand.nextFloat() * 0.4F);
         }

         if (this.duration >= 4800) {
            this.duration = 0;
            this.health = 100;
            this.world.removeTileEntity(this.pos);
            this.world.setBlockToAir(this.pos);
            EntityItem generator = new EntityItem(
               this.world,
               this.pos.getX(),
               this.pos.getY() + 1,
               this.pos.getZ(),
               new ItemStack(ItemInit.astralGenerator)
            );
            this.world.spawnEntity(generator);
            this.world.playSound(null, this.pos, SoundInit.SPACE_VICTORY, SoundCategory.BLOCKS, 1.5F, 1.0F);
            IParticleSpawner.spawnParticle(
               this.world,
               61,
               16,
               (double)this.pos.getX(),
               (double)(this.pos.getY() + 1),
               (double)this.pos.getZ()
            );
         }
      }
   }

   private void checkIfDamaged() {
      if (this.duration % 40 == 0) {
         List<EntityNebulaGrunt> nearGrunts = this.world
            .getEntitiesWithinAABB(EntityNebulaGrunt.class, new AxisAlignedBB(this.pos).grow(3.0));
         List<EntityNebulaGiant> nearGiants = this.world
            .getEntitiesWithinAABB(EntityNebulaGiant.class, new AxisAlignedBB(this.pos).grow(3.0));
         List<EntityNebulaWizard> nearWizards = this.world
            .getEntitiesWithinAABB(EntityNebulaWizard.class, new AxisAlignedBB(this.pos).grow(3.0));
         int damage = nearGrunts.size() + nearGiants.size() + nearWizards.size();
         this.health -= damage;
         if (damage > 0) {
            this.world
               .playSound(
                  null, this.pos, SoundEvents.ENTITY_ZOMBIE_ATTACK_DOOR_WOOD, SoundCategory.PLAYERS, 1.0F, 1.5F - this.world.rand.nextFloat()
               );
         }
      }
   }

   private void trySpawnMob() {
      if (this.duration % 40 == 0 && this.world.rand.nextBoolean()) {
         double x = this.world.rand.nextBoolean()
            ? this.pos.getX() - (this.world.rand.nextInt(15) + 25)
            : this.pos.getX() + this.world.rand.nextInt(15) + 25;
         double y = this.pos.getY();
         double z = this.world.rand.nextBoolean()
            ? this.pos.getZ() - (this.world.rand.nextInt(15) + 25)
            : this.pos.getZ() + this.world.rand.nextInt(15) + 25;
         BlockPos spawnPos = new BlockPos(x, y, z);

         while (!this.world.isAirBlock(spawnPos.add(0, -1, 0))) {
            spawnPos = new BlockPos(x, ++y, z);
         }

         BlockPos targetPos = this.pos.add(0.0, 1.0, 0.0);
         if (this.duration / 4800.0F < 0.25) {
            EntityNebulaGrunt grunt = new EntityNebulaGrunt(this.world, targetPos);
            grunt.setPosition(spawnPos.getX(), spawnPos.getY(), spawnPos.getZ());
            this.world.spawnEntity(grunt);
         } else if (this.duration / 4800.0F < 0.5) {
            EntityNebulaWizard wizard = new EntityNebulaWizard(this.world, targetPos);
            wizard.setPosition(spawnPos.getX(), spawnPos.getY(), spawnPos.getZ());
            this.world.spawnEntity(wizard);
         } else if (this.duration / 4800.0F < 0.75) {
            EntityNebulaGiant giant = new EntityNebulaGiant(this.world, targetPos);
            giant.setPosition(spawnPos.getX(), spawnPos.getY(), spawnPos.getZ());
            this.world.spawnEntity(giant);
         } else {
            switch (this.world.rand.nextInt(3)) {
               case 0:
                  EntityNebulaGrunt grunt = new EntityNebulaGrunt(this.world, targetPos);
                  grunt.setPosition(spawnPos.getX(), spawnPos.getY(), spawnPos.getZ());
                  this.world.spawnEntity(grunt);
                  break;
               case 1:
                  EntityNebulaWizard wizard = new EntityNebulaWizard(this.world, targetPos);
                  wizard.setPosition(spawnPos.getX(), spawnPos.getY(), spawnPos.getZ());
                  this.world.spawnEntity(wizard);
                  break;
               case 2:
                  EntityNebulaGiant giant = new EntityNebulaGiant(this.world, targetPos);
                  giant.setPosition(spawnPos.getX(), spawnPos.getY(), spawnPos.getZ());
                  this.world.spawnEntity(giant);
            }
         }
      }
   }

   public int getSizeInventory() {
      return 0;
   }

   public boolean isEmpty() {
      return false;
   }

   public ItemStack getStackInSlot(int index) {
      return null;
   }

   public ItemStack decrStackSize(int index, int count) {
      return null;
   }

   public ItemStack removeStackFromSlot(int index) {
      return null;
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
   }

   public int getInventoryStackLimit() {
      return 0;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return true;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      return false;
   }

   public int getField(int id) {
      switch (id) {
         case 0:
            return this.health;
         case 1:
            return this.duration;
         default:
            return 0;
      }
   }

   public void setField(int id, int value) {
      switch (id) {
         case 0:
            this.health = value;
            break;
         case 1:
            this.duration = value;
      }
   }

   public int getFieldCount() {
      return 2;
   }

   public void clear() {
   }

   public String getName() {
      return "tile.nebulous_beacon";
   }

   public boolean hasCustomName() {
      return false;
   }

   public int getCurrentHealth() {
      return this.getField(0);
   }

   public int getCurrentDuration() {
      return this.getField(1);
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setInteger("health", this.health);
      compound.setInteger("duration", this.duration);
      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.health = compound.getInteger("health");
      this.duration = compound.getInteger("duration");
   }
}
