package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityPowerConduit extends TileEntity implements ITickable {
   private Vec3i upDir = null;
   private Vec3i leftDir = null;
   private static final Vec3i offset = new Vec3i(0, -2, 0);
   private ArrayList<BlockPos> tiles = null;
   private BlockPos ref = null;
   private int upCount = 0;
   private int leftCount = 0;
   ArrayList<TileEntityPowerConduit.LogData> logs = new ArrayList<>();
   private boolean game = false;
   private boolean lost = false;
   private int loseTimer = 0;

   public void lose() {
      this.lost = true;
      this.loseTimer = 0;
   }

   public void reset(int upCount, int leftCount) {
      this.ref = null;
      this.upCount = upCount;
      this.leftCount = leftCount;
      this.logs.clear();
      if (this.tiles != null && this.upDir != null && this.leftDir != null) {
         this.ref = this.pos.add(this.leftDir).add(this.upDir).add(offset);

         for (int i = 0; i < this.leftCount; i++) {
            BlockPos temp = this.ref.add(this.leftDir.getX() * i, 0, this.leftDir.getZ() * i);
            BlockPos tempEnd = temp.add(this.upDir.getX() * (this.upCount - 1), 0, this.upDir.getZ() * (this.upCount - 1));
            this.world.setBlockState(tempEnd, BlockInit.powerNodule.getStateFromMeta(2));
            if (i == this.leftCount / 2) {
               this.world.setBlockState(temp, BlockInit.powerNodule.getStateFromMeta(3));
            } else if (this.tiles.contains(temp)) {
               this.world.setBlockState(temp, BlockInit.powerNodule.getStateFromMeta(2));
            }
         }

         boolean moveLeft = true;

         for (int ix = 1; ix < this.upCount - 1; ix++) {
            BlockPos temp;
            if (moveLeft) {
               temp = this.ref.add(this.upDir.getX() * ix, 0, this.upDir.getZ() * ix);
            } else {
               temp = this.ref
                  .add(
                     this.upDir.getX() * ix + this.leftDir.getX() * (this.leftCount - 1),
                     0,
                     this.upDir.getZ() * ix + this.leftDir.getZ() * (this.leftCount - 1)
                  );
            }

            int startPointer = 0;
            int endPointer = 0;
            Random rand = new Random();

            for (int timer = rand.nextInt(10) + 8; endPointer < this.leftCount - 3; startPointer = endPointer + 1) {
               int spacesLeft = this.leftCount - 1 - endPointer;
               int logLength = rand.nextInt(2) + 1;
               int spacing = Math.max(rand.nextInt(Math.min(Math.max(spacesLeft - logLength, 1), 3)), 2);
               if (spacing + logLength > spacesLeft) {
                  spacing = spacesLeft - logLength;
               }

               endPointer += logLength + spacing;
               ArrayList<BlockPos> logPositions = new ArrayList<>();

               for (int k = startPointer; k < startPointer + logLength; k++) {
                  BlockPos logPos;
                  if (moveLeft) {
                     logPos = temp.add(k * this.leftDir.getX(), 0, k * this.leftDir.getZ());
                  } else {
                     logPos = temp.add(-k * this.leftDir.getX(), 0, -k * this.leftDir.getZ());
                  }

                  this.world.setBlockState(logPos, BlockInit.powerNodule.getStateFromMeta(2));
                  logPositions.add(logPos);
               }

               TileEntityPowerConduit.LogData log = new TileEntityPowerConduit.LogData(logPositions, timer, moveLeft, this.ref, ix);
               this.logs.add(log);
            }

            moveLeft = !moveLeft;
         }
      }

      this.game = true;
      this.world.playSound(null, this.pos, SoundInit.GEAR_MACHINE_2, SoundCategory.BLOCKS, 1.0F, 1.0F);
   }

   public void setTiles(ArrayList<BlockPos> tiles) {
      this.tiles = tiles;
   }

   public void endGame() {
      this.game = false;
   }

   public void update() {
      if (!this.world.isRemote) {
         if (this.lost) {
            this.loseTimer++;
            if (this.loseTimer > 30) {
               this.lost = false;
               this.reset(this.upCount, this.leftCount);
            }
         }

         if (this.logs != null && this.logs.size() > 0 && this.game) {
            for (TileEntityPowerConduit.LogData log : this.logs) {
               log.move(this.world, this.leftDir, this.upDir, this.leftCount, this);
            }
         }

         if (this.tiles != null) {
            for (BlockPos tilePos : this.tiles) {
               IBlockState state = this.world.getBlockState(tilePos);
               Block block = state.getBlock();
               if (block.getMetaFromState(state) == 1) {
                  this.lose();
               }
            }
         }
      }
   }

   public void setDirs(Vec3i upDir, Vec3i leftDir) {
      this.upDir = upDir;
      this.leftDir = leftDir;
   }

   public ArrayList<BlockPos> getTiles() {
      return this.tiles;
   }

   public Vec3i getUpDir() {
      return this.upDir;
   }

   private class LogData {
      ArrayList<BlockPos> positions = null;
      int timer = 100;
      int progress = 0;
      boolean moveLeft = true;
      BlockPos ref = null;
      private int row = 0;

      private LogData(ArrayList<BlockPos> positions, int timer, boolean moveLeft, BlockPos ref, int row) {
         this.positions = positions;
         this.timer = timer;
         this.moveLeft = moveLeft;
         this.progress = 0;
         this.ref = ref;
         this.row = row;
      }

      public void move(World world, Vec3i leftDir, Vec3i upDir, int leftCount, TileEntityPowerConduit TE) {
         if (this.positions != null && this.ref != null) {
            this.progress++;
            if (this.progress >= this.timer) {
               this.progress = 0;
               BlockPos rowPos;
               if (this.moveLeft) {
                  rowPos = this.ref.add(upDir.getX() * this.row, 0, upDir.getZ() * this.row);
               } else {
                  rowPos = this.ref
                     .add(
                        upDir.getX() * this.row + leftDir.getX() * (leftCount - 1),
                        0,
                        upDir.getZ() * this.row + leftDir.getZ() * (leftCount - 1)
                     );
               }

               ArrayList<BlockPos> toReset = new ArrayList<>();
               ArrayList<BlockPos> set = new ArrayList<>();
               BlockPos connectorPos = null;

               for (BlockPos position : this.positions) {
                  int dist = Math.abs(rowPos.getX() - position.getX() + rowPos.getZ() - position.getZ());
                  if (dist < leftCount - 1) {
                     BlockPos next;
                     if (this.moveLeft) {
                        next = position.add(leftDir.getX(), 0, leftDir.getZ());
                     } else {
                        next = position.add(-leftDir.getX(), 0, -leftDir.getZ());
                     }

                     if (world.getBlockState(position).getBlock().equals(BlockInit.powerNodule)) {
                        if (BlockInit.powerNodule.getMetaFromState(world.getBlockState(position)) == 3) {
                           connectorPos = next;
                        }

                        set.add(next);
                        toReset.add(position);
                     }
                  } else {
                     if (BlockInit.powerNodule.getMetaFromState(world.getBlockState(position)) == 3) {
                        TE.lose();
                        return;
                     }

                     world.setBlockState(rowPos, BlockInit.powerNodule.getStateFromMeta(2));
                     set.add(rowPos);
                     toReset.add(position);
                  }
               }

               this.positions.clear();
               this.positions.addAll(set);
               toReset.removeAll(set);

               for (BlockPos setPos : set) {
                  world.setBlockState(setPos, BlockInit.powerNodule.getStateFromMeta(2));
               }

               for (BlockPos resetPos : toReset) {
                  world.setBlockState(resetPos, BlockInit.powerNodule.getStateFromMeta(0));
               }

               if (connectorPos != null) {
                  world.setBlockState(connectorPos, BlockInit.powerNodule.getStateFromMeta(3));
               }
            }
         }
      }
   }
}
