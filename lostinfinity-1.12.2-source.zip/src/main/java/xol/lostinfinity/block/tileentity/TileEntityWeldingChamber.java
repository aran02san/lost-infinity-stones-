package xol.lostinfinity.block.tileentity;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.NonNullList;
import net.minecraft.util.SoundCategory;
import xol.lostinfinity.block.crafting.BlockWeldingChamber;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityWeldingChamber extends TileEntity implements IInventory, ITickable {
   private NonNullList<ItemStack> inventory = NonNullList.withSize(2, ItemStack.EMPTY);
   private final int smeltTime = 300;
   private final int maxHeat = 6000;
   private int currentSmeltTime;
   private int heat = 3000;
   private int acetylene = 4;

   public void update() {
      ItemStack input = (ItemStack)this.inventory.get(0);
      int inputCount = input.getCount();
      if (input.getItem().getUnlocalizedName().equalsIgnoreCase("item.atomite_fragments")
         && inputCount >= 5
         && ((ItemStack)this.inventory.get(1)).getCount() <= 64) {
         BlockWeldingChamber.setState(true, this.world, this.pos);
         this.currentSmeltTime = this.getField(0) + 1;
         if (!this.calculateHeat(input, inputCount)) {
            return;
         }

         if (this.currentSmeltTime == 300) {
            this.fuseAtomite(input, inputCount);
         }
      } else {
         BlockWeldingChamber.setState(false, this.world, this.pos);
         this.currentSmeltTime = 0;
         if (this.heat != 3000) {
            this.cool();
         }
      }
   }

   private boolean calculateHeat(ItemStack input, int inputCount) {
      int targetAcetyleneLevel = 0;
      int multiplier = 0;
      int offset = ThreadLocalRandom.current().nextInt(2) == 0 ? -(ThreadLocalRandom.current().nextInt(50) + 1) : ThreadLocalRandom.current().nextInt(50) + 1;
      if (this.heat < 6000 && this.heat > 0) {
         if (this.currentSmeltTime / 300.0F <= 0.2) {
            targetAcetyleneLevel = 1;
            multiplier = 20;
         } else if (this.currentSmeltTime / 300.0F <= 0.4) {
            targetAcetyleneLevel = 4;
            multiplier = 30;
         } else if (this.currentSmeltTime / 300.0F <= 0.6) {
            targetAcetyleneLevel = 2;
            multiplier = 30;
         } else if (this.currentSmeltTime / 300.0F <= 0.8) {
            targetAcetyleneLevel = 6;
            multiplier = 25;
         } else if (this.currentSmeltTime / 300.0F <= 1.0) {
            targetAcetyleneLevel = 2;
            multiplier = 25;
         }

         int diff = this.acetylene - targetAcetyleneLevel;
         this.heat += diff * multiplier + offset;
         return true;
      } else {
         this.failFuse(input, inputCount);
         return false;
      }
   }

   private void failFuse(ItemStack input, int inputCount) {
      this.currentSmeltTime = 0;
      this.heat = 3000;
      this.world.playSound(null, this.pos, SoundInit.GENERIC_UI_4, SoundCategory.BLOCKS, 1.0F, 1.0F);
      input.setCount(inputCount - 5);
      this.markDirty();
   }

   private void cool() {
      if (this.heat == 2999) {
         this.heat++;
      } else if (this.heat == 3001) {
         this.heat--;
      } else if (this.heat > 3000) {
         this.heat -= 4;
      } else if (this.heat < 3000) {
         this.heat += 4;
      }
   }

   private void fuseAtomite(ItemStack input, int inputCount) {
      this.setField(0, 0);
      ItemStack output;
      if (((ItemStack)this.inventory.get(1)).isEmpty()) {
         output = new ItemStack(ItemInit.weldedAtomite, 1);
      } else {
         output = (ItemStack)this.inventory.get(1);
         output.setCount(output.getCount() + 1);
      }

      this.inventory.set(1, output);
      input.setCount(inputCount - 5);
      this.world.playSound(null, this.pos, SoundInit.WELDING, SoundCategory.BLOCKS, 1.0F, 3.0F);
      this.markDirty();
   }

   public int getSizeInventory() {
      return this.inventory.size();
   }

   public boolean isEmpty() {
      for (ItemStack stack : this.inventory) {
         if (!stack.isEmpty()) {
            return false;
         }
      }

      return true;
   }

   public ItemStack getStackInSlot(int index) {
      return (ItemStack)this.inventory.get(index);
   }

   public ItemStack decrStackSize(int index, int count) {
      return ItemStackHelper.getAndSplit(this.inventory, index, count);
   }

   public ItemStack removeStackFromSlot(int index) {
      return ItemStackHelper.getAndRemove(this.inventory, index);
   }

   public void setInventorySlotContents(int index, ItemStack stack) {
      this.inventory.set(index, stack);
      int limit = this.getInventoryStackLimit();
      if (stack.getCount() > limit) {
         stack.setCount(limit);
      }
   }

   public int getInventoryStackLimit() {
      return 64;
   }

   public boolean isUsableByPlayer(EntityPlayer player) {
      return this.world.getTileEntity(this.pos) != this
         ? false
         : player.getDistanceSq(this.pos.getX() + 0.5, this.pos.getY() + 0.5, this.pos.getZ() + 0.5)
            <= 64.0;
   }

   public void openInventory(EntityPlayer player) {
   }

   public void closeInventory(EntityPlayer player) {
   }

   public boolean isItemValidForSlot(int index, ItemStack stack) {
      return false;
   }

   public int getField(int id) {
      switch (id) {
         case 0:
            return this.currentSmeltTime;
         case 1:
            return this.heat;
         case 2:
            return this.acetylene;
         default:
            return 0;
      }
   }

   public void setField(int id, int value) {
      switch (id) {
         case 0:
            this.currentSmeltTime = value;
            break;
         case 1:
            this.heat = value;
            break;
         case 2:
            if (value < 0) {
               value = 0;
            } else if (value > 7) {
               value = 7;
            }

            this.acetylene = value;
      }
   }

   public int getFieldCount() {
      return 3;
   }

   public void clear() {
      this.inventory.clear();
   }

   public String getName() {
      return "tile.welding_chamber";
   }

   public boolean hasCustomName() {
      return false;
   }

   public NBTTagCompound writeToNBT(NBTTagCompound compound) {
      super.writeToNBT(compound);
      compound.setInteger("currentSmeltTime", this.currentSmeltTime);
      compound.setInteger("heat", this.heat);
      compound.setInteger("acetylene", this.acetylene);
      ItemStackHelper.saveAllItems(compound, this.inventory);
      return compound;
   }

   public void readFromNBT(NBTTagCompound compound) {
      super.readFromNBT(compound);
      this.inventory = NonNullList.withSize(this.getSizeInventory(), ItemStack.EMPTY);
      ItemStackHelper.loadAllItems(compound, this.inventory);
      this.currentSmeltTime = compound.getInteger("currentSmeltTime");
      this.heat = compound.getInteger("heat");
      this.acetylene = compound.getInteger("acetylene");
   }

   public int getSmeltTime() {
      return 300;
   }

   public int getMaxHeat() {
      return 6000;
   }

   public int getGuiID() {
      return GuiHandler.RegisteredGuis.WELDING_CHAMBER.getId();
   }
}
