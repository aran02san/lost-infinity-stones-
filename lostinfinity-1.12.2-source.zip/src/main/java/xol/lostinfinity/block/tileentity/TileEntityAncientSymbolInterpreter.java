package xol.lostinfinity.block.tileentity;

import java.util.ArrayList;
import java.util.Collections;
import net.minecraft.init.SoundEvents;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import xol.lostinfinity.init.BlockInit;

public class TileEntityAncientSymbolInterpreter extends TileEntity implements ITickable {
   private Vec3i dir = null;
   private int[][] symbols = (int[][])null;
   private ArrayList<BlockPos> tiles = null;
   private BlockPos first = null;
   private BlockPos second = null;
   private BlockPos ref = null;
   private boolean flipBack = false;
   private static final int numSymbols = 15;

   public void flip(BlockPos pos) {
      if (!this.flipBack) {
         int symbol = this.getSymbol(pos);
         if (this.first == null) {
            this.first = pos;
         } else {
            if (this.second != null) {
               return;
            }

            this.second = pos;
            int firstSymbol = this.getSymbol(this.first);
            if (symbol == firstSymbol) {
               this.world.setBlockState(pos, BlockInit.ancientSymbol.getStateFromMeta(symbol));
               this.world.playSound(null, pos.up(), SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.BLOCKS, 2.0F, 1.0F);
               this.first = null;
               this.second = null;
               return;
            }

            this.flipBack = true;
         }

         this.world.setBlockState(pos, BlockInit.ancientSymbol.getStateFromMeta(symbol));
         this.world.playSound(null, pos.up(), SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.BLOCKS, 2.0F, 1.0F);
      }
   }

   public int getSymbol(BlockPos pos) {
      if (this.ref != null && this.symbols != null) {
         int i = Math.abs(pos.getX() - this.ref.getX());
         int j = Math.abs(pos.getZ() - this.ref.getZ());
         if (i < this.symbols.length && j < this.symbols[i].length) {
            return this.symbols[i][j];
         }
      }

      return 0;
   }

   public void setSymbol(BlockPos pos, int symbol) {
      if (this.ref != null && this.symbols != null) {
         int i = Math.abs(pos.getX() - this.ref.getX());
         int j = Math.abs(pos.getZ() - this.ref.getZ());
         if (i < this.symbols.length && j < this.symbols[i].length) {
            this.symbols[i][j] = symbol;
         }
      }
   }

   public void setDir(Vec3i dir) {
      this.dir = dir;
   }

   public void reset(int dimension) {
      this.first = null;
      this.second = null;
      this.flipBack = false;
      this.ref = null;
      this.symbols = new int[dimension][dimension];
      if (this.dir != null && this.tiles != null) {
         this.ref = this.pos.add(this.dir).add(0, -3, 0);
         Collections.shuffle(this.tiles);
         int symbol = 1;

         for (int i = 0; i < this.tiles.size(); i += 2) {
            BlockPos tile2 = this.tiles.get(i + 1);
            BlockPos tile1 = this.tiles.get(i);
            if (tile1 != null && tile2 != null) {
               this.setSymbol(tile2, symbol);
               this.setSymbol(tile1, symbol);
            }

            if (symbol < 15) {
               symbol++;
            }
         }
      }
   }

   public void setTiles(ArrayList<BlockPos> tiles) {
      this.tiles = tiles;
   }

   public void update() {
      if (!this.world.isRemote && this.world.getTotalWorldTime() % 20L == 0L && this.flipBack && this.first != null && this.second != null) {
         this.flipBack = false;
         this.world.setBlockState(this.first, BlockInit.ancientSymbol.getStateFromMeta(0));
         this.world.setBlockState(this.second, BlockInit.ancientSymbol.getStateFromMeta(0));
         this.first = null;
         this.second = null;
      }
   }
}
