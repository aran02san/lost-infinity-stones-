package xol.lostinfinity.block.tileentity;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityPolymerizationDevice extends TileEntity {
   private boolean active = false;
   private int nextMonomer = 0;

   public AxisAlignedBB getTank() {
      int minY = this.pos.getY() + 3;
      int minX = this.pos.getX() - 2;
      int minZ = this.pos.getZ() - 2;
      int maxY = minY + 1;
      int maxX = minX + 4;
      int maxZ = minZ + 4;
      return new AxisAlignedBB(minX, minY, minZ, maxX, maxY, maxZ);
   }

   public boolean isActivated() {
      return this.active;
   }

   public void activate(EntityPlayer playerIn, EnumHand hand) {
      if (!this.active) {
         this.clearTank();
         int radius = 7;
         this.nextMonomer = this.world.rand.nextInt(5);

         for (EntityPlayer player : this.world
            .getEntitiesWithinAABB(
               EntityPlayer.class,
               new AxisAlignedBB(this.getPos().add(-radius, -4, -radius), this.getPos().add(radius, 4, radius))
            )) {
            ItemStack newStack = new ItemStack(ItemInit.monomerCollector, 1);
            newStack.setTagCompound(new NBTTagCompound());
            newStack.getTagCompound().setLong("EndTime", System.currentTimeMillis() + 200000L);
            player.addItemStackToInventory(newStack);
            player.sendMessage(
               new TextComponentString(TextFmt.Green + "Collect monomer samples around the labyrinth and return them to start the polymerization process.")
            );
            this.messageMonomer(player);
            this.world.playSound(null, this.pos, SoundInit.GENERIC_UI_4, SoundCategory.PLAYERS, 1.25F, 1.0F);
         }

         this.active = true;
      } else if (this.active) {
         Item nextMonomer;
         switch (this.nextMonomer) {
            case 0:
               nextMonomer = ItemInit.purpleMonomerSample;
               break;
            case 1:
               nextMonomer = ItemInit.blueMonomerSample;
               break;
            case 2:
               nextMonomer = ItemInit.redMonomerSample;
               break;
            case 3:
               nextMonomer = ItemInit.yellowMonomerSample;
               break;
            case 4:
               nextMonomer = ItemInit.greenMonomerSample;
               break;
            default:
               nextMonomer = ItemInit.purpleMonomerSample;
         }

         ItemStack stack = playerIn.getHeldItem(hand);
         Item item = stack.getItem();
         if (!item.equals(nextMonomer)) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Red + "That is not the correct monomer!"));
            this.messageMonomer(playerIn);
            return;
         }

         IBlockState state;
         if (item.equals(ItemInit.purpleMonomerSample)) {
            state = BlockInit.monomerCube.getStateFromMeta(0);
         } else if (item.equals(ItemInit.blueMonomerSample)) {
            state = BlockInit.monomerCube.getStateFromMeta(1);
         } else if (item.equals(ItemInit.redMonomerSample)) {
            state = BlockInit.monomerCube.getStateFromMeta(2);
         } else if (item.equals(ItemInit.yellowMonomerSample)) {
            state = BlockInit.monomerCube.getStateFromMeta(3);
         } else {
            if (!item.equals(ItemInit.greenMonomerSample)) {
               return;
            }

            state = BlockInit.monomerCube.getStateFromMeta(4);
         }

         AxisAlignedBB tank = this.getTank();
         int xMin = (int)tank.minX;
         int xMax = (int)tank.maxX;
         int zMin = (int)tank.minZ;
         int zMax = (int)tank.maxZ;
         int yMin = (int)tank.minY;
         int yMax = (int)tank.maxY;
         boolean placed = false;

         label105:
         for (int i = yMin; i <= yMax; i++) {
            for (int j = xMin; j <= xMax; j++) {
               for (int k = zMin; k <= zMax; k++) {
                  BlockPos checkPos = new BlockPos(j, i, k);
                  if (this.world.isAirBlock(checkPos)) {
                     this.world.setBlockState(checkPos, state);
                     placed = true;
                     stack.shrink(1);
                     break label105;
                  }
               }
            }
         }

         if (!placed) {
            int radius = 7;

            for (EntityPlayer player : this.world
               .getEntitiesWithinAABB(
                  EntityPlayer.class,
                  new AxisAlignedBB(this.getPos().add(-radius, -4, -radius), this.getPos().add(radius, 4, radius))
               )) {
               player.sendMessage(new TextComponentString(TextFmt.Green + "Sucessfully Combined Monomers into Polymer!"));

               for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
                  if (player.inventory.getStackInSlot(i).getItem() == ItemInit.monomerCollector) {
                     player.inventory.setInventorySlotContents(i, ItemStack.EMPTY);
                  }
               }

               player.addItemStackToInventory(new ItemStack(ItemInit.dimensionalPolymer, 1));
               this.world
                  .playSound(
                     null,
                     this.pos,
                     SoundInit.CHEMICAL_MIXING,
                     SoundCategory.PLAYERS,
                     0.7F,
                     0.7F + this.world.rand.nextFloat() * 0.6F
                  );
            }

            this.clearTank();
            this.active = false;
         } else {
            int randMonomer = this.world.rand.nextInt(5);

            while (randMonomer == this.nextMonomer) {
               randMonomer = this.world.rand.nextInt(5);
            }

            this.nextMonomer = randMonomer;
            this.messageMonomer(playerIn);
            this.world
               .playSound(
                  null,
                  this.pos,
                  SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM,
                  SoundCategory.PLAYERS,
                  1.0F,
                  0.7F + this.world.rand.nextFloat() * 0.6F
               );
         }
      }
   }

   private void messageMonomer(EntityPlayer player) {
      TextFmt fmt = TextFmt.Dark_Purple;
      String monomer;
      switch (this.nextMonomer) {
         case 0:
            monomer = "Purple";
            fmt = TextFmt.Dark_Purple;
            break;
         case 1:
            monomer = "Blue";
            fmt = TextFmt.Dark_Blue;
            break;
         case 2:
            monomer = "Red";
            fmt = TextFmt.Dark_Red;
            break;
         case 3:
            monomer = "Yellow";
            fmt = TextFmt.Yellow;
            break;
         case 4:
            monomer = "Green";
            fmt = TextFmt.Green;
            break;
         default:
            monomer = "Purple";
            fmt = TextFmt.Dark_Purple;
      }

      player.sendMessage(new TextComponentString(String.format(fmt + "%s monomer is needed next", monomer)));
   }

   private void clearTank() {
      AxisAlignedBB tank = this.getTank();
      int xMin = (int)tank.minX;
      int xMax = (int)tank.maxX;
      int zMin = (int)tank.minZ;
      int zMax = (int)tank.maxZ;
      int yMin = (int)tank.minY;
      int yMax = (int)tank.maxY;

      for (BlockPos pos : BlockPos.getAllInBox(xMin, yMin, zMin, xMax, yMax, zMax)) {
         this.world.setBlockToAir(pos);
      }
   }
}
