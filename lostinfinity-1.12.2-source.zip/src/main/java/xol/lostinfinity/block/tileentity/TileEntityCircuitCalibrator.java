package xol.lostinfinity.block.tileentity;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ITickable;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextComponentString;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class TileEntityCircuitCalibrator extends TileEntity implements ITickable {
   private boolean game = false;
   private int cur = 0;
   private int time = 0;
   private int switchTime = 0;
   private static int timeRange = 10;
   private int baseTime = 25;
   private int score = 0;
   private EntityPlayer player = null;
   private boolean pressed = false;
   private static Random rand = new Random();
   BlockPos monPos = null;

   public void update() {
      if (!this.world.isRemote && this.game) {
         if (this.score >= 15) {
            this.game = false;
            if (this.player != null) {
               this.player.addItemStackToInventory(new ItemStack(ItemInit.biosyncedClock));
               this.player.sendMessage(new TextComponentString(TextFmt.Green + "You have managed to fully calibrate the circuit!"));
               if (this.monPos != null) {
                  this.world.setBlockState(this.monPos, BlockInit.circuitMonitor.getStateFromMeta(0));
               }
            }
         } else if (this.score < 0) {
            this.game = false;
            if (this.player != null) {
               this.player.sendMessage(new TextComponentString(TextFmt.Dark_Red + "You have failed to calibrate the circuit."));
            }
         } else if (this.time >= this.switchTime) {
            this.time = 0;
            if (this.baseTime > 12) {
               this.baseTime -= 3;
            }

            this.switchTime = rand.nextInt(timeRange) + this.baseTime;
            if (this.monPos != null) {
               int meta = 0;

               try {
                  meta = BlockInit.circuitMonitor.getMetaFromState(this.world.getBlockState(this.monPos));
               } catch (Exception var3) {
                  meta = 0;
               }

               int newMeta = 0;
               switch (meta) {
                  case 0:
                     newMeta = rand.nextBoolean() ? 1 : 2;
                     break;
                  case 1:
                     newMeta = 0;
                     if (this.pressed) {
                        this.score++;
                        this.world
                           .playSound(null, this.pos, SoundInit.MINIGAME_SCORE, SoundCategory.BLOCKS, 1.5F, 0.8F + rand.nextFloat() * 0.4F);
                        this.pressed = false;
                     } else {
                        this.score -= 3;
                        this.world
                           .playSound(null, this.pos, SoundInit.GAME_BUZZER, SoundCategory.BLOCKS, 1.5F, 0.8F + rand.nextFloat() * 0.4F);
                     }

                     if (this.player != null) {
                        this.player.sendMessage(new TextComponentString(TextFmt.Green + "Score: " + this.score));
                     }
                     break;
                  case 2:
                     newMeta = 0;
                     if (this.pressed) {
                        this.score -= 3;
                        this.world
                           .playSound(null, this.pos, SoundInit.GAME_BUZZER, SoundCategory.BLOCKS, 1.5F, 0.8F + rand.nextFloat() * 0.4F);
                        if (this.player != null) {
                           this.player.sendMessage(new TextComponentString(TextFmt.Green + "Score: " + this.score));
                        }

                        this.pressed = false;
                     }
               }

               this.world.setBlockState(this.monPos, BlockInit.circuitMonitor.getStateFromMeta(newMeta));
               if (newMeta != 0) {
                  this.world
                     .playSound(null, this.pos, SoundInit.BLOCK_DING, SoundCategory.BLOCKS, 1.5F, 0.8F + rand.nextFloat() * 0.4F);
               }
            }
         } else {
            this.time++;
         }
      }
   }

   public void startGame() {
      this.pressed = false;
      this.game = true;
      this.cur = 0;
      this.time = 0;
      this.baseTime = 32;
      this.score = 0;
      this.switchTime = rand.nextInt(timeRange) + this.baseTime;
      int radius = 7;
      Vec3i offset = new Vec3i(0, 0, 0);

      for (int i = -radius; i <= radius; i++) {
         for (int k = -radius; k <= radius; k++) {
            BlockPos check = this.getPos().add(offset).add(i, 0, k);
            IBlockState state = this.world.getBlockState(check);
            if (state.getBlock() == BlockInit.circuitMonitor) {
               this.monPos = check;
               this.world.setBlockState(this.monPos, BlockInit.circuitMonitor.getStateFromMeta(0));
               return;
            }
         }
      }
   }

   public void press(int meta, BlockPos pos, EntityPlayer playerIn) {
      this.monPos = pos;
      this.player = playerIn;
      if (meta == 2 || meta == 1) {
         this.pressed = true;
         this.time = this.switchTime;
      }
   }
}
