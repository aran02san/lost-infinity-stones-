package xol.lostinfinity.block.activator;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.misc.BlockLaunchCoordinator;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;

public class BlockLaunchCore extends Block {
   public BlockLaunchCore(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && !worldIn.isRemote) {
         if (this.iteratePads(pos, worldIn, false) != 24) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Launch pad missing!"));
            return true;
         }

         boolean correct = true;

         for (int i = 0; i < 4; i++) {
            if (correct) {
               int running_total = 0;

               for (int j = 0; j < 5; j++) {
                  BlockPos check_pos;
                  if (i < 2) {
                     check_pos = pos.add(-2 + j, 0, i % 2 == 0 ? 3 : -3);
                  } else {
                     check_pos = pos.add(i % 2 == 0 ? 3 : -3, 0, -2 + j);
                  }

                  Block block_at_pos = worldIn.getBlockState(check_pos).getBlock();
                  if (block_at_pos instanceof BlockLaunchCoordinator) {
                     BlockLaunchCoordinator coordinator = (BlockLaunchCoordinator)block_at_pos;
                     running_total += coordinator.getColor() * coordinator.getShape();
                  } else {
                     correct = false;
                     playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Coordinator missing!"));
                  }
               }

               int goal = 22 + 5 * i;
               if (running_total != goal) {
                  correct = false;
                  playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Row did not equal goal of:  " + goal + ". Outcome was: " + running_total));
               }
            }
         }

         if (correct) {
            this.iteratePads(pos, worldIn, true);
            worldIn.playSound(null, pos, SoundInit.SUPERMUTATION, SoundCategory.MASTER, 1.0F, 1.0F);
         }
      }

      return true;
   }

   public int iteratePads(BlockPos pos, World worldIn, boolean light) {
      int light_total = 0;

      for (int i = -2; i < 3; i++) {
         for (int j = -2; j < 3; j++) {
            if (j != 0 || i != 0) {
               BlockPos check_pos = pos.add(i, 0, j);
               if (light) {
                  worldIn.setBlockState(check_pos, BlockInit.launchPad.getDefaultState());
               } else {
                  Block block_check = worldIn.getBlockState(check_pos).getBlock();
                  if (block_check.equals(BlockInit.launchPad) || block_check.equals(BlockInit.launchPadUnpowered)) {
                     light_total++;
                  }
               }
            }
         }
      }

      return light_total;
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Gold + "Needs launch coordinators with the following values:");
      tooltip.add(TextFmt.Aqua + "South: 22");
      tooltip.add(TextFmt.Light_Purple + "North: 27");
      tooltip.add(TextFmt.Aqua + "East: 32");
      tooltip.add(TextFmt.Light_Purple + "West: 37");
   }
}
