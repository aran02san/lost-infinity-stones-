package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityPowerConduit;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockPowerConduit extends BlockBasic implements ITileEntityProvider {
   private static final Vec3i offset = new Vec3i(0, -2, 0);

   public BlockPowerConduit(String name) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.blankOpticalDisc);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote) {
               this.reset(worldIn, pos, state, false);
            }

            playerIn.getHeldItem(hand).shrink(1);
         } else if (!worldIn.isRemote) {
            BlockPos ref = pos.add(offset);
            Vec3i dir = findTileDir(worldIn, ref);
            Vec3i upDir = new Vec3i(0, 0, 1);
            Vec3i leftDir = new Vec3i(1, 0, 0);
            if (dir.getX() < 0) {
               if (dir.getZ() < 0) {
                  upDir = new Vec3i(0, 0, -1);
                  leftDir = new Vec3i(-1, 0, 0);
               } else {
                  upDir = new Vec3i(-1, 0, 0);
                  leftDir = new Vec3i(0, 0, 1);
               }
            } else if (dir.getZ() < 0) {
               upDir = new Vec3i(1, 0, 0);
               leftDir = new Vec3i(0, 0, -1);
            }

            ref = ref.add(dir);
            int upCount = 0;
            BlockPos temp = ref;

            while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.powerNodule)) {
               temp = ref.add(upDir.getX() * ++upCount, 0, upDir.getZ() * upCount);
            }

            int leftCount = 0;
            temp = ref;

            while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.powerNodule)) {
               temp = ref.add(leftDir.getX() * ++leftCount, 0, leftDir.getZ() * leftCount);
            }

            boolean reachedEnd = false;
            BlockPos lastRow = ref.add(upDir.getX() * (upCount - 1), 0, upDir.getZ() * (upCount - 1));

            for (int i = 0; i < leftCount; i++) {
               BlockPos check = lastRow.add(leftDir.getX() * i, 0, leftDir.getZ() * i);
               if (BlockInit.powerNodule.getMetaFromState(worldIn.getBlockState(check)) == 3) {
                  reachedEnd = true;
                  break;
               }
            }

            if (reachedEnd) {
               EntityItem item = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.powerControlDisc, 1)
               );
               item.motionX = 0.0;
               item.motionY = 0.0;
               item.motionZ = 0.0;
               worldIn.spawnEntity(item);
               this.reset(worldIn, pos, state, true);
            }
         }
      }

      return true;
   }

   private void reset(World worldIn, BlockPos pos, IBlockState state, boolean end) {
      BlockPos ref = pos.add(offset);
      Vec3i dir = findTileDir(worldIn, ref);
      Vec3i upDir = new Vec3i(0, 0, 1);
      Vec3i leftDir = new Vec3i(1, 0, 0);
      if (dir.getX() < 0) {
         if (dir.getZ() < 0) {
            upDir = new Vec3i(0, 0, -1);
            leftDir = new Vec3i(-1, 0, 0);
         } else {
            upDir = new Vec3i(-1, 0, 0);
            leftDir = new Vec3i(0, 0, 1);
         }
      } else if (dir.getZ() < 0) {
         upDir = new Vec3i(1, 0, 0);
         leftDir = new Vec3i(0, 0, -1);
      }

      ref = ref.add(dir);
      int upCount = 11;
      int leftCount = 11;
      ArrayList<BlockPos> tiles = new ArrayList<>();
      boolean foundAllTiles = true;

      for (int i = 0; i < upCount; i++) {
         for (int j = 0; j < leftCount; j++) {
            BlockPos tile = ref.add(
               upDir.getX() * i + leftDir.getX() * j, 0, upDir.getZ() * i + leftDir.getZ() * j
            );
            worldIn.setBlockState(tile, BlockInit.powerNodule.getStateFromMeta(0));
            tiles.add(tile);
         }
      }

      if (foundAllTiles && worldIn.getBlockState(pos).getBlock() instanceof BlockPowerConduit) {
         TileEntity tileEntity = worldIn.getTileEntity(pos);
         if (tileEntity != null && tileEntity instanceof TileEntityPowerConduit) {
            TileEntityPowerConduit TE = (TileEntityPowerConduit)tileEntity;
            TE.setDirs(upDir, leftDir);
            TE.setTiles(tiles);
            TE.reset(upCount, leftCount);
            if (end) {
               TE.endGame();
            }
         }
      }
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(-1, 0, -1));
      dirs.add(new Vec3i(1, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.powerNodule)) {
            return dir;
         }
      }

      return null;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public boolean hasTileEntity() {
      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityPowerConduit();
   }
}
