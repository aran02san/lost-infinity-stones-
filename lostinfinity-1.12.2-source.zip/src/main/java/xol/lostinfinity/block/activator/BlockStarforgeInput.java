package xol.lostinfinity.block.activator;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockStarforgeInput extends BlockBasic {
   public BlockStarforgeInput(String name) {
      super(name, Material.ROCK);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         int xpos = 13;
         int freeX = 0;
         boolean freespot = false;

         for (int var16 = 13; var16 <= 15; var16++) {
            BlockPos checkPos = new BlockPos(pos.add(var16, 9, -5));
            IBlockState checkState = worldIn.getBlockState(checkPos);
            if (checkState.getBlock().equals(Blocks.FLOWING_LAVA) || checkState.getBlock().equals(Blocks.LAVA)) {
               freespot = true;
               freeX = var16;
            }
         }

         if (freespot) {
            Item resultFromHeld = this.returnItem(playerIn.getHeldItem(hand).getItem());
            if (resultFromHeld != null) {
               worldIn.playSound(null, pos, SoundEvents.BLOCK_FURNACE_FIRE_CRACKLE, SoundCategory.MASTER, 2.0F, worldIn.rand.nextFloat() + 0.5F);
               if (!worldIn.isRemote) {
                  BlockPos dropPos = new BlockPos(pos.add(6.5, 4.0, -6.0));
                  EntityItem dropIngot = new EntityItem(
                     worldIn, dropPos.getX(), dropPos.getY(), dropPos.getZ(), new ItemStack(resultFromHeld)
                  );
                  dropIngot.motionX = 0.0;
                  dropIngot.motionY = 0.0;
                  dropIngot.motionZ = 0.0;
                  worldIn.spawnEntity(dropIngot);
                  if (worldIn.rand.nextInt(8) == 0) {
                     worldIn.setBlockState(pos.add(freeX, 9, -5), BlockInit.slagDeposit.getDefaultState());
                  }
               }

               playerIn.getHeldItem(hand).shrink(1);
            }
         } else if (!worldIn.isRemote) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Red + "The forge is clogged. Clear it out with carbonic acid."));
         }
      }

      return true;
   }

   private Item returnItem(Item held) {
      if (held.equals(ItemInit.emberium)) {
         return ItemInit.emberiumIngot;
      } else if (held.equals(ItemInit.noxerium)) {
         return ItemInit.noxeriumIngot;
      } else if (held.equals(ItemInit.incadium)) {
         return ItemInit.incadiumIngot;
      } else if (held.equals(ItemInit.hextorium)) {
         return ItemInit.hextoriumIngot;
      } else if (held.equals(ItemInit.kylaxium)) {
         return ItemInit.kylaxiumIngot;
      } else if (held.equals(ItemInit.vellorium)) {
         return ItemInit.velloriumIngot;
      } else if (held.equals(ItemInit.xerovium)) {
         return ItemInit.xeroviumIngot;
      } else if (held.equals(ItemInit.phytrosium)) {
         return ItemInit.phytrosiumIngot;
      } else if (held.equals(ItemInit.detherium)) {
         return ItemInit.detheriumIngot;
      } else if (held.equals(ItemInit.olysium)) {
         return ItemInit.olysiumIngot;
      } else if (held.equals(ItemInit.astrallium)) {
         return ItemInit.astralliumIngot;
      } else {
         return held.equals(ItemInit.crystonium) ? ItemInit.crystoniumIngot : null;
      }
   }
}
