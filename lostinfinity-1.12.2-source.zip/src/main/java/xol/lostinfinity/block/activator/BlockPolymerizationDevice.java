package xol.lostinfinity.block.activator;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityPolymerizationDevice;
import xol.lostinfinity.init.ItemInit;

public class BlockPolymerizationDevice extends BlockBasic implements ITileEntityProvider {
   public BlockPolymerizationDevice(String name) {
      super(name);
   }

   public boolean hasTileEntity() {
      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityPolymerizationDevice();
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      TileEntity tileEntity = worldIn.getTileEntity(pos);
      if (tileEntity != null && tileEntity instanceof TileEntityPolymerizationDevice) {
         TileEntityPolymerizationDevice deviceEntity = (TileEntityPolymerizationDevice)tileEntity;
         ItemStack stack = playerIn.getHeldItem(hand);
         if (stack.getItem() == ItemInit.rainfallCollectorFull && !deviceEntity.isActivated()) {
            stack.shrink(1);
         }

         if (!worldIn.isRemote) {
            deviceEntity.activate(playerIn, hand);
         }
      }

      return true;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }
}
