package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityMelodicSequencer;
import xol.lostinfinity.init.BlockInit;

public class BlockMelodyButton extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 4);

   public BlockMelodyButton(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote && !playerIn.isSneaking()) {
         boolean played = false;
         int radius = 7;
         Vec3i offset = new Vec3i(0, 2, 0);

         for (int i = -radius; i <= radius; i++) {
            for (int k = -radius; k <= radius; k++) {
               BlockPos check = new BlockPos(pos.add(offset).add(i, 0, k));
               IBlockState checkState = worldIn.getBlockState(check);
               Block checkBlock = checkState.getBlock();
               if (checkBlock == BlockInit.melodicSequencer) {
                  TileEntity tileEntity = worldIn.getTileEntity(check);
                  if (tileEntity != null && tileEntity instanceof TileEntityMelodicSequencer) {
                     TileEntityMelodicSequencer sequencer = (TileEntityMelodicSequencer)tileEntity;
                     int meta = this.getMetaFromState(state);
                     played = sequencer.playNote(meta, pos, playerIn);
                  }
               }
            }
         }

         if (!played) {
            int meta = this.getMetaFromState(state);
            ArrayList<SoundEvent> notes = TileEntityMelodicSequencer.getNotes();
            if (notes.size() > meta) {
               worldIn.playSound(null, pos, notes.get(meta), SoundCategory.BLOCKS, 0.8F, 1.0F);
            }
         }
      }

      return true;
   }
}
