package xol.lostinfinity.block.activator;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.monster.EntityEvoker;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockDeviationField extends BlockBasic {
   public BlockDeviationField(String name) {
      super(name, Material.ROCK);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         ItemStack heldstack = playerIn.getHeldItem(hand);
         if (heldstack.getItem() == Items.NETHER_STAR) {
            if (!worldIn.isRemote) {
               for (EntityLiving mob_die : worldIn.getEntitiesWithinAABB(EntityLiving.class, this.getArenaAABB())) {
                  mob_die.setDead();
               }

               EntityWither wither = new EntityWither(worldIn);
               wither.setPosition(985.5, 63.0, 890.0);
               worldIn.spawnEntity(wither);
               playerIn.setPositionAndUpdate(985.5, 62.0, 906.0);
               playerIn.sendMessage(
                  new TextComponentString(
                     TextFmt.getFormatting(TextFmt.Italic, TextFmt.Aqua)
                        + "Looming Voice: A wither has been released. Deviate it, and show me what you are made of "
                        + playerIn.getName()
                  )
               );
            }

            heldstack.shrink(1);
         } else if (heldstack.getItem().equals(ItemInit.arenaCard)) {
            playerIn.playSound(SoundInit.ARENA_TELEPORT, 3.0F, 1.0F);
            heldstack.shrink(1);
            if (!worldIn.isRemote) {
               playerIn.setPositionAndUpdate(985.5, 62.0, 927.0);
            }
         } else if (heldstack.getItem().equals(Items.TOTEM_OF_UNDYING)) {
            if (!worldIn.isRemote) {
               for (EntityLiving mob_die : worldIn.getEntitiesWithinAABB(EntityLiving.class, this.getArenaAABB())) {
                  mob_die.setDead();
               }

               EntityEvoker evoker = new EntityEvoker(worldIn);
               evoker.setPosition(985.5, 63.0, 890.0);
               worldIn.spawnEntity(evoker);
               playerIn.setPositionAndUpdate(985.5, 62.0, 906.0);
               playerIn.sendMessage(
                  new TextComponentString(
                     TextFmt.getFormatting(TextFmt.Italic, TextFmt.Aqua)
                        + "Looming Voice: An evoker has been released. Deviate it, and show me what you are made of "
                        + playerIn.getName()
                  )
               );
            }

            heldstack.shrink(1);
         }
      }

      return true;
   }

   private AxisAlignedBB getArenaAABB() {
      return new AxisAlignedBB(new BlockPos(958.0, 60.0, 877.0), new BlockPos(1012.0, 82.0, 924.0));
   }
}
