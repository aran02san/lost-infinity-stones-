package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.dimension.data.MazeMap;
import xol.lostinfinity.dimension.data.MazeNode;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockTimelineStabilizerConsole extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 1);

   public BlockTimelineStabilizerConsole(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote && !playerIn.isSneaking()) {
         int meta = this.getMetaFromState(state);
         ItemStack stack = playerIn.getHeldItem(hand);
         if (stack.getItem().equals(ItemInit.timelineMonitor)) {
            if (!stack.hasTagCompound()) {
               stack.setTagCompound(new NBTTagCompound());
            }

            NBTTagCompound compound = stack.getTagCompound();
            switch (meta) {
               case 0:
                  if (compound.hasKey("1x") && compound.hasKey("2x")) {
                     this.generateMaze(stack, worldIn);
                     worldIn.playSound(null, playerIn.getPosition(), SoundInit.MANUFACTURE_MACHINE, SoundCategory.BLOCKS, 1.5F, 1.0F);
                  } else {
                     compound.setInteger("1x", pos.getX());
                     compound.setInteger("1y", pos.getY());
                     compound.setInteger("1z", pos.getZ());
                     playerIn.sendMessage(new TextComponentString("Marked 1st Console"));
                  }
                  break;
               case 1:
                  compound.setInteger("2x", pos.getX());
                  compound.setInteger("2y", pos.getY());
                  compound.setInteger("2z", pos.getZ());
                  playerIn.sendMessage(new TextComponentString("Marked 2nd Console"));
            }
         }
      } else if (!worldIn.isRemote) {
         int meta = this.getMetaFromState(state);
         if (meta < 1) {
            worldIn.setBlockState(pos, this.getStateFromMeta(meta + 1));
         } else {
            worldIn.setBlockState(pos, this.getStateFromMeta(0));
         }
      }

      return true;
   }

   public static Vec3i getRotatedVec(Vec3i vec, double rad) {
      return new Vec3i(
         Math.round(vec.getX() * Math.cos(rad)) + Math.round(vec.getZ() * Math.sin(rad)),
         vec.getY(),
         Math.round(-vec.getX() * Math.sin(rad)) + Math.round(vec.getZ() * Math.cos(rad))
      );
   }

   private void generateMaze(ItemStack stack, World worldIn) {
      int width = 29;
      int height = 16;
      MazeMap map1 = new MazeMap(width, height);
      MazeMap map2 = new MazeMap(width, height);
      NBTTagCompound compound = stack.getTagCompound();
      ArrayList<BlockPos> pillars = new ArrayList<>();
      double rad = 0.0;
      Vec3i offset = new Vec3i(0, 3, 0);
      pillars.add(
         new BlockPos(
            compound.getInteger("1x") + offset.getX(),
            compound.getInteger("1y") + offset.getY(),
            compound.getInteger("1z") + offset.getZ()
         )
      );
      pillars.add(
         new BlockPos(
            compound.getInteger("2x") + offset.getX(),
            compound.getInteger("2y") + offset.getY(),
            compound.getInteger("2z") + offset.getZ()
         )
      );
      World overworld = worldIn.getMinecraftServer().getWorld(0);

      for (int i = 0; i < 2; i++) {
         for (int h = 0; h < 4; h++) {
            for (int j = 0; j < width / 4; j++) {
               for (int k = 0; k < height; k++) {
                  BlockPos ref = pillars.get(i);
                  int xDir = 1;
                  int zDir = 1;
                  if (worldIn.getBlockState(ref.add(-1, 0, 0)).getBlock().equals(BlockInit.labyrinthGlassBlue)) {
                     xDir = -1;
                  }

                  if (worldIn.getBlockState(ref.add(0, 0, -1)).getBlock().equals(BlockInit.labyrinthGlassBlue)) {
                     zDir = -1;
                  }

                  if (xDir == 1) {
                     if (zDir == 1) {
                        rad = 0.0;
                     } else {
                        rad = Math.PI / 2;
                     }
                  } else if (zDir == 1) {
                     rad = Math.PI * 3.0 / 2.0;
                  } else {
                     rad = Math.PI;
                  }

                  ref = ref.add(xDir * 1, -4, zDir * 1);
                  Vec3i front = new Vec3i(0, 0, -1);
                  front = getRotatedVec(front, rad);
                  Vec3i dir = new Vec3i(1, 0, 0);
                  Vec3i refOffset = new Vec3i(0, 0, 0);
                  switch (h) {
                     case 0:
                     default:
                        break;
                     case 1:
                        refOffset = new Vec3i(width / 4, 0, 0);
                        dir = new Vec3i(0, 0, 1);
                        break;
                     case 2:
                        refOffset = new Vec3i(width / 4, 0, width / 4);
                        dir = new Vec3i(-1, 0, 0);
                        break;
                     case 3:
                        refOffset = new Vec3i(0, 0, width / 4);
                        dir = new Vec3i(0, 0, -1);
                  }

                  refOffset = getRotatedVec(refOffset, rad);
                  ref = ref.add(refOffset);
                  dir = getRotatedVec(dir, rad);
                  ref = ref.add(dir.getX() * j, k, dir.getZ() * j);
                  MazeNode mazeNode;
                  if (i == 0) {
                     mazeNode = map1.getNodeAtLocation(j + h * (width / 4), k);
                  } else {
                     mazeNode = map2.getNodeAtLocation(j + h * (width / 4), k);
                  }

                  worldIn.setBlockState(ref, BlockInit.trackWall.getDefaultState());
                  if ((mazeNode.getType().equals("path") || mazeNode.getType().equals("trigger")) && mazeNode.isVisited()) {
                     worldIn.setBlockToAir(ref);
                  }

                  if (i == 0 && j == 0 && h == 0 && k == 0) {
                     worldIn.setBlockState(ref, BlockInit.timelineStabilizerCapsule.getDefaultState());
                  } else if (h == 0 && j == 0 && k == height - 1) {
                     worldIn.setBlockState(ref, BlockInit.timelineStabilizerGoal.getDefaultState());
                  }
               }
            }
         }
      }
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }
}
