package xol.lostinfinity.block.activator;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityPowerCollider;
import xol.lostinfinity.init.ItemInit;

public class BlockPowerCollider extends BlockBasic implements ITileEntityProvider {
   public BlockPowerCollider(String name) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.chargeCell);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && this.validInput(playerIn.getHeldItem(hand))) {
         if (!worldIn.isRemote) {
            this.reset(worldIn, pos, state);
         }

         playerIn.getHeldItem(hand).shrink(1);
      }

      return true;
   }

   private void reset(World worldIn, BlockPos pos, IBlockState state) {
      if (worldIn.getBlockState(pos).getBlock() instanceof BlockPowerCollider) {
         TileEntity tileEntity = worldIn.getTileEntity(pos);
         if (tileEntity != null && tileEntity instanceof TileEntityPowerCollider) {
            TileEntityPowerCollider TE = (TileEntityPowerCollider)tileEntity;
            TE.reset();
         }
      }
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public boolean hasTileEntity() {
      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityPowerCollider();
   }
}
