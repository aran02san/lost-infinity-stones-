package xol.lostinfinity.block.activator;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerBase;
import xol.lostinfinity.util.coordinates.ContestCoordinates;

public class BlockDungeonSelector extends BlockBasic {
   public BlockDungeonSelector(String name) {
      super(name, Material.ROCK);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         if (worldIn.provider.getDimensionType() == DimensionInit.grandmasterOutpost) {
            AxisAlignedBB aabb = this.gameByPos(pos);
            if (aabb != null) {
               for (EntityControllerBase search_cont : worldIn.getEntitiesWithinAABB(EntityControllerBase.class, aabb)) {
                  search_cont.registerTouch(playerIn);
               }
            }
         }

         worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }

   private AxisAlignedBB gameByPos(BlockPos pos) {
      AxisAlignedBB game = null;
      if (this.posInAABB(ContestCoordinates.huntersArenaAABB(), pos)) {
         game = ContestCoordinates.huntersArenaAABB();
      } else if (this.posInAABB(ContestCoordinates.redlightArenaAABB(), pos)) {
         game = ContestCoordinates.redlightArenaAABB();
      } else if (this.posInAABB(ContestCoordinates.lightBridgeArenaAABB(), pos)) {
         game = ContestCoordinates.lightBridgeArenaAABB();
      } else if (this.posInAABB(ContestCoordinates.parkourArenaAABB(), pos)) {
         game = ContestCoordinates.parkourArenaAABB();
      }

      return game;
   }

   private boolean posInAABB(AxisAlignedBB aabb, BlockPos pos) {
      return pos.getX() >= aabb.minX
         && pos.getX() <= aabb.maxX
         && pos.getY() >= aabb.minY
         && pos.getY() <= aabb.maxY
         && pos.getZ() >= aabb.minZ
         && pos.getZ() <= aabb.maxZ;
   }
}
