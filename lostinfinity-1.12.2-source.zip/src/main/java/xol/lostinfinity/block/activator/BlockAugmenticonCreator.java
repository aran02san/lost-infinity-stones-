package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagInt;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.item.misc.ItemAugmentSlide;
import xol.lostinfinity.item.misc.ItemAugmenticonBox;
import xol.lostinfinity.mob.entity.starforge.EntityAugmenticon;

public class BlockAugmenticonCreator extends Block {
   public BlockAugmenticonCreator(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         ItemStack stack = playerIn.getHeldItem(hand);
         if (stack.isEmpty()) {
            if (!worldIn.isRemote) {
               playerIn.setPositionAndUpdate(1553.0, 11.0, -584.0);
               worldIn.playSound(null, pos, SoundInit.ARENA_TELEPORT, SoundCategory.MASTER, 1.0F, 1.0F);
            }
         } else if (stack.getItem() instanceof ItemAugmenticonBox) {
            if (!ItemAugmenticonBox.getAugmentList(stack).hasNoTags()) {
               if (!worldIn.isRemote) {
                  NBTTagList list = ItemAugmenticonBox.getAugmentList(stack);
                  playerIn.setPositionAndUpdate(1554.0, 12.0, -556.0);
                  EntityAugmenticon augmenticon = new EntityAugmenticon(worldIn);
                  augmenticon.setPosition(1576.0, 13.0, -551.0);

                  for (NBTBase tag : list) {
                     NBTTagInt strTag = (NBTTagInt)tag;
                     augmenticon.addAbility(ItemAugmentSlide.SlideType.values()[strTag.getInt()].registryName);
                  }

                  worldIn.spawnEntity(augmenticon);
               }

               playerIn.setHeldItem(hand, ItemStack.EMPTY);
               worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
            } else if (!worldIn.isRemote) {
               playerIn.sendMessage(new TextComponentString(TextFmt.Red + "The augmenticon must have at least one programmed ability."));
            }
         }
      }

      return true;
   }
}
