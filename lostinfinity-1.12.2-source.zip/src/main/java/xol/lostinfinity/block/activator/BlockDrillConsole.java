package xol.lostinfinity.block.activator;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityDrillConsole;
import xol.lostinfinity.init.ItemInit;

public class BlockDrillConsole extends BlockBasic implements ITileEntityProvider {
   public BlockDrillConsole(String name) {
      super(name);
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityDrillConsole();
   }

   public boolean hasTileEntity() {
      return true;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      if (stack.getItem() == ItemInit.externalCloviniteBattery) {
         TileEntity te = worldIn.getTileEntity(pos);
         if (te != null && te instanceof TileEntityDrillConsole) {
            ((TileEntityDrillConsole)te).activateDrill(playerIn);
            stack.shrink(1);
         }
      }

      return true;
   }
}
