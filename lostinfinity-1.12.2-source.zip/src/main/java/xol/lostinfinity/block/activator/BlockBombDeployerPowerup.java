package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.activate.ItemBombDeployer;

public class BlockBombDeployerPowerup extends BlockBasicLight {
   private int power_type = 0;

   public BlockBombDeployerPowerup(String name, int type) {
      super(name);
      this.setLightLevel(1.0F);
      this.power_type = type;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      if (held.getItem() instanceof ItemBombDeployer) {
         if (!held.hasTagCompound()) {
            held.setTagCompound(new NBTTagCompound());
         }

         switch (this.power_type) {
            case 0:
               int speedVal = held.getTagCompound().getInteger("BombSpeed");
               if (++speedVal > 5) {
                  speedVal = 5;
                  if (!worldIn.isRemote) {
                     playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Bomb Deployer at max speed."));
                  }
               }

               held.getTagCompound().setInteger("BombSpeed", speedVal);
               break;
            case 1:
               int sizeVal = held.getTagCompound().getInteger("BombSize");
               if (++sizeVal > 9) {
                  sizeVal = 9;
                  if (!worldIn.isRemote) {
                     playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Bomb Deployer at max size."));
                  }
               }

               held.getTagCompound().setInteger("BombSize", sizeVal);
               break;
            case 2:
               int cdVal = held.getTagCompound().getInteger("BombCooldown");
               if (++cdVal > 5) {
                  cdVal = 5;
                  if (!worldIn.isRemote) {
                     playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Bomb Deployer at max cooldown."));
                  }
               }

               held.getTagCompound().setInteger("BombCooldown", cdVal);
               break;
            case 3:
               if (!worldIn.isRemote) {
                  playerIn.addPotionEffect(new PotionEffect(PotionInit.PROTECTED, 400));
                  playerIn.sendMessage(new TextComponentString(TextFmt.Red + "You temporarily are immune to bombs."));
               }
         }

         if (!worldIn.isRemote) {
            worldIn.setBlockState(pos, BlockInit.bombersPowerupClosed.getDefaultState());
            worldIn.playSound(null, pos, SoundInit.MINIGAME_POWERUP, SoundCategory.PLAYERS, 1.0F, 0.8F + worldIn.rand.nextFloat() * 0.4F);
         }
      }

      return true;
   }
}
