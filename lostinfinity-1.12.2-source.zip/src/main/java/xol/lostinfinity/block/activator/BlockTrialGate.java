package xol.lostinfinity.block.activator;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.common.packets.serverbound.PacketTextTitle;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.activate.ItemTrial;
import xol.lostinfinity.mob.entity.deviant.titan.EntityTrialObserver;

public class BlockTrialGate extends BlockBasic {
   public BlockTrialGate(String name) {
      super(name, Material.ROCK);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         ItemStack heldstack = playerIn.getHeldItem(hand);
         if (heldstack.getItem() instanceof ItemTrial) {
            if (worldIn.isRemote) {
               lostinfinity.instance
                  .packetHandler
                  .sendTitleToPlayer(
                     new PacketTextTitle(true, false, 80, 30, 30, TextFmt.Dark_Aqua + "Trial of the " + this.getCreatureName(heldstack.getItem())),
                     playerIn
                  );
            } else {
               for (EntityLiving mob_die : worldIn.getEntitiesWithinAABB(EntityLiving.class, this.getArenaAABB())) {
                  mob_die.setDead();
               }

               EntityTrialObserver trialob = new EntityTrialObserver(worldIn);
               trialob.setPosition(522.0, 75.0, 438.0);
               trialob.setEventType(this.trialType(heldstack.getItem()));
               worldIn.spawnEntity(trialob);
               playerIn.setPositionAndUpdate(521.5, 62.0, 450.0);
            }

            heldstack.shrink(1);
         } else if (heldstack.getItem().equals(ItemInit.arenaCard)) {
            playerIn.playSound(SoundInit.ARENA_TELEPORT, 3.0F, 1.0F);
            heldstack.shrink(1);
            if (!worldIn.isRemote) {
               playerIn.setPositionAndUpdate(521.5, 62.0, 464.0);
            }
         }
      }

      return true;
   }

   private byte trialType(Item item) {
      if (item.equals(ItemInit.trialBlaze)) {
         return 0;
      } else if (item.equals(ItemInit.trialSkeleton)) {
         return 1;
      } else if (item.equals(ItemInit.trialSpider)) {
         return 2;
      } else if (item.equals(ItemInit.trialCreeper)) {
         return 3;
      } else if (item.equals(ItemInit.trialEnderman)) {
         return 4;
      } else if (item.equals(ItemInit.trialLlama)) {
         return 5;
      } else if (item.equals(ItemInit.trialMagmacube)) {
         return 6;
      } else if (item.equals(ItemInit.trialPigman)) {
         return 7;
      } else if (item.equals(ItemInit.trialStray)) {
         return 8;
      } else if (item.equals(ItemInit.trialVex)) {
         return 9;
      } else if (item.equals(ItemInit.trialZombie)) {
         return 10;
      } else {
         return (byte)(item.equals(ItemInit.trialShulker) ? 11 : 1);
      }
   }

   private String getCreatureName(Item item) {
      if (item.equals(ItemInit.trialBlaze)) {
         return "Blaze";
      } else if (item.equals(ItemInit.trialSkeleton)) {
         return "Skeleton";
      } else if (item.equals(ItemInit.trialSpider)) {
         return "Spider";
      } else if (item.equals(ItemInit.trialCreeper)) {
         return "Creeper";
      } else if (item.equals(ItemInit.trialEnderman)) {
         return "Enderman";
      } else if (item.equals(ItemInit.trialLlama)) {
         return "Llama";
      } else if (item.equals(ItemInit.trialMagmacube)) {
         return "Magma Cube";
      } else if (item.equals(ItemInit.trialPigman)) {
         return "Pigman";
      } else if (item.equals(ItemInit.trialStray)) {
         return "Stray";
      } else if (item.equals(ItemInit.trialVex)) {
         return "Vex";
      } else if (item.equals(ItemInit.trialZombie)) {
         return "Zombie";
      } else {
         return item.equals(ItemInit.trialShulker) ? "Shulker" : "Nothing";
      }
   }

   private AxisAlignedBB getArenaAABB() {
      return new AxisAlignedBB(new BlockPos(-493.0, 60.0, 407.0), new BlockPos(548.0, 85.0, 460.0));
   }
}
