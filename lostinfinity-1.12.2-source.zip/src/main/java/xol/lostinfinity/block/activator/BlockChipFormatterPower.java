package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.dimension.data.SlideMap;
import xol.lostinfinity.dimension.data.SlideNode;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockChipFormatterPower extends BlockBasic {
   public BlockChipFormatterPower(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         BlockPos tablePos = GalaxyCoordinates.ChipTable();
         SlideMap puzzle = new SlideMap(5, 5, 40, 17);

         for (int z = 0; z < 5; z++) {
            for (int x = 0; x < 5; x++) {
               BlockPos addPos = tablePos.add(x, 0, z);
               SlideNode node = puzzle.getNodeAtLocation(z, x);
               if (node.isEmpty()) {
                  worldIn.setBlockState(addPos, BlockAlienSlide.getSlideByNum(17).getDefaultState());
               } else {
                  worldIn.setBlockState(addPos, BlockAlienSlide.getSlideByNum(node.getTileNum()).getDefaultState());
               }
            }
         }

         worldIn.playSound(null, pos, SoundEvents.BLOCK_COMPARATOR_CLICK, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }
}
