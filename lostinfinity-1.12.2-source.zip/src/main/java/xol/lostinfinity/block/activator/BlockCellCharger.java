package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockCellCharger extends BlockBasic {
   public BlockCellCharger(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      if (stack.getItem() == ItemInit.unpoweredCell) {
         ArrayList<BlockPos> corePositions = GalaxyCoordinates.getCorePositions();
         boolean foundAll = true;

         for (BlockPos corePos : corePositions) {
            if (worldIn.getBlockState(corePos) != BlockInit.blightedCore.getStateFromMeta(1)) {
               foundAll = false;
               break;
            }
         }

         if (foundAll) {
            if (!worldIn.isRemote) {
               for (BlockPos corePosx : corePositions) {
                  worldIn.setBlockState(corePosx, BlockInit.blightedCore.getStateFromMeta(0));
               }

               playerIn.addItemStackToInventory(new ItemStack(ItemInit.eternoCell));
               worldIn.playSound(null, pos, SoundInit.ELECTRIC_WOOSH, SoundCategory.MASTER, 1.0F, 1.0F);
            }

            stack.shrink(1);
         } else if (!worldIn.isRemote) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Red + "The power cores are not all powered."));
         }
      }

      return true;
   }
}
