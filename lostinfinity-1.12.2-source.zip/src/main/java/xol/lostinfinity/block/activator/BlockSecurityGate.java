package xol.lostinfinity.block.activator;

import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.tool.ItemSecurityPass;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockSecurityGate extends BlockBasic {
   private int securityLevel = 0;

   public BlockSecurityGate(String name, int security) {
      super(name);
      this.securityLevel = security;
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         Item heldItem = playerIn.getHeldItemMainhand().getItem();
         if (heldItem instanceof ItemSecurityPass) {
            ItemSecurityPass pass = (ItemSecurityPass)heldItem;
            int passLevel = pass.getSecurityLevel();
            if (passLevel >= this.securityLevel) {
               playerIn.addPotionEffect(new PotionEffect(PotionInit.SECURITY_CLEARANCE, 300, this.securityLevel));
               worldIn.playSound(null, pos, SoundInit.SECURITY_CLEAR, SoundCategory.MASTER, 1.0F, 1.0F);
               Map<BlockPos, String> specialGates = GalaxyCoordinates.securityWithMSG();

               for (Entry<BlockPos, String> entry : specialGates.entrySet()) {
                  if (this.posNearAABB(pos, entry.getKey())) {
                     playerIn.sendMessage(new TextComponentString(entry.getValue()));
                  }
               }
            }
         }
      }

      return true;
   }

   private boolean posNearAABB(BlockPos posGate, BlockPos check) {
      AxisAlignedBB aabb = new AxisAlignedBB(check).grow(2.0);
      Vec3d vec = new Vec3d(posGate);
      return aabb.contains(vec);
   }
}
