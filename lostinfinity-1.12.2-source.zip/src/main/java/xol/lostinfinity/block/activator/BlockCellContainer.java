package xol.lostinfinity.block.activator;

import java.util.Iterator;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.misc.EntityCellGameMerchant;

public class BlockCellContainer extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 9);

   public BlockCellContainer(String name, int i) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         int radius = 9;
         AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-radius, -radius, -radius), pos.add(radius, radius, radius));
         Iterator var12 = worldIn.getEntitiesWithinAABB(EntityCellGameMerchant.class, checkBox).iterator();
         if (var12.hasNext()) {
            EntityCellGameMerchant merch = (EntityCellGameMerchant)var12.next();
            if (playerIn.getHeldItem(hand).getItem().equals(ItemInit.powerAnalyzer)) {
               merch.readPowerLevel(pos, worldIn, playerIn);
               merch.selectCell1(pos, worldIn, playerIn);
            } else {
               merch.selectCell2(pos, worldIn, playerIn);
            }
         }
      }

      return true;
   }

   public IBlockState getStateWithAmount(int amount) {
      return this.getDefaultState().withProperty(AMOUNT, amount);
   }
}
