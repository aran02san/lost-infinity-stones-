package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxySpire;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockGalaxyRewardSelector extends Block {
   public BlockGalaxyRewardSelector(String name, float hardness) {
      this(name, hardness, 1.0F);
   }

   public BlockGalaxyRewardSelector(String name, float hardness, float lilev) {
      super(Material.ROCK);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(hardness);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(lilev);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         Block below = worldIn.getBlockState(pos.down()).getBlock();
         int game_style = -1;
         AxisAlignedBB arena_aabb = null;
         double spireHeight = 8.0;
         if (below.equals(BlockInit.astroRockBlue)) {
            game_style = 1;
            arena_aabb = GalaxyCoordinates.getBlueAABB();
         } else if (below.equals(BlockInit.astroRockGreen)) {
            game_style = 2;
            arena_aabb = GalaxyCoordinates.getGreenAABB();
         } else if (below.equals(BlockInit.astroRockPurple)) {
            game_style = 3;
            arena_aabb = GalaxyCoordinates.getPinkAABB();
         } else if (below.equals(BlockInit.astroRockYellow)) {
            game_style = 4;
            arena_aabb = GalaxyCoordinates.getYellowAABB();
         } else if (below.equals(BlockInit.astroRockLampBlue)) {
            game_style = 5;
            arena_aabb = GalaxyCoordinates.getSwordAABB();
            spireHeight = 15.0;
         } else if (below.equals(BlockInit.astroRockLampGreen)) {
            game_style = 6;
            arena_aabb = GalaxyCoordinates.getBombAABB();
            spireHeight = 15.0;
         } else if (below.equals(BlockInit.astroRockLampPurple)) {
            game_style = 7;
            arena_aabb = GalaxyCoordinates.getKnifeAABB();
            spireHeight = 15.0;
         }

         if (game_style > 0) {
            BlockPos spirePos = new BlockPos(
               (arena_aabb.maxX + arena_aabb.minX) / 2.0,
               arena_aabb.minY + spireHeight,
               (arena_aabb.maxZ + arena_aabb.minZ) / 2.0
            );
            BlockPos gameStart = new BlockPos(arena_aabb.minX + 2.0, arena_aabb.minY + 6.0, arena_aabb.minZ + 15.0);
            int playCount = 0;

            for (EntityPlayer plays : worldIn.getEntitiesWithinAABB(EntityPlayer.class, arena_aabb)) {
               playCount++;
            }

            if (playCount == 0) {
               for (EntityMob leftover : worldIn.getEntitiesWithinAABB(EntityMob.class, arena_aabb)) {
                  leftover.setDead();
               }

               this.replaceFloor(worldIn, arena_aabb, Blocks.AIR, this.getMyBarrier(game_style), game_style >= 5 ? 64 : 32);
               playerIn.setPositionAndUpdate(gameStart.getX(), gameStart.getY(), gameStart.getZ());
               EntityGalaxySpire spire = new EntityGalaxySpire(worldIn);
               spire.setPosition(spirePos.getX(), spirePos.getY(), spirePos.getZ());
               spire.setItemDrop(this.lightToItem());
               spire.setGameStyle(game_style);
               if (game_style >= 5) {
                  spire.setElite();
               }

               worldIn.spawnEntity(spire);
            } else {
               playerIn.sendMessage(new TextComponentString(TextFmt.Dark_Red + "The arena is currently in use."));
            }
         }
      }

      return true;
   }

   private void replaceFloor(World world, AxisAlignedBB box, Block repblock, Block newblock, int size) {
      for (int blx = 0; blx < size; blx++) {
         for (int blz = 0; blz < size; blz++) {
            BlockPos pos = new BlockPos(box.minX + blx, box.minY, box.minZ + blz);
            if (world.getBlockState(pos).getBlock().equals(repblock)) {
               world.setBlockState(pos, newblock.getDefaultState());
            }
         }
      }
   }

   private int lightToItem() {
      switch (this.lightValue) {
         case 6:
            return 3;
         case 9:
            return 2;
         case 12:
            return 1;
         default:
            return 0;
      }
   }

   private Block getMyBarrier(int style) {
      Block bl = BlockInit.astroBarrierBlue;
      switch (style) {
         case 2:
            bl = BlockInit.astroBarrierGreen;
            break;
         case 3:
            bl = BlockInit.astroBarrierPurple;
            break;
         case 4:
            bl = BlockInit.astroBarrierYellow;
         case 5:
         default:
            break;
         case 6:
            bl = BlockInit.astroBarrierGreen;
            break;
         case 7:
            bl = BlockInit.astroBarrierPurple;
      }

      return bl;
   }
}
