package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;
import xol.lostinfinity.util.damagesource.DeathMessage;

public class BlockMetaMaterializer extends BlockBasic {
   public BlockMetaMaterializer(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && !worldIn.isRemote) {
         BlockMetaMaterializer.MetaRecipe rec = this.getRecipe(playerIn.getHeldItem(hand));
         if (rec == null) {
            return true;
         }

         ArrayList<Item> ingots = rec.getIngots();
         ArrayList<Item> organics = rec.getOrganics();
         Item result = rec.getResult();
         if (ingots != null && organics != null && result != null) {
            AxisAlignedBB ingotBox = GalaxyCoordinates.materializerOreAABB();
            AxisAlignedBB organicsBox = GalaxyCoordinates.materializerOrganicsAABB();
            AxisAlignedBB sacrificeBox = GalaxyCoordinates.materializerSacrificeAABB();
            ArrayList<EntityItem> IngotEntities = new ArrayList<>();
            ArrayList<Item> ingotsFound = new ArrayList<>();

            for (EntityItem itemEntity : worldIn.getEntitiesWithinAABB(EntityItem.class, ingotBox)) {
               Item testItem = itemEntity.getItem().getItem();

               for (Item ingot : ingots) {
                  if (testItem.equals(ingot)) {
                     ingotsFound.add(testItem);
                     IngotEntities.add(itemEntity);
                  }
               }
            }

            for (Item toRemove : ingotsFound) {
               ingots.remove(toRemove);
            }

            ArrayList<EntityItem> OrganicEntities = new ArrayList<>();
            ArrayList<Item> organicsFound = new ArrayList<>();

            for (EntityItem itemEntity : worldIn.getEntitiesWithinAABB(EntityItem.class, organicsBox)) {
               Item testItem = itemEntity.getItem().getItem();

               for (Item organic : organics) {
                  if (testItem.equals(organic)) {
                     organicsFound.add(testItem);
                     OrganicEntities.add(itemEntity);
                  }
               }
            }

            for (Item toRemove : organicsFound) {
               organics.remove(toRemove);
            }

            int count = 0;
            ArrayList<EntityLivingBase> sacrifices = new ArrayList<>();

            for (EntityLivingBase sacrifice : worldIn.getEntitiesWithinAABB(EntityLivingBase.class, sacrificeBox)) {
               count++;
               sacrifices.add(sacrifice);
               if (sacrifice instanceof EntityPlayer) {
                  count = 3;
               }
            }

            int minNum = 99;

            for (EntityItem entity : IngotEntities) {
               ItemStack stack = entity.getItem();
               if (stack.getCount() < minNum) {
                  minNum = stack.getCount();
               }
            }

            for (EntityItem entityx : OrganicEntities) {
               ItemStack stack = entityx.getItem();
               if (stack.getCount() < minNum) {
                  minNum = stack.getCount();
               }
            }

            if (ingots.isEmpty() && organics.isEmpty() && count >= 3) {
               for (EntityItem entityxx : IngotEntities) {
                  entityxx.getItem().shrink(minNum);
               }

               for (EntityItem entityxx : OrganicEntities) {
                  entityxx.getItem().shrink(minNum);
               }

               for (EntityLivingBase entityxx : sacrifices) {
                  entityxx.setHealth(0.0F);
                  if (entityxx instanceof EntityPlayer) {
                     DeathMessage.broadcastDeathMessage(
                        entityxx.getServer(), TextFmt.Red + entityxx.getName() + " was sacrificed to the Meta Materializer."
                     );
                  }
               }

               for (int i = 0; i < 3; i++) {
                  EntityItem resultItem = new EntityItem(worldIn, pos.getX(), pos.getY(), pos.getZ(), new ItemStack(result, minNum));
                  resultItem.motionX = 0.0;
                  resultItem.motionY = 0.0;
                  resultItem.motionZ = 0.0;
                  worldIn.spawnEntity(resultItem);
                  worldIn.playSound(null, pos, SoundInit.MACHINE_CRAFT, SoundCategory.MASTER, 1.0F, 1.0F);
               }
            }
         }
      }

      return true;
   }

   private BlockMetaMaterializer.MetaRecipe getRecipe(ItemStack heldItem) {
      if (heldItem.getItem().equals(ItemInit.clovinitePowerBank)) {
         return new BlockMetaMaterializer.MetaRecipe(
            ItemInit.velloriumIngot,
            ItemInit.kylaxiumIngot,
            ItemInit.xeroviumIngot,
            ItemInit.organicPlate,
            ItemInit.corruptedRoot,
            ItemInit.giantTentacle,
            ItemInit.kyvoriumIngot
         );
      } else if (heldItem.getItem().equals(ItemInit.adhesiveFibre)) {
         return new BlockMetaMaterializer.MetaRecipe(
            ItemInit.olysiumIngot,
            ItemInit.detheriumIngot,
            ItemInit.phytrosiumIngot,
            ItemInit.gloomBulb,
            ItemInit.pickle,
            ItemInit.anthocite,
            ItemInit.biosynthiumIngot
         );
      } else if (heldItem.getItem().equals(ItemInit.externalCloviniteBattery)) {
         return new BlockMetaMaterializer.MetaRecipe(
            ItemInit.noxeriumIngot,
            ItemInit.incadiumIngot,
            ItemInit.emberiumIngot,
            ItemInit.ghostlyHusk,
            ItemInit.flexibleHusk,
            ItemInit.corruptedRoot,
            ItemInit.maliciumIngot
         );
      } else if (heldItem.getItem().equals(ItemInit.ionCell)) {
         return new BlockMetaMaterializer.MetaRecipe(
            ItemInit.olysiumIngot,
            ItemInit.xeroviumIngot,
            ItemInit.detheriumIngot,
            ItemInit.ghostlyHusk,
            ItemInit.photochromicHusk,
            ItemInit.luminescentStingers,
            ItemInit.etheriumIngot
         );
      } else {
         return heldItem.getItem().equals(ItemInit.potentPolarcronite)
            ? new BlockMetaMaterializer.MetaRecipe(
               ItemInit.phytrosiumIngot,
               ItemInit.xeroviumIngot,
               ItemInit.hextoriumIngot,
               ItemInit.volatileBlood,
               ItemInit.glowingGlobes,
               ItemInit.glowingOrgan,
               ItemInit.polariumIngot
            )
            : null;
      }
   }

   public class MetaRecipe {
      private ArrayList<Item> ingots = null;
      private ArrayList<Item> organics = null;
      private Item result = null;

      private MetaRecipe(Item ingot1, Item ingot2, Item ingot3, Item organic1, Item organic2, Item organic3, Item result) {
         this.ingots = new ArrayList<>();
         this.ingots.add(ingot1);
         this.ingots.add(ingot2);
         this.ingots.add(ingot3);
         this.organics = new ArrayList<>();
         this.organics.add(organic1);
         this.organics.add(organic2);
         this.organics.add(organic3);
         this.result = result;
      }

      private ArrayList<Item> getIngots() {
         return this.ingots;
      }

      private ArrayList<Item> getOrganics() {
         return this.organics;
      }

      private Item getResult() {
         return this.result;
      }
   }
}
