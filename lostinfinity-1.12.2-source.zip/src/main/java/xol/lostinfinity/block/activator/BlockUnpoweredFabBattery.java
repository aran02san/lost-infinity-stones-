package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockUnpoweredFabBattery extends BlockBasicLight {
   public BlockUnpoweredFabBattery(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      if (!stack.isEmpty() && stack.getItem().equals(ItemInit.fabricationPowerCore)) {
         if (!worldIn.isRemote) {
            worldIn.playSound(null, pos, SoundInit.GENERIC_UI_3, SoundCategory.MASTER, 1.0F, 1.0F);
            worldIn.setBlockState(pos, BlockInit.fabricationBattery.getDefaultState());
         }

         stack.shrink(1);
         return true;
      } else {
         return false;
      }
   }
}
