package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicRotational;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;

public class BlockLightReflector extends BlockBasicRotational {
   public BlockLightReflector(String name) {
      this(name, 60.0F, Material.ROCK);
      this.setLightLevel(0.7F);
   }

   public BlockLightReflector(String name, float hardness, Material material) {
      this(name, hardness, material, TabsInit.TAB_BLOCKS);
   }

   public BlockLightReflector(String name, float hardness, Material material, CreativeTabs tab) {
      super(name, hardness, material, tab);
   }

   public IBlockState getStateNextRotation(IBlockState state) {
      EnumFacing facing = (EnumFacing)state.getValue(FACING);
      switch (facing) {
         case NORTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.EAST);
         case EAST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.SOUTH);
         case SOUTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.WEST);
         case WEST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.NORTH);
         default:
            return state;
      }
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         worldIn.setBlockState(pos, this.getStateNextRotation(state));
         worldIn.playSound(null, pos, SoundInit.GEAR_MACHINE, SoundCategory.BLOCKS, 0.75F, 0.8F + 0.4F * worldIn.rand.nextFloat());
      }

      return true;
   }

   public IBlockState getStateWithFacing(EnumFacing facing) {
      return this.getDefaultState().withProperty(FACING, facing);
   }

   public ArrayList<Vec3d> getBeamDirs(IBlockState state) {
      EnumFacing facing = (EnumFacing)state.getValue(FACING);
      ArrayList<Vec3d> beamDirs = new ArrayList<>();
      switch (facing) {
         case NORTH:
            beamDirs.add(new Vec3d(0.0, 0.0, -1.0));
            beamDirs.add(new Vec3d(1.0, 0.0, 0.0));
            break;
         case EAST:
            beamDirs.add(new Vec3d(1.0, 0.0, 0.0));
            beamDirs.add(new Vec3d(0.0, 0.0, 1.0));
            break;
         case SOUTH:
            beamDirs.add(new Vec3d(0.0, 0.0, 1.0));
            beamDirs.add(new Vec3d(-1.0, 0.0, 0.0));
            break;
         case WEST:
            beamDirs.add(new Vec3d(-1.0, 0.0, 0.0));
            beamDirs.add(new Vec3d(0.0, 0.0, -1.0));
            break;
         default:
            beamDirs.add(new Vec3d(0.0, 0.0, -1.0));
            beamDirs.add(new Vec3d(1.0, 0.0, 0.0));
      }

      return beamDirs;
   }
}
