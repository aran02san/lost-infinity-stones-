package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;

public class BlockPuzzleKey extends BlockBasic {
   public BlockPuzzleKey(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack heldstack = playerIn.getHeldItem(hand);
      if (heldstack.getItem() == ItemInit.puzzleKey) {
         if (!worldIn.isRemote) {
            playerIn.addItemStackToInventory(new ItemStack(ItemInit.beaconKey));
            playerIn.setPositionAndUpdate(0.0, 33.0, 0.0);
            playerIn.sendMessage(new TextComponentString(TextFmt.Dark_Aqua + "The Echo: Activate the beacon if you wish to play " + playerIn.getName()));
         }

         heldstack.shrink(1);
      }

      return true;
   }
}
