package xol.lostinfinity.block.activator;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.DimensionType;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.dimension.util.DimensionActivator;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.basics.ItemArenaToken;
import xol.lostinfinity.mob.entity.boss.EntityAlestria;
import xol.lostinfinity.mob.entity.boss.EntityArash;
import xol.lostinfinity.mob.entity.boss.EntityAtlasSpire;
import xol.lostinfinity.mob.entity.boss.EntityBarul;
import xol.lostinfinity.mob.entity.boss.EntityCryonus;
import xol.lostinfinity.mob.entity.boss.EntityDarrio;
import xol.lostinfinity.mob.entity.boss.EntityNuxuro;
import xol.lostinfinity.mob.entity.boss.EntityOzor;
import xol.lostinfinity.mob.entity.boss.EntityRikarus;
import xol.lostinfinity.mob.entity.boss.EntityThundyron;
import xol.lostinfinity.mob.entity.boss.EntityUrogo;
import xol.lostinfinity.mob.entity.boss.EntityVelo;
import xol.lostinfinity.mob.entity.boss.EntityVycellia;

public class BlockArenaBoss extends BlockBasic {
   public BlockArenaBoss(String name) {
      super(name, Material.ROCK);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (pos.getX() < 350) {
            if (pos.getZ() > 0) {
               DimensionActivator.transferEntityWithCoords(playerIn, DimensionType.OVERWORLD, 0.0, 0.0, 0.0);
            } else {
               ItemStack heldstack = playerIn.getHeldItem(hand);
               if (heldstack.getItem() instanceof ItemArenaToken) {
                  AxisAlignedBB aabb = this.getArenaAABB();
                  boolean found_pl = false;

                  for (EntityPlayer playerCheck : worldIn.getEntitiesWithinAABB(EntityPlayer.class, aabb)) {
                     found_pl = true;
                  }

                  if (!found_pl) {
                     if (!worldIn.isRemote) {
                        playerIn.setPositionAndUpdate(25.5, 61.2, -73.0);
                     }

                     worldIn.playSound(playerIn, 25.5, 61.2, -73.0, SoundInit.ARENA_CHALLENGE, SoundCategory.MASTER, 2.0F, 1.0F);
                     this.spawnMyBoss(heldstack.getItem(), worldIn, playerIn);
                     heldstack.shrink(1);
                  } else if (!worldIn.isRemote) {
                     playerIn.sendMessage(new TextComponentString(TextFmt.Red + "The arena is currently in use."));
                  }
               } else if (heldstack.getItem() == ItemInit.arenaCard) {
                  playerIn.playSound(SoundInit.ARENA_TELEPORT, 3.0F, 1.0F);
                  heldstack.shrink(1);
                  if (!worldIn.isRemote) {
                     playerIn.setPositionAndUpdate(25.5, 61.2, -33.0);
                  }
               }
            }
         } else {
            DimensionActivator.transferEntityWithCoords(playerIn, DimensionType.OVERWORLD, 0.0, 0.0, 0.0);
         }
      }

      return true;
   }

   private AxisAlignedBB getArenaAABB() {
      return new AxisAlignedBB(new BlockPos(-3.0, 60.0, -145.0), new BlockPos(52.0, 85.0, -40.0));
   }

   private void spawnMyBoss(Item held, World world, EntityPlayer play) {
      AxisAlignedBB aabb = this.getArenaAABB();

      for (EntityMob mob_die : world.getEntitiesWithinAABB(EntityMob.class, aabb)) {
         mob_die.setDead();
      }

      if (held == ItemInit.tokenUrogo) {
         if (!world.isRemote) {
            EntityUrogo urogo = new EntityUrogo(world);
            urogo.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(urogo);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Urogo!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Urogo: Let's make this quick."));
         }
      } else if (held == ItemInit.tokenVelo) {
         if (!world.isRemote) {
            EntityVelo velo = new EntityVelo(world);
            velo.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(velo);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Velo!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Velo: I'll battle you here, I'll battle you anywhere..."));
         }
      } else if (held == ItemInit.tokenNuxuro) {
         if (!world.isRemote) {
            EntityNuxuro velo = new EntityNuxuro(world);
            velo.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(velo);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Velo!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Nuxuro: Run little being, while you still have the chance."));
         }
      } else if (held == ItemInit.tokenRikarus) {
         if (!world.isRemote) {
            EntityRikarus rikarus = new EntityRikarus(world);
            rikarus.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(rikarus);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Rikarus!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Rikarus: Your life now belongs to me."));
         }
      } else if (held == ItemInit.tokenArash) {
         if (!world.isRemote) {
            EntityArash arash = new EntityArash(world);
            arash.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(arash);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Arash!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Arash: You? A challenge? We'll see about that."));
         }
      } else if (held == ItemInit.tokenAlestria) {
         if (!world.isRemote) {
            EntityAlestria alestria = new EntityAlestria(world);
            alestria.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(alestria);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Alestria!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Alestria: Your life will soon be as empty as the void around us."));
         }
      } else if (held == ItemInit.tokenDario) {
         if (!world.isRemote) {
            EntityDarrio darrio = new EntityDarrio(world);
            darrio.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(darrio);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Darrio!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Darrio: I'm already dead, what can you possibly do to me?"));
         }
      } else if (held == ItemInit.tokenAtlasspire) {
         if (!world.isRemote) {
            EntityAtlasSpire spire = new EntityAtlasSpire(world);
            spire.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(spire);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges The Atlas Spire!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Looming Voice: Interesting choice."));
         }
      } else if (held == ItemInit.tokenVycellia) {
         if (!world.isRemote) {
            EntityVycellia vycel = new EntityVycellia(world);
            vycel.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(vycel);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Spider Queen Vycellia!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Vycellia: My army is eternal, and YOU. ARE. NOT."));
         }
      } else if (held == ItemInit.tokenOzor) {
         if (!world.isRemote) {
            EntityOzor ozor = new EntityOzor(world);
            ozor.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(ozor);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Ozor!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Ozor: Your life is but an illusion... a mirage waiting to disappear."));
         }
      } else if (held == ItemInit.tokenThundyron) {
         if (!world.isRemote) {
            EntityThundyron thund = new EntityThundyron(world);
            thund.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(thund);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Thundyron!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Thundyron: YOU... HAVE... NO... POWER..."));
         }
      } else if (held == ItemInit.tokenBarul) {
         if (!world.isRemote) {
            EntityBarul barul = new EntityBarul(world);
            barul.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(barul);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Barul!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Barul: You like tiny and weak.... and like you're about to be dead."));
         }
      } else if (held == ItemInit.tokenCryonus) {
         if (!world.isRemote) {
            EntityCryonus cryro = new EntityCryonus(world);
            cryro.setPosition(25.5, 62.2, -90.0);
            world.spawnEntity(cryro);
         } else {
            play.sendMessage(new TextComponentString(TextFmt.Aqua + play.getName() + " challenges Cryonus!"));
            play.sendMessage(new TextComponentString(TextFmt.Red + "Cryonus: What is it you fear " + play.getName() + "?"));
         }
      }
   }
}
