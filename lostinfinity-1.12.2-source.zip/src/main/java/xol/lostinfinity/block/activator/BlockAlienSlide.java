package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockAlienSlide extends BlockBasic {
   private int slideNum = 0;

   public BlockAlienSlide(String name) {
      super(name);
      this.slideNum = Integer.parseInt(name.replace("slide_puzzle_alien_", ""));
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         if (this.slideNum != 17) {
            BlockPos[] adjBlocks = new BlockPos[]{pos.north(), pos.east(), pos.south(), pos.west()};

            for (BlockPos side : adjBlocks) {
               if (worldIn.getBlockState(side).getBlock() instanceof BlockAlienSlide) {
                  BlockAlienSlide nextBlock = (BlockAlienSlide)worldIn.getBlockState(side).getBlock();
                  if (nextBlock.getBlockNum() == 17) {
                     worldIn.setBlockState(side, this.getDefaultState());
                     worldIn.setBlockState(pos, BlockInit.alienSlide17.getDefaultState());
                     break;
                  }
               }
            }
         }

         worldIn.playSound(null, pos, SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }

   public int getBlockNum() {
      return this.slideNum;
   }

   public static Block getSlideByNum(int num) {
      switch (num) {
         case 0:
            return BlockInit.alienSlide0;
         case 1:
            return BlockInit.alienSlide1;
         case 2:
            return BlockInit.alienSlide2;
         case 3:
            return BlockInit.alienSlide3;
         case 4:
            return BlockInit.alienSlide4;
         case 5:
            return BlockInit.alienSlide5;
         case 6:
            return BlockInit.alienSlide6;
         case 7:
            return BlockInit.alienSlide7;
         case 8:
            return BlockInit.alienSlide8;
         case 9:
            return BlockInit.alienSlide9;
         case 10:
            return BlockInit.alienSlide10;
         case 11:
            return BlockInit.alienSlide11;
         case 12:
            return BlockInit.alienSlide12;
         case 13:
            return BlockInit.alienSlide13;
         case 14:
            return BlockInit.alienSlide14;
         case 15:
            return BlockInit.alienSlide15;
         case 16:
            return BlockInit.alienSlide16;
         case 17:
            return BlockInit.alienSlide17;
         case 18:
            return BlockInit.alienSlide18;
         case 19:
            return BlockInit.alienSlide19;
         case 20:
            return BlockInit.alienSlide20;
         case 21:
            return BlockInit.alienSlide21;
         case 22:
            return BlockInit.alienSlide22;
         case 23:
            return BlockInit.alienSlide23;
         case 24:
            return BlockInit.alienSlide24;
         default:
            return BlockInit.alienSlide17;
      }
   }
}
