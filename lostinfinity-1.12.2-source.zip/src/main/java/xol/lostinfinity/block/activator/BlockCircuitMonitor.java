package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityCircuitCalibrator;
import xol.lostinfinity.init.BlockInit;

public class BlockCircuitMonitor extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 2);

   public BlockCircuitMonitor(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         int radius = 7;
         Vec3i offset = new Vec3i(0, 0, 0);

         for (int i = -radius; i <= radius; i++) {
            for (int k = -radius; k <= radius; k++) {
               BlockPos check = new BlockPos(pos.add(offset).add(i, 0, k));
               IBlockState checkState = worldIn.getBlockState(check);
               Block checkBlock = checkState.getBlock();
               if (checkBlock == BlockInit.circuitCalibrator) {
                  TileEntity tileEntity = worldIn.getTileEntity(check);
                  if (tileEntity != null && tileEntity instanceof TileEntityCircuitCalibrator) {
                     TileEntityCircuitCalibrator calibrator = (TileEntityCircuitCalibrator)tileEntity;
                     int meta = this.getMetaFromState(state);
                     calibrator.press(meta, pos, playerIn);
                  }
               }
            }
         }
      }

      return true;
   }
}
