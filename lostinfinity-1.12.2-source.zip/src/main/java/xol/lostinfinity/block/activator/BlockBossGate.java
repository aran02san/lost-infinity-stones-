package xol.lostinfinity.block.activator;

import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGlass;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.SoundInit;

public class BlockBossGate extends BlockBasicGlass {
   public BlockBossGate(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         playerIn.setHealth(0.5F);
         playerIn.sendMessage(
            new TextComponentString(
               TextFmt.Dark_Purple + "You'll never get through that gate " + playerIn.getName() + ". You will have to open a portal to my prison."
            )
         );
         worldIn.playSound(null, pos, SoundInit.ELECTRIC_SHOCK, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }

   @Nullable
   public AxisAlignedBB getCollisionBoundingBox(IBlockState blockState, IBlockAccess worldIn, BlockPos pos) {
      return NULL_AABB;
   }

   public void onEntityCollidedWithBlock(World worldIn, BlockPos pos, IBlockState state, Entity entityIn) {
      if (!worldIn.isRemote && !entityIn.isDead && entityIn instanceof EntityLivingBase) {
         worldIn.playSound(null, pos, SoundInit.SCANNER, SoundCategory.MASTER, 1.0F, 1.0F);
         EntityLivingBase living = (EntityLivingBase)entityIn;
         living.setHealth(0.0F);
      }
   }
}
