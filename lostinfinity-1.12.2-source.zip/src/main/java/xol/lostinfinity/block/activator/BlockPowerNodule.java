package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.Stack;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.block.tileentity.TileEntityPowerConduit;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.SoundInit;

public class BlockPowerNodule extends BlockBasicLight {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 3);

   public BlockPowerNodule(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         BlockPos gameBlock = this.findGameBlock(worldIn, pos);
         if (gameBlock != null) {
            TileEntity tileEntity = worldIn.getTileEntity(gameBlock);
            if (tileEntity != null && tileEntity instanceof TileEntityPowerConduit) {
               TileEntityPowerConduit TE = (TileEntityPowerConduit)tileEntity;
               ArrayList<BlockPos> tiles = TE.getTiles();
               BlockPos connectorPos = null;

               for (BlockPos tilePos : tiles) {
                  if (this.getMetaFromState(worldIn.getBlockState(tilePos)) == 3) {
                     connectorPos = tilePos;
                     break;
                  }
               }

               if (connectorPos != null) {
                  boolean xDir = pos.getX() - connectorPos.getX() > 0;
                  boolean zDir = pos.getZ() - connectorPos.getZ() > 0;
                  Vec3i upDir = TE.getUpDir();
                  Vec3i newDir = null;
                  if (xDir) {
                     if (upDir.getX() > 0) {
                        newDir = new Vec3i(1, 0, 0);
                     } else if (upDir.getX() < 0) {
                        newDir = new Vec3i(1, 0, 0);
                     }
                  } else if (upDir.getX() > 0) {
                     newDir = new Vec3i(-1, 0, 0);
                  } else if (upDir.getX() < 0) {
                     newDir = new Vec3i(-1, 0, 0);
                  }

                  if (zDir) {
                     if (upDir.getZ() > 0) {
                        newDir = new Vec3i(0, 0, 1);
                     } else if (upDir.getZ() < 0) {
                        newDir = new Vec3i(0, 0, 1);
                     }
                  } else if (upDir.getZ() > 0) {
                     newDir = new Vec3i(0, 0, -1);
                  } else if (upDir.getZ() < 0) {
                     newDir = new Vec3i(0, 0, -1);
                  }

                  BlockPos next = connectorPos.add(newDir);
                  IBlockState nextState = worldIn.getBlockState(next);
                  if (!nextState.getBlock().equals(BlockInit.powerNodule)) {
                     return true;
                  }

                  worldIn.playSound(null, connectorPos, SoundInit.GENERIC_UI_2, SoundCategory.BLOCKS, 1.0F, 0.8F * worldIn.rand.nextFloat() * 0.4F);
                  if (BlockInit.powerNodule.getMetaFromState(nextState) == 2) {
                     worldIn.setBlockState(next, BlockInit.powerNodule.getStateFromMeta(3));
                     worldIn.setBlockState(connectorPos, BlockInit.powerNodule.getStateFromMeta(2));
                  } else if (BlockInit.powerNodule.getMetaFromState(nextState) == 0) {
                     worldIn.setBlockState(next, BlockInit.powerNodule.getStateFromMeta(1));
                     worldIn.setBlockState(connectorPos, BlockInit.powerNodule.getStateFromMeta(2));
                  }
               }
            }
         }
      }

      return true;
   }

   private BlockPos findGameBlock(World worldIn, BlockPos pos) {
      Vec3i offset = new Vec3i(0, 2, 0);
      ArrayList<BlockPos> visited = new ArrayList<>();
      Stack<BlockPos> toVisit = new Stack<>();
      visited.add(pos);
      toVisit.addAll(this.getNeighbours(pos));

      while (!toVisit.isEmpty()) {
         BlockPos node = toVisit.pop();
         if (node != null) {
            Block block = worldIn.getBlockState(node).getBlock();
            Block upBlock = worldIn.getBlockState(node.add(offset)).getBlock();
            if (block instanceof BlockPowerNodule) {
               visited.add(node);

               for (BlockPos neighbour : this.getNeighbours(node)) {
                  if (!visited.contains(neighbour)) {
                     toVisit.add(neighbour);
                  }
               }
            } else if (upBlock instanceof BlockPowerConduit) {
               return node.add(offset);
            }
         }
      }

      return null;
   }

   ArrayList<BlockPos> getNeighbours(BlockPos pos) {
      ArrayList<BlockPos> neighbours = new ArrayList<>();
      neighbours.add(pos.add(1, 0, 0));
      neighbours.add(pos.add(-1, 0, 0));
      neighbours.add(pos.add(1, 0, 1));
      neighbours.add(pos.add(1, 0, -1));
      neighbours.add(pos.add(-1, 0, 1));
      neighbours.add(pos.add(-1, 0, -1));
      neighbours.add(pos.add(0, 0, 1));
      neighbours.add(pos.add(0, 0, -1));
      return neighbours;
   }
}
