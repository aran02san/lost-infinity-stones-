package xol.lostinfinity.block.activator;

import java.util.Random;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.misc.EntityRhythmGameMerchant;

public class BlockRhythmGame extends BlockBasic {
   private boolean hard_mode = false;
   private Vec3i dir;

   public BlockRhythmGame(String name, boolean hard) {
      super(name, Material.IRON);
      this.setLightLevel(1.0F);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.timeTrigger);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && this.validInput(playerIn.getHeldItem(hand))) {
         if (!worldIn.isRemote) {
            Random rand = worldIn.rand;
            AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-10, -10, -10), pos.add(10, 10, 10));

            for (EntityRhythmGameMerchant merch : worldIn.getEntitiesWithinAABB(EntityRhythmGameMerchant.class, checkBox)) {
               ((WorldServer)worldIn)
                  .spawnParticle(
                     EnumParticleTypes.PORTAL,
                     merch.posX,
                     merch.posY,
                     merch.posZ,
                     5,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.3,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.15F,
                     new int[0]
                  );
               merch.setDead();
            }

            worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
            EntityRhythmGameMerchant newMerchant = new EntityRhythmGameMerchant(worldIn);
            newMerchant.setPosition(pos.getX(), pos.getY() + 1.5, pos.getZ());
            ((WorldServer)worldIn)
               .spawnParticle(
                  EnumParticleTypes.PORTAL,
                  newMerchant.posX,
                  newMerchant.posY,
                  newMerchant.posZ,
                  8,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.3,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.15F,
                  new int[0]
               );
            worldIn.spawnEntity(newMerchant);
            newMerchant.genRhythmGame(pos.add(0, -1, 0));
            newMerchant.startGame();
         }

         playerIn.getHeldItem(hand).shrink(1);
      }

      return true;
   }
}
