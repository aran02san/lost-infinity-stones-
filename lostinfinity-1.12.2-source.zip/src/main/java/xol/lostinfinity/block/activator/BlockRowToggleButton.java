package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.init.BlockInit;

public class BlockRowToggleButton extends BlockBasic {
   public BlockRowToggleButton(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && !worldIn.isRemote) {
         Vec3i dir = findTileDir(worldIn, pos);
         if (dir != null) {
            for (BlockPos nextPos = pos.add(dir);
               worldIn.getBlockState(nextPos).getBlock().equals(BlockInit.rowToggleTile);
               nextPos = nextPos.add(dir)
            ) {
               int meta = ((BlockBasicBoolState)BlockInit.rowToggleTile).getMetaFromState(worldIn.getBlockState(nextPos));
               if (meta == 0) {
                  worldIn.setBlockState(nextPos, BlockInit.rowToggleTile.getStateFromMeta(1));
               } else {
                  worldIn.setBlockState(nextPos, BlockInit.rowToggleTile.getStateFromMeta(0));
               }
            }
         }
      }

      return true;
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 0));
      dirs.add(new Vec3i(-1, 0, 0));
      dirs.add(new Vec3i(0, 0, 1));
      dirs.add(new Vec3i(0, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.rowToggleTile)) {
            return dir;
         }
      }

      return null;
   }
}
