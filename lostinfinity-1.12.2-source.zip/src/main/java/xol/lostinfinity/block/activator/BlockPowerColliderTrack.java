package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityPowerCollider;

public class BlockPowerColliderTrack extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 2);
   private static final Vec3i offset = new Vec3i(0, 0, 0);

   public BlockPowerColliderTrack(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         BlockPos collider = this.findCollider(worldIn, pos);
         if (collider != null) {
            TileEntity tileEntity = worldIn.getTileEntity(collider);
            if (tileEntity != null && tileEntity instanceof TileEntityPowerCollider) {
               TileEntityPowerCollider TE = (TileEntityPowerCollider)tileEntity;
               TE.light(pos);
            }
         }
      }

      return true;
   }

   private BlockPos findCollider(World worldIn, BlockPos pos) {
      BlockPos ref = pos.add(offset);
      int radius = 30;

      for (int i = -radius; i < radius; i++) {
         for (int j = -radius; j < radius; j++) {
            BlockPos check = ref.add(i, 0, j);
            Block block = worldIn.getBlockState(check).getBlock();
            if (block instanceof BlockPowerCollider) {
               return check;
            }
         }
      }

      return null;
   }

   ArrayList<BlockPos> getNeighbours(BlockPos pos) {
      ArrayList<BlockPos> neighbours = new ArrayList<>();
      neighbours.add(pos.add(1, 0, 0));
      neighbours.add(pos.add(-1, 0, 0));
      neighbours.add(pos.add(1, 0, 1));
      neighbours.add(pos.add(1, 0, -1));
      neighbours.add(pos.add(-1, 0, 1));
      neighbours.add(pos.add(-1, 0, -1));
      neighbours.add(pos.add(0, 0, 1));
      neighbours.add(pos.add(0, 0, -1));
      return neighbours;
   }
}
