package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.item.activate.ItemEncryptedPowerBlueprints;

public class BlockPowerGenerator extends BlockBasic {
   public BlockPowerGenerator(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         ItemStack held = playerIn.getHeldItem(hand);
         if (held.getItem() == ItemInit.encryptedPowerBlueprints) {
            ItemEncryptedPowerBlueprints scroll = (ItemEncryptedPowerBlueprints)held.getItem();
            if (scroll.getCompletion(held) < 3 && scroll.matchBlock(held, pos, worldIn)) {
               scroll.progress(held, playerIn);
            } else {
               playerIn.sendMessage(
                  new TextComponentString(TextFmt.Italic + "You can not currently connect this generator, please consult the main blueprints.")
               );
            }
         }
      }

      return true;
   }
}
