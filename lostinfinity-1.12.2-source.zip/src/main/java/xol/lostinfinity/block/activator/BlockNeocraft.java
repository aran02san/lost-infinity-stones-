package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockNeocraft extends BlockBasic {
   public BlockNeocraft(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      Block makeBlock = this.blockFromItem(held.getItem());
      if (makeBlock != null && makeBlock != worldIn.getBlockState(pos).getBlock()) {
         if (!worldIn.isRemote) {
            worldIn.setBlockState(pos, makeBlock.getDefaultState());
            worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
         }

         held.shrink(1);
      }

      return true;
   }

   private Block blockFromItem(Item item) {
      if (item == ItemInit.cureSampleBlue) {
         return BlockInit.neocraftBlue;
      } else if (item == ItemInit.cureSampleGreen) {
         return BlockInit.neocraftGreen;
      } else if (item == ItemInit.cureSampleYellow) {
         return BlockInit.neocraftYellow;
      } else if (item == ItemInit.cureSampleOrange) {
         return BlockInit.neocraftOrange;
      } else {
         return item == ItemInit.cureSamplePink ? BlockInit.neocraftPink : null;
      }
   }
}
