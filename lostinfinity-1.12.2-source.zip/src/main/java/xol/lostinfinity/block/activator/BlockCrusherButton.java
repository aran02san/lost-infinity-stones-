package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;
import xol.lostinfinity.util.damagesource.DeathMessage;

public class BlockCrusherButton extends BlockBasic {
   public BlockCrusherButton(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         AxisAlignedBB crushBox = GalaxyCoordinates.crusherAABB();
         boolean crush = false;

         for (int i = (int)crushBox.minX; i <= (int)crushBox.maxX; i++) {
            for (int j = (int)crushBox.minY; j <= (int)crushBox.maxY; j++) {
               for (int k = (int)crushBox.minZ; k <= (int)crushBox.maxZ; k++) {
                  BlockPos check = new BlockPos(i, j, k);
                  if (!worldIn.isAirBlock(check) && !crush) {
                     worldIn.setBlockToAir(check);
                  } else {
                     worldIn.setBlockState(check, BlockInit.neosteelBeam.getDefaultState());
                     crush = true;
                  }
               }
            }
         }

         if (crush) {
            worldIn.playSound(null, pos, SoundEvents.BLOCK_ANVIL_LAND, SoundCategory.MASTER, 1.0F, 0.9F);

            for (EntityLivingBase mob : worldIn.getEntitiesWithinAABB(EntityLivingBase.class, crushBox)) {
               EntityItem bones = new EntityItem(worldIn, mob.posX, mob.posY + 0.4, mob.posZ, new ItemStack(ItemInit.crushedBones));
               bones.motionX = 0.0;
               bones.motionY = 0.0;
               bones.motionZ = 0.0;
               worldIn.spawnEntity(bones);
               mob.setHealth(0.0F);
               if (mob instanceof EntityPlayer) {
                  DeathMessage.broadcastDeathMessage(mob.getServer(), TextFmt.Red + mob.getName() + " was brutally crushed.");
               }
            }
         }
      }

      return true;
   }
}
