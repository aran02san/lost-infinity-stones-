package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.boss.EntityDuskerQueen;

public class BlockTerrorGlow extends BlockBasicBoolState {
   public BlockTerrorGlow(String name) {
      super(name);
   }

   private static boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.quickflameSolution);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (validInput(playerIn.getHeldItem(hand)) && !worldIn.isRemote && state == BlockInit.terrorGlow.getStateFromMeta(0)) {
            worldIn.setBlockState(pos, BlockInit.terrorGlow.getStateFromMeta(1));
            ArrayList<BlockPos> lit = new ArrayList<>();
            lit.add(pos);
            int radius = 20;
            int count = 0;

            for (int i = -radius; i <= radius; i++) {
               for (int j = -2; j <= 2; j++) {
                  for (int k = -radius; k <= radius; k++) {
                     BlockPos check = pos.add(i, j, k);
                     if (worldIn.getBlockState(check) == BlockInit.terrorGlow.getStateFromMeta(1)) {
                        count++;
                        lit.add(check);
                     }
                  }
               }
            }

            if (count >= 8) {
               for (BlockPos litPos : lit) {
                  worldIn.setBlockState(litPos, BlockInit.terrorGlow.getStateFromMeta(0));
               }

               EntityDuskerQueen queen = new EntityDuskerQueen(worldIn);
               queen.setPosition(173.0, 35.0, -86.0);
               worldIn.spawnEntity(queen);
            }
         }

         playerIn.getHeldItem(hand).shrink(1);
      }

      return true;
   }
}
