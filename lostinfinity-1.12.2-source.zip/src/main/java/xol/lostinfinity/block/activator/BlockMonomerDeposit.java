package xol.lostinfinity.block.activator;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.ItemInit;

public class BlockMonomerDeposit extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 5);

   public BlockMonomerDeposit(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      if (playerIn.isSneaking() && !worldIn.isRemote) {
         int meta = this.getMetaFromState(state);
         if (meta < 5) {
            worldIn.setBlockState(pos, this.getStateFromMeta(meta + 1));
         } else {
            worldIn.setBlockState(pos, this.getStateFromMeta(0));
         }
      }

      if (held.getItem().equals(ItemInit.monomerCollector) && held.hasTagCompound() && !worldIn.isRemote) {
         long endTime = held.getTagCompound().getLong("EndTime");
         if (endTime > System.currentTimeMillis()) {
            int amount = worldIn.rand.nextInt(4) + 2;
            int meta = this.getMetaFromState(state);
            if (meta != 0) {
               switch (meta) {
                  case 1:
                     playerIn.addItemStackToInventory(new ItemStack(ItemInit.purpleMonomerSample, amount));
                     break;
                  case 2:
                     playerIn.addItemStackToInventory(new ItemStack(ItemInit.blueMonomerSample, amount));
                     break;
                  case 3:
                     playerIn.addItemStackToInventory(new ItemStack(ItemInit.redMonomerSample, amount));
                     break;
                  case 4:
                     playerIn.addItemStackToInventory(new ItemStack(ItemInit.yellowMonomerSample, amount));
                     break;
                  case 5:
                     playerIn.addItemStackToInventory(new ItemStack(ItemInit.greenMonomerSample, amount));
               }

               worldIn.setBlockState(pos, this.getStateFromMeta(0));
            }
         } else {
            playerIn.sendMessage(new TextComponentString("You have taken too long to collect the monomers, the collector has been diminished"));
         }
      }

      return true;
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int meta = this.getMetaFromState(state);
         if (meta == 0) {
            int randMeta = world.rand.nextInt(5) + 1;
            world.setBlockState(pos, this.getStateFromMeta(randMeta));
         }
      }
   }
}
