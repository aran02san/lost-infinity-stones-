package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockLightTile extends BlockBasic {
   public BlockLightTile(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         if (state.getBlock().equals(BlockInit.lightTileLit)) {
            worldIn.setBlockState(pos, BlockInit.lightTileDark.getDefaultState());
         } else {
            worldIn.setBlockState(pos, BlockInit.lightTileLit.getDefaultState());
         }

         BlockPos[] adjblocks = new BlockPos[]{pos.north(), pos.east(), pos.south(), pos.west()};

         for (BlockPos side : adjblocks) {
            if (worldIn.getBlockState(side).getBlock().equals(BlockInit.lightTileDark)) {
               worldIn.setBlockState(side, BlockInit.lightTileLit.getDefaultState());
            } else if (worldIn.getBlockState(side).getBlock().equals(BlockInit.lightTileLit)) {
               worldIn.setBlockState(side, BlockInit.lightTileDark.getDefaultState());
            }
         }

         worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }
}
