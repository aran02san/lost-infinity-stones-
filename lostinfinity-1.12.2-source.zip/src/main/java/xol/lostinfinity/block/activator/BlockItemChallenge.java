package xol.lostinfinity.block.activator;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;

public class BlockItemChallenge extends Block {
   private int item_num = 0;

   public BlockItemChallenge(String name, int itemNum) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      this.item_num = itemNum;
      if (itemNum != 0) {
         BlockInit.ITEM_CHALLENGE_BLOCKS.add(this);
      }

      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (this.item_num != 0) {
         ItemStack held = playerIn.getHeldItemMainhand();
         if (held.getItem() == this.getItemNeeded()) {
            boolean run = true;

            for (int up_check = 2; run; up_check++) {
               BlockPos check = pos.add(0, up_check, 0);
               if (worldIn.isAirBlock(check)) {
                  run = false;
                  held.shrink(1);
                  if (!worldIn.isRemote) {
                     worldIn.setBlockState(check, BlockInit.itemChallengeCrate.getDefaultState());
                     worldIn.playSound(null, playerIn.getPosition(), SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.PLAYERS, 1.0F, 1.0F);
                  }
               } else if (worldIn.getBlockState(check).getBlock() == BlockInit.labyrinthLamp) {
                  run = false;
               }
            }
         }
      }

      return true;
   }

   private Item getItemNeeded() {
      switch (this.item_num) {
         case 1:
            return ItemInit.acidicTongue;
         case 2:
            return ItemInit.firefeather;
         case 3:
            return ItemInit.hypnoticEye;
         case 4:
            return ItemInit.nightmarePowder;
         case 5:
            return ItemInit.stickyHide;
         case 6:
            return ItemInit.mysteriousGloop;
         case 7:
            return ItemInit.glowBulb;
         case 8:
            return ItemInit.metalBranch;
         case 9:
            return ItemInit.shadowHide;
         case 10:
            return ItemInit.heavyCrystal;
         case 11:
            return ItemInit.duskerEggs;
         case 12:
            return ItemInit.explosiveSack;
         case 13:
            return ItemInit.hardBone;
         case 14:
            return ItemInit.magicStone;
         case 15:
            return ItemInit.livingSlime;
         case 16:
            return ItemInit.reflectiveShard;
         case 17:
            return ItemInit.rockspine;
         case 18:
            return ItemInit.razorFangs;
         case 19:
            return ItemInit.potentPolarcronite;
         case 20:
            return ItemInit.organicFuse;
         default:
            return ItemInit.masterCraftedAlloy;
      }
   }

   public static Block randomItemBlock(Random rand) {
      return BlockInit.ITEM_CHALLENGE_BLOCKS.get(rand.nextInt(BlockInit.ITEM_CHALLENGE_BLOCKS.size()));
   }
}
