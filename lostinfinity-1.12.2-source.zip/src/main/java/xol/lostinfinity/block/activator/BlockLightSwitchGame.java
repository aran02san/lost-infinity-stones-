package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.mob.entity.misc.EntityLightGame;

public class BlockLightSwitchGame extends BlockBasic {
   public BlockLightSwitchGame(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-10, -10, -10), pos.add(10, 10, 10));

         for (EntityLightGame merch : worldIn.getEntitiesWithinAABB(EntityLightGame.class, checkBox)) {
            ((WorldServer)worldIn)
               .spawnParticle(
                  EnumParticleTypes.PORTAL,
                  merch.posX,
                  merch.posY,
                  merch.posZ,
                  5,
                  (-0.5 + worldIn.rand.nextDouble()) * 3.0,
                  0.3,
                  (-0.5 + worldIn.rand.nextDouble()) * 3.0,
                  0.15F,
                  new int[0]
               );
            merch.setDead();
         }

         BlockPos refPos = pos.add(0, 1, 0);
         int radius = 8;
         List<BlockPos> switches = new ArrayList<>();
         List<BlockPos> lights = new ArrayList<>();

         for (int i = -radius; i <= radius; i++) {
            for (int j = -radius; j <= radius; j++) {
               Block block = worldIn.getBlockState(refPos.add(i, 0, j)).getBlock();
               if (block == BlockInit.switchableLightOff || block == BlockInit.switchableLightOn) {
                  lights.add(refPos.add(i, 0, j));
               } else if (block == BlockInit.lightSwitchOff || block == BlockInit.lightSwitchOn) {
                  switches.add(refPos.add(i, 0, j));
               }
            }
         }

         for (EntityLightGame entity : worldIn.getEntitiesWithinAABB(EntityLightGame.class, new AxisAlignedBB(-8.0, 0.0, -8.0, 8.0, 8.0, 8.0))) {
            entity.setDead();
         }

         EntityLightGame lightGame = new EntityLightGame(worldIn, lights, switches);
         BlockPos entityPos = pos.add(-1, 1, -1);
         lightGame.setPosition(entityPos.getX(), entityPos.getY(), entityPos.getZ());
         worldIn.spawnEntity(lightGame);
      }

      return true;
   }
}
