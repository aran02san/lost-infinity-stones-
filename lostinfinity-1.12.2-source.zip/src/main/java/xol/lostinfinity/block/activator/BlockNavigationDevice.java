package xol.lostinfinity.block.activator;

import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityNavigationDevice;
import xol.lostinfinity.init.ItemInit;

public class BlockNavigationDevice extends BlockBasic implements ITileEntityProvider {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 12);

   public BlockNavigationDevice(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      TileEntity te = worldIn.getTileEntity(pos);
      if (te != null && te instanceof TileEntityNavigationDevice) {
         TileEntityNavigationDevice device = (TileEntityNavigationDevice)te;
         if (stack.getItem() == ItemInit.basicSextant) {
            if (!worldIn.isRemote) {
               playerIn.sendMessage(
                  new TextComponentString(
                     "From the lit starting block, light up the nodules to match the direction and colour shown in the sequence displayed."
                  )
               );
            }

            device.activate();
            stack.shrink(1);
         } else {
            device.checkCompletion(playerIn);
         }
      }

      return true;
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   @Nullable
   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   @Nullable
   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityNavigationDevice();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }
}
