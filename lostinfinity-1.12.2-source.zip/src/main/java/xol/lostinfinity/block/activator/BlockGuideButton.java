package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.misc.BlockTrackTrigger;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.util.coordinates.CelestialCoordinates;

public class BlockGuideButton extends Block {
   public BlockGuideButton(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         BlockPos baseReference = CelestialCoordinates.mazeReferencePos();
         BlockPos guidePos = null;
         worldIn.playSound(null, pos, SoundEvents.BLOCK_COMPARATOR_CLICK, SoundCategory.MASTER, 1.0F, 1.0F);

         label93:
         for (int x = 0; x <= 29; x++) {
            for (int z = 0; z <= 29; z++) {
               if (worldIn.getBlockState(baseReference.add(x, 1, z)).getBlock() == BlockInit.guideBlock) {
                  guidePos = baseReference.add(x, 1, z);
                  break label93;
               }
            }
         }

         if (guidePos != null) {
            int side = 0;
            byte var16;
            if (worldIn.getBlockState(pos.down()).getBlock() == BlockInit.arenaBrickBlack) {
               var16 = 0;
            } else if (worldIn.getBlockState(pos.add(1, 0, 0)).getBlock() == BlockInit.arenaBrickBlack) {
               var16 = 1;
            } else if (worldIn.getBlockState(pos.up()).getBlock() == BlockInit.arenaBrickBlack) {
               var16 = 2;
            } else {
               var16 = 3;
            }

            switch (var16) {
               case 0:
                  int trackxxx = this.trackStyle(worldIn.getBlockState(guidePos.add(0, -1, 1)).getBlock());
                  if (worldIn.isAirBlock(guidePos.add(0, 0, 1)) && trackxxx > 0) {
                     if (trackxxx == 2) {
                        BlockTrackTrigger trigger = (BlockTrackTrigger)worldIn.getBlockState(guidePos.add(0, -1, 1)).getBlock();
                        trigger.trigger(worldIn, guidePos.add(0, -1, 1));
                     }

                     if (trackxxx != 3) {
                        worldIn.setBlockState(guidePos.add(0, -1, 1), BlockInit.blockTrackUsed.getDefaultState());
                     }

                     worldIn.setBlockState(guidePos.add(0, 0, 1), BlockInit.guideBlock.getDefaultState());
                     worldIn.setBlockToAir(guidePos);
                     worldIn.playSound(null, pos, SoundInit.GEAR_MACHINE, SoundCategory.MASTER, 0.75F, 1.0F);
                  }
                  break;
               case 1:
                  int trackxx = this.trackStyle(worldIn.getBlockState(guidePos.add(-1, -1, 0)).getBlock());
                  if (worldIn.isAirBlock(guidePos.add(-1, 0, 0)) && trackxx > 0) {
                     if (trackxx == 2) {
                        BlockTrackTrigger trigger = (BlockTrackTrigger)worldIn.getBlockState(guidePos.add(-1, 0, 0)).getBlock();
                        trigger.trigger(worldIn, guidePos.add(-1, 0, 0));
                     }

                     if (trackxx != 3) {
                        worldIn.setBlockState(guidePos.add(-1, -1, 0), BlockInit.blockTrackUsed.getDefaultState());
                     }

                     worldIn.setBlockState(guidePos.add(-1, 0, 0), BlockInit.guideBlock.getDefaultState());
                     worldIn.setBlockToAir(guidePos);
                     worldIn.playSound(null, pos, SoundInit.GEAR_MACHINE, SoundCategory.MASTER, 0.75F, 1.0F);
                  }
                  break;
               case 2:
                  int trackx = this.trackStyle(worldIn.getBlockState(guidePos.add(0, -1, -1)).getBlock());
                  if (worldIn.isAirBlock(guidePos.add(0, 0, -1)) && trackx > 0) {
                     if (trackx == 2) {
                        BlockTrackTrigger trigger = (BlockTrackTrigger)worldIn.getBlockState(guidePos.add(0, -1, -1)).getBlock();
                        trigger.trigger(worldIn, guidePos.add(0, -1, -1));
                     }

                     if (trackx != 3) {
                        worldIn.setBlockState(guidePos.add(0, -1, -1), BlockInit.blockTrackUsed.getDefaultState());
                     }

                     worldIn.setBlockState(guidePos.add(0, 0, -1), BlockInit.guideBlock.getDefaultState());
                     worldIn.setBlockToAir(guidePos);
                     worldIn.playSound(null, pos, SoundInit.GEAR_MACHINE, SoundCategory.MASTER, 0.75F, 1.0F);
                  }
                  break;
               case 3:
                  int track = this.trackStyle(worldIn.getBlockState(guidePos.add(1, -1, 0)).getBlock());
                  if (worldIn.isAirBlock(guidePos.add(1, 0, 0)) && track > 0) {
                     if (track == 2) {
                        BlockTrackTrigger trigger = (BlockTrackTrigger)worldIn.getBlockState(guidePos.add(1, -1, 0)).getBlock();
                        trigger.trigger(worldIn, guidePos.add(1, -1, 0));
                     }

                     if (track != 3) {
                        worldIn.setBlockState(guidePos.add(1, -1, 0), BlockInit.blockTrackUsed.getDefaultState());
                     }

                     worldIn.setBlockState(guidePos.add(1, 0, 0), BlockInit.guideBlock.getDefaultState());
                     worldIn.setBlockToAir(guidePos);
                     worldIn.playSound(null, pos, SoundInit.GEAR_MACHINE, SoundCategory.MASTER, 0.75F, 1.0F);
                  }
            }
         }
      }

      return true;
   }

   private int trackStyle(Block block) {
      if (block instanceof BlockTrackTrigger) {
         return 2;
      } else if (block == BlockInit.blockTrack) {
         return 1;
      } else {
         return block == BlockInit.blockTrackWin ? 3 : 0;
      }
   }
}
