package xol.lostinfinity.block.activator;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;

public class BlockLabTeleporter extends BlockBasic {
   public BlockLabTeleporter(String name) {
      super(name, Material.ROCK);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && !worldIn.isRemote) {
         int roomRand_X = worldIn.rand.nextInt(8);
         int roomRand_Z = worldIn.rand.nextInt(8);
         double yPlace;
         if (roomRand_X == roomRand_Z) {
            yPlace = 35.0;
         } else {
            yPlace = 26.0;
         }

         playerIn.setPositionAndUpdate(1295.0 + 160 * roomRand_X, yPlace, 1295.0 + 160 * roomRand_Z);
      }

      return true;
   }
}
