package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.dimension.data.TetrisMap;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockNeocraftingStation extends BlockBasic {
   private static int[][][] linePiece = new int[][][]{{{0, 1, 2, 3}, {0, 0, 0, 0}}, {{0, 0, 0, 0}, {0, 1, 2, 3}}};
   private static int[][][] lPiece = new int[][][]{
      {{0, 1, 2, 2}, {0, 0, 0, 1}},
      {{0, 0, 0, 1}, {0, 1, 2, 2}},
      {{0, 0, 0, -1}, {0, 1, 2, 2}},
      {{-1, 0, 0, 0}, {0, 0, 1, 2}},
      {{1, 0, 0, 0}, {0, 0, 1, 2}},
      {{0, 1, 2, 2}, {0, 0, 0, -1}},
      {{0, 0, 1, 2}, {-1, 0, 0, 0}},
      {{0, 0, 1, 2}, {1, 0, 0, 0}}
   };
   private static int[][][] tPiece = new int[][][]{
      {{0, 1, 1, 2}, {0, 0, -1, 0}}, {{0, 1, 1, 1}, {0, 1, 0, -1}}, {{0, 0, 0, 1}, {1, 0, -1, 0}}, {{0, 1, 1, 2}, {0, 0, 1, 0}}
   };
   private static int[][][] zigPiece = new int[][][]{
      {{0, 0, 1, 1}, {-1, 0, 0, 1}}, {{1, 1, 0, 0}, {1, 0, 0, -1}}, {{0, 1, 1, 2}, {0, 0, 1, 1}}, {{0, 1, 1, 2}, {0, 0, -1, -1}}
   };
   private static int[][][] squarePiece = new int[][][]{{{0, 0, 1, 1}, {0, 1, 0, 1}}};

   public BlockNeocraftingStation(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      if (stack.getItem() == ItemInit.polychargeSolution) {
         if (!worldIn.isRemote) {
            int randN = worldIn.rand.nextInt(3) + 1;
            int randM = worldIn.rand.nextInt(3) + 1;
            TetrisMap map = new TetrisMap(randN * 4, randM * 4);
            playerIn.sendMessage(new TextComponentString("Fill in an " + randN * 4 + " by " + randM * 4 + " area with the pieces shown."));
            int[] pieceList = map.getPieceList();
            int linePieces = pieceList[0];
            int lPieces = pieceList[1];
            int tPieces = pieceList[2];
            int zigPieces = pieceList[3];
            int squarePieces = pieceList[4];
            Vec3i upDir = new Vec3i(0, 0, 0);
            Vec3i rightDir = new Vec3i(0, 0, 0);
            Vec3i offset = new Vec3i(-7, -2, 13);
            BlockPos ref = pos.add(offset);
            if (worldIn.getBlockState(ref.add(-1, 0, 0)).getBlock() instanceof BlockNeocraft) {
               upDir = new Vec3i(1, 0, 0);
               rightDir = new Vec3i(0, 0, 1);
            } else if (worldIn.getBlockState(ref.add(1, 0, 0)).getBlock() instanceof BlockNeocraft) {
               upDir = new Vec3i(-1, 0, 0);
               rightDir = new Vec3i(0, 0, -1);
            } else if (worldIn.getBlockState(ref.add(0, 0, 1)).getBlock() instanceof BlockNeocraft) {
               upDir = new Vec3i(0, 0, -1);
               rightDir = new Vec3i(1, 0, 0);
            } else if (worldIn.getBlockState(ref.add(0, 0, -1)).getBlock() instanceof BlockNeocraft) {
               upDir = new Vec3i(0, 0, 1);
               rightDir = new Vec3i(-1, 0, 0);
            }

            BlockPos linePos = ref.add(rightDir.getX() * 1, 1, rightDir.getZ() * 1);
            BlockPos lPos = ref.add(rightDir.getX() * 3, 1, rightDir.getZ() * 3);
            BlockPos tPos = ref.add(rightDir.getX() * 5, 1, rightDir.getZ() * 5);
            BlockPos zigPos = ref.add(rightDir.getX() * 7, 1, rightDir.getZ() * 7);
            BlockPos squarePos = ref.add(rightDir.getX() * 9, 1, rightDir.getZ() * 9);
            this.reset(upDir, rightDir, worldIn, ref);

            for (int i = 0; i < linePieces; i++) {
               worldIn.setBlockState(linePos.add(0, i, 0), BlockInit.neocraftGoalBlue.getDefaultState());
            }

            for (int i = 0; i < lPieces; i++) {
               worldIn.setBlockState(lPos.add(0, i, 0), BlockInit.neocraftGoalOrange.getDefaultState());
            }

            for (int i = 0; i < tPieces; i++) {
               worldIn.setBlockState(tPos.add(0, i, 0), BlockInit.neocraftGoalPink.getDefaultState());
            }

            for (int i = 0; i < zigPieces; i++) {
               worldIn.setBlockState(zigPos.add(0, i, 0), BlockInit.neocraftGoalGreen.getDefaultState());
            }

            for (int i = 0; i < squarePieces; i++) {
               worldIn.setBlockState(squarePos.add(0, i, 0), BlockInit.neocraftGoalYellow.getDefaultState());
            }
         }

         stack.shrink(1);
      } else if (!worldIn.isRemote) {
         new ArrayList();
         Vec3i upDir = new Vec3i(0, 0, 0);
         Vec3i rightDir = new Vec3i(0, 0, 0);
         Vec3i offset = new Vec3i(-7, -2, 13);
         BlockPos ref = pos.add(offset);
         if (worldIn.getBlockState(ref.add(-1, 0, 0)).getBlock() instanceof BlockNeocraft) {
            upDir = new Vec3i(1, 0, 0);
            rightDir = new Vec3i(0, 0, 1);
         } else if (worldIn.getBlockState(ref.add(1, 0, 0)).getBlock() instanceof BlockNeocraft) {
            upDir = new Vec3i(-1, 0, 0);
            rightDir = new Vec3i(0, 0, -1);
         } else if (worldIn.getBlockState(ref.add(0, 0, 1)).getBlock() instanceof BlockNeocraft) {
            upDir = new Vec3i(0, 0, -1);
            rightDir = new Vec3i(1, 0, 0);
         } else if (worldIn.getBlockState(ref.add(0, 0, -1)).getBlock() instanceof BlockNeocraft) {
            upDir = new Vec3i(0, 0, 1);
            rightDir = new Vec3i(-1, 0, 0);
         }

         BlockPos linePos = ref.add(rightDir.getX() * 1, 1, rightDir.getZ() * 1);
         BlockPos lPos = ref.add(rightDir.getX() * 3, 1, rightDir.getZ() * 3);
         BlockPos tPos = ref.add(rightDir.getX() * 5, 1, rightDir.getZ() * 5);
         BlockPos zigPos = ref.add(rightDir.getX() * 7, 1, rightDir.getZ() * 7);
         BlockPos squarePos = ref.add(rightDir.getX() * 9, 1, rightDir.getZ() * 9);
         int lineCount = 0;
         int lCount = 0;
         int tCount = 0;
         int zigCount = 0;
         int squareCount = 0;

         for (BlockPos checkPos = new BlockPos(linePos);
            worldIn.getBlockState(checkPos).getBlock() == BlockInit.neocraftGoalBlue;
            checkPos = checkPos.add(0, 1, 0)
         ) {
            lineCount++;
         }

         for (BlockPos var53 = new BlockPos(lPos);
            worldIn.getBlockState(var53).getBlock() == BlockInit.neocraftGoalOrange;
            var53 = var53.add(0, 1, 0)
         ) {
            lCount++;
         }

         for (BlockPos var54 = new BlockPos(tPos);
            worldIn.getBlockState(var54).getBlock() == BlockInit.neocraftGoalPink;
            var54 = var54.add(0, 1, 0)
         ) {
            tCount++;
         }

         for (BlockPos var55 = new BlockPos(zigPos);
            worldIn.getBlockState(var55).getBlock() == BlockInit.neocraftGoalGreen;
            var55 = var55.add(0, 1, 0)
         ) {
            zigCount++;
         }

         for (BlockPos var56 = new BlockPos(squarePos);
            worldIn.getBlockState(var56).getBlock() == BlockInit.neocraftGoalYellow;
            var56 = var56.add(0, 1, 0)
         ) {
            squareCount++;
         }

         if (lineCount + squareCount + zigCount + lCount + tCount == 0) {
            playerIn.sendMessage(new TextComponentString("No Goal Blocks Present. Cannot craft"));
            return true;
         }

         BlockPos var57 = ref.subtract(upDir);

         while (worldIn.getBlockState(var57).getBlock() instanceof BlockNeocraft) {
            var57 = var57.subtract(upDir);
         }

         var57 = var57.add(upDir);

         while (worldIn.getBlockState(var57).getBlock() instanceof BlockNeocraft) {
            var57 = var57.subtract(rightDir);
         }

         var57 = var57.add(rightDir);
         BlockPos startPos = var57;
         int blueCount = 0;
         int greenCount = 0;
         int orangeCount = 0;
         int pinkCount = 0;
         int yellowCount = 0;
         boolean notFound = false;

         label153:
         for (int i = 0; i < 12; i++) {
            for (int j = 0; j < 12; j++) {
               BlockPos countPos = startPos.add(
                  rightDir.getX() * i + upDir.getX() * j, 0, rightDir.getZ() * i + upDir.getZ() * j
               );
               Block block = worldIn.getBlockState(countPos).getBlock();
               if (block == BlockInit.neocraftBlue) {
                  blueCount++;
                  notFound = !this.findPiece(worldIn, countPos, "line");
               } else if (block == BlockInit.neocraftGreen) {
                  greenCount++;
                  notFound = !this.findPiece(worldIn, countPos, "zig");
               } else if (block == BlockInit.neocraftPink) {
                  pinkCount++;
                  notFound = !this.findPiece(worldIn, countPos, "t");
               } else if (block == BlockInit.neocraftYellow) {
                  yellowCount++;
                  notFound = !this.findPiece(worldIn, countPos, "square");
               } else if (block == BlockInit.neocraftOrange) {
                  orangeCount++;
                  notFound = !this.findPiece(worldIn, countPos, "l");
               }

               if (notFound) {
                  break label153;
               }
            }
         }

         if (blueCount / 4 < lineCount || pinkCount / 4 < tCount || greenCount / 4 < zigCount || yellowCount / 4 < squareCount || orangeCount / 4 < lCount) {
            notFound = true;
         }

         if (notFound) {
            playerIn.sendMessage(new TextComponentString("You have failed to input the correct configuration."));
         } else {
            playerIn.sendMessage(new TextComponentString("Craft Successful!"));
            playerIn.addItemStackToInventory(new ItemStack(ItemInit.solarumVial, 1));
            worldIn.playSound(null, pos, SoundInit.MACHINE_CRAFT, SoundCategory.MASTER, 1.0F, 1.0F);
            this.reset(upDir, rightDir, worldIn, ref);
         }
      }

      return true;
   }

   private void reset(Vec3i upDir, Vec3i rightDir, World worldIn, BlockPos ref) {
      int count = 0;

      for (int i = 0; i <= 5; i++) {
         for (BlockPos clearPos = ref.add(rightDir.getX() * (i * 2 + 1), 1, rightDir.getZ() * (i * 2 + 1));
            worldIn.getBlockState(clearPos).getBlock() != BlockInit.neocraftGoalEmpty && count <= 9;
            clearPos = clearPos.add(0, 1, 0)
         ) {
            count++;
            worldIn.setBlockState(clearPos, BlockInit.neocraftGoalEmpty.getDefaultState());
         }

         count = 0;
      }

      BlockPos checkPos = ref.subtract(upDir);

      while (worldIn.getBlockState(checkPos).getBlock() instanceof BlockNeocraft) {
         checkPos = checkPos.subtract(upDir);
      }

      checkPos = checkPos.add(upDir);

      while (worldIn.getBlockState(checkPos).getBlock() instanceof BlockNeocraft) {
         checkPos = checkPos.subtract(rightDir);
      }

      checkPos = checkPos.add(rightDir);
      BlockPos startPos = checkPos;

      for (int i = 0; i < 12; i++) {
         for (int j = 0; j < 12; j++) {
            BlockPos countPos = startPos.add(
               rightDir.getX() * i + upDir.getX() * j, 0, rightDir.getZ() * i + upDir.getZ() * j
            );
            Block block = worldIn.getBlockState(countPos).getBlock();
            if (block instanceof BlockNeocraft) {
               worldIn.setBlockState(countPos, BlockInit.neocraftUnpowered.getDefaultState());
            }
         }
      }
   }

   private boolean findPiece(World worldIn, BlockPos pos, String pieceName) {
      int[][][] orientations = (int[][][])null;
      Block block = null;
      switch (pieceName) {
         case "line":
            orientations = linePiece;
            block = BlockInit.neocraftBlue;
            break;
         case "l":
            orientations = lPiece;
            block = BlockInit.neocraftOrange;
            break;
         case "t":
            orientations = tPiece;
            block = BlockInit.neocraftPink;
            break;
         case "square":
            orientations = squarePiece;
            block = BlockInit.neocraftYellow;
            break;
         case "zig":
            orientations = zigPiece;
            block = BlockInit.neocraftGreen;
      }

      if (orientations != null && block != null) {
         for (int i = 0; i < orientations.length; i++) {
            int[][] orientation = orientations[i];

            for (int n = 0; n < orientation[0].length; n++) {
               int startX = orientation[0][n];
               int startZ = orientation[1][n];
               boolean orientationFits = true;

               for (int k = 0; k < orientation[0].length; k++) {
                  int relX = orientation[0][k] - startX;
                  int relZ = orientation[1][k] - startZ;
                  BlockPos checkPos = pos.add(relX, 0, relZ);
                  if (worldIn.getBlockState(checkPos).getBlock() != block) {
                     orientationFits = false;
                  }
               }

               if (orientationFits) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }
}
