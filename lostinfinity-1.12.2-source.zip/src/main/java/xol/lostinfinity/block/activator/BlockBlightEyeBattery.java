package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockBlightEyeBattery extends BlockBasic {
   public BlockBlightEyeBattery(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && !worldIn.isRemote) {
         ArrayList<BlockPos> eyes = new ArrayList<>();
         int eyeCount = 0;

         for (int i = -6; i <= 6; i++) {
            for (int j = -6; j < 6; j++) {
               if (worldIn.getBlockState(pos.add(i, 0, j)).getBlock().equals(BlockInit.blightEye)) {
                  eyeCount++;
                  eyes.add(pos.add(i, 0, j));
               }
            }
         }

         if (eyeCount >= 6) {
            ArrayList<BlockPos> mouthBlocks = new ArrayList<>();

            for (int i = -6; i <= 6; i++) {
               for (int jx = -6; jx < 6; jx++) {
                  if (worldIn.getBlockState(pos.add(i, 0, jx)).getBlock().equals(BlockInit.blightMouth)) {
                     mouthBlocks.add(pos.add(i, 0, jx));
                  }
               }
            }

            boolean stack1 = false;
            boolean stack2 = false;
            boolean stack3 = false;
            boolean stack4 = false;
            EntityItem stack1Entity = null;
            EntityItem stack2Entity = null;
            EntityItem stack3Entity = null;
            EntityItem stack4Entity = null;

            for (BlockPos mouthPos : mouthBlocks) {
               AxisAlignedBB aabb = new AxisAlignedBB(mouthPos.up());

               for (EntityItem itemEntity : worldIn.getEntitiesWithinAABB(EntityItem.class, aabb)) {
                  Item testItem = itemEntity.getItem().getItem();
                  if (testItem == ItemInit.basicStorageChip && !stack1) {
                     if (itemEntity.getItem().getCount() >= 3) {
                        stack1Entity = itemEntity;
                        stack1 = true;
                     }
                  } else if (testItem == ItemInit.organicPlate && !stack2) {
                     if (itemEntity.getItem().getCount() >= 10) {
                        stack2Entity = itemEntity;
                        stack2 = true;
                     }
                  } else if (testItem == ItemInit.gloominessenceCubes && !stack3) {
                     if (itemEntity.getItem().getCount() >= 20) {
                        stack3Entity = itemEntity;
                        stack3 = true;
                     }
                  } else if (testItem == ItemInit.organicWire && !stack4 && itemEntity.getItem().getCount() >= 5) {
                     stack4Entity = itemEntity;
                     stack4 = true;
                  }
               }
            }

            if (stack1 && stack2 && stack3 && stack4) {
               EntityItem resultItem = new EntityItem(
                  worldIn,
                  mouthBlocks.get(0).getX(),
                  mouthBlocks.get(0).getY() + 2,
                  mouthBlocks.get(0).getZ(),
                  new ItemStack(ItemInit.darkworldDataChip)
               );
               resultItem.motionX = 0.0;
               resultItem.motionY = 1.0;
               resultItem.motionZ = 0.0;
               resultItem.velocityChanged = true;
               worldIn.spawnEntity(resultItem);
               worldIn.playSound(null, pos.up(), SoundInit.CRUNCHING, SoundCategory.BLOCKS, 2.0F, 1.0F);
               stack1Entity.getItem().shrink(stack1Entity.getItem().getCount());
               stack2Entity.getItem().shrink(stack2Entity.getItem().getCount());
               stack3Entity.getItem().shrink(stack3Entity.getItem().getCount());
               stack4Entity.getItem().shrink(stack4Entity.getItem().getCount());

               for (BlockPos eye : eyes) {
                  worldIn.setBlockState(eye, BlockInit.blightEyeEmpty.getDefaultState());
               }

               playerIn.sendMessage(new TextComponentString(TextFmt.Light_Purple + "Feed the darkness, and it will feed you in return..."));
            }
         }
      }

      return true;
   }
}
