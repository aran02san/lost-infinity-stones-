package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.dimension.data.LightTileMap;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockLightTileGame extends BlockBasic {
   public BlockLightTileGame(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      boolean isCrafter = false;
      if (worldIn.getBlockState(pos).getBlock() == BlockInit.highPoweredCharger) {
         isCrafter = true;
      }

      if (!playerIn.isSneaking()) {
         int col = 9;
         int row = 9;
         int checkoffset = isCrafter ? 2 : 1;
         boolean downX = true;
         boolean downZ = true;

         for (int i = 0; i < 4; i++) {
            int checkX = -checkoffset + i % 2 * checkoffset * 2;
            int checkZ = -checkoffset + MathHelper.floor(i / 2) * checkoffset * 2;
            BlockPos checkPos = new BlockPos(pos.add(checkX, 0, checkZ));
            if (worldIn.getBlockState(checkPos).getBlock() instanceof BlockLightTile) {
               if (checkX > 0) {
                  downX = false;
               }

               if (checkZ > 0) {
                  downZ = false;
               }
               break;
            }
         }

         BlockPos gridStart = pos.add(downX ? -8 - checkoffset : checkoffset, 0, downZ ? -8 - checkoffset : checkoffset);
         if (!isCrafter) {
            if (!worldIn.isRemote) {
               LightTileMap lightTileMap = new LightTileMap(col, row, 10);

               for (int c = 0; c < col; c++) {
                  for (int r = 0; r < row; r++) {
                     if (lightTileMap.getNodeAtLocation(c, r).isLit()) {
                        worldIn.setBlockState(gridStart.add(c, 0, r), BlockInit.lightTileLit.getDefaultState());
                     } else {
                        worldIn.setBlockState(gridStart.add(c, 0, r), BlockInit.lightTileDark.getDefaultState());
                     }
                  }
               }
            }
         } else if (playerIn.getHeldItem(hand).getItem().equals(ItemInit.superchargedCell)) {
            boolean allLit = true;

            label95:
            for (int c = 0; c < col; c++) {
               for (int rx = 0; rx < row; rx++) {
                  if (worldIn.getBlockState(gridStart.add(c, 0, rx)).getBlock() == BlockInit.lightTileDark) {
                     allLit = false;
                     break label95;
                  }
               }
            }

            if (allLit) {
               if (!worldIn.isRemote) {
                  EntityItem cellItem = new EntityItem(
                     worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.overchargedCell)
                  );
                  cellItem.motionX = 0.0;
                  cellItem.motionY = 0.0;
                  cellItem.motionZ = 0.0;
                  worldIn.spawnEntity(cellItem);
                  worldIn.playSound(null, pos.up(), SoundInit.SPECIAL_CRAFT, SoundCategory.BLOCKS, 2.0F, 1.0F);

                  for (int c = 0; c < col; c++) {
                     for (int rxx = 0; rxx < row; rxx++) {
                        worldIn.setBlockState(gridStart.add(c, 0, rxx), BlockInit.lightTileDark.getDefaultState());
                     }
                  }
               }

               playerIn.getHeldItem(hand).shrink(1);
            } else if (!worldIn.isRemote) {
               playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Light tiles not all lit or missing."));
            }
         }
      }

      return true;
   }
}
