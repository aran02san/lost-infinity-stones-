package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.misc.BlockTrackTrigger;
import xol.lostinfinity.dimension.data.MazeMap;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.util.coordinates.CelestialCoordinates;

public class BlockMazeCreator extends Block {
   public BlockMazeCreator(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      if (held.getItem() == ItemInit.mazeToken) {
         if (!worldIn.isRemote) {
            BlockPos mazeStartPos = CelestialCoordinates.mazeReferencePos();
            int col = 29;
            int row = 29;
            MazeMap maze = new MazeMap(col, row);

            for (int c = 0; c < col; c++) {
               for (int r = 0; r < row; r++) {
                  BlockPos mazeReferencePos = mazeStartPos.add(c, 0, r);
                  worldIn.setBlockState(mazeReferencePos, BlockInit.blockTrack.getDefaultState());
                  worldIn.setBlockToAir(mazeReferencePos.up());
               }
            }

            for (int c = 0; c < col; c++) {
               for (int r = 0; r < row; r++) {
                  BlockPos mazeReferencePos = mazeStartPos.add(c, 0, r);
                  if (c == 0 && r == 0) {
                     worldIn.setBlockState(mazeReferencePos.up(), BlockInit.guideBlock.getDefaultState());
                  } else if (c == col - 1 && r == row - 1) {
                     worldIn.setBlockState(mazeReferencePos, BlockInit.blockTrackWin.getDefaultState());
                  } else if (maze.getNodeAtLocation(c, r).getType().equals("path") && maze.getNodeAtLocation(c, r).isVisited()) {
                     worldIn.setBlockState(mazeReferencePos, BlockInit.blockTrack.getDefaultState());
                  } else if (maze.getNodeAtLocation(c, r).getType().equals("trigger") && maze.getNodeAtLocation(c, r).isVisited()) {
                     worldIn.setBlockState(mazeReferencePos, BlockTrackTrigger.randomTriggerBlock(worldIn.rand).getDefaultState());
                  } else {
                     worldIn.setBlockState(mazeReferencePos.up(), BlockInit.trackWall.getDefaultState());
                  }
               }
            }

            worldIn.playSound(null, pos, SoundInit.MAZE_BUILD, SoundCategory.MASTER, 1.0F, 1.0F);
         }

         held.shrink(1);
      }

      return true;
   }
}
