package xol.lostinfinity.block.activator;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicRotational;
import xol.lostinfinity.block.tileentity.TileEntityLightEmitter;
import xol.lostinfinity.init.SoundInit;

public class BlockLightEmitter extends BlockBasicRotational implements ITileEntityProvider {
   public BlockLightEmitter(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public IBlockState getStateNextRotation(IBlockState state) {
      EnumFacing facing = (EnumFacing)state.getValue(FACING);
      switch (facing) {
         case NORTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.EAST);
         case EAST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.SOUTH);
         case SOUTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.WEST);
         case WEST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.NORTH);
         default:
            return state;
      }
   }

   public IBlockState getStateWithFacing(EnumFacing facing) {
      return this.getDefaultState().withProperty(FACING, facing);
   }

   public Vec3d getBeamDir(IBlockState state) {
      EnumFacing facing = (EnumFacing)state.getValue(FACING);
      switch (facing) {
         case NORTH:
            return new Vec3d(0.0, 0.0, -1.0);
         case EAST:
            return new Vec3d(1.0, 0.0, 0.0);
         case SOUTH:
            return new Vec3d(0.0, 0.0, 1.0);
         case WEST:
            return new Vec3d(-1.0, 0.0, 0.0);
         default:
            return new Vec3d(0.0, 0.0, -1.0);
      }
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         worldIn.setBlockState(pos, this.getStateNextRotation(state));
         worldIn.playSound(null, pos, SoundInit.GEAR_MACHINE, SoundCategory.BLOCKS, 0.75F, 0.8F + 0.4F * worldIn.rand.nextFloat());
      }

      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityLightEmitter();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   private TileEntityLightEmitter getTE(World world, BlockPos pos) {
      return (TileEntityLightEmitter)world.getTileEntity(pos);
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }
}
