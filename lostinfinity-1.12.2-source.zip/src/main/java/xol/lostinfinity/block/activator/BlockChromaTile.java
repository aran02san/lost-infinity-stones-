package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityChromaGame;
import xol.lostinfinity.init.BlockInit;

public class BlockChromaTile extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 3);

   public BlockChromaTile(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         worldIn.setBlockState(pos, this.getNewState(worldIn, pos, state, playerIn));
         ArrayList<Vec3i> neighbours = new ArrayList<>();
         neighbours.add(new Vec3i(1, 0, 0));
         neighbours.add(new Vec3i(-1, 0, 0));
         neighbours.add(new Vec3i(0, 0, 1));
         neighbours.add(new Vec3i(0, 0, -1));

         for (Vec3i neighbour : neighbours) {
            IBlockState neighbourState = worldIn.getBlockState(pos.add(neighbour));
            Block block = neighbourState.getBlock();
            if (block instanceof BlockChromaTile) {
               worldIn.setBlockState(pos.add(neighbour), this.getNewState(worldIn, pos, neighbourState, playerIn));
            }
         }
      }

      return true;
   }

   private IBlockState getNewState(World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn) {
      int meta = this.getMetaFromState(state);
      BlockPos ref = pos.add(0, 0, 0);
      int radius = 20;

      for (int i = -radius; i <= radius; i++) {
         for (int j = -radius; j <= radius; j++) {
            BlockPos check = ref.add(i, 0, j);
            if (worldIn.getBlockState(check).getBlock().equals(BlockInit.chromaGame)
               && worldIn.getTileEntity(check) != null
               && worldIn.getTileEntity(check) instanceof TileEntityChromaGame) {
               TileEntityChromaGame tileentity = (TileEntityChromaGame)worldIn.getTileEntity(check);
               if (tileentity.isFirst(playerIn)) {
                  switch (meta) {
                     case 0:
                        return this.getStateFromMeta(1);
                     case 1:
                        return this.getStateFromMeta(0);
                     case 2:
                        return this.getStateFromMeta(3);
                     case 3:
                        return this.getStateFromMeta(2);
                  }
               } else {
                  if (!tileentity.isSecond(playerIn)) {
                     return state;
                  }

                  switch (meta) {
                     case 0:
                        return this.getStateFromMeta(2);
                     case 1:
                        return this.getStateFromMeta(3);
                     case 2:
                        return this.getStateFromMeta(0);
                     case 3:
                        return this.getStateFromMeta(1);
                  }
               }
            }
         }
      }

      return state;
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }
}
