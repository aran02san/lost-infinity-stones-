package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockStarforgeDeclogger extends BlockBasic {
   public BlockStarforgeDeclogger(String name) {
      super(name, Material.ROCK);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         int xpos = 13;
         int freeX = 0;
         List<BlockPos> blocks = new ArrayList<>();

         for (int var16 = -6; var16 >= -9; var16--) {
            BlockPos checkPos = new BlockPos(pos.add(var16, 9, -1));
            IBlockState checkState = worldIn.getBlockState(checkPos);
            if (checkState.getBlock().equals(BlockInit.slagDeposit)) {
               blocks.add(checkPos);
            }
         }

         if (!blocks.isEmpty()) {
            ItemStack resultFromHeld = playerIn.getHeldItem(hand);
            if (!resultFromHeld.isEmpty() && resultFromHeld.getItem().equals(ItemInit.carbonicAcid)) {
               worldIn.playSound(null, pos, SoundEvents.ITEM_BUCKET_FILL_LAVA, SoundCategory.MASTER, 2.0F, worldIn.rand.nextFloat() + 0.5F);
               if (!worldIn.isRemote) {
                  for (BlockPos b : blocks) {
                     worldIn.setBlockState(b, Blocks.FLOWING_LAVA.getDefaultState());
                  }
               }

               playerIn.getHeldItem(hand).shrink(1);
            }
         } else if (!worldIn.isRemote) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Red + "The forge is not clogged. There is no need to unclog it."));
         }
      }

      return true;
   }
}
