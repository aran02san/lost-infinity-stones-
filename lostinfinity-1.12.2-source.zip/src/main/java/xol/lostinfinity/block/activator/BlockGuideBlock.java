package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;

public class BlockGuideBlock extends Block {
   public BlockGuideBlock(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote && worldIn.getBlockState(pos.down()).getBlock() == BlockInit.blockTrackWin) {
         worldIn.setBlockToAir(pos);
         ItemStack stack = playerIn.getHeldItem(hand);
         if (stack.getItem() == ItemInit.webbedIdol) {
            playerIn.setHeldItem(hand, new ItemStack(ItemInit.tokenVycellia));
            playerIn.setPositionAndUpdate(25.5, 31.5, 31.5);
         } else if (stack.getItem() == ItemInit.pendantOfTheStorm) {
            playerIn.setHeldItem(hand, new ItemStack(ItemInit.tokenOzor));
            playerIn.setPositionAndUpdate(25.5, 31.5, 31.5);
         } else if (stack.getItem() == ItemInit.conductiveBar) {
            playerIn.setHeldItem(hand, new ItemStack(ItemInit.tokenThundyron));
            playerIn.setPositionAndUpdate(25.5, 31.5, 31.5);
         } else if (stack.getItem() == ItemInit.jarOfBlood) {
            playerIn.setHeldItem(hand, new ItemStack(ItemInit.tokenBarul));
            playerIn.setPositionAndUpdate(25.5, 31.5, 31.5);
         } else if (stack.getItem() == ItemInit.frostedLog) {
            playerIn.setHeldItem(hand, new ItemStack(ItemInit.tokenCryonus));
            playerIn.setPositionAndUpdate(25.5, 31.5, 31.5);
         }
      }

      return true;
   }
}
