package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockRotatableTileGame extends BlockBasic {
   public BlockRotatableTileGame(String name, boolean hard) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.geocoordinatedOrb);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote) {
               this.reset(pos, worldIn, playerIn, hand, facing, hitX, hitY, hitZ);
            }

            playerIn.getHeldItem(hand).shrink(1);
         } else if (!worldIn.isRemote) {
            BlockPos ref = pos.add(0, 0, 0);
            Vec3i dir = findTileDir(worldIn, ref);
            int xDir = dir.getX();
            int zDir = dir.getZ();
            int dimension = 6;
            ref = ref.add(dir);
            boolean flag = true;

            for (int i = 0; i < dimension; i++) {
               for (int j = 0; j < dimension; j++) {
                  BlockPos tile = ref.add(xDir * i, 0, zDir * j);
                  if (!worldIn.getBlockState(tile).equals(((BlockRotatableTile)BlockInit.rotatableTile).getStateWithFacing(EnumFacing.NORTH))) {
                     flag = false;
                     break;
                  }
               }
            }

            if (flag) {
               EntityItem item = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.georedirectionOrb)
               );
               item.motionX = 0.0;
               item.motionY = 0.0;
               item.motionZ = 0.0;
               worldIn.spawnEntity(item);
               this.reset(pos, worldIn, playerIn, hand, facing, hitX, hitY, hitZ);
            }
         }
      }

      return true;
   }

   private void reset(BlockPos pos, World worldIn, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
      BlockPos ref = pos.add(0, 0, 0);
      Vec3i dir = findTileDir(worldIn, ref);
      int xDir = dir.getX();
      int zDir = dir.getZ();
      int dimension = 6;
      int iterations = 10;
      ref = ref.add(dir);
      ArrayList<BlockPos> tiles = new ArrayList<>();

      for (int i = 0; i < dimension; i++) {
         for (int j = 0; j < dimension; j++) {
            BlockPos tile = ref.add(xDir * i, 0, zDir * j);
            if (worldIn.getBlockState(tile).getBlock().equals(BlockInit.rotatableTile)) {
               tiles.add(tile);
               worldIn.setBlockState(tile, ((BlockRotatableTile)BlockInit.rotatableTile).getStateWithFacing(EnumFacing.NORTH));
            }
         }
      }

      Random rand = new Random();

      for (int k = 0; k < iterations; k++) {
         int index = rand.nextInt(tiles.size());
         IBlockState tileState = worldIn.getBlockState(tiles.get(index));
         Block tileBlock = tileState.getBlock();
         if (tileBlock instanceof BlockRotatableTile) {
            ((BlockRotatableTile)tileBlock).onBlockActivated(worldIn, tiles.get(index), tileState, playerIn, hand, facing, hitX, hitY, hitZ);
         }
      }
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(-1, 0, -1));
      dirs.add(new Vec3i(1, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.rotatableTile)) {
            return dir;
         }
      }

      return null;
   }
}
