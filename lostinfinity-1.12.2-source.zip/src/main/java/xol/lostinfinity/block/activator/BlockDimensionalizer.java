package xol.lostinfinity.block.activator;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.misc.BlockLaunchCoordinator;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.dimension.util.DimensionActivator;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.item.activate.ItemComplexLostMap;

public class BlockDimensionalizer extends Block {
   public BlockDimensionalizer(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         boolean valid_hold = false;
         ItemStack held = playerIn.getHeldItem(hand);
         if (held.getItem() instanceof ItemComplexLostMap && held.hasTagCompound() && held.getTagCompound().getInteger("MapProgress") == 2) {
            valid_hold = true;
         }

         if (!worldIn.isRemote && valid_hold) {
            int[] goals = new int[]{
               held.getTagCompound().getInteger("MapSouth"),
               held.getTagCompound().getInteger("MapNorth"),
               held.getTagCompound().getInteger("MapEast"),
               held.getTagCompound().getInteger("MapWest")
            };
            boolean correct = true;

            for (int i = 0; i < 4; i++) {
               if (correct) {
                  int running_total = 0;

                  for (int j = 0; j < 7; j++) {
                     BlockPos check_pos;
                     if (i < 2) {
                        check_pos = pos.add(-3 + j, 0, i % 2 == 0 ? 4 : -4);
                     } else {
                        check_pos = pos.add(i % 2 == 0 ? 4 : -4, 0, -3 + j);
                     }

                     Block block_at_pos = worldIn.getBlockState(check_pos).getBlock();
                     if (block_at_pos instanceof BlockLaunchCoordinator) {
                        BlockLaunchCoordinator coordinator = (BlockLaunchCoordinator)block_at_pos;
                        running_total += coordinator.getColor() * coordinator.getShape();
                     } else {
                        correct = false;
                        playerIn.sendMessage(new TextComponentString(TextFmt.Red + "Coordinator missing!"));
                     }
                  }

                  int goal = goals[i];
                  if (running_total != goal) {
                     correct = false;
                     String[] rownames = new String[]{"South", "North", "East", "West"};
                     playerIn.sendMessage(
                        new TextComponentString(TextFmt.Red + rownames[i] + " Row did not equal goal of:  " + goal + ". Outcome was: " + running_total)
                     );
                  }
               }
            }

            if (correct) {
               held.shrink(1);
               playerIn.setHeldItem(hand, new ItemStack(ItemInit.mazeToken, 1));
               DimensionActivator.transferEntityWithCoords(playerIn, DimensionInit.celestialVoid, 1465.0, 65.0, 431.0);
            }
         }
      }

      return true;
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Gold + "Match launch coordinator values to Advanced Celestial Map.");
   }
}
