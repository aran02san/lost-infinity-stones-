package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.item.misc.ItemGeolocationOrb;

public class BlockGeolocator extends Block {
   private int blockType = 0;

   public BlockGeolocator(String name, int locatorType) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      this.blockType = locatorType;
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.blockType != 4) {
            if (playerIn.getHeldItem(hand).getItem() instanceof ItemGeolocationOrb) {
               ItemStack stack = playerIn.getHeldItem(hand);
               boolean flag = false;
               if (!stack.hasTagCompound()) {
                  flag = true;
               } else if (stack.getTagCompound().getInteger("geolocator") != this.blockType) {
                  flag = true;
               } else if (stack.getTagCompound().getInteger("geocount") == 1) {
                  playerIn.setHeldItem(hand, new ItemStack(ItemInit.geocoordinatedOrb, 2));
                  if (!worldIn.isRemote) {
                     worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_PLACE, SoundCategory.MASTER, 1.0F, 1.0F);
                  }
               } else {
                  stack.getTagCompound().setInteger("geocount", stack.getTagCompound().getInteger("geocount") - 1);
                  if (!worldIn.isRemote) {
                     worldIn.playSound(null, pos, SoundInit.SCANNER, SoundCategory.MASTER, 1.0F, 1.0F);
                  }

                  boolean run = true;
                  int newType = -1;

                  while (run) {
                     newType = worldIn.rand.nextInt(4);
                     if (newType != this.blockType) {
                        run = false;
                     }
                  }

                  stack.getTagCompound().setInteger("geolocator", newType);
               }

               if (flag) {
                  if (!worldIn.isRemote) {
                     playerIn.sendMessage(new TextComponentString(TextFmt.Gray + "The orb smashes as you attempt to sync it with the geolocator."));
                     worldIn.playSound(null, pos, SoundEvents.BLOCK_GLASS_BREAK, SoundCategory.MASTER, 1.0F, 1.0F);
                  }

                  playerIn.setHeldItem(hand, ItemStack.EMPTY);
               }
            }
         } else if (playerIn.getHeldItem(hand).getItem().equals(ItemInit.deviantGlobe)) {
            playerIn.getHeldItem(hand).shrink(1);
            if (!worldIn.isRemote) {
               worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
               ItemStack geostack = new ItemStack(ItemInit.geolocationOrb);
               geostack.setTagCompound(new NBTTagCompound());
               geostack.getTagCompound().setInteger("geocount", 3);
               geostack.getTagCompound().setInteger("geolocator", worldIn.rand.nextInt(4));
               EntityItem geoloc = new EntityItem(worldIn, playerIn.posX, playerIn.posY, playerIn.posZ, geostack);
               geoloc.motionX = 0.0;
               geoloc.motionY = 0.0;
               geoloc.motionZ = 0.0;
               worldIn.spawnEntity(geoloc);
            }
         }
      }

      return true;
   }
}
