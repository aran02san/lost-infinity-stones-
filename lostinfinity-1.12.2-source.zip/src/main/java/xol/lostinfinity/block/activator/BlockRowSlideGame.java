package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import scala.util.Random;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockRowSlideGame extends BlockBasic {
   public BlockRowSlideGame(String name) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.holotronDisc);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote && this.validInput(playerIn.getHeldItem(hand))) {
               this.reset(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
            }

            playerIn.getHeldItem(hand).shrink(1);
         } else if (!worldIn.isRemote) {
            BlockPos ref = pos.add(0, 0, 0);
            Vec3i dir = findTileDir(worldIn, ref);
            int dirX = dir.getX();
            int dirZ = dir.getZ();
            ref = ref.add(dir);
            int count = 0;
            BlockPos temp = ref;

            while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.rowSlideTile)) {
               temp = ref.add(dirX * ++count, 0, 0);
            }

            int dimension = count;
            boolean flag = true;
            int meta1 = BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref));

            for (int c = 1; c < dimension / 2; c++) {
               for (int r = 1; r < dimension / 2; r++) {
                  if (BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * r))) != meta1) {
                     flag = false;
                     break;
                  }
               }
            }

            int meta2 = BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref.add(dirX * (dimension / 2), 0, 0)));

            for (int c = dimension / 2 + 1; c < dimension; c++) {
               for (int rx = 1; rx < dimension / 2; rx++) {
                  if (BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * rx))) != meta2) {
                     flag = false;
                     break;
                  }
               }
            }

            int meta3 = BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref.add(dirX * (dimension / 2), 0, dirZ * (dimension / 2))));

            for (int c = dimension / 2 + 1; c < dimension; c++) {
               for (int rxx = dimension / 2 + 1; rxx < dimension; rxx++) {
                  if (BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * rxx))) != meta3) {
                     flag = false;
                     break;
                  }
               }
            }

            int meta4 = BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref.add(0, 0, dirZ * (dimension / 2))));

            for (int c = 1; c < dimension / 2; c++) {
               for (int rxxx = dimension / 2 + 1; rxxx < dimension; rxxx++) {
                  if (BlockInit.rowSlideTile.getMetaFromState(worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * rxxx))) != meta4) {
                     flag = false;
                     break;
                  }
               }
            }

            if (meta1 == meta2 || meta1 == meta3 || meta1 == meta4) {
               flag = false;
            }

            if (flag) {
               EntityItem item = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.astralPlaneAnalyzer)
               );
               item.motionX = 0.0;
               item.motionY = 0.0;
               item.motionZ = 0.0;
               worldIn.spawnEntity(item);
               this.reset(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
            }
         }
      }

      return true;
   }

   private void reset(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      BlockPos ref = pos.add(0, 0, 0);
      Vec3i dir = findTileDir(worldIn, ref);
      int dirX = dir.getX();
      int dirZ = dir.getZ();
      int maxRolls = 8;
      int count = 0;
      ref = ref.add(dir);
      BlockPos temp = ref;

      while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.rowSlideTile)) {
         temp = ref.add(dirX * ++count, 0, 0);
      }

      int dimension = count;

      for (int c = 0; c < dimension / 2; c++) {
         for (int r = 0; r < dimension / 2; r++) {
            if (worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * r)).getBlock() instanceof BlockRowSlideTile) {
               worldIn.setBlockState(ref.add(dirX * c, 0, dirZ * r), BlockInit.rowSlideTile.getStateFromMeta(0));
            }
         }
      }

      for (int c = dimension / 2; c < dimension; c++) {
         for (int rx = 0; rx < dimension / 2; rx++) {
            if (worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * rx)).getBlock() instanceof BlockRowSlideTile) {
               worldIn.setBlockState(ref.add(dirX * c, 0, dirZ * rx), BlockInit.rowSlideTile.getStateFromMeta(1));
            }
         }
      }

      for (int c = 0; c < dimension / 2; c++) {
         for (int rxx = dimension / 2; rxx < dimension; rxx++) {
            if (worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * rxx)).getBlock() instanceof BlockRowSlideTile) {
               worldIn.setBlockState(ref.add(dirX * c, 0, dirZ * rxx), BlockInit.rowSlideTile.getStateFromMeta(2));
            }
         }
      }

      for (int c = dimension / 2; c < dimension; c++) {
         for (int rxxx = dimension / 2; rxxx < dimension; rxxx++) {
            if (worldIn.getBlockState(ref.add(dirX * c, 0, dirZ * rxxx)).getBlock() instanceof BlockRowSlideTile) {
               worldIn.setBlockState(ref.add(dirX * c, 0, dirZ * rxxx), BlockInit.rowSlideTile.getStateFromMeta(3));
            }
         }
      }

      Random rand = new Random();

      for (int x = 1; x < dimension + 1; x++) {
         int iterations = rand.nextInt(maxRolls);
         if (iterations > 0) {
            Block block = worldIn.getBlockState(pos.add(dirX * x, 0, 0)).getBlock();
            if (block instanceof BlockRowSlideButton) {
               for (int i = 0; i <= iterations; i++) {
                  ((BlockRowSlideButton)block).onBlockActivated(worldIn, pos.add(dirX * x, 0, 0), state, playerIn, hand, facing, hitX, hitY, hitZ);
               }
            }
         }
      }

      for (int z = 1; z < dimension + 1; z++) {
         int iterations = rand.nextInt(maxRolls);
         if (iterations > 0) {
            Block block = worldIn.getBlockState(pos.add(0, 0, dirZ * z)).getBlock();
            if (block instanceof BlockRowSlideButton) {
               for (int i = 0; i <= iterations; i++) {
                  ((BlockRowSlideButton)block).onBlockActivated(worldIn, pos.add(0, 0, dirZ * z), state, playerIn, hand, facing, hitX, hitY, hitZ);
               }
            }
         }
      }
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(1, 0, -1));
      dirs.add(new Vec3i(-1, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock() instanceof BlockRowSlideTile) {
            return dir;
         }
      }

      return null;
   }
}
