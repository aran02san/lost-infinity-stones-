package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.mob.entity.misc.EntityConnectGameMerchant;

public class BlockConnectButton extends Block {
   public BlockConnectButton(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && !worldIn.isRemote) {
         AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-10, -10, -10), pos.add(10, 10, 10));

         for (EntityConnectGameMerchant merch : worldIn.getEntitiesWithinAABB(EntityConnectGameMerchant.class, checkBox)) {
            if (!merch.playerPlaced() && !merch.isLost()) {
               merch.put(pos, true);
            }
         }
      }

      return true;
   }
}
