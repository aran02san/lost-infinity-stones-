package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityDrillConsole;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockDrillControl extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 5);

   public BlockDrillControl(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         if (playerIn.isSneaking()) {
            int meta = this.getMetaFromState(state);
            if (meta < 5) {
               worldIn.setBlockState(pos, this.getStateFromMeta(meta + 1));
            } else {
               worldIn.setBlockState(pos, this.getStateFromMeta(0));
            }
         } else {
            int meta = this.getMetaFromState(state);
            BlockPos checkPos = GalaxyCoordinates.lucientOreConsolePos();
            IBlockState checkState = worldIn.getBlockState(checkPos);
            Block block = checkState.getBlock();
            if (block instanceof BlockDrillConsole) {
               TileEntity te = worldIn.getTileEntity(checkPos);
               if (te != null && te instanceof TileEntityDrillConsole) {
                  ((TileEntityDrillConsole)te).moveDrill(meta);
               }
            }
         }
      }

      return true;
   }
}
