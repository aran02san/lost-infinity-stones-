package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import xol.lostinfinity.block.basic.BlockBasicBoolState;

public class BlockRhythmTile extends BlockBasicBoolState {
   public BlockRhythmTile(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public IBlockState getActiveState() {
      return this.getDefaultState().withProperty(ACTIVE, true);
   }

   public IBlockState getInactiveState() {
      return this.getDefaultState().withProperty(ACTIVE, false);
   }
}
