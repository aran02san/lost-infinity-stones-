package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockRadionPillar extends BlockBasicBoolState implements ISpecialHarvest {
   private static final boolean DEBUG = false;
   private static final int PILLAR_MAX_HEIGHT = 10;

   public BlockRadionPillar(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return null;
   }

   @Override
   public Item getToolNeeded() {
      return null;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return false;
   }

   public void updateTick(World worldIn, BlockPos pos, IBlockState state, Random rand) {
      if (!worldIn.isRemote) {
         this.unlightPillarSegment(worldIn, pos);
      }
   }

   public void onBlockClicked(World worldIn, BlockPos pos, EntityPlayer playerIn) {
      Iterable<BlockPos> nearBlocks = BlockPos.getAllInBox(pos.add(-10, -10, -10), pos.add(10, 10, 10));
      List<BlockRadionPillar> pillarBlocks = new ArrayList<>();
      List<BlockPos> pillarBlockPositions = new ArrayList<>();
      int pillarCharge = 0;

      for (BlockPos nearPos : nearBlocks) {
         if (worldIn.getBlockState(nearPos).getBlock() instanceof BlockRadionPillar
            && nearPos.getX() == pos.getX()
            && nearPos.getZ() == pos.getZ()) {
            pillarBlocks.add((BlockRadionPillar)worldIn.getBlockState(nearPos).getBlock());
            pillarBlockPositions.add(nearPos);
            if (worldIn.getBlockState(nearPos).getBlock().getMetaFromState(worldIn.getBlockState(nearPos)) == 1) {
               pillarCharge++;
            }
         }
      }

      if (pillarCharge == pillarBlocks.size()) {
         if (!worldIn.isRemote) {
            for (int i = 0; i < pillarBlocks.size(); i++) {
               pillarBlocks.get(i).unlightPillarSegment(worldIn, pillarBlockPositions.get(i));
            }

            playerIn.dropItem(ItemInit.radionFragment, new Random().nextInt(4) + 3);
         }

         playerIn.playSound(SoundInit.ENERGY_PULSE, 1.0F, 1.0F);
      }
   }

   public void lightUpPillarSegment(World worldIn, BlockPos pos) {
      if (!worldIn.isRemote) {
         Iterable<BlockPos> nearBlocks = BlockPos.getAllInBox(pos.add(-10, -10, -10), pos.add(10, 10, 10));
         List<BlockRadionPillar> pillarBlocks = new ArrayList<>();
         List<BlockPos> pillarBlockPositions = new ArrayList<>();

         for (BlockPos nearPos : nearBlocks) {
            if (worldIn.getBlockState(nearPos).getBlock() instanceof BlockRadionPillar) {
               BlockRadionPillar pillarBlock = (BlockRadionPillar)worldIn.getBlockState(nearPos).getBlock();
               if (nearPos.getX() == pos.getX() && nearPos.getZ() == pos.getZ()) {
                  pillarBlocks.add(pillarBlock);
                  pillarBlockPositions.add(nearPos);
               }
            }
         }

         for (int i = 0; i < pillarBlocks.size(); i++) {
            BlockRadionPillar pillarBlock = pillarBlocks.get(i);
            BlockPos pillarBlockPos = pillarBlockPositions.get(i);
            int meta = pillarBlock.getMetaFromState(worldIn.getBlockState(pillarBlockPos));
            if (meta == 0) {
               worldIn.setBlockState(pillarBlockPos, pillarBlock.getStateFromMeta(1));
               break;
            }
         }
      }
   }

   private void unlightPillarSegment(World worldIn, BlockPos pos) {
      if (!worldIn.isRemote) {
         Iterable<BlockPos> nearBlocks = BlockPos.getAllInBox(pos.add(-10, -10, -10), pos.add(10, 10, 10));
         List<BlockRadionPillar> pillarBlocks = new ArrayList<>();
         List<BlockPos> pillarBlockPositions = new ArrayList<>();

         for (BlockPos nearPos : nearBlocks) {
            if (worldIn.getBlockState(nearPos).getBlock() instanceof BlockRadionPillar) {
               BlockRadionPillar pillarBlock = (BlockRadionPillar)worldIn.getBlockState(nearPos).getBlock();
               if (nearPos.getX() == pos.getX() && nearPos.getZ() == pos.getZ()) {
                  pillarBlocks.add(pillarBlock);
                  pillarBlockPositions.add(nearPos);
               }
            }
         }

         Collections.reverse(pillarBlocks);
         Collections.reverse(pillarBlockPositions);

         for (int i = 0; i < pillarBlocks.size(); i++) {
            BlockRadionPillar pillarBlock = pillarBlocks.get(i);
            BlockPos pillarBlockPos = pillarBlockPositions.get(i);
            int meta = pillarBlock.getMetaFromState(worldIn.getBlockState(pillarBlockPos));
            if (meta == 1) {
               worldIn.setBlockState(pillarBlockPos, pillarBlock.getStateFromMeta(0));
               break;
            }
         }
      }
   }
}
