package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockRingGame extends BlockBasic {
   public BlockRingGame(String name) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.highToleranceWire);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote) {
               this.reset(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
            }

            playerIn.getHeldItem(hand).shrink(1);
         } else if (!worldIn.isRemote) {
            BlockPos ref = pos.add(0, -2, 0);
            Vec3i dir = findTileDir(worldIn, ref);
            int xDir = dir.getX();
            int zDir = dir.getZ();
            int count = 0;
            ref = ref.add(dir);
            BlockPos temp = ref;

            while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.ringTile)) {
               temp = ref.add(xDir * ++count, 0, 0);
            }

            int dimension = count;
            boolean flag = true;

            for (int i = 0; i < dimension; i++) {
               for (int j = 0; j < dimension; j++) {
                  BlockPos tile = ref.add(xDir * i, 0, zDir * j);
                  if (!worldIn.getBlockState(tile).equals(BlockInit.ringTile.getStateFromMeta(1))) {
                     flag = false;
                     break;
                  }
               }
            }

            if (flag) {
               EntityItem item = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.highSpeedWire, 1)
               );
               item.motionX = 0.0;
               item.motionY = 0.0;
               item.motionZ = 0.0;
               worldIn.spawnEntity(item);
               this.reset(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
            }
         }
      }

      return true;
   }

   private void reset(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      BlockPos ref = pos.add(0, -2, 0);
      Vec3i dir = findTileDir(worldIn, ref);
      int xDir = dir.getX();
      int zDir = dir.getZ();
      int iterations = 10;
      ref = ref.add(dir);
      int count = 0;
      BlockPos temp = ref;

      while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.ringTile)) {
         temp = ref.add(xDir * ++count, 0, 0);
      }

      int dimension = count;

      for (int i = 0; i < dimension; i++) {
         for (int j = 0; j < dimension; j++) {
            BlockPos tile = ref.add(xDir * i, 0, zDir * j);
            if (worldIn.getBlockState(tile).getBlock().equals(BlockInit.ringTile)) {
               worldIn.setBlockState(tile, BlockInit.ringTile.getStateFromMeta(1));
            }
         }
      }

      Random rand = new Random();

      for (int k = 0; k < iterations; k++) {
         int randx = rand.nextInt(dimension);
         int randz = rand.nextInt(dimension);
         BlockPos tile = ref.add(xDir * randx, 0, zDir * randz);
         if (worldIn.getBlockState(tile).getBlock().equals(BlockInit.ringTile)) {
            ((BlockRingTile)worldIn.getBlockState(tile).getBlock()).onBlockActivated(worldIn, tile, state, playerIn, hand, facing, hitX, hitY, hitZ);
         }
      }

      for (int x = 1; x < dimension + 1; x++) {
         if (iterations > 0) {
            Block block = worldIn.getBlockState(pos.add(xDir * x, 0, 0)).getBlock();
            if (block instanceof BlockRowSlideButton) {
               for (int i = 0; i <= iterations; i++) {
                  ((BlockRingSlideButton)block).onBlockActivated(worldIn, pos.add(xDir * x, 0, 0), state, playerIn, hand, facing, hitX, hitY, hitZ);
               }
            }
         }
      }

      for (int z = 1; z < dimension + 1; z++) {
         if (iterations > 0) {
            Block block = worldIn.getBlockState(pos.add(0, 0, zDir * z)).getBlock();
            if (block instanceof BlockRowSlideButton) {
               for (int i = 0; i <= iterations; i++) {
                  ((BlockRingSlideButton)block).onBlockActivated(worldIn, pos.add(0, 0, zDir * z), state, playerIn, hand, facing, hitX, hitY, hitZ);
               }
            }
         }
      }
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(-1, 0, -1));
      dirs.add(new Vec3i(1, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.ringTile)) {
            return dir;
         }
      }

      return null;
   }
}
