package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.init.TabsInit;

public class BlockItemGameCollector extends Block {
   public BlockItemGameCollector(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         int crates = 0;

         for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
               if (worldIn.getBlockState(pos.add(x, 3, z)).getBlock() == BlockInit.labyrinthLamp
                  && worldIn.getBlockState(pos.add(x, 2, z)).getBlock() == BlockInit.itemChallengeCrate) {
                  crates++;
               }
            }
         }

         ItemStack held = playerIn.getHeldItemMainhand();
         Item resultFromHold = this.resultMap(held.getItem());
         if (crates == 4 && resultFromHold != null) {
            held.shrink(1);
            ItemStack mapstack = new ItemStack(resultFromHold);
            mapstack.setTagCompound(new NBTTagCompound());
            mapstack.getTagCompound().setInteger("MapEntityType", worldIn.rand.nextInt(8));
            mapstack.getTagCompound().setInteger("MapEntityNum", 2 + worldIn.rand.nextInt(4));
            EntityItem geoloc = new EntityItem(worldIn, playerIn.posX, playerIn.posY, playerIn.posZ, mapstack);
            geoloc.motionX = 0.0;
            geoloc.motionY = 0.0;
            geoloc.motionZ = 0.0;
            worldIn.spawnEntity(geoloc);
         }

         worldIn.playSound(null, pos, SoundInit.MACHINE_CRAFT, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }

   private Item resultMap(Item held) {
      if (held == ItemInit.webbedIdol) {
         return ItemInit.ambitionMap;
      } else if (held == ItemInit.conductiveBar) {
         return ItemInit.anticipationMap;
      } else if (held == ItemInit.frostedLog) {
         return ItemInit.resolveMap;
      } else if (held == ItemInit.relicOfTheMirage) {
         return ItemInit.perceptionMap;
      } else {
         return held == ItemInit.jarOfBlood ? ItemInit.crueltyMap : null;
      }
   }
}
