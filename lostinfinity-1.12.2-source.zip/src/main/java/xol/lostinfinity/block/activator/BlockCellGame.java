package xol.lostinfinity.block.activator;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.misc.EntityCellGameMerchant;

public class BlockCellGame extends BlockBasic {
   public BlockCellGame(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   private boolean validInput1(ItemStack stack) {
      return stack.getItem().equals(ItemInit.clovinitePowerBank) && stack.getCount() >= 4;
   }

   private boolean validInput2(ItemStack stack) {
      return stack.getItem().equals(ItemInit.reinforcedBlade);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput1(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote) {
               Random rand = worldIn.rand;
               int radius = 10;
               AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-radius, -radius, -radius), pos.add(radius, radius, radius));

               for (EntityCellGameMerchant merch : worldIn.getEntitiesWithinAABB(EntityCellGameMerchant.class, checkBox)) {
                  ((WorldServer)worldIn)
                     .spawnParticle(
                        EnumParticleTypes.PORTAL,
                        merch.posX,
                        merch.posY,
                        merch.posZ,
                        5,
                        (-0.5 + rand.nextDouble()) * 3.0,
                        0.3,
                        (-0.5 + rand.nextDouble()) * 3.0,
                        0.15F,
                        new int[0]
                     );
                  merch.setDead();
               }

               worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
               EntityCellGameMerchant newMerchant = new EntityCellGameMerchant(worldIn);
               newMerchant.setPosition(pos.getX(), pos.getY() + 1.5, pos.getZ());
               newMerchant.setHealth(420.0F);
               ((WorldServer)worldIn)
                  .spawnParticle(
                     EnumParticleTypes.PORTAL,
                     newMerchant.posX,
                     newMerchant.posY,
                     newMerchant.posZ,
                     8,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.3,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.15F,
                     new int[0]
                  );
               newMerchant.setCellPositions(pos, radius, worldIn, playerIn);
               worldIn.spawnEntity(newMerchant);
            }

            playerIn.getHeldItem(hand).shrink(4);
         }

         if (this.validInput2(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote) {
               Random rand = worldIn.rand;
               int radius = 10;
               AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-radius, -radius, -radius), pos.add(radius, radius, radius));

               for (EntityCellGameMerchant merch : worldIn.getEntitiesWithinAABB(EntityCellGameMerchant.class, checkBox)) {
                  ((WorldServer)worldIn)
                     .spawnParticle(
                        EnumParticleTypes.PORTAL,
                        merch.posX,
                        merch.posY,
                        merch.posZ,
                        5,
                        (-0.5 + rand.nextDouble()) * 3.0,
                        0.3,
                        (-0.5 + rand.nextDouble()) * 3.0,
                        0.15F,
                        new int[0]
                     );
                  merch.setDead();
               }

               worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
               EntityCellGameMerchant newMerchant = new EntityCellGameMerchant(worldIn);
               newMerchant.setPosition(pos.getX(), pos.getY() + 1.5, pos.getZ());
               newMerchant.setHealth(69.0F);
               ((WorldServer)worldIn)
                  .spawnParticle(
                     EnumParticleTypes.PORTAL,
                     newMerchant.posX,
                     newMerchant.posY,
                     newMerchant.posZ,
                     8,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.3,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.15F,
                     new int[0]
                  );
               newMerchant.setCellPositions(pos, radius, worldIn, playerIn);
               worldIn.spawnEntity(newMerchant);
            }

            playerIn.getHeldItem(hand).shrink(1);
         }
      }

      return true;
   }
}
