package xol.lostinfinity.block.activator;

import java.util.Iterator;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicRotational;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.mob.entity.misc.EntityPipeGameMerchant;

public class BlockPipe extends BlockBasicRotational {
   public BlockPipe(String name) {
      this(name, 60.0F, Material.ROCK);
   }

   public BlockPipe(String name, float hardness, Material material) {
      this(name, hardness, material, TabsInit.TAB_BLOCKS);
   }

   public BlockPipe(String name, float hardness, Material material, CreativeTabs tab) {
      super(name, hardness, material, tab);
   }

   public IBlockState getStateNextRotation(IBlockState state) {
      EnumFacing facing = (EnumFacing)state.getValue(FACING);
      switch (facing) {
         case NORTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.EAST);
         case EAST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.SOUTH);
         case SOUTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.WEST);
         case WEST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.NORTH);
         default:
            return state;
      }
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote && hand == playerIn.getActiveHand()) {
         AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-40, -40, -40), pos.add(40, 40, 40));
         Iterator var11 = worldIn.getEntitiesWithinAABB(EntityPipeGameMerchant.class, checkBox).iterator();
         if (var11.hasNext()) {
            EntityPipeGameMerchant merch = (EntityPipeGameMerchant)var11.next();
            merch.rotate(pos);
         }
      }

      return super.onBlockActivated(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
   }

   public IBlockState getStateWithFacing(EnumFacing facing) {
      return this.getDefaultState().withProperty(FACING, facing);
   }
}
