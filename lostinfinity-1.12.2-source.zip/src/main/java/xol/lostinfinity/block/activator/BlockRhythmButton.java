package xol.lostinfinity.block.activator;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.mob.entity.misc.EntityRhythmGameMerchant;

public class BlockRhythmButton extends BlockBasicBoolState {
   public BlockRhythmButton(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         Random rand = new Random();
         AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-10, -10, -10), pos.add(10, 10, 10));

         for (EntityRhythmGameMerchant merch : worldIn.getEntitiesWithinAABB(EntityRhythmGameMerchant.class, checkBox)) {
            ((WorldServer)worldIn)
               .spawnParticle(
                  EnumParticleTypes.PORTAL,
                  merch.posX,
                  merch.posY,
                  merch.posZ,
                  5,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.3,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.15F,
                  new int[0]
               );
            merch.pressButton(pos);
         }
      }

      return true;
   }

   public IBlockState getActiveState() {
      return this.getDefaultState().withProperty(ACTIVE, true);
   }

   public IBlockState getInactiveState() {
      return this.getDefaultState().withProperty(ACTIVE, false);
   }
}
