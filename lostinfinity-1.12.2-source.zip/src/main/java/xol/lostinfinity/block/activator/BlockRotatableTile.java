package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicRotational;
import xol.lostinfinity.init.TabsInit;

public class BlockRotatableTile extends BlockBasicRotational {
   public BlockRotatableTile(String name) {
      this(name, 60.0F, Material.ROCK);
   }

   public BlockRotatableTile(String name, float hardness, Material material) {
      this(name, hardness, material, TabsInit.TAB_BLOCKS);
   }

   public BlockRotatableTile(String name, float hardness, Material material, CreativeTabs tab) {
      super(name, hardness, material, tab);
   }

   public IBlockState getStateNextRotation(IBlockState state) {
      EnumFacing facing = (EnumFacing)state.getValue(FACING);
      switch (facing) {
         case NORTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.EAST);
         case EAST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.SOUTH);
         case SOUTH:
            return this.getDefaultState().withProperty(FACING, EnumFacing.WEST);
         case WEST:
            return this.getDefaultState().withProperty(FACING, EnumFacing.NORTH);
         default:
            return state;
      }
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         worldIn.setBlockState(pos, this.getStateNextRotation(state));
         ArrayList<Vec3i> neighbours = new ArrayList<>();
         neighbours.add(new Vec3i(1, 0, 0));
         neighbours.add(new Vec3i(-1, 0, 0));
         neighbours.add(new Vec3i(0, 0, 1));
         neighbours.add(new Vec3i(0, 0, -1));

         for (Vec3i neighbour : neighbours) {
            IBlockState neighbourState = worldIn.getBlockState(pos.add(neighbour));
            Block block = neighbourState.getBlock();
            if (block instanceof BlockRotatableTile) {
               worldIn.setBlockState(pos.add(neighbour), this.getStateNextRotation(neighbourState));
            }
         }
      }

      return true;
   }

   public IBlockState getStateWithFacing(EnumFacing facing) {
      return this.getDefaultState().withProperty(FACING, facing);
   }
}
