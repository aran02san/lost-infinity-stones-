package xol.lostinfinity.block.activator;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityAlignmentDialGame;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.dimension.util.DimensionActivator;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.item.activate.ItemComplexLostMap;

public class BlockAlignmentDialGame extends BlockBasic implements ITileEntityProvider {
   public BlockAlignmentDialGame(String name) {
      super(name);
   }

   private boolean validMap(ItemStack stack) {
      return stack.getItem() instanceof ItemComplexLostMap && stack.hasTagCompound() && stack.getTagCompound().getInteger("MapProgress") == 2;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      if (this.validMap(held)) {
         if (!worldIn.isRemote && this.checkWin(pos, worldIn, playerIn)) {
            playerIn.getHeldItem(hand).shrink(1);
            playerIn.setHeldItem(hand, new ItemStack(ItemInit.mazeToken, 1));
            DimensionActivator.transferEntityWithCoords(playerIn, DimensionInit.celestialVoid, 1465.0, 65.0, 431.0);
            if (worldIn.getTileEntity(pos) != null) {
               TileEntityAlignmentDialGame tileentity = (TileEntityAlignmentDialGame)worldIn.getTileEntity(pos);
               tileentity.reset();
            }
         }
      } else if (!worldIn.isRemote && worldIn.getTileEntity(pos) != null) {
         TileEntityAlignmentDialGame tileEntity = (TileEntityAlignmentDialGame)worldIn.getTileEntity(pos);
         tileEntity.reset();
      }

      return true;
   }

   private boolean checkWin(BlockPos pos, World worldIn, EntityPlayer playerIn) {
      if (worldIn.getTileEntity(pos) != null) {
         TileEntityAlignmentDialGame tileEntity = (TileEntityAlignmentDialGame)worldIn.getTileEntity(pos);
         Vec3i dir = null;
         String count = tileEntity.getDir();
         switch (count) {
            case "North":
               dir = new Vec3i(0, 0, -1);
               break;
            case "East":
               dir = new Vec3i(1, 0, 0);
               break;
            case "South":
               dir = new Vec3i(0, 0, 1);
               break;
            case "West":
               dir = new Vec3i(-1, 0, 0);
         }

         if (dir != null) {
            int count = tileEntity.getRingCount();
            if (count > 0) {
               for (int i = 1; i <= count; i++) {
                  BlockPos check = pos.add(dir.getX() * count, 0, dir.getZ() * count);
                  if (BlockInit.alignmentTile.getMetaFromState(worldIn.getBlockState(check)) != 1) {
                     playerIn.sendMessage(new TextComponentString(TextFmt.Gold + String.format("The dials must point %s", tileEntity.getDir())));
                     return false;
                  }
               }

               return true;
            }
         }
      }

      return false;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public boolean hasTileEntity() {
      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityAlignmentDialGame();
   }
}
