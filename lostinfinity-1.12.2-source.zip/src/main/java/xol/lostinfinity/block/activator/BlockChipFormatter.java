package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockChipFormatter extends BlockBasic {
   public BlockChipFormatter(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      if (held.getItem() == ItemInit.freshDataChip) {
         BlockPos tablePos = GalaxyCoordinates.ChipTable();
         int pieceId = 0;
         boolean allCorrect = true;

         for (int z = 0; z < 5; z++) {
            for (int x = 0; x < 5; x++) {
               BlockPos addPos = tablePos.add(x, 0, z);
               if (worldIn.getBlockState(addPos).getBlock() instanceof BlockAlienSlide) {
                  BlockAlienSlide slide = (BlockAlienSlide)worldIn.getBlockState(addPos).getBlock();
                  if (slide.getBlockNum() != pieceId) {
                     allCorrect = false;
                  }
               } else {
                  allCorrect = false;
               }

               pieceId++;
            }
         }

         if (allCorrect) {
            held.shrink(1);
            if (!worldIn.isRemote) {
               EntityItem cellItem = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.basicStorageChip)
               );
               cellItem.motionX = 0.0;
               cellItem.motionY = 0.0;
               cellItem.motionZ = 0.0;
               worldIn.spawnEntity(cellItem);
               worldIn.playSound(null, pos.up(), SoundInit.CHIP_FORMAT, SoundCategory.BLOCKS, 2.0F, 1.0F);

               for (int z = 0; z < 5; z++) {
                  for (int x = 0; x < 5; x++) {
                     BlockPos addPos = tablePos.add(x, 0, z);
                     worldIn.setBlockState(addPos, BlockAlienSlide.getSlideByNum(17).getDefaultState());
                  }
               }
            }
         }
      }

      return true;
   }
}
