package xol.lostinfinity.block.activator;

import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.mob.entity.labyrinth.EntityAspect;

public class BlockLabGameType3 extends BlockBasic {
   public BlockLabGameType3(String name) {
      super(name, Material.ROCK);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && !playerIn.getHeldItem(hand).isEmpty()) {
         Item mapItem = this.canStartGame(playerIn.getHeldItem(hand).getItem());
         if (mapItem != null) {
            if (!worldIn.isRemote) {
               EntityAspect aspect = new EntityAspect(worldIn);
               aspect.setPosition(pos.getX(), pos.getY() + 9.0, pos.getZ());
               aspect.setMapDrop(mapItem);
               aspect.setStyle(2);
               worldIn.spawnEntity(aspect);
            } else {
               playerIn.sendMessage(new TextComponentString(TextFmt.Dark_Aqua + "The Echo: So you wish to play a game " + playerIn.getName() + "?"));
               playerIn.sendMessage(new TextComponentString(TextFmt.Gray + "You have 2 minutes to kill the aspect above you."));
            }

            worldIn.playSound(
               playerIn.posX, playerIn.posY, playerIn.posZ, SoundInit.LAB_GAME_BEGIN, SoundCategory.MASTER, 2.0F, 1.0F, false
            );
            playerIn.getHeldItem(hand).shrink(1);
         }
      }

      return true;
   }

   private Item canStartGame(Item held) {
      if (held.equals(ItemInit.deviantFlesh)) {
         return ItemInit.impositionMap;
      } else {
         return held.equals(ItemInit.deviantMushroom) ? ItemInit.retrospectionMap : null;
      }
   }
}
