package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockTimelineStabilizerArrow extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 3);

   public BlockTimelineStabilizerArrow(String name) {
      super(name);
   }

   public static Vec3i getRotatedVec(Vec3i vec, double rad) {
      return new Vec3i(
         Math.round(vec.getX() * Math.cos(rad)) + Math.round(vec.getZ() * Math.sin(rad)),
         vec.getY(),
         Math.round(-vec.getX() * Math.sin(rad)) + Math.round(vec.getZ() * Math.cos(rad))
      );
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack stack = playerIn.getHeldItem(hand);
      if (!worldIn.isRemote && playerIn.isSneaking()) {
         int meta = this.getMetaFromState(state);
         if (meta < 3) {
            worldIn.setBlockState(pos, this.getStateFromMeta(meta + 1));
         } else {
            worldIn.setBlockState(pos, this.getStateFromMeta(0));
         }
      } else if (!worldIn.isRemote) {
         int width = 29;
         int height = 16;
         NBTTagCompound compound = stack.getTagCompound();
         if (!stack.hasTagCompound()) {
            return true;
         }

         if (compound.hasKey("1x") && compound.hasKey("2x")) {
            ArrayList<BlockPos> pillars = new ArrayList<>();
            Vec3i offset = new Vec3i(0, 3, 0);
            pillars.add(
               new BlockPos(
                  compound.getInteger("1x") + offset.getX(),
                  compound.getInteger("1y") + offset.getY(),
                  compound.getInteger("1z") + offset.getZ()
               )
            );
            pillars.add(
               new BlockPos(
                  compound.getInteger("2x") + offset.getX(),
                  compound.getInteger("2y") + offset.getY(),
                  compound.getInteger("2z") + offset.getZ()
               )
            );
            double rad = 0.0;
            double closestDist = 999999.0;
            BlockPos closest = null;

            for (BlockPos pillar : pillars) {
               double dist = pillar.getDistance(pos.getX(), pos.getY(), pos.getZ());
               if (dist < closestDist) {
                  closestDist = dist;
                  closest = pillar;
               }
            }

            if (closest != null) {
               int radius = 40;

               for (int i = -radius; i < radius; i++) {
                  for (int j = -radius; j < radius; j++) {
                     for (int k = -radius; k < radius; k++) {
                        BlockPos check = pos.add(i, j, k);
                        if (worldIn.getBlockState(check).getBlock().equals(BlockInit.timelineStabilizerCapsule)) {
                           int pillarNum = pillars.indexOf(closest);
                           BlockPos ref = pillars.get(pillarNum);
                           int xDir = 1;
                           int zDir = 1;
                           if (worldIn.getBlockState(ref.add(-1, 0, 0)).getBlock().equals(BlockInit.labyrinthGlassBlue)) {
                              xDir = -1;
                           }

                           if (worldIn.getBlockState(ref.add(0, 0, -1)).getBlock().equals(BlockInit.labyrinthGlassBlue)) {
                              zDir = -1;
                           }

                           if (xDir == 1) {
                              if (zDir == 1) {
                                 rad = 0.0;
                              } else {
                                 rad = Math.PI / 2;
                              }
                           } else if (zDir == 1) {
                              rad = Math.PI * 3.0 / 2.0;
                           } else {
                              rad = Math.PI;
                           }

                           ref = ref.add(xDir, 0, zDir);
                           int meta = this.getMetaFromState(state);
                           int xDiff = check.getX() - closest.getX() - 1 * xDir;
                           int zDiff = check.getZ() - closest.getZ() - 1 * zDir;
                           Vec3i cornerDir = null;
                           boolean byRight = xDiff == 0;
                           boolean byLeft = xDiff == width / 4;
                           boolean byFront = zDiff == 0;
                           boolean byBack = zDiff == width / 4;
                           boolean onRight = xDiff == -1;
                           boolean onLeft = xDiff == width / 4 + 1;
                           boolean onBack = zDiff == width / 4 + 1;
                           boolean onFront = zDiff == -1;
                           if (rad == 0.0) {
                              byRight = xDiff == 0;
                              byLeft = xDiff == width / 4;
                              byFront = zDiff == 0;
                              byBack = zDiff == width / 4;
                              onRight = xDiff == -1;
                              onLeft = xDiff == width / 4 + 1;
                              onBack = zDiff == width / 4 + 1;
                              onFront = zDiff == -1;
                           } else if (rad == Math.PI / 2) {
                              byRight = zDiff == 0;
                              byLeft = zDiff == -(width / 4);
                              byBack = xDiff == width / 4;
                              byFront = xDiff == 0;
                              onRight = zDiff == 1;
                              onLeft = zDiff == -(width / 4) - 1;
                              onFront = xDiff == -1;
                              onBack = xDiff == width / 4 + 1;
                           } else if (rad == Math.PI) {
                              byLeft = xDiff == -width / 4;
                              byRight = xDiff == 0;
                              byBack = zDiff == -(width / 4);
                              byFront = zDiff == 0;
                              onLeft = xDiff == -width / 4 - 1;
                              onRight = xDiff == 1;
                              onFront = zDiff == 1;
                              onBack = zDiff == -(width / 4) - 1;
                           } else if (rad == Math.PI * 3.0 / 2.0) {
                              byLeft = zDiff == width / 4;
                              byRight = zDiff == 0;
                              byFront = xDiff == 0;
                              byBack = xDiff == -(width / 4);
                              onLeft = zDiff == width / 4 + 1;
                              onRight = zDiff == -1;
                              onBack = xDiff == -(width / 4) - 1;
                              onFront = xDiff == 1;
                           }

                           Vec3i dir = new Vec3i(0, 0, 0);
                           switch (meta) {
                              case 0:
                                 if (byFront && !byRight) {
                                    dir = new Vec3i(-1, 0, 0);
                                 } else if (byRight && !byBack) {
                                    dir = new Vec3i(0, 0, 1);
                                 } else if (byBack && !byLeft) {
                                    dir = new Vec3i(1, 0, 0);
                                 } else if (byLeft && !byFront) {
                                    dir = new Vec3i(0, 0, -1);
                                 }
                                 break;
                              case 1:
                                 dir = new Vec3i(0, 1, 0);
                                 break;
                              case 2:
                                 if (byFront && !byLeft) {
                                    dir = new Vec3i(1, 0, 0);
                                 } else if (byRight && !byFront) {
                                    dir = new Vec3i(0, 0, -1);
                                 } else if (byBack && !byRight) {
                                    dir = new Vec3i(-1, 0, 0);
                                 } else if (byLeft && !byBack) {
                                    dir = new Vec3i(0, 0, 1);
                                 }
                                 break;
                              case 3:
                                 dir = new Vec3i(0, -1, 0);
                           }

                           dir = getRotatedVec(dir, rad);
                           int relativeY = check.subtract(closest).getY();
                           if (relativeY >= 11) {
                              return true;
                           }

                           if (cornerDir != null) {
                              cornerDir = getRotatedVec(cornerDir, rad);
                           }

                           if (worldIn.getBlockState(check.add(dir)).getBlock().equals(BlockInit.timelineStabilizerGoal)) {
                              if (pillarNum == 0) {
                                 BlockPos next = pillars.get(pillarNum + 1);
                                 int nextXDir = 1;
                                 int nextZDir = 1;
                                 if (worldIn.getBlockState(next.add(-1, 0, 0)).getBlock().equals(BlockInit.labyrinthGlassBlue)) {
                                    nextXDir = -1;
                                 }

                                 if (worldIn.getBlockState(next.add(0, 0, -1)).getBlock().equals(BlockInit.labyrinthGlassBlue)) {
                                    nextZDir = -1;
                                 }

                                 if (nextXDir == 1) {
                                    if (nextZDir == 1) {
                                       rad = 0.0;
                                    } else {
                                       rad = Math.PI / 2;
                                    }
                                 } else if (nextZDir == 1) {
                                    rad = Math.PI * 3.0 / 2.0;
                                 } else {
                                    rad = Math.PI;
                                 }

                                 BlockPos nextRef = next.add(nextXDir * 1, -4, nextZDir * 1);
                                 worldIn.setBlockToAir(check);
                                 worldIn.setBlockState(nextRef, BlockInit.timelineStabilizerCapsule.getDefaultState());
                                 worldIn.playSound(null, playerIn.getPosition(), SoundInit.MYSTERY_VOICE_TRANSMISSION, SoundCategory.BLOCKS, 1.5F, 1.0F);
                              } else {
                                 worldIn.setBlockToAir(check);
                                 this.win(check.add(dir), worldIn, playerIn);
                              }

                              return true;
                           }

                           if ((worldIn.isAirBlock(check.add(dir)) || cornerDir != null && worldIn.isAirBlock(check.add(cornerDir)))
                              && worldIn.isAirBlock(check.add(dir))) {
                              worldIn.setBlockState(check.add(dir), BlockInit.timelineStabilizerCapsule.getDefaultState());
                              worldIn.setBlockToAir(check);
                              worldIn.playSound(
                                 null,
                                 playerIn.getPosition(),
                                 SoundInit.GEAR_MACHINE_2,
                                 SoundCategory.BLOCKS,
                                 1.5F,
                                 0.8F + worldIn.rand.nextFloat() * 0.4F
                              );
                              return true;
                           }
                        }
                     }
                  }
               }
            }
         }
      }

      return true;
   }

   private void win(BlockPos pos, World worldIn, EntityPlayer playerIn) {
      EntityItem reward = new EntityItem(
         worldIn, playerIn.posX, playerIn.posY, playerIn.posZ, new ItemStack(ItemInit.multiTimelineDataChip)
      );
      reward.motionX = 0.0;
      reward.motionY = 0.0;
      reward.motionZ = 0.0;
      worldIn.spawnEntity(reward);
      worldIn.playSound(null, playerIn.getPosition(), SoundInit.MYSTERY_VOICE_TRANSMISSION, SoundCategory.BLOCKS, 1.5F, 1.0F);
   }

   private boolean onTrack(BlockPos check, Chunk chunk) {
      ArrayList<Vec3i> positions = new ArrayList<>();
      positions.add(new Vec3i(1, 0, 0));
      positions.add(new Vec3i(-1, 0, 0));
      positions.add(new Vec3i(0, 0, 1));
      positions.add(new Vec3i(0, 0, -1));

      for (Vec3i pos : positions) {
         if (chunk.getBlockState(check.add(pos)).getBlock().equals(BlockInit.trackWall)) {
            return true;
         }
      }

      return false;
   }

   private void transfer(World worldIn, BlockPos pos) {
   }

   private boolean onTrack(BlockPos check, World worldIn) {
      ArrayList<Vec3i> positions = new ArrayList<>();
      positions.add(new Vec3i(1, 0, 0));
      positions.add(new Vec3i(-1, 0, 0));
      positions.add(new Vec3i(0, 0, 1));
      positions.add(new Vec3i(0, 0, -1));

      for (Vec3i pos : positions) {
         if (worldIn.getBlockState(check.add(pos)).getBlock().equals(BlockInit.trackWall)) {
            return true;
         }
      }

      return false;
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }
}
