package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.Stack;
import net.minecraft.block.Block;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityAncientSymbolInterpreter;

public class BlockAncientSymbol extends BlockBasic {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 15);

   public BlockAncientSymbol(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         if (this.getMetaFromState(state) != 0) {
            return true;
         }

         BlockPos interpreter = this.findInterpreter(worldIn, pos);
         if (interpreter != null) {
            TileEntity tileEntity = worldIn.getTileEntity(interpreter);
            if (tileEntity != null && tileEntity instanceof TileEntityAncientSymbolInterpreter) {
               TileEntityAncientSymbolInterpreter TE = (TileEntityAncientSymbolInterpreter)tileEntity;
               TE.flip(pos);
            }
         }
      }

      return true;
   }

   private BlockPos findInterpreter(World worldIn, BlockPos pos) {
      ArrayList<BlockPos> visited = new ArrayList<>();
      Stack<BlockPos> toVisit = new Stack<>();
      visited.add(pos);
      toVisit.addAll(this.getNeighbours(pos));

      while (!toVisit.isEmpty()) {
         BlockPos node = toVisit.pop();
         if (node != null) {
            Block block = worldIn.getBlockState(node).getBlock();
            Block upBlock = worldIn.getBlockState(node.add(0, 3, 0)).getBlock();
            if (block instanceof BlockAncientSymbol) {
               visited.add(node);

               for (BlockPos neighbour : this.getNeighbours(node)) {
                  if (!visited.contains(neighbour)) {
                     toVisit.add(neighbour);
                  }
               }
            } else if (upBlock instanceof BlockAncientSymbolInterpreter) {
               return node.add(0, 3, 0);
            }
         }
      }

      return null;
   }

   ArrayList<BlockPos> getNeighbours(BlockPos pos) {
      ArrayList<BlockPos> neighbours = new ArrayList<>();
      neighbours.add(pos.add(1, 0, 0));
      neighbours.add(pos.add(-1, 0, 0));
      neighbours.add(pos.add(1, 0, 1));
      neighbours.add(pos.add(1, 0, -1));
      neighbours.add(pos.add(-1, 0, 1));
      neighbours.add(pos.add(-1, 0, -1));
      neighbours.add(pos.add(0, 0, 1));
      neighbours.add(pos.add(0, 0, -1));
      return neighbours;
   }
}
