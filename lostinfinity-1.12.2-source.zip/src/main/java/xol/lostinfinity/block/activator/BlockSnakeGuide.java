package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicRotational;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.mob.entity.contest.controller.EntityControllerBattleSnakes;
import xol.lostinfinity.util.coordinates.ContestCoordinates;

public class BlockSnakeGuide extends BlockBasicRotational {
   public BlockSnakeGuide(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         AxisAlignedBB arena = ContestCoordinates.battleSnakesArenaAABB();
         EntityControllerBattleSnakes controller = null;

         for (EntityControllerBattleSnakes entity : worldIn.getEntitiesWithinAABB(EntityControllerBattleSnakes.class, arena)) {
            if (!entity.isDead) {
               controller = entity;
               break;
            }
         }

         if (controller != null) {
            if (state.getBlock().equals(BlockInit.snakeGuideLeft)) {
               controller.turnSnake(pos, false);
            } else if (state.getBlock().equals(BlockInit.snakeGuideRight)) {
               controller.turnSnake(pos, true);
            }
         }
      }

      return true;
   }
}
