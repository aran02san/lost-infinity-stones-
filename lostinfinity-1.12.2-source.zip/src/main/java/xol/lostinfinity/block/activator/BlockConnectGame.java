package xol.lostinfinity.block.activator;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.mob.entity.misc.EntityConnectGameMerchant;

public class BlockConnectGame extends Block {
   private boolean hard_mode = false;

   public BlockConnectGame(String name, boolean hard) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      this.hard_mode = hard;
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   private boolean validInput(Item item) {
      return item.equals(ItemInit.frostedLog);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && this.validInput(playerIn.getHeldItem(hand).getItem())) {
         if (!worldIn.isRemote) {
            Random rand = worldIn.rand;
            AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-10, -10, -10), pos.add(10, 10, 10));

            for (EntityConnectGameMerchant merch : worldIn.getEntitiesWithinAABB(EntityConnectGameMerchant.class, checkBox)) {
               merch.clearTokens();
               merch.setDead();
            }

            worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
            EntityConnectGameMerchant newMerchant = new EntityConnectGameMerchant(worldIn);
            newMerchant.setPosition(pos.getX(), pos.getY() + 1.5, pos.getZ());
            ((WorldServer)worldIn)
               .spawnParticle(
                  EnumParticleTypes.PORTAL,
                  newMerchant.posX,
                  newMerchant.posY,
                  newMerchant.posZ,
                  8,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.3,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.15F,
                  new int[0]
               );
            newMerchant.setButtonPositions(pos, 8, 8, 4);
            newMerchant.clearTokens();
            worldIn.spawnEntity(newMerchant);
         }

         playerIn.getHeldItem(hand).shrink(1);
      }

      return true;
   }
}
