package xol.lostinfinity.block.activator;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityCircuitCalibrator;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;

public class BlockCircuitCalibrator extends BlockBasic implements ITileEntityProvider {
   public BlockCircuitCalibrator(String name) {
      super(name);
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityCircuitCalibrator();
   }

   public boolean hasTileEntity() {
      return true;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      TileEntity tileEntity = worldIn.getTileEntity(pos);
      ItemStack stack = playerIn.getHeldItem(hand);
      if (tileEntity != null && tileEntity instanceof TileEntityCircuitCalibrator && stack.getItem() == ItemInit.timeTrigger) {
         TileEntityCircuitCalibrator deviceEntity = (TileEntityCircuitCalibrator)tileEntity;
         if (!worldIn.isRemote) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Green + "React quickly to calibrate the circuit! Click the monitor when it is green!"));
            deviceEntity.startGame();
         }

         stack.shrink(1);
      }

      return true;
   }
}
