package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.mob.entity.starforge.EntityEssenceIdol;

public class BlockGloomIdol extends Block {
   public BlockGloomIdol(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && playerIn.getHeldItem(hand).getItem().equals(ItemInit.gloomshadowStone)) {
         if (!worldIn.isRemote) {
            BlockPos reference = pos.add(0, 2, 0);
            AxisAlignedBB aabb = new AxisAlignedBB(reference.add(-32, -5, -32), reference.add(32, 15, 32));

            for (EntityEssenceIdol existing_idols : worldIn.getEntitiesWithinAABB(EntityEssenceIdol.class, aabb)) {
               existing_idols.setDead();
            }

            EntityEssenceIdol idol = new EntityEssenceIdol(worldIn);
            idol.setPosition(pos.getX(), pos.getY() + 1, pos.getZ());
            idol.setGameRef(reference, 1);
            idol.darkenAll();
            worldIn.spawnEntity(idol);
         }

         playerIn.getHeldItem(hand).shrink(1);
         worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }
}
