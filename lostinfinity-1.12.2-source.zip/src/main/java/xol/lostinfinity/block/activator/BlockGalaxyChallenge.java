package xol.lostinfinity.block.activator;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.mob.entity.starforge.EntityGalacticTerror;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;

public class BlockGalaxyChallenge extends Block {
   public BlockGalaxyChallenge(String name) {
      super(Material.IRON);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(3.0F);
      this.setCreativeTab(TabsInit.TAB_BLOCKS);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         ItemStack stack = playerIn.getHeldItem(hand);
         if (stack.getItem() == ItemInit.galacticChallengeEmblem) {
            if (!worldIn.isRemote) {
               AxisAlignedBB teleport = GalaxyCoordinates.getShockArenaAABB();
               playerIn.setPositionAndUpdate(teleport.minX + 6.0, teleport.minY + 2.0, teleport.minZ + 6.0);
               EntityGalacticTerror terror = new EntityGalacticTerror(worldIn);
               terror.setPosition(teleport.maxX - 6.0, teleport.minY + 3.0, teleport.maxZ - 6.0);
               worldIn.spawnEntity(terror);
            }

            stack.shrink(1);
         }
      }

      return true;
   }
}
