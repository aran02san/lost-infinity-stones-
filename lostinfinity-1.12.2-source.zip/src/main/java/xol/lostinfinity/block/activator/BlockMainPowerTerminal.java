package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.item.activate.ItemEncryptedPowerBlueprints;

public class BlockMainPowerTerminal extends BlockBasic {
   public BlockMainPowerTerminal(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      if (held.getItem() == ItemInit.wiredRing) {
         if (!worldIn.isRemote) {
            held.shrink(1);
            EntityItem item = new EntityItem(
               worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.encryptedPowerBlueprints)
            );
            item.motionX = 0.0;
            item.motionY = 0.0;
            item.motionZ = 0.0;
            worldIn.spawnEntity(item);
         }
      } else if (held.getItem() == ItemInit.encryptedPowerBlueprints && !worldIn.isRemote) {
         ItemEncryptedPowerBlueprints scroll = (ItemEncryptedPowerBlueprints)held.getItem();
         if (scroll.getCompletion(held) == 3) {
            held.shrink(1);
            EntityItem item = new EntityItem(
               worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.electricalAccelerator)
            );
            item.motionX = 0.0;
            item.motionY = 0.0;
            item.motionZ = 0.0;
            worldIn.spawnEntity(item);
         }
      }

      return true;
   }
}
