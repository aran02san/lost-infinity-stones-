package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.mob.entity.sea.EntityFish;

public class BlockFishChow extends BlockBasic {
   public BlockFishChow(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         playerIn.sendMessage(new TextComponentString(TextFmt.Red + "You break off some of the fish chow."));
         int radius = 25;

         for (EntityFish fish : worldIn.getEntitiesWithinAABB(EntityFish.class, new AxisAlignedBB(pos).grow(radius, radius, radius))) {
            fish.setTargetPos(pos.up());
         }
      }

      return true;
   }
}
