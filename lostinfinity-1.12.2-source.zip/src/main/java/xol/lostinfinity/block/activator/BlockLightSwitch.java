package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;

public class BlockLightSwitch extends BlockBasic {
   public BlockLightSwitch(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         if (state.getBlock().equals(BlockInit.lightSwitchOn)) {
            worldIn.setBlockState(pos, BlockInit.lightSwitchOff.getDefaultState());
         } else {
            worldIn.setBlockState(pos, BlockInit.lightSwitchOn.getDefaultState());
         }

         worldIn.playSound(null, pos, SoundEvents.BLOCK_LEVER_CLICK, SoundCategory.BLOCKS, 2.0F, 1.0F);
      }

      return true;
   }
}
