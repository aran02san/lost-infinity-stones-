package xol.lostinfinity.block.activator;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.block.tileentity.TileEntityAlignmentDialGame;
import xol.lostinfinity.init.BlockInit;

public class BlockAlignmentTile extends BlockBasicBoolState {
   public BlockAlignmentTile(String name) {
      super(name);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         int radius = 15;

         for (int i = -radius; i <= radius; i++) {
            for (int j = -radius; j <= radius; j++) {
               BlockPos check = pos.add(i, 0, j);
               if (worldIn.getBlockState(check).getBlock().equals(BlockInit.alignmentDialGame) && worldIn.getTileEntity(check) != null) {
                  TileEntityAlignmentDialGame tileEntity = (TileEntityAlignmentDialGame)worldIn.getTileEntity(check);
                  tileEntity.toggleRing(pos);
               }
            }
         }
      }

      return true;
   }
}
