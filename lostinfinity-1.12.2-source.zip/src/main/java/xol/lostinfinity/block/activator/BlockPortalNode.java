package xol.lostinfinity.block.activator;

import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.block.tileentity.TileEntityPortalNexus;
import xol.lostinfinity.block.tileentity.TileEntityPortalNode;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockPortalNode extends BlockBasicBoolState implements ITileEntityProvider {
   public BlockPortalNode(String name) {
      super(name);
   }

   private boolean validInput(Item item) {
      return item.equals(ItemInit.blightedCapacitor);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand).getItem())) {
            if (!worldIn.isRemote) {
               if (state.equals(BlockInit.portalNode.getStateFromMeta(0))) {
                  int radius = 15;
                  TileEntityPortalNode node = (TileEntityPortalNode)worldIn.getTileEntity(pos);
                  if (node != null) {
                     TileEntityPortalNexus nexus = null;
                     BlockPos nexusPos = null;

                     label55:
                     for (int i = -radius; i <= radius; i++) {
                        for (int k = -radius; k <= radius; k++) {
                           nexusPos = pos.add(i, 0, k);
                           if (worldIn.getBlockState(nexusPos).getBlock().equals(BlockInit.portalNexus)) {
                              nexus = (TileEntityPortalNexus)worldIn.getTileEntity(nexusPos);
                              break label55;
                           }
                        }
                     }

                     if (nexus != null && nexusPos != null) {
                        nexus.addNodePos(pos);
                     }
                  }

                  worldIn.setBlockState(pos, BlockInit.portalNode.getStateFromMeta(1));
               }
            } else {
               int radius = 15;
               TileEntityPortalNode node = (TileEntityPortalNode)worldIn.getTileEntity(pos);
               if (node != null) {
                  TileEntityPortalNexus nexus = null;
                  BlockPos nexusPos = null;

                  label73:
                  for (int i = -radius; i <= radius; i++) {
                     for (int kx = -radius; kx <= radius; kx++) {
                        nexusPos = pos.add(i, 0, kx);
                        if (worldIn.getBlockState(nexusPos).getBlock().equals(BlockInit.portalNexus)) {
                           nexus = (TileEntityPortalNexus)worldIn.getTileEntity(nexusPos);
                           break label73;
                        }
                     }
                  }

                  if (nexus != null && nexusPos != null) {
                     node.setNexusPos(nexusPos);
                  }
               }
            }
         }

         playerIn.getHeldItem(hand).shrink(1);
      }

      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityPortalNode();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }
}
