package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import xol.lostinfinity.block.basic.BlockBasicPillar;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.misc.EntityPipeGameMerchant;

public class BlockPipeGame extends BlockBasicPillar {
   private boolean hard_mode = false;
   private Vec3i dir;

   public BlockPipeGame(String name, boolean hard) {
      super(name, Material.IRON);
      this.setLightLevel(1.0F);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.florocite) && stack.getCount() >= 10;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && this.validInput(playerIn.getHeldItem(hand))) {
         if (!worldIn.isRemote) {
            Random rand = worldIn.rand;
            AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-10, -10, -10), pos.add(10, 10, 10));

            for (EntityPipeGameMerchant merch : worldIn.getEntitiesWithinAABB(EntityPipeGameMerchant.class, checkBox)) {
               ((WorldServer)worldIn)
                  .spawnParticle(
                     EnumParticleTypes.PORTAL,
                     merch.posX,
                     merch.posY,
                     merch.posZ,
                     5,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.3,
                     (-0.5 + rand.nextDouble()) * 3.0,
                     0.15F,
                     new int[0]
                  );
               merch.setDead();
            }

            worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
            EntityPipeGameMerchant newMerchant = new EntityPipeGameMerchant(worldIn);
            BlockPos spawnPos = this.findSpawnPos(worldIn, pos);
            newMerchant.setPosition(spawnPos.getX(), spawnPos.getY() + 1.5, spawnPos.getZ());
            ((WorldServer)worldIn)
               .spawnParticle(
                  EnumParticleTypes.PORTAL,
                  newMerchant.posX,
                  newMerchant.posY,
                  newMerchant.posZ,
                  8,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.3,
                  (-0.5 + rand.nextDouble()) * 3.0,
                  0.15F,
                  new int[0]
               );
            newMerchant.setGridSize(29, 29);
            newMerchant.genPipeGame(worldIn, pos);
            worldIn.spawnEntity(newMerchant);
            newMerchant.startGame();
         }

         playerIn.getHeldItem(hand).shrink(10);
      }

      return true;
   }

   private BlockPos findSpawnPos(World world, BlockPos pos) {
      BlockPos pos1 = this.findNearestPipe(world, pos);
      if (pos1 != null) {
         BlockPos pos2 = this.findNearestPipe(world, pos1);
         if (pos2 != null) {
            if (pos2.getX() == pos1.getX()) {
               boolean zdir = pos2.getZ() > pos1.getZ();
               this.dir = new Vec3i(zdir ? -2 : 2, 0, zdir ? 2 : -2);
            } else {
               boolean xdir = pos2.getX() > pos1.getX();
               this.dir = new Vec3i(xdir ? 2 : -2, 0, xdir ? 2 : -2);
            }
         }
      }

      return this.dir != null ? pos.add(this.dir) : pos;
   }

   private BlockPos findNearestPipe(World world, BlockPos pos) {
      ArrayList<BlockPos> positions = new ArrayList<>();
      positions.add(pos.add(1, 0, 0));
      positions.add(pos.add(-1, 0, 0));
      positions.add(pos.add(0, 0, 1));
      positions.add(pos.add(0, 0, -1));
      positions.add(pos.add(1, 0, 1));
      positions.add(pos.add(1, 0, -1));
      positions.add(pos.add(-1, 0, 1));
      positions.add(pos.add(-1, 0, -1));

      for (BlockPos position : positions) {
         Block block = world.getBlockState(position).getBlock();
         if (block instanceof BlockPipe) {
            return position;
         }
      }

      return pos;
   }
}
