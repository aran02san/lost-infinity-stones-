package xol.lostinfinity.block.activator;

import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityMelodicSequencer;
import xol.lostinfinity.init.ItemInit;

public class BlockMelodicSequencer extends BlockBasic implements ITileEntityProvider {
   public BlockMelodicSequencer(String name) {
      super(name);
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   @Nullable
   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityMelodicSequencer();
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      TileEntity tileEntity = worldIn.getTileEntity(pos);
      ItemStack stack = playerIn.getHeldItem(hand);
      if (tileEntity != null && tileEntity instanceof TileEntityMelodicSequencer && stack.getItem() == ItemInit.blankOpticalDisc) {
         TileEntityMelodicSequencer deviceEntity = (TileEntityMelodicSequencer)tileEntity;
         if (!worldIn.isRemote) {
            playerIn.sendMessage(new TextComponentString("Repeat the sequences!"));
            deviceEntity.startGame();
         }

         stack.shrink(1);
      }

      return true;
   }

   @Nullable
   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }
}
