package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockRowToggleGame extends BlockBasic {
   public BlockRowToggleGame(String name) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.polychargeSolution) && stack.getCount() >= 10;
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote) {
               this.reset(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
            }

            playerIn.getHeldItem(hand).shrink(10);
         } else if (!worldIn.isRemote) {
            BlockPos ref = pos.add(0, 0, 0);
            Vec3i dir = findTileDir(worldIn, ref);
            int xDir = dir.getX();
            int zDir = dir.getZ();
            int count = 0;
            ref = ref.add(dir);
            BlockPos temp = ref;

            while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.rowToggleTile)) {
               temp = ref.add(xDir * ++count, 0, 0);
            }

            int dimension = count;
            boolean flag = true;

            for (int i = 0; i < dimension; i++) {
               for (int j = 0; j < dimension; j++) {
                  BlockPos tile = ref.add(xDir * i, 0, zDir * j);
                  if (!worldIn.getBlockState(tile).equals(BlockInit.rowToggleTile.getStateFromMeta(1))) {
                     flag = false;
                     break;
                  }
               }
            }

            if (flag) {
               EntityItem item = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.electrolysisSolution, 10)
               );
               item.motionX = 0.0;
               item.motionY = 0.0;
               item.motionZ = 0.0;
               worldIn.spawnEntity(item);
               this.reset(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
            }
         }
      }

      return true;
   }

   private void reset(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      BlockPos ref = pos.add(0, 0, 0);
      Vec3i dir = findTileDir(worldIn, ref);
      int xDir = dir.getX();
      int zDir = dir.getZ();
      int maxIterations = 200;
      ref = ref.add(dir);
      int count = 0;
      BlockPos temp = ref;

      while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.rowToggleTile)) {
         temp = ref.add(xDir * ++count, 0, 0);
      }

      int dimension = count;

      for (int i = 0; i < dimension; i++) {
         for (int j = 0; j < dimension; j++) {
            BlockPos tile = ref.add(xDir * i, 0, zDir * j);
            if (worldIn.getBlockState(tile).getBlock().equals(BlockInit.rowToggleTile)) {
               worldIn.setBlockState(tile, BlockInit.rowToggleTile.getStateFromMeta(0));
            }
         }
      }

      ref = pos.add(0, 0, 0);
      Random rand = new Random();
      int iterations = rand.nextInt(maxIterations + 1);

      for (int k = 0; k < iterations; k++) {
         for (int i = 1; i <= dimension; i++) {
            if (rand.nextBoolean()) {
               Block button = worldIn.getBlockState(ref.add(xDir * i, 0, 0)).getBlock();
               if (button instanceof BlockRowToggleButton) {
                  ((BlockRowToggleButton)button).onBlockActivated(worldIn, ref.add(xDir * i, 0, 0), state, playerIn, hand, facing, hitX, hitY, hitZ);
               }
            }
         }

         for (int jx = 1; jx <= dimension; jx++) {
            if (rand.nextBoolean()) {
               Block button = worldIn.getBlockState(ref.add(0, 0, zDir * jx)).getBlock();
               if (button instanceof BlockRowToggleButton) {
                  ((BlockRowToggleButton)button).onBlockActivated(worldIn, ref.add(0, 0, zDir * jx), state, playerIn, hand, facing, hitX, hitY, hitZ);
               }
            }
         }
      }
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(-1, 0, -1));
      dirs.add(new Vec3i(1, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.rowToggleTile)) {
            return dir;
         }
      }

      return null;
   }
}
