package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.init.BlockInit;

public class BlockRingTile extends BlockBasicBoolState {
   public BlockRingTile(String name) {
      super(name);
      this.setLightLevel(1.0F);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!worldIn.isRemote) {
         ArrayList<BlockPos> adjblocks = new ArrayList<>();
         adjblocks.add(pos.add(1, 0, 0));
         adjblocks.add(pos.add(1, 0, 1));
         adjblocks.add(pos.add(1, 0, -1));
         adjblocks.add(pos.add(0, 0, 1));
         adjblocks.add(pos.add(0, 0, -1));
         adjblocks.add(pos.add(-1, 0, 1));
         adjblocks.add(pos.add(-1, 0, 0));
         adjblocks.add(pos.add(-1, 0, -1));

         for (BlockPos side : adjblocks) {
            if (worldIn.getBlockState(side).equals(BlockInit.ringTile.getStateFromMeta(1))) {
               worldIn.setBlockState(side, BlockInit.ringTile.getStateFromMeta(0));
            } else if (worldIn.getBlockState(side).equals(BlockInit.ringTile.getStateFromMeta(0))) {
               worldIn.setBlockState(side, BlockInit.ringTile.getStateFromMeta(1));
            }
         }

         worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.MASTER, 1.0F, 1.0F);
      }

      return true;
   }
}
