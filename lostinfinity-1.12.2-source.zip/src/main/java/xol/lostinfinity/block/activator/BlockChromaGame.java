package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityChromaGame;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockChromaGame extends BlockBasic implements ITileEntityProvider {
   public BlockChromaGame(String name) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.frostedLog);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand))) {
            double closest = 99999.0;
            double nextClosest = 99999.1;
            double radius = 10.0;
            AxisAlignedBB checkBox = new AxisAlignedBB(pos.add(-radius, -radius, -radius), pos.add(radius, radius, radius));
            List<EntityPlayer> players = worldIn.getEntitiesWithinAABB(EntityPlayer.class, checkBox);
            EntityPlayer first = null;
            EntityPlayer second = null;

            for (EntityPlayer player : players) {
               double dist = player.getDistanceSq(pos);
               if (player.getDistanceSq(pos) < closest) {
                  first = player;
                  closest = dist;
               }
            }

            players.remove(first);

            for (EntityPlayer playerx : players) {
               double dist = playerx.getDistanceSq(pos);
               if (playerx.getDistanceSq(pos) < nextClosest) {
                  second = playerx;
                  nextClosest = dist;
               }
            }

            if (first != null && second != null) {
               if (!worldIn.isRemote) {
                  this.setPlayers(worldIn, pos, first, second);
                  this.reset(pos, worldIn, playerIn, hand, facing, hitX, hitY, hitZ);
               }

               playerIn.getHeldItem(hand).shrink(1);
            }
         } else if (!worldIn.isRemote) {
            BlockPos ref = pos.add(0, 0, 0);
            Vec3i dir = findTileDir(worldIn, ref);
            int xDir = dir.getX();
            int zDir = dir.getZ();
            int dimension = 6;
            ref = ref.add(dir);
            boolean flag = true;

            for (int i = 0; i < dimension; i++) {
               for (int j = 0; j < dimension; j++) {
                  BlockPos tile = ref.add(xDir * i, 0, zDir * j);
                  if (!worldIn.getBlockState(tile).equals(BlockInit.chromaTile.getStateFromMeta(3))) {
                     flag = false;
                     break;
                  }
               }
            }

            if (flag) {
               ItemStack mapstack = new ItemStack(ItemInit.resolveMap);
               mapstack.setTagCompound(new NBTTagCompound());
               mapstack.getTagCompound().setInteger("MapEntityType", worldIn.rand.nextInt(8));
               mapstack.getTagCompound().setInteger("MapEntityNum", 2 + worldIn.rand.nextInt(4));
               EntityItem geoloc = new EntityItem(worldIn, playerIn.posX, playerIn.posY, playerIn.posZ, mapstack);
               geoloc.motionX = 0.0;
               geoloc.motionY = 0.0;
               geoloc.motionZ = 0.0;
               worldIn.spawnEntity(geoloc);
               this.reset(pos, worldIn, playerIn, hand, facing, hitX, hitY, hitZ);
               this.setPlayers(worldIn, pos, null, null);
               worldIn.playSound(null, pos, SoundInit.MACHINE_CRAFT, SoundCategory.MASTER, 1.0F, 1.0F);
            }
         }
      }

      return true;
   }

   private void setPlayers(World worldIn, BlockPos pos, EntityPlayer first, EntityPlayer second) {
      if (worldIn.getTileEntity(pos) != null && worldIn.getTileEntity(pos) instanceof TileEntityChromaGame) {
         TileEntityChromaGame tileentity = (TileEntityChromaGame)worldIn.getTileEntity(pos);
         tileentity.setPlayers(first, second);
      }
   }

   private EntityPlayer getRandomPlayer(World worldIn, BlockPos pos) {
      if (worldIn.getTileEntity(pos) != null && worldIn.getTileEntity(pos) instanceof TileEntityChromaGame) {
         TileEntityChromaGame tileentity = (TileEntityChromaGame)worldIn.getTileEntity(pos);
         boolean rand = worldIn.rand.nextBoolean();
         return rand ? tileentity.getFirst() : tileentity.getSecond();
      } else {
         return null;
      }
   }

   private void reset(BlockPos pos, World worldIn, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ) {
      BlockPos ref = pos.add(0, 0, 0);
      Vec3i dir = findTileDir(worldIn, ref);
      int xDir = dir.getX();
      int zDir = dir.getZ();
      int iterations = 40;
      int count = 0;
      ref = ref.add(dir);
      BlockPos temp = ref;

      while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.chromaTile)) {
         temp = ref.add(xDir * ++count, 0, 0);
      }

      ArrayList<BlockPos> tiles = new ArrayList<>();

      for (int i = 0; i < count; i++) {
         for (int j = 0; j < count; j++) {
            BlockPos tile = ref.add(xDir * i, 0, zDir * j);
            if (worldIn.getBlockState(tile).getBlock().equals(BlockInit.chromaTile)) {
               tiles.add(tile);
               worldIn.setBlockState(tile, BlockInit.chromaTile.getStateFromMeta(3));
            }
         }
      }

      Random rand = new Random();

      for (int k = 0; k < iterations; k++) {
         int index = rand.nextInt(tiles.size());
         IBlockState tileState = worldIn.getBlockState(tiles.get(index));
         Block tileBlock = tileState.getBlock();
         if (tileBlock instanceof BlockChromaTile) {
            EntityPlayer presser = this.getRandomPlayer(worldIn, pos);
            if (presser != null) {
               ((BlockChromaTile)tileBlock).onBlockActivated(worldIn, tiles.get(index), tileState, presser, hand, facing, hitX, hitY, hitZ);
            }
         }
      }
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(-1, 0, -1));
      dirs.add(new Vec3i(1, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.chromaTile)) {
            return dir;
         }
      }

      return null;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public boolean hasTileEntity() {
      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityChromaGame();
   }
}
