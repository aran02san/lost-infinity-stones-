package xol.lostinfinity.block.activator;

import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.tileentity.TileEntityAncientSymbolInterpreter;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockAncientSymbolInterpreter extends BlockBasic implements ITileEntityProvider {
   public BlockAncientSymbolInterpreter(String name) {
      super(name);
   }

   private boolean validInput(ItemStack stack) {
      return stack.getItem().equals(ItemInit.magicalBook);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         if (this.validInput(playerIn.getHeldItem(hand))) {
            if (!worldIn.isRemote) {
               this.reset(worldIn, pos, state);
            }

            playerIn.getHeldItem(hand).shrink(1);
         } else if (!worldIn.isRemote) {
            BlockPos ref = pos.add(0, -3, 0);
            Vec3i dir = findTileDir(worldIn, ref);
            int xDir = dir.getX();
            int zDir = dir.getZ();
            ref = ref.add(dir);
            int count = 0;
            BlockPos temp = ref;

            while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.ancientSymbol)) {
               temp = ref.add(xDir * ++count, 0, 0);
            }

            int dimension = count + 1;
            boolean allFlipped = true;

            label40:
            for (int i = 0; i < dimension; i++) {
               for (int j = 0; j < dimension; j++) {
                  BlockPos tile = ref.add(xDir * i, 0, zDir * j);
                  IBlockState tileState = worldIn.getBlockState(tile);
                  Block block = tileState.getBlock();
                  if (block instanceof BlockAncientSymbol) {
                     int meta = ((BlockAncientSymbol)block).getMetaFromState(tileState);
                     if (meta == 0) {
                        allFlipped = false;
                        break label40;
                     }
                  }
               }
            }

            if (allFlipped) {
               worldIn.playSound(null, pos.up(), SoundInit.CHIP_FORMAT, SoundCategory.BLOCKS, 2.0F, 1.0F);
               EntityItem item = new EntityItem(
                  worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.bookOfTranslation, 1)
               );
               item.motionX = 0.0;
               item.motionY = 0.0;
               item.motionZ = 0.0;
               worldIn.spawnEntity(item);
               this.reset(worldIn, pos, state);
            }
         }
      }

      return true;
   }

   private void reset(World worldIn, BlockPos pos, IBlockState state) {
      BlockPos ref = pos.add(0, -3, 0);
      Vec3i dir = findTileDir(worldIn, ref);
      int xDir = dir.getX();
      int zDir = dir.getZ();
      ref = ref.add(dir);
      int count = 0;
      BlockPos temp = ref;

      while (worldIn.getBlockState(temp).getBlock().equals(BlockInit.ancientSymbol)) {
         temp = ref.add(xDir * ++count, 0, 0);
      }

      int dimension = count + 1;
      ArrayList<BlockPos> tiles = new ArrayList<>();
      boolean foundAllTiles = true;

      for (int i = 0; i < dimension; i++) {
         for (int j = 0; j < dimension; j++) {
            BlockPos tile = ref.add(xDir * i, 0, zDir * j);
            if (worldIn.getBlockState(tile).getBlock().equals(BlockInit.ancientSymbol)) {
               worldIn.setBlockState(tile, BlockInit.ancientSymbol.getStateFromMeta(0));
               tiles.add(tile);
            }
         }
      }

      if (foundAllTiles && worldIn.getBlockState(pos).getBlock() instanceof BlockAncientSymbolInterpreter) {
         TileEntity tileEntity = worldIn.getTileEntity(pos);
         if (tileEntity != null && tileEntity instanceof TileEntityAncientSymbolInterpreter) {
            TileEntityAncientSymbolInterpreter TE = (TileEntityAncientSymbolInterpreter)tileEntity;
            TE.setDir(dir);
            TE.setTiles(tiles);
            TE.reset(dimension);
         }
      }
   }

   private static Vec3i findTileDir(World worldIn, BlockPos pos) {
      ArrayList<Vec3i> dirs = new ArrayList<>();
      dirs.add(new Vec3i(1, 0, 1));
      dirs.add(new Vec3i(-1, 0, 1));
      dirs.add(new Vec3i(-1, 0, -1));
      dirs.add(new Vec3i(1, 0, -1));

      for (Vec3i dir : dirs) {
         if (worldIn.getBlockState(pos.add(dir)).getBlock().equals(BlockInit.ancientSymbol)) {
            return dir;
         }
      }

      return null;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public boolean hasTileEntity() {
      return true;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityAncientSymbolInterpreter();
   }
}
