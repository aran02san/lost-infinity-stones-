package xol.lostinfinity.block.crafting;

import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.TabsInit;

public class BlockModulator extends BlockBasicGui {
   public BlockModulator(String name) {
      this(name, TabsInit.TAB_BLOCKS);
   }

   public BlockModulator(String name, CreativeTabs tab) {
      super(name, GuiHandler.RegisteredGuis.MODULATOR.getId());
      this.setCreativeTab(tab);
      this.setSoundType(SoundType.METAL);
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         int poweredCount = 0;
         Block poweredBlock = BlockInit.modulationBattery;
         BlockPos[] positions = new BlockPos[]{
            pos.add(0, -1, 1), pos.add(-1, -1, 0), pos.add(1, -1, 0), pos.add(0, -1, -1)
         };

         for (BlockPos position : positions) {
            if (worldIn.getBlockState(position).getBlock().equals(poweredBlock)) {
               poweredCount++;
            }
         }

         if (poweredCount == 4) {
            playerIn.openGui(
               lostinfinity.instance, GuiHandler.RegisteredGuis.MODULATOR.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
            );
         } else if (!worldIn.isRemote) {
            playerIn.sendMessage(new TextComponentString(TextFmt.Red + "The modulator is unpowered."));
         }
      }

      return true;
   }
}
