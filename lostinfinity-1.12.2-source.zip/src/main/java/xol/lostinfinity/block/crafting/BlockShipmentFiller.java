package xol.lostinfinity.block.crafting;

import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.block.tileentity.TileEntityShipmentFiller;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;

public class BlockShipmentFiller extends BlockBasicGui implements ITileEntityProvider {
   public BlockShipmentFiller(String name, Material material, CreativeTabs tab) {
      super(name, material, tab);
      this.setCreativeTab(tab).setHardness(3.0F).setResistance(10.0F);
      this.setSoundType(SoundType.STONE);
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.SHIPMENT_FILLER.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return super.getItemDropped(state, rand, fortune);
   }

   @Nullable
   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return new TileEntityShipmentFiller();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   @Nullable
   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityShipmentFiller();
   }

   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
      if (this.hasTileEntity(state)) {
         TileEntityShipmentFiller tileEntity = (TileEntityShipmentFiller)worldIn.getTileEntity(pos);
         tileEntity.dropInventory();
         worldIn.updateComparatorOutputLevel(pos, this);
         worldIn.removeTileEntity(pos);
      }
   }
}
