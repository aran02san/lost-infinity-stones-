package xol.lostinfinity.block.crafting;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.block.tileentity.TileEntityWeldingChamber;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.TabsInit;

public class BlockWeldingChamber extends BlockBasicGui implements ITileEntityProvider {
   public static final PropertyBool BURNING = PropertyBool.create("burning");

   public BlockWeldingChamber(String name) {
      this(name, Material.ROCK, TabsInit.TAB_BLOCKS);
   }

   public BlockWeldingChamber(String name, Material material, CreativeTabs tab) {
      super(name, material, tab);
      this.setCreativeTab(tab).setHardness(3.0F).setResistance(10.0F);
      this.setSoundType(SoundType.STONE);
      this.setDefaultState(this.blockState.getBaseState().withProperty(BURNING, false));
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityWeldingChamber();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.WELDING_CHAMBER.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{BURNING});
   }

   public static void setState(boolean active, World worldIn, BlockPos pos) {
      IBlockState state = worldIn.getBlockState(pos);
      TileEntity tileEntity = worldIn.getTileEntity(pos);
      worldIn.setBlockState(pos, state.withProperty(BURNING, active), 3);
      if (tileEntity != null) {
         tileEntity.validate();
         worldIn.setTileEntity(pos, tileEntity);
      }
   }

   public IBlockState getStateFromMeta(int meta) {
      switch (meta) {
         case 0:
            return this.getDefaultState().withProperty(BURNING, false);
         case 1:
            return this.getDefaultState().withProperty(BURNING, true);
         default:
            return this.getDefaultState();
      }
   }

   public int getMetaFromState(IBlockState state) {
      if (state.equals(this.getDefaultState().withProperty(BURNING, false))) {
         return 0;
      } else {
         return state.equals(this.getDefaultState().withProperty(BURNING, true)) ? 1 : 0;
      }
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Gray + "This incredibly advanced machine is");
      tooltip.add(TextFmt.Gray + "used to fuse Atomite Fragments.");
      tooltip.add("");
      tooltip.add(TextFmt.Gray + "Requires " + TextFmt.Aqua + "5 Atomite Fragments" + TextFmt.Gray + ".");
   }

   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
      if (this.hasTileEntity(state)) {
         TileEntity tileentity = worldIn.getTileEntity(pos);
         if (tileentity instanceof TileEntityWeldingChamber) {
            InventoryHelper.dropInventoryItems(worldIn, pos, (TileEntityWeldingChamber)tileentity);
            worldIn.updateComparatorOutputLevel(pos, this);
            worldIn.removeTileEntity(pos);
         }
      }
   }
}
