package xol.lostinfinity.block.crafting;

import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyBool;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.block.tileentity.TileEntitySapEvaporator;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.TabsInit;

public class BlockSapEvaporator extends BlockBasicGui implements ITileEntityProvider {
   public static final PropertyBool BURNING = PropertyBool.create("burning");
   private final boolean isBurning;

   public BlockSapEvaporator(String name, boolean isBurning) {
      this(name, Material.ROCK, isBurning);
   }

   public BlockSapEvaporator(String name, Material material, boolean isBurning) {
      this(name, material, TabsInit.TAB_BLOCKS, isBurning);
   }

   public BlockSapEvaporator(String name, Material material, CreativeTabs tab, boolean isBurning) {
      super(name, material, tab);
      this.setCreativeTab(tab);
      this.setSoundType(SoundType.METAL);
      this.setLightLevel(1.0F);
      this.setDefaultState(this.blockState.getBaseState().withProperty(BURNING, false));
      this.isBurning = isBurning;
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return Item.getItemFromBlock(BlockInit.sapEvaporator);
   }

   public ItemStack getItem(World worldIn, BlockPos pos, IBlockState state) {
      return new ItemStack(BlockInit.sapEvaporator);
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntitySapEvaporator();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   private TileEntitySapEvaporator getTE(World world, BlockPos pos) {
      return (TileEntitySapEvaporator)world.getTileEntity(pos);
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.SAP_EVAPORATOR.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }

   public static void setState(boolean active, World worldIn, BlockPos pos) {
      IBlockState state = worldIn.getBlockState(pos);
      TileEntity tileentity = worldIn.getTileEntity(pos);
      if (active) {
         worldIn.setBlockState(pos, BlockInit.sapEvaporator.getDefaultState().withProperty(BURNING, true), 3);
      } else {
         worldIn.setBlockState(pos, BlockInit.sapEvaporator.getDefaultState().withProperty(BURNING, false), 3);
      }

      if (tileentity != null) {
         tileentity.validate();
         worldIn.setTileEntity(pos, tileentity);
      }
   }

   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
      TileEntitySapEvaporator tileentity = (TileEntitySapEvaporator)worldIn.getTileEntity(pos);
      InventoryHelper.dropInventoryItems(worldIn, pos, tileentity);
      super.breakBlock(worldIn, pos, state);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{BURNING});
   }

   public IBlockState getStateFromMeta(int meta) {
      switch (meta) {
         case 0:
            return this.getDefaultState().withProperty(BURNING, false);
         case 1:
            return this.getDefaultState().withProperty(BURNING, true);
         default:
            return this.getDefaultState();
      }
   }

   public int getMetaFromState(IBlockState state) {
      if (state.equals(this.getDefaultState().withProperty(BURNING, false))) {
         return 0;
      } else {
         return state.equals(this.getDefaultState().withProperty(BURNING, true)) ? 1 : 0;
      }
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Italic + "Boils sap down into syrup.");
   }
}
