package xol.lostinfinity.block.crafting;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.block.tileentity.TileEntityCompressionTable;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.TabsInit;

public class BlockCompressionTable extends BlockBasicGui {
   public BlockCompressionTable(String name) {
      this(name, Material.ROCK);
   }

   public BlockCompressionTable(String name, Material material) {
      this(name, material, TabsInit.TAB_BLOCKS);
   }

   public BlockCompressionTable(String name, Material material, CreativeTabs tab) {
      super(name, material, tab);
      this.setCreativeTab(tab);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityCompressionTable();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   private TileEntityCompressionTable getTE(World world, BlockPos pos) {
      return (TileEntityCompressionTable)world.getTileEntity(pos);
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.COMPRESSION_TABLE.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Italic + "Unleashes an extremely powerful shockwave when given a Celestial Emerald.");
      tooltip.add(TextFmt.Italic + "Per Module Upgrades:");
      tooltip.add(TextFmt.Red + "NW: Power Modules | 22% Damage");
      tooltip.add(TextFmt.Aqua + "NE: Efficiency Modules | 16% Reduced Consumption");
      tooltip.add(TextFmt.Light_Purple + "SE: Depth Modules | 4 Blocks Up/Down");
      tooltip.add(TextFmt.Yellow + "SW: Range Modules | 8 Block Radius");
   }
}
