package xol.lostinfinity.block.crafting;

import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.block.tileentity.TileEntityChemistryTable;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.TabsInit;

public class BlockChemistryTable extends BlockBasicGui implements ITileEntityProvider {
   public BlockChemistryTable(String name) {
      this(name, Material.ROCK, TabsInit.TAB_BLOCKS);
   }

   public BlockChemistryTable(String name, Material material, CreativeTabs tab) {
      super(name, material, tab);
      this.setCreativeTab(tab).setHardness(3.0F).setResistance(10.0F);
      this.setSoundType(SoundType.STONE);
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.CHEMISTRY_TABLE.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }

   @Nullable
   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityChemistryTable();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
      if (this.hasTileEntity(state)) {
         TileEntity tileentity = worldIn.getTileEntity(pos);
         if (tileentity instanceof TileEntityChemistryTable) {
            InventoryHelper.dropInventoryItems(worldIn, pos, (TileEntityChemistryTable)tileentity);
            worldIn.updateComparatorOutputLevel(pos, this);
            worldIn.removeTileEntity(pos);
         }
      }
   }
}
