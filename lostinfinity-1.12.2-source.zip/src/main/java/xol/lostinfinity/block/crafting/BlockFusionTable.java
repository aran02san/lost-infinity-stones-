package xol.lostinfinity.block.crafting;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.InventoryHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.block.basic.BlockBasicGui;
import xol.lostinfinity.block.tileentity.TileEntityFusionTable;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.gui.GuiHandler;
import xol.lostinfinity.init.TabsInit;

public class BlockFusionTable extends BlockBasicGui implements ITileEntityProvider {
   public BlockFusionTable(String name) {
      super(name, Material.ROCK, TabsInit.TAB_BLOCKS);
   }

   public BlockFusionTable(String name, Material material, CreativeTabs tab) {
      super(name, material, tab);
      this.setCreativeTab(tab).setHardness(3.0F).setResistance(10.0F);
      this.setSoundType(SoundType.STONE);
   }

   public TileEntity createTileEntity(World worldIn, IBlockState state) {
      return new TileEntityFusionTable();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   public TileEntity createNewTileEntity(World worldIn, int meta) {
      return null;
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()) {
         playerIn.openGui(
            lostinfinity.instance, GuiHandler.RegisteredGuis.FUSION_TABLE.getId(), worldIn, pos.getX(), pos.getY(), pos.getZ()
         );
      }

      return true;
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Gray + "Takes " + TextFmt.Aqua + "Ionite Bars " + TextFmt.Gray + "and " + TextFmt.Aqua + "Inverse Magnecronite" + TextFmt.Gray + ".");
   }

   public void breakBlock(World worldIn, BlockPos pos, IBlockState state) {
      if (this.hasTileEntity(state)) {
         TileEntity tileentity = worldIn.getTileEntity(pos);
         if (tileentity instanceof TileEntityFusionTable) {
            InventoryHelper.dropInventoryItems(worldIn, pos, (TileEntityFusionTable)tileentity);
            worldIn.updateComparatorOutputLevel(pos, this);
            worldIn.removeTileEntity(pos);
         }
      }
   }
}
