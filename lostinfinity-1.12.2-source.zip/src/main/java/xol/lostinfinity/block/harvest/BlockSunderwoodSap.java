package xol.lostinfinity.block.harvest;

import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicPillar;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockSunderwoodSap extends BlockBasicPillar implements ISpecialHarvest {
   public BlockSunderwoodSap(String name) {
      super(name, Material.WOOD);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.burningSap;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.forgefireAxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         int meta = this.getMetaFromState(world.getBlockState(pos));
         world.setBlockState(pos, BlockInit.sunderwoodSapEmpty.getStateFromMeta(meta));
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
