package xol.lostinfinity.block.harvest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.ParticleInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.mob.entity.starforge.EntityGlomite;
import xol.lostinfinity.util.data.CustomParticleConfig;
import xol.lostinfinity.util.data.IMaxAttack;
import xol.lostinfinity.util.fx.IParticleSpawner;

public class BlockPrismosisOre extends BlockBasicLight implements ISpecialHarvest, IMaxAttack {
   public BlockPrismosisOre(String name) {
      super(name);
      this.setHardness(2.0F);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.prismosisShards;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         boolean teleported = false;

         for (EntityGlomite glomite : world.getEntitiesWithinAABB(EntityGlomite.class, new AxisAlignedBB(pos.add(-7, -7, -7), pos.add(7, 7, 7)))) {
            glomite.setPositionAndUpdate(harvester.posX, harvester.posY, harvester.posZ);
            glomite.setAttackTarget(harvester);
            teleported = true;
         }

         if (teleported) {
            world.playSound(null, pos, SoundInit.GLOMITE_TELEPORT, SoundCategory.HOSTILE, 2.0F, 1.0F);
            CustomParticleConfig config = new CustomParticleConfig();
            config.createInstance().setParticle(ParticleInit.GLOMITE_WARP).setIgnoreRange(true);
            IParticleSpawner.spawnParticle(world, config, harvester.posX, harvester.posY + 0.5, harvester.posZ);
         }
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
