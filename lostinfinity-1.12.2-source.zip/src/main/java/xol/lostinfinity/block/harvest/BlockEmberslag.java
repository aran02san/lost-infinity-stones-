package xol.lostinfinity.block.harvest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.ItemInit;

public class BlockEmberslag extends BlockBasicLight implements ISpecialHarvest {
   public BlockEmberslag(String name) {
      super(name);
      this.setHardness(2.0F);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return Items.FLINT;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.forgeFirePickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         world.setBlockToAir(pos);
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
