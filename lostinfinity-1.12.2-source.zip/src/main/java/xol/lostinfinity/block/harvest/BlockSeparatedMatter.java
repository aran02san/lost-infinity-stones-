package xol.lostinfinity.block.harvest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockSeparatedMatter extends BlockBasic implements ISpecialHarvest {
   public BlockSeparatedMatter(String name) {
      super(name);
      this.setHardness(2.0F);
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return Item.getItemFromBlock(BlockInit.separatedMatter);
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.forgeFirePickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         world.setBlockToAir(pos);
      }
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
