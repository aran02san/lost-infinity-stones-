package xol.lostinfinity.block.harvest;

import net.minecraft.block.material.Material;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.ItemInit;

public class BlockCelestialLogsRed extends BlockBasic implements ISpecialHarvest {
   public BlockCelestialLogsRed(String name) {
      super(name, Material.WOOD);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.negativeMagnecronite;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.forgefireAxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
