package xol.lostinfinity.block.harvest;

import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.ItemInit;

public class BlockCatatoniteOre extends BlockBasic implements ISpecialHarvest {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 3);

   public BlockCatatoniteOre(String name) {
      super(name);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.catatoniteShard;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote && world.rand.nextInt(10) == 0) {
         world.setBlockState(pos, this.getStateFromMeta(0));
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return this.getMetaFromState(world.getBlockState(pos)) == 3;
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }
}
