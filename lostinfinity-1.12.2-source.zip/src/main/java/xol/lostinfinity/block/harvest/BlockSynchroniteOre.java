package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.block.misc.BlockSynchroniteSignal;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.ParticleInit;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;
import xol.lostinfinity.util.data.CustomParticleConfig;
import xol.lostinfinity.util.fx.IParticleSpawner;

public class BlockSynchroniteOre extends BlockBasic implements ISpecialHarvest {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 4);

   public BlockSynchroniteOre(String name) {
      super(name);
      this.setTickRandomly(true);
      this.setHardness(2.0F);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int range = 3;

         for (BlockPos nearpos : BlockPos.getAllInBox(pos.add(-range, -range, -range), pos.add(range, range, range))) {
            if (world.getBlockState(nearpos).getBlock() instanceof BlockSynchroniteOre) {
               int newMeta = 1 + rand.nextInt(4);
               world.setBlockState(nearpos, this.getStateFromMeta(newMeta));
            }
         }
      }
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      switch (this.getMetaFromState(world.getBlockState(pos))) {
         case 1:
            return ItemInit.synchroniteTypeA;
         case 2:
            return ItemInit.synchroniteTypeB;
         case 3:
            return ItemInit.synchroniteTypeC;
         case 4:
            return ItemInit.synchroniteTypeD;
         default:
            return ItemInit.synchroniteTypeA;
      }
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         world.setBlockState(pos, this.getStateFromMeta(0));
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      int meta = this.getMetaFromState(world.getBlockState(pos));
      IBlockState state = world.getBlockState(GalaxyCoordinates.SynchroniteSignal());
      BlockSynchroniteSignal signal = (BlockSynchroniteSignal)state.getBlock();
      int requiredMeta = 1 + signal.getMetaFromState(state);
      return meta != 0 && meta == requiredMeta;
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         IBlockState state = world.getBlockState(pos);
         if (this.getMetaFromState(state) != 0) {
            world.createExplosion(null, pos.getX(), pos.getY(), pos.getZ(), 3.0F, false);

            for (EntityPlayer target : world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(pos).grow(5.0))) {
               harvester.setHealth(harvester.getHealth() - harvester.getMaxHealth() * 2.0F);
               target.sendMessage(new TextComponentString(TextFmt.Red + "A massive reaction occured from mining an asynchronous ore!"));
            }

            CustomParticleConfig config1 = new CustomParticleConfig();
            config1.createInstance().setParticle(ParticleInit.ION_BLAST).setSpread(6.0, 4.0, 6.0).setCount(5).setIgnoreRange(true);
            IParticleSpawner.spawnParticle(world, config1, (double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
            CustomParticleConfig config2 = new CustomParticleConfig();
            config2.createInstance().setParticle(ParticleInit.NUCLEAR_BLAST).setSpread(1.0, 1.0, 1.0).setCount(5).setIgnoreRange(true);
            IParticleSpawner.spawnParticle(world, config2, (double)pos.getX(), (double)pos.getY(), (double)pos.getZ());
         }
      }
   }
}
