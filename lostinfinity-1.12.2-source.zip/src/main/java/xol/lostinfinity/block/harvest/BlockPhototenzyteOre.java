package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.ItemInit;

public class BlockPhototenzyteOre extends BlockBasicBoolState implements ISpecialHarvest {
   public BlockPhototenzyteOre(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.phototenzyte;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return this.getMetaFromState(world.getBlockState(pos)) == 1;
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int range = 12;

         for (BlockPos nearpos : BlockPos.getAllInBox(pos.add(-range, -range, -range), pos.add(range, range, range))) {
            if (world.getBlockState(nearpos).getBlock() instanceof BlockPhototenzyteOre && world.rand.nextBoolean()) {
               IBlockState nearState = world.getBlockState(nearpos);
               int meta = this.getMetaFromState(nearState);
               if (meta == 0) {
                  world.setBlockState(nearpos, this.getStateFromMeta(1));
               } else {
                  world.setBlockState(nearpos, this.getStateFromMeta(0));
               }
            }
         }
      }
   }
}
