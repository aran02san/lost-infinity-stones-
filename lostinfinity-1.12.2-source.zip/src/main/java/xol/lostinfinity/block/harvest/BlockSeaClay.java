package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;

public class BlockSeaClay extends BlockBasicBoolState {
   public BlockSeaClay(String name) {
      super(name);
      this.setTickRandomly(true);
      this.setHardness(3.0F);
      this.setResistance(5.0F);
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int range = 3;

         for (BlockPos nearpos : BlockPos.getAllInBox(pos.add(-range, -range, -range), pos.add(range, range, range))) {
            if (world.getBlockState(nearpos).getBlock() instanceof BlockSeaClay && world.rand.nextBoolean()) {
               IBlockState nearState = world.getBlockState(nearpos);
               int meta = this.getMetaFromState(nearState);
               if (meta == 0) {
                  world.setBlockState(nearpos, this.getStateFromMeta(1));
               } else {
                  world.setBlockState(nearpos, this.getStateFromMeta(0));
               }
            }
         }
      }
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return ItemStack.EMPTY.getItem();
   }
}
