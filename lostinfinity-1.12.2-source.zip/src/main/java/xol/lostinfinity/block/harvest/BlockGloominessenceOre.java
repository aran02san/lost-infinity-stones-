package xol.lostinfinity.block.harvest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.mob.entity.starforge.EntityEssenceDweller;
import xol.lostinfinity.util.data.IMaxAttack;

public class BlockGloominessenceOre extends BlockBasicLight implements ISpecialHarvest, IMaxAttack {
   public BlockGloominessenceOre(String name) {
      super(name);
      this.setHardness(2.0F);
      this.setLightLevel(1.0F);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.gloominessence;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         world.setBlockState(pos, BlockInit.gloominessenceOreEmpty.getDefaultState());
         int rand_result = world.rand.nextInt(3);
         switch (rand_result) {
            case 0:
               world.createExplosion(null, pos.getX(), pos.getY(), pos.getZ(), 3.0F, false);

               for (EntityPlayer target : world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(pos).grow(5.0))) {
                  IMaxAttack.dealMaxHealth(harvester, target, 2);
                  target.sendMessage(new TextComponentString(TextFmt.Red + "A gas pocket in the ore explodes!"));
               }
               break;
            case 1:
               EntityEssenceDweller dwel = new EntityEssenceDweller(world);
               dwel.setPosition(harvester.posX, harvester.posY + 1.0, harvester.posZ);
               dwel.setAttackTarget(harvester);
               world.spawnEntity(dwel);
               harvester.sendMessage(new TextComponentString(TextFmt.Dark_Aqua + "An Essence Dweller emerged when you mined the Luminessence!"));
               break;
            case 2:
               for (EntityPlayer target : world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(pos).grow(5.0))) {
                  target.addPotionEffect(new PotionEffect(PotionInit.NULLIFIED, 100));
                  target.sendMessage(new TextComponentString(TextFmt.Red + "An electrical surge from the ore temporarily disables your armor."));
               }
         }
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
