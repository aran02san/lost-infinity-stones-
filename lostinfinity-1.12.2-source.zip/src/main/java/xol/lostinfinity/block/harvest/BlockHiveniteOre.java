package xol.lostinfinity.block.harvest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.starforge.EntityFlutterbee;

public class BlockHiveniteOre extends BlockBasicLight implements ISpecialHarvest {
   public BlockHiveniteOre(String name) {
      super(name);
      this.setHardness(2.0F);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.hivenite;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         world.setBlockState(pos, BlockInit.hiveniteEmpty.getDefaultState());

         for (EntityFlutterbee bee : world.getEntitiesWithinAABB(
            EntityFlutterbee.class, new AxisAlignedBB(pos.add(-15, -15, -15), pos.add(15, 15, 15))
         )) {
            bee.shootMiner(harvester.getPosition().up());
         }
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
