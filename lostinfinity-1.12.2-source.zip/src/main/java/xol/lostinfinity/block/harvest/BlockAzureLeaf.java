package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockCappedPlant;
import xol.lostinfinity.init.ItemInit;

public class BlockAzureLeaf extends BlockCappedPlant {
   public BlockAzureLeaf(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote && this.getMetaFromState(state) == 0) {
         world.setBlockState(pos, this.getStateFromMeta(1));
      }
   }

   @Override
   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItemMainhand();
      if (held.getItem() == ItemInit.heatResistantTongs && !worldIn.isRemote) {
         EntityItem leaf = new EntityItem(worldIn, pos.getX(), pos.getY() + 2, pos.getZ(), new ItemStack(ItemInit.azureLeaf));
         leaf.motionX = 0.0;
         leaf.motionY = 0.0;
         leaf.motionZ = 0.0;
         worldIn.spawnEntity(leaf);
         worldIn.setBlockState(pos, this.getStateFromMeta(0));
         worldIn.playSound(null, pos.up(), SoundEvents.ITEM_HOE_TILL, SoundCategory.BLOCKS, 2.0F, 1.0F);
      }

      return super.onBlockActivated(worldIn, pos, state, playerIn, hand, facing, hitX, hitY, hitZ);
   }
}
