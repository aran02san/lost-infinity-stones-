package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;

public class BlockIgneousPearlOre extends BlockBasic {
   public BlockIgneousPearlOre(String name) {
      super(name);
      this.setHardness(3.0F);
      this.setResistance(5.0F);
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return ItemStack.EMPTY.getItem();
   }

   public void onBlockDestroyedByPlayer(World worldIn, BlockPos pos, IBlockState state) {
      if (!worldIn.isRemote) {
         EntityPlayer player = worldIn.getClosestPlayer(pos.getX(), pos.getY(), pos.getZ(), 3.0, false);
         if (player != null) {
            boolean found = false;

            for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
               ItemStack playerStack = player.inventory.getStackInSlot(i);
               if (playerStack.getItem() == ItemInit.pearlIgneous) {
                  found = true;
                  break;
               }
            }

            if (found) {
               player.sendMessage(new TextComponentString(TextFmt.Red + "A strange magical property in the pearl prevents you from collecting another."));
            } else {
               player.addItemStackToInventory(new ItemStack(ItemInit.pearlIgneous));
            }
         }
      }
   }
}
