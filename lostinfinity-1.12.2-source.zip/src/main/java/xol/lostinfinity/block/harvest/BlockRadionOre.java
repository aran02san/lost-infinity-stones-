package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.activator.BlockRadionPillar;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.init.SoundInit;

public class BlockRadionOre extends BlockBasicBoolState {
   private static final boolean DEBUG = true;

   public BlockRadionOre(String name) {
      super(name);
      this.setTickRandomly(true);
      this.setHardness(3.0F);
      this.setResistance(5.0F);
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int range = 3;

         for (BlockPos nearpos : BlockPos.getAllInBox(pos.add(-range, -range, -range), pos.add(range, range, range))) {
            if (world.getBlockState(nearpos).getBlock() instanceof BlockRadionOre && world.rand.nextBoolean()) {
               IBlockState nearState = world.getBlockState(nearpos);
               int meta = this.getMetaFromState(nearState);
               if (meta == 0) {
                  world.setBlockState(nearpos, this.getStateFromMeta(1));
               } else {
                  world.setBlockState(nearpos, this.getStateFromMeta(0));
               }
            }
         }
      }
   }

   public Item getItemDropped(IBlockState state, Random rand, int fortune) {
      return ItemStack.EMPTY.getItem();
   }

   public void onBlockDestroyedByPlayer(World worldIn, BlockPos pos, IBlockState state) {
      if (!worldIn.isRemote && !worldIn.getClosestPlayer(pos.getX(), pos.getY(), pos.getZ(), 15.0, false).isCreative()) {
         worldIn.setBlockState(pos, this.getStateFromMeta(0));
         if (this.getMetaFromState(state) == 1) {
            int range = 15;

            for (BlockPos nearPos : BlockPos.getAllInBox(pos.add(-range, -range, -range), pos.add(range, range, range))) {
               if (worldIn.getBlockState(nearPos).getBlock() instanceof BlockRadionPillar
                  && worldIn.getBlockState(nearPos).getBlock().getMetaFromState(worldIn.getBlockState(nearPos)) == 0) {
                  System.out.println("RadionOre destroyed, charging RadionPillar at " + nearPos);
                  BlockRadionPillar pillarBlock = (BlockRadionPillar)worldIn.getBlockState(nearPos).getBlock();
                  pillarBlock.lightUpPillarSegment(worldIn, nearPos);
                  break;
               }
            }
         }
      }

      if (worldIn.isRemote && this.getMetaFromState(state) == 1) {
         EntityPlayer player = worldIn.getClosestPlayer(pos.getX(), pos.getY(), pos.getZ(), 15.0, false);
         EnumFacing facing = player.getHorizontalFacing();
         player.playSound(SoundInit.ORE_LIGHT, 0.5F, 1.0F + (worldIn.rand.nextFloat() - worldIn.rand.nextFloat()) * 0.2F);
         double centerX = pos.getX() + 0.5;
         double centerY = pos.getY() + 0.5;
         double centerZ = pos.getZ() + 0.5;
         switch (facing) {
            case NORTH:
               for (int i = 0; i < 15; i++) {
                  double offSetX = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.8 : -(worldIn.rand.nextDouble() % 0.8);
                  double offsetY = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.5 : -(worldIn.rand.nextDouble() % 0.5);
                  worldIn.spawnParticle(
                     EnumParticleTypes.DRAGON_BREATH,
                     centerX + offSetX,
                     centerY + offsetY,
                     centerZ + worldIn.rand.nextFloat() % 0.8,
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
               }
               break;
            case SOUTH:
               for (int i = 0; i < 15; i++) {
                  double offSetX = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.8 : -(worldIn.rand.nextDouble() % 0.8);
                  double offsetY = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.5 : -(worldIn.rand.nextDouble() % 0.5);
                  worldIn.spawnParticle(
                     EnumParticleTypes.DRAGON_BREATH,
                     centerX + offSetX,
                     centerY + offsetY,
                     centerZ - worldIn.rand.nextFloat() % 0.8,
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
               }
               break;
            case EAST:
               for (int i = 0; i < 15; i++) {
                  double offSetZ = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.8 : -(worldIn.rand.nextDouble() % 0.8);
                  double offsetY = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.5 : -(worldIn.rand.nextDouble() % 0.5);
                  worldIn.spawnParticle(
                     EnumParticleTypes.DRAGON_BREATH,
                     centerX - worldIn.rand.nextFloat() % 0.8,
                     centerY + offsetY,
                     centerZ + offSetZ,
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
               }
               break;
            case WEST:
               for (int i = 0; i < 15; i++) {
                  double offSetZ = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.8 : -(worldIn.rand.nextDouble() % 0.8);
                  double offsetY = worldIn.rand.nextBoolean() ? worldIn.rand.nextDouble() % 0.5 : -(worldIn.rand.nextDouble() % 0.5);
                  worldIn.spawnParticle(
                     EnumParticleTypes.DRAGON_BREATH,
                     centerX + worldIn.rand.nextFloat() % 0.8,
                     centerY + offsetY,
                     centerZ + offSetZ,
                     0.0,
                     0.0,
                     0.0,
                     new int[0]
                  );
               }
         }
      }
   }
}
