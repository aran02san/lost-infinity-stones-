package xol.lostinfinity.block.harvest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.mob.entity.starforge.EntityEssenceDweller;
import xol.lostinfinity.mob.entity.starforge.EntityGlochipper;
import xol.lostinfinity.util.data.IMaxAttack;

public class BlockLuminescentOre extends BlockBasicLight implements ISpecialHarvest, IMaxAttack {
   public BlockLuminescentOre(String name) {
      super(name);
      this.setHardness(2.0F);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.luminessence;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         world.setBlockState(pos, BlockInit.lumioOreEmpty.getDefaultState());
         int rand_result = world.rand.nextInt(8);
         if (rand_result == 0) {
            world.createExplosion(null, pos.getX(), pos.getY(), pos.getZ(), 3.0F, false);

            for (EntityPlayer target : world.getEntitiesWithinAABB(EntityPlayer.class, new AxisAlignedBB(pos).grow(5.0))) {
               harvester.setHealth(harvester.getHealth() - harvester.getMaxHealth() * 0.5F);
               target.sendMessage(new TextComponentString(TextFmt.Red + "A gas pocket in the ore explodes!"));
            }
         } else if (rand_result == 2) {
            EntityEssenceDweller dwel = new EntityEssenceDweller(world);
            dwel.setPosition(harvester.posX, harvester.posY + 1.0, harvester.posZ);
            dwel.setAttackTarget(harvester);
            world.spawnEntity(dwel);
            harvester.sendMessage(new TextComponentString(TextFmt.Dark_Aqua + "An Essence Dweller emerged when you mined the Luminessence!"));
         } else if (rand_result == 4) {
            for (int i = 0; i < 4; i++) {
               EntityGlochipper glo = new EntityGlochipper(world);
               glo.setPosition(harvester.posX, harvester.posY + 2.0, harvester.posZ);
               glo.setAttackTarget(harvester);
               world.spawnEntity(glo);
            }

            harvester.sendMessage(new TextComponentString(TextFmt.Yellow + "A swarm of glochippers notice the light disappear."));
         }
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return true;
   }
}
