package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockExothermiteOre extends BlockBasicBoolState implements ISpecialHarvest {
   public BlockExothermiteOre(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.impureExothermite;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.forgeFirePickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      world.setBlockState(pos, this.getStateFromMeta(0));
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return this.getMetaFromState(world.getBlockState(pos)) == 1;
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         if (this.getMetaFromState(state) == 1) {
            if (world.getBlockState(pos.up()).getBlock() != BlockInit.concentratedAcid) {
               world.setBlockState(pos, this.getStateFromMeta(0));
            }
         } else if (world.getBlockState(pos.up()).getBlock() == BlockInit.concentratedAcid) {
            world.setBlockState(pos, this.getStateFromMeta(1));
         }
      }
   }
}
