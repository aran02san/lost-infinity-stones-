package xol.lostinfinity.block.harvest;

import java.util.ArrayList;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicLight;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;

public class BlockSerpentineOre extends BlockBasicLight implements ISpecialHarvest {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 2);

   public BlockSerpentineOre(String name) {
      super(name);
      this.setHardness(2.0F);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public IBlockState getStateWithAmount(int amount) {
      return this.getDefaultState().withProperty(AMOUNT, amount);
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return this.getMetaFromState(world.getBlockState(pos)) == 2;
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.serpentineCrystal;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (!world.isRemote) {
         this.reset(world, pos);
      }
   }

   private boolean validInput(Item item) {
      return item.equals(ItemInit.ultravioletSolution);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking() && this.validInput(playerIn.getHeldItem(hand).getItem()) && !worldIn.isRemote) {
         if (state.equals(this.getStateWithAmount(1))) {
            worldIn.setBlockState(pos, this.getStateWithAmount(2));
            playerIn.getHeldItem(hand).shrink(1);
            worldIn.playSound(null, pos, SoundInit.GLOW_BOMB, SoundCategory.BLOCKS, 1.0F, 1.0F);
            return true;
         }

         if (state.equals(this.getStateWithAmount(2))) {
            return true;
         }

         playerIn.getHeldItem(hand).shrink(1);
         worldIn.playSound(null, pos, SoundEvents.ENTITY_ITEMFRAME_ADD_ITEM, SoundCategory.BLOCKS, 1.0F, 0.8F + worldIn.rand.nextFloat() * 0.4F);
         int radius = 20;
         boolean found = this.findOreRadius(worldIn, pos, radius);
         if (!found) {
            this.reset(worldIn, pos);
            this.findOreRadius(worldIn, pos, radius);
         }
      }

      return true;
   }

   private boolean findOreRadius(World worldIn, BlockPos pos, int radius) {
      boolean found = false;

      for (int i = -radius; i <= radius; i++) {
         for (int j = -radius; j <= radius; j++) {
            BlockPos checkPos = new BlockPos(pos.getX() + i, pos.getY(), pos.getZ() + j);
            IBlockState checkState = worldIn.getBlockState(checkPos);
            if (checkState.equals(this.getStateWithAmount(1))) {
               int dist = (int)pos.getDistance(checkPos.getX(), checkPos.getY(), checkPos.getZ())
                  + worldIn.rand.nextInt(3);

               for (EntityPlayer player : worldIn.getEntitiesWithinAABB(
                  EntityPlayer.class, new AxisAlignedBB(pos.add(-15, -15, -15), pos.add(15, 15, 15))
               )) {
                  String message = String.format("The level of shine indicates the ore is within a radius of %d", dist);
                  player.sendMessage(new TextComponentString(TextFmt.getFormatting(TextFmt.Bold, TextFmt.Green) + message));
                  found = true;
               }
            }
         }
      }

      return found;
   }

   private ArrayList<BlockPos> setBlockNeighbours(World world, BlockPos pos, ArrayList<BlockPos> visited) {
      ArrayList<BlockPos> reset = new ArrayList<>();
      if (world.getBlockState(pos).equals(this.getStateWithAmount(2))) {
         world.setBlockState(pos, this.getStateWithAmount(0));
         reset.add(pos);
      } else {
         if (!world.getBlockState(pos).equals(this.getStateWithAmount(0))) {
            return null;
         }

         reset.add(pos);
      }

      ArrayList<BlockPos> neighbours = new ArrayList<>();
      visited.add(pos);
      neighbours.add(pos.add(0, 0, 1));
      neighbours.add(pos.add(0, 0, -1));
      neighbours.add(pos.add(1, 0, 0));
      neighbours.add(pos.add(-1, 0, 0));
      neighbours.add(pos.add(-1, 0, 1));
      neighbours.add(pos.add(-1, 0, -1));
      neighbours.add(pos.add(1, 0, 1));
      neighbours.add(pos.add(1, 0, -1));

      for (BlockPos neighbour : neighbours) {
         if (!visited.contains(neighbour)) {
            ArrayList<BlockPos> moreNeighbours = this.setBlockNeighbours(world, neighbour, visited);
            if (moreNeighbours != null) {
               for (BlockPos n : moreNeighbours) {
                  reset.add(n);
               }
            }
         }
      }

      return reset;
   }

   private void reset(World world, BlockPos pos) {
      new ArrayList();
      ArrayList<BlockPos> visited = new ArrayList<>();
      ArrayList<BlockPos> blocks = this.setBlockNeighbours(world, pos, visited);
      int randDecoy = world.rand.nextInt(blocks.size());
      world.setBlockState((BlockPos)blocks.get(randDecoy), this.getStateWithAmount(1));
   }
}
