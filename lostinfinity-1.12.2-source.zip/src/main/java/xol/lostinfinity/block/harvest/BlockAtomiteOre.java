package xol.lostinfinity.block.harvest;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasicBoolState;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;

public class BlockAtomiteOre extends BlockBasicBoolState implements ISpecialHarvest {
   public BlockAtomiteOre(String name) {
      super(name);
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.atomiteFragments;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.nightmarePickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
      if (world.rand.nextInt(10) == 0) {
         world.setBlockState(pos, BlockInit.murkstone.getDefaultState());
      }
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return this.getMetaFromState(world.getBlockState(pos)) == 1;
   }
}
