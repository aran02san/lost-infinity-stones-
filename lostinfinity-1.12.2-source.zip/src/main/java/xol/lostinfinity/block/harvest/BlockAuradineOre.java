package xol.lostinfinity.block.harvest;

import java.util.Random;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.basic.BlockBasic;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.init.ItemInit;

public class BlockAuradineOre extends BlockBasic implements ISpecialHarvest {
   public static final PropertyInteger AMOUNT = PropertyInteger.create("amount", 0, 4);

   public BlockAuradineOre(String name) {
      super(name);
      this.setTickRandomly(true);
   }

   public IBlockState getStateForPlacement(World worldIn, BlockPos pos, EnumFacing facing, float hitX, float hitY, float hitZ, int meta, EntityLivingBase placer) {
      return this.getDefaultState().withProperty(AMOUNT, 0);
   }

   public IBlockState getStateFromMeta(int meta) {
      return this.getDefaultState().withProperty(AMOUNT, meta);
   }

   public int getMetaFromState(IBlockState state) {
      return (Integer)state.getValue(AMOUNT);
   }

   protected BlockStateContainer createBlockState() {
      return new BlockStateContainer(this, new IProperty[]{AMOUNT});
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      ItemStack held = playerIn.getHeldItem(hand);
      if (held.getItem() == ItemInit.chlorodivergentSolution) {
         int oreValue = this.getMetaFromState(state);
         if (oreValue < 4 && !worldIn.isRemote) {
            Iterable<BlockPos> nearblocks = BlockPos.getAllInBox(pos.add(-7, -7, -7), pos.add(7, 7, 7));
            BlockPos nearestPos = null;

            for (BlockPos nearpos : nearblocks) {
               IBlockState nearState = worldIn.getBlockState(nearpos);
               if (nearState.getBlock() instanceof BlockAuradineOre) {
                  int nearValue = this.getMetaFromState(nearState);
                  if (!nearpos.equals(pos)
                     && nearValue == oreValue
                     && (
                        nearestPos == null
                           || pos.getDistance(nearpos.getX(), nearpos.getY(), nearpos.getZ())
                              < pos.getDistance(nearestPos.getX(), nearestPos.getY(), nearestPos.getZ())
                     )) {
                     nearestPos = nearpos;
                  }
               }
            }

            if (nearestPos != null) {
               worldIn.setBlockState(nearestPos, this.getStateFromMeta(oreValue + 1));
               worldIn.setBlockState(pos, this.getStateFromMeta(0));
            }

            worldIn.playSound(null, pos, SoundEvents.BLOCK_SLIME_PLACE, SoundCategory.BLOCKS, 1.0F, 1.0F);
         }

         held.shrink(1);
      }

      return true;
   }

   public void updateTick(World world, BlockPos pos, IBlockState state, Random rand) {
      if (!world.isRemote) {
         int oreValue = this.getMetaFromState(state);
         if (oreValue > 0 && world.rand.nextInt(8) == 0) {
            world.setBlockState(pos, this.getStateFromMeta(oreValue - 1));
         }
      }
   }

   @Override
   public Item getHarvestResult(World world, BlockPos pos) {
      return ItemInit.auradine;
   }

   @Override
   public Item getToolNeeded() {
      return ItemInit.crystalPickaxe;
   }

   @Override
   public void worldHarvestEffect(World world, BlockPos pos, EntityPlayer harvester) {
   }

   @Override
   public boolean isHarvestable(World world, BlockPos pos, EntityPlayer harvester) {
      return this.getMetaFromState(world.getBlockState(pos)) == 4;
   }

   @Override
   public void failedHarvest(World world, BlockPos pos, EntityPlayer harvester) {
   }
}
