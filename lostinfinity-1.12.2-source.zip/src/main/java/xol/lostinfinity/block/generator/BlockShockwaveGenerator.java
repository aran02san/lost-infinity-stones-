package xol.lostinfinity.block.generator;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.TabsInit;
import xol.lostinfinity.util.data.IMaxAttack;

public class BlockShockwaveGenerator extends BlockGenerator implements IMaxAttack {
   public BlockShockwaveGenerator(String name) {
      super(name, 3.0F, Material.ROCK, TabsInit.TAB_BLOCKS);
   }

   @Override
   public void activateGenerator(
      World worldIn,
      BlockPos pos,
      IBlockState state,
      EntityPlayer playerIn,
      int power_upgrade,
      int efficiency_upgrade,
      int range_upgrade,
      int depth_upgrade,
      UUID placer_uuid
   ) {
      for (EntityLivingBase detected_player : worldIn.getEntitiesWithinAABB(
         EntityLivingBase.class, new AxisAlignedBB(pos).grow(20.0 + range_upgrade * 8, 10.0 + depth_upgrade * 4, 20.0 + range_upgrade * 8)
      )) {
         if (!detected_player.getUniqueID().equals(placer_uuid) && this.is_detectable(detected_player)) {
            IMaxAttack.dealMaxHealth(playerIn, detected_player, 12 - power_upgrade * 2, 3.0F);
            if (detected_player.motionX <= 7.0
               && detected_player.motionX >= -7.0
               && detected_player.motionZ <= 7.0
               && detected_player.motionZ >= -7.0) {
               double xboost = Math.signum(playerIn.posX - detected_player.posX) * -5.0;

               double zboost;
               for (zboost = Math.signum(playerIn.posZ - detected_player.posZ) * -5.0;
                  xboost > 7.0 || zboost > 7.0 || xboost < -7.0 || zboost < -7.0;
                  zboost *= 0.98
               ) {
                  xboost *= 0.98;
               }

               detected_player.addVelocity(xboost, 1.0, zboost);
               detected_player.velocityChanged = true;
            }
         }
      }
   }

   @SideOnly(Side.CLIENT)
   public void addInformation(ItemStack stack, @Nullable World worldIn, List<String> tooltip, ITooltipFlag flagIn) {
      tooltip.add(TextFmt.Italic + "Unleashes an extremely powerful shockwave when given a Celestial Redstone.");
      tooltip.add(TextFmt.Italic + "Per Module Upgrades:");
      tooltip.add(TextFmt.Red + "NW: Power Modules | 22% Damage");
      tooltip.add(TextFmt.Aqua + "NE: Efficiency Modules | 16% Reduced Consumption");
      tooltip.add(TextFmt.Light_Purple + "SE: Depth Modules | 4 Blocks Up/Down");
      tooltip.add(TextFmt.Yellow + "SW: Range Modules | 8 Block Radius");
   }
}
