package xol.lostinfinity.block.generator;

import java.util.ArrayList;
import java.util.UUID;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.server.management.PlayerList;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import xol.lostinfinity.block.tileentity.TileEntityGenerator;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.tool.ItemCloakingDevice;

public class BlockGenerator extends Block {
   public BlockGenerator(String name, float hardness, Material material, CreativeTabs tab) {
      super(material);
      this.setUnlocalizedName(name);
      this.setRegistryName(name);
      this.setHardness(hardness);
      this.setCreativeTab(tab);
      this.setSoundType(SoundType.STONE);
      this.setLightLevel(1.0F);
      BlockInit.BLOCKS.add(this);
      ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
   }

   public TileEntity createTileEntity(World world, IBlockState state) {
      return new TileEntityGenerator();
   }

   public boolean hasTileEntity(IBlockState state) {
      return true;
   }

   private TileEntityGenerator getTE(World world, BlockPos pos) {
      return (TileEntityGenerator)world.getTileEntity(pos);
   }

   public boolean onBlockActivated(
      World worldIn, BlockPos pos, IBlockState state, EntityPlayer playerIn, EnumHand hand, EnumFacing facing, float hitX, float hitY, float hitZ
   ) {
      if (!playerIn.isSneaking()
         && !playerIn.getHeldItem(hand).isEmpty()
         && playerIn.getHeldItem(hand).getItem().equals(ItemInit.celestialRedstone)) {
         if (!worldIn.isRemote) {
            TileEntityGenerator te = this.getTE(worldIn, pos);
            PlayerList pl = worldIn.getMinecraftServer().getPlayerList();
            boolean isPlacerNull = te.getMyPlacer() == null;
            boolean isUUIDZeroes = isPlacerNull || te.getMyPlacer() == UUID.fromString("00000000-0000-0000-0000-000000000000");
            boolean shouldReplaceOwner = isUUIDZeroes || pl.getPlayerByUUID(te.getMyPlacer()) == null;
            if (shouldReplaceOwner && playerIn.getUniqueID() != null && !playerIn.getName().toLowerCase().contains(".")) {
               te.setMyPlacer(playerIn.getUniqueID());
            }

            UUID placer_uuid = te.getMyPlacer();
            int power_upgrade = 0;
            int efficiency_upgrade = 0;
            int range_upgrade = 0;
            int depth_upgrade = 0;

            for (int bl = 0; bl < 4; bl++) {
               if (worldIn.getBlockState(new BlockPos(pos.getX() - 2, pos.getY() + bl, pos.getZ() - 2))
                  .getBlock()
                  .equals(BlockInit.powerModule)) {
                  power_upgrade++;
               }

               if (worldIn.getBlockState(new BlockPos(pos.getX() + 2, pos.getY() + bl, pos.getZ() - 2))
                  .getBlock()
                  .equals(BlockInit.efficiencyModule)) {
                  efficiency_upgrade++;
               }

               if (worldIn.getBlockState(new BlockPos(pos.getX() - 2, pos.getY() + bl, pos.getZ() + 2))
                  .getBlock()
                  .equals(BlockInit.rangeModule)) {
                  range_upgrade++;
               }

               if (worldIn.getBlockState(new BlockPos(pos.getX() + 2, pos.getY() + bl, pos.getZ() + 2))
                  .getBlock()
                  .equals(BlockInit.depthModule)) {
                  depth_upgrade++;
               }
            }

            this.activateGenerator(worldIn, pos, state, playerIn, power_upgrade, efficiency_upgrade, range_upgrade, depth_upgrade, placer_uuid);
            boolean run = true;
            int yOff = 1;
            ArrayList<BlockGenerator> gens_used = new ArrayList<>();
            gens_used.add(this);

            for (; run; yOff++) {
               Block aboveBlock = worldIn.getBlockState(pos.add(0, yOff, 0)).getBlock();
               if (aboveBlock instanceof BlockGenerator && !gens_used.contains(aboveBlock)) {
                  BlockGenerator nextGen = (BlockGenerator)aboveBlock;
                  gens_used.add(nextGen);
                  nextGen.activateGenerator(worldIn, pos, state, playerIn, power_upgrade, efficiency_upgrade, range_upgrade, depth_upgrade, placer_uuid);
               } else {
                  run = false;
               }
            }
         }

         worldIn.playSound(
            playerIn.posX, playerIn.posY, playerIn.posZ, SoundInit.GALAXYFIRE, SoundCategory.MASTER, 2.0F, 1.0F, false
         );
         playerIn.getHeldItem(hand).shrink(1);
      }

      return true;
   }

   public void activateGenerator(
      World worldIn,
      BlockPos pos,
      IBlockState state,
      EntityPlayer playerIn,
      int power_upgrade,
      int efficiency_upgrade,
      int range_upgrade,
      int depth_upgrade,
      UUID placer_uuid
   ) {
   }

   protected boolean is_detectable(EntityLivingBase entity) {
      if (entity instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)entity;
         if (player.getHeldItemMainhand().getItem() instanceof ItemCloakingDevice) {
            ItemStack held = player.getHeldItemMainhand();
            if (held.hasTagCompound() && held.getTagCompound().getBoolean("Cloaking")) {
               return false;
            }
         }
      }

      return true;
   }
}
