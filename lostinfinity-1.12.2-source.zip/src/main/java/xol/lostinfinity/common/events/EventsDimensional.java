package xol.lostinfinity.common.events;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Enchantments;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.DimensionType;
import net.minecraftforge.event.world.BlockEvent.BreakEvent;
import net.minecraftforge.event.world.BlockEvent.EntityPlaceEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xol.lostinfinity.block.basic.BlockStarforgeOre;
import xol.lostinfinity.block.basic.ISpecialHarvest;
import xol.lostinfinity.block.misc.BlockPowerCrystal;
import xol.lostinfinity.dimension.util.DimensionActivator;
import xol.lostinfinity.dimension.util.DimensionNoBuild;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.init.ItemInit;

public class EventsDimensional {
   @SubscribeEvent
   public void celestialArenaNoBuild(EntityPlaceEvent event) {
      if (event.getWorld().getBiome(event.getPos()) instanceof DimensionNoBuild && event.getEntity() instanceof EntityPlayer) {
         EntityPlayer pl = (EntityPlayer)event.getEntity();
         if (!pl.isCreative()
            && !(event.getPlacedBlock().getBlock() instanceof BlockPowerCrystal)
            && !event.getPlacedBlock().getBlock().equals(Blocks.AIR)) {
            event.setCanceled(true);
         }
      }
   }

   @SubscribeEvent
   public void celestialArenaProt(BreakEvent event) {
      if (event.getWorld().getBiome(event.getPos()).equals(DimensionInit.biomeNonexistence)
         && event.getState().getBlock().equals(Blocks.MAGMA)
         && event.getPlayer() != null) {
         ItemStack held = event.getPlayer().getHeldItem(event.getPlayer().getActiveHand());
         if (!held.isEmpty() && held.getItem().equals(ItemInit.forgeFirePickaxe)) {
            DimensionActivator.transferEntity(event.getPlayer(), DimensionType.OVERWORLD);
            event.setCanceled(true);
         }
      }

      if (event.getWorld().getBiome(event.getPos()) instanceof DimensionNoBuild) {
         if (event.getState().getBlock() instanceof BlockStarforgeOre) {
            BlockStarforgeOre block = (BlockStarforgeOre)event.getState().getBlock();
            boolean schedule = false;
            if (!block.isDepletedType) {
               if (event.getPlayer() != null) {
                  ItemStack held = event.getPlayer().getHeldItem(event.getPlayer().getActiveHand());
                  if (!held.isEmpty() && held.getItem().equals(ItemInit.forgeFirePickaxe)) {
                     int fortune = EnchantmentHelper.getEnchantmentLevel(Enchantments.FORTUNE, event.getPlayer().getHeldItemMainhand());
                     Item drop = event.getState().getBlock().getItemDropped(event.getState(), event.getWorld().rand, fortune);
                     if (!held.hasTagCompound()) {
                        held.setTagCompound(new NBTTagCompound());
                     } else {
                        String[] split = drop.getRegistryName().getResourcePath().split("_");
                        int chargesLeft = held.getTagCompound().getInteger(split[split.length - 2]);
                        if (chargesLeft > 0) {
                           event.getState()
                              .getBlock()
                              .dropBlockAsItem(event.getWorld(), event.getPlayer().getPosition().add(0, 2, 0), event.getState(), fortune);
                           event.getWorld().setBlockState(event.getPos(), BlockInit.oreDepleted.getDefaultState());
                           schedule = true;
                           held.getTagCompound().setInteger(split[split.length - 2], chargesLeft - 1);
                        } else {
                           event.setCanceled(true);
                        }
                     }
                  }
               }
            } else {
               schedule = !event.getWorld().isUpdateScheduled(event.getPos(), block);
            }

            if (schedule) {
               int lowestDelay = 10;
               int highestDelay = 31;
               int delay = event.getWorld().rand.nextInt(highestDelay - lowestDelay) + lowestDelay;
               event.getWorld().scheduleUpdate(event.getPos(), block, delay * 20);
            }
         } else if (event.getState().getBlock() instanceof ISpecialHarvest) {
            ISpecialHarvest harvest_block = (ISpecialHarvest)event.getState().getBlock();
            if (harvest_block.isHarvestable(event.getWorld(), event.getPos(), event.getPlayer())) {
               if (event.getPlayer().getHeldItemMainhand().getItem() == harvest_block.getToolNeeded()) {
                  if (!event.getWorld().isRemote) {
                     EntityItem crystal = new EntityItem(
                        event.getWorld(),
                        event.getPos().getX(),
                        event.getPos().getY(),
                        event.getPos().getZ(),
                        new ItemStack(harvest_block.getHarvestResult(event.getWorld(), event.getPos()))
                     );
                     crystal.motionX = 0.0;
                     crystal.motionY = 0.0;
                     crystal.motionZ = 0.0;
                     event.getWorld().spawnEntity(crystal);
                  }

                  harvest_block.worldHarvestEffect(event.getWorld(), event.getPos(), event.getPlayer());
               }
            } else {
               harvest_block.failedHarvest(event.getWorld(), event.getPos(), event.getPlayer());
            }
         }

         event.setCanceled(!event.getPlayer().isCreative());
      }
   }
}
