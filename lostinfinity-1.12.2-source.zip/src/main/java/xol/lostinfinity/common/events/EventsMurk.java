package xol.lostinfinity.common.events;

import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.event.world.ChunkEvent.Load;
import net.minecraftforge.fluids.BlockFluidBase;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xol.lostinfinity.block.basic.BlockBasicCrop;
import xol.lostinfinity.block.basic.ISpecialMurkMeta;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.DimensionInit;

public class EventsMurk {
   private Random rand = new Random();

   @SubscribeEvent
   public void ChunkLoad(Load event) {
      World world = event.getWorld();
      if (world != null && !world.isRemote && world.provider.getDimensionType() == DimensionInit.infiniteMurk) {
         Chunk chunk = event.getChunk();
         World overworld = world.getMinecraftServer().getWorld(0);
         Chunk overChunk = overworld.getChunkFromChunkCoords(chunk.x, chunk.z);

         for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
               for (int y = 0; y < 256; y++) {
                  IBlockState state = overChunk.getBlockState(x, y, z);
                  IBlockState placeState = getBlockToPlace(state, y);
                  chunk.setBlockState(new BlockPos(x, y, z), placeState);
               }
            }
         }

         chunk.setModified(true);
      }
   }

   public static IBlockState getBlockToPlace(IBlockState state, int height) {
      Block block = state.getBlock();
      String regName = block.getRegistryName().toString();
      Material material = state.getMaterial();
      Random rand = new Random();
      if (!block.isFullCube(state)) {
         if (block instanceof BlockStairs) {
            return material == Material.WOOD
               ? BlockInit.murkplankStairs.getStateFromMeta(block.getMetaFromState(state))
               : BlockInit.murkbrickStairs.getStateFromMeta(block.getMetaFromState(state));
         } else if (block instanceof BlockSlab) {
            return material == Material.WOOD
               ? BlockInit.murkplankHalf.getStateFromMeta(block.getMetaFromState(state))
               : BlockInit.murkbrickHalf.getStateFromMeta(block.getMetaFromState(state));
         } else if (regName.contains("glass") && material == Material.GLASS) {
            return BlockInit.murkglass.getDefaultState();
         } else if (!(block instanceof BlockFluidBase) && !(block instanceof BlockLiquid)) {
            if (block == BlockInit.moonFlower) {
               BlockBasicCrop flower = (BlockBasicCrop)block;
               if (flower.getMaxAge() == flower.getCropAge(state)) {
                  return BlockInit.voidFlower.getDefaultState();
               }
            }

            return Blocks.AIR.getDefaultState();
         } else {
            return state;
         }
      } else if (block instanceof ISpecialMurkMeta) {
         int meta = ((ISpecialMurkMeta)block).getMurkMeta(state);
         return block.getStateFromMeta(meta);
      } else if (regName.contains("leaves") && material == Material.LEAVES) {
         return BlockInit.leavesMurk.getDefaultState();
      } else if (regName.contains("log") && material == Material.WOOD) {
         return BlockInit.logsMurk.getDefaultState();
      } else if (regName.toString().contains("planks") && material == Material.WOOD) {
         return BlockInit.murkplanks.getDefaultState();
      } else if (regName.contains("ice") && material == Material.ICE) {
         return BlockInit.murkice.getDefaultState();
      } else if (material == Material.GRASS) {
         return BlockInit.murksoil.getDefaultState();
      } else if (material == Material.GROUND) {
         return BlockInit.murkdirt.getDefaultState();
      } else if (regName.contains("brick")) {
         return BlockInit.murkbricks.getDefaultState();
      } else if (regName.contains("obsidian")) {
         return BlockInit.igneousMurkstone.getDefaultState();
      } else if (regName.contains("bedrock")) {
         return height < 15 && rand.nextInt(20) == 0 ? BlockInit.multiversiteMurk.getDefaultState() : BlockInit.murkcore.getDefaultState();
      } else if (height < 25 && rand.nextInt(100) == 0) {
         return BlockInit.darksteelOre.getDefaultState();
      } else {
         return height < 65 && rand.nextInt(150) == 0 ? BlockInit.atomiteOre.getStateFromMeta(0) : BlockInit.murkstone.getDefaultState();
      }
   }
}
