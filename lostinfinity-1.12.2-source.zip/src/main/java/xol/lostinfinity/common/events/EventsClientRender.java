package xol.lostinfinity.common.events;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelBiped.ArmPose;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumHandSide;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogColors;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogDensity;
import net.minecraftforge.client.event.RenderLivingEvent.Post;
import net.minecraftforge.client.event.RenderLivingEvent.Pre;
import net.minecraftforge.event.entity.player.ItemTooltipEvent;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.FMLNetworkEvent.ClientDisconnectionFromServerEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.dimension.util.DimensionNoBuild;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.item.basics.ItemChanneling;
import xol.lostinfinity.item.classify.ICustomHoldPose;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhu;
import xol.lostinfinity.mob.entity.galaxy.EntityGalaxyDragon;
import xol.lostinfinity.mob.entity.minion.EntityBombDrone;
import xol.lostinfinity.mob.entity.minion.andromeda.EntityAndromedaSegment;

@EventBusSubscriber({Side.CLIENT})
public class EventsClientRender {
   private static final Map<Integer, Entity> renderLast = new HashMap<>();
   private static final Map<Integer, Entity> rendered = new HashMap<>();
   public static final Map<Integer, Entity> renderForce = new HashMap<>();
   private static boolean lock = false;

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void onFogEvent(FogColors event) {
      if (event.getEntity().world.provider.getDimensionType() == DimensionInit.nonexistence) {
         double height = event.getEntity().posY - 30.0;
         if (height < 0.0) {
            height = 0.0;
         }

         float var_clr = (float)height / 400.0F;
         if (var_clr > 0.5F) {
            var_clr = 0.5F;
         }

         event.setRed(var_clr);
         event.setGreen(var_clr / 2.0F);
         event.setBlue(0.0F);
      } else if (event.getEntity().world.provider.getDimensionType() == DimensionInit.infiniteMurk) {
         event.setRed(0.0F);
         event.setBlue(0.1F);
         event.setGreen(0.05F);
      } else if (event.getEntity().world.getBiome(event.getEntity().getPosition()) instanceof DimensionNoBuild) {
         event.setRed(0.0F);
         event.setBlue(0.0F);
         event.setGreen(0.0F);
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public void onFogDensity(FogDensity event) {
      if (event.getEntity().world.provider.getDimensionType() == DimensionInit.nonexistence) {
         event.setDensity(0.03F);
         event.setCanceled(true);
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent(
      receiveCanceled = true
   )
   public void itemToolTip(ItemTooltipEvent event) {
      if (event.getItemStack().hasTagCompound() && event.getItemStack().getTagCompound().hasKey("InfinityMiraged")) {
         event.getToolTip().add(TextFmt.getFormatting(TextFmt.Italic, TextFmt.Aqua) + "MIRAGED");
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onRenderHand(RenderHandEvent event) {
      EntityPlayer player = Minecraft.getMinecraft().player;
      if (player.isInvisible()) {
         event.setCanceled(true);
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onRenderPlayer(Pre<EntityPlayer> event) {
      if (event.getEntity() instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)event.getEntity();
         if (player.isInvisible()) {
            event.setCanceled(true);
         }

         if (player.getLowestRidingEntity() instanceof EntityBombDrone) {
            GlStateManager.pushMatrix();
            GlStateManager.scale(0.0F, 0.0F, 0.0F);
         }

         EnumHand right = EnumHand.MAIN_HAND;
         EnumHand left = EnumHand.OFF_HAND;
         if (player instanceof EntityPlayerSP && player.getPrimaryHand() == EnumHandSide.LEFT) {
            right = EnumHand.OFF_HAND;
            left = EnumHand.MAIN_HAND;
         }

         if (event.getRenderer().getMainModel() instanceof ModelBiped) {
            if (isHoldingCustomPose(player, right)) {
               ((ModelBiped)event.getRenderer().getMainModel()).rightArmPose = ArmPose.BOW_AND_ARROW;
            } else if (isHoldingCustomPose(player, left)) {
               ((ModelBiped)event.getRenderer().getMainModel()).leftArmPose = ArmPose.BOW_AND_ARROW;
            }
         }
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onPostRenderPlayer(Post<EntityPlayer> event) {
      if (event.getEntity() instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)event.getEntity();
         if (player.isInvisible()) {
            event.setCanceled(true);
         }

         if (player.getLowestRidingEntity() instanceof EntityBombDrone) {
            GlStateManager.popMatrix();
         }
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onFOVChange(FOVUpdateEvent event) {
      EntityPlayer player = event.getEntity();
      ItemStack stack = player.getActiveItemStack();
      if (player.isHandActive() && stack.getItem() instanceof ItemChanneling) {
         ItemChanneling channeling = (ItemChanneling)stack.getItem();
         float oldFOV = event.getFov();
         event.setNewfov(channeling.updateFOV(player, stack, oldFOV));
      }
   }

   private static boolean isHoldingCustomPose(EntityPlayer player, EnumHand hand) {
      return player.getHeldItem(hand).getItem() instanceof ICustomHoldPose;
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onRenderGalaxyDragon(Pre<EntityGalaxyDragon> event) {
      if (!lock && event.getEntity() instanceof EntityGalaxyDragon) {
         EntityGalaxyDragon dragon = (EntityGalaxyDragon)event.getEntity();
         if (Minecraft.getMinecraft().gameSettings.thirdPersonView == 0 && Minecraft.getMinecraft().player.getLowestRidingEntity() == dragon) {
            event.setCanceled(true);
            renderLast.put(dragon.getEntityId(), dragon);
         }
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onRenderAndromeda(Pre<EntityAndromedaSegment> event) {
      if (!lock && event.getEntity() instanceof EntityAndromedaSegment) {
         EntityAndromedaSegment segment = (EntityAndromedaSegment)event.getEntity();
         EntityPlayer owner = segment.getController().getOwner();
         if (owner != null && owner == Minecraft.getMinecraft().player && segment.getDistanceSq(owner) <= 900.0) {
            event.setCanceled(true);
            renderLast.put(segment.getEntityId(), segment);
         } else {
            rendered.put(segment.getEntityId(), segment);
         }
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onRenderCthulhu(Pre<EntityCthulhu> event) {
      if (!lock && event.getEntity() instanceof EntityCthulhu) {
         EntityCthulhu cthulhu = (EntityCthulhu)event.getEntity();
         rendered.put(cthulhu.getEntityId(), cthulhu);
      }
   }

   @SideOnly(Side.CLIENT)
   @SubscribeEvent
   public static void onRenderLast(RenderWorldLastEvent event) {
      if (renderLast.isEmpty() && renderForce.isEmpty()) {
         rendered.clear();
      } else {
         lock = true;
         GlStateManager.enableFog();
         RenderHelper.enableStandardItemLighting();
         Minecraft.getMinecraft().entityRenderer.enableLightmap();
         Iterator<Integer> i = renderForce.keySet().iterator();

         while (i.hasNext()) {
            int id = i.next();
            Entity entity = renderForce.get(id);
            if (entity != null && !entity.isDead) {
               if (!rendered.containsKey(id) && !renderLast.containsKey(id)) {
                  Minecraft.getMinecraft().getRenderManager().renderEntityStatic(entity, event.getPartialTicks(), false);
               }
            } else {
               i.remove();
            }
         }

         for (Entity entity : renderLast.values()) {
            if (entity != null && !entity.isDead) {
               Minecraft.getMinecraft().getRenderManager().renderEntityStatic(entity, event.getPartialTicks(), false);
            }
         }

         Minecraft.getMinecraft().entityRenderer.disableLightmap();
         RenderHelper.disableStandardItemLighting();
         GlStateManager.disableFog();
         lock = false;
         renderLast.clear();
         rendered.clear();
      }
   }

   @SubscribeEvent
   public void onClientDisconnect(ClientDisconnectionFromServerEvent event) {
      renderLast.clear();
      renderForce.clear();
      rendered.clear();
   }

   @SubscribeEvent
   public void onPlayerChangeWorld(Unload event) {
      renderLast.clear();
      renderForce.clear();
      rendered.clear();
   }
}
