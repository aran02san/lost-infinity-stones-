package xol.lostinfinity.common.events;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.state.IBlockState;
import net.minecraft.command.CommandKill;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.DimensionType;
import net.minecraft.world.World;
import net.minecraftforge.event.CommandEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingJumpEvent;
import net.minecraftforge.event.entity.living.PotionEvent.PotionAddedEvent;
import net.minecraftforge.event.entity.living.PotionEvent.PotionExpiryEvent;
import net.minecraftforge.event.entity.living.PotionEvent.PotionRemoveEvent;
import net.minecraftforge.event.entity.player.FillBucketEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.world.BlockEvent.HarvestDropsEvent;
import net.minecraftforge.fluids.UniversalBucket;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.ItemCraftedEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerChangedDimensionEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.PlayerTickEvent;
import net.minecraftforge.fml.server.FMLServerHandler;
import xol.lostinfinity.block.basic.BlockBasicFluid;
import xol.lostinfinity.block.basic.ITetherable;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.dimension.util.DimensionActivator;
import xol.lostinfinity.dimension.util.DimensionEffectRegistry;
import xol.lostinfinity.dimension.util.DimensionNoBuild;
import xol.lostinfinity.init.BlockInit;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.init.ItemInit;
import xol.lostinfinity.init.ParticleInit;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.activate.ItemRiftWalker;
import xol.lostinfinity.item.armor.ItemLostArmor;
import xol.lostinfinity.item.classify.IChargeItem;
import xol.lostinfinity.item.classify.IDimensionSwitch;
import xol.lostinfinity.item.classify.IHeldTick;
import xol.lostinfinity.item.classify.IHotbarTick;
import xol.lostinfinity.item.classify.IMoveTick;
import xol.lostinfinity.item.classify.IPotionReactive;
import xol.lostinfinity.item.classify.ItemSoulbound;
import xol.lostinfinity.mob.entity.base.EntityMultipleLives;
import xol.lostinfinity.mob.entity.misc.EntitySkybooster;
import xol.lostinfinity.util.coordinates.GalaxyCoordinates;
import xol.lostinfinity.util.damagesource.DeathMessage;
import xol.lostinfinity.util.data.CustomParticleConfig;
import xol.lostinfinity.util.data.IMaxAttack;
import xol.lostinfinity.util.fx.IParticleSpawner;
import xol.lostinfinity.util.player.PlayerManager;

public class EventsPlayerAction implements IMaxAttack {
   private final Map<EntityPlayer, ItemStack> clientMainhandItem = new ConcurrentHashMap<>();
   private final Map<EntityPlayer, ItemStack> serverMainhandItem = new ConcurrentHashMap<>();
   private final Map<EntityPlayer, ItemStack> clientOffhandItem = new ConcurrentHashMap<>();
   private final Map<EntityPlayer, ItemStack> serverOffhandItem = new ConcurrentHashMap<>();

   private EntityPlayer getPlayerByUUID(World world, UUID uuid) {
      return uuid == null
         ? null
         : (
            world.isRemote
               ? FMLServerHandler.instance().getServer().getPlayerList().getPlayerByUUID(uuid)
               : world.getMinecraftServer().getPlayerList().getPlayerByUUID(uuid)
         );
   }

   @SubscribeEvent
   public void onDimensionTransfer(PlayerChangedDimensionEvent event) {
      ItemSoulbound.removeSoulBound(event.player);
      if ((event.fromDim == DimensionInit.celestialVoid.getId() || event.fromDim == DimensionInit.grandmasterOutpost.getId())
         && !event.player.world.isRemote) {
         event.player.removePotionEffect(Potion.getPotionById(23));
      }

      ItemStack stack = event.player.getHeldItemMainhand();
      Item item = stack.getItem();
      if (item instanceof IDimensionSwitch) {
         ((IDimensionSwitch)item).onDimensionSwitch(event.player, stack);
      }
   }

   @SubscribeEvent
   public void onPlayerCraft(ItemCraftedEvent event) {
      EntityPlayer crafter = event.player;
      if (!crafter.world.isRemote && event.crafting.getItem() == ItemInit.puzzleKey) {
         crafter.sendMessage(
            new TextComponentString(
               TextFmt.Dark_Aqua
                  + "The Echo: I see everywhere "
                  + crafter.getName()
                  + ". Are you looking to play"
                  + TextFmt.Reset
                  + TextFmt.Gold
                  + " one last game?"
            )
         );
      }
   }

   @SubscribeEvent
   public void onPlayerHurt(LivingHurtEvent event) {
      if (!event.getEntity().getEntityWorld().isRemote && event.getEntity() instanceof EntityPlayer) {
         if (event.getSource() == DamageSource.OUT_OF_WORLD && event.getEntity().world.provider.getDimensionType() == DimensionInit.nonexistence) {
            BlockPos teleport = GalaxyCoordinates.galaxyDungeonEntry();
            ((EntityPlayer)event.getEntity()).setPositionAndUpdate(teleport.getX(), teleport.getY(), teleport.getZ());
            ((EntityPlayer)event.getEntity()).fallDistance = -1.0F;
            event.setCanceled(true);
         }

         EntityPlayer owner = (EntityPlayer)event.getEntity();
         if (PlayerManager.isWearingAnySet(owner)) {
            event.setCanceled(true);
         } else {
            ItemStack vessel = null;

            for (int i = 0; i <= 8; i++) {
               ItemStack stack = owner.inventory.getStackInSlot(i);
               if (stack.getItem().equals(ItemInit.lifeVessel)
                  && stack.hasTagCompound()
                  && this.getPlayerByUUID(event.getEntity().world, stack.getTagCompound().getUniqueId("target")) != null) {
                  vessel = stack;
                  break;
               }
            }

            if (vessel != null) {
               EntityPlayer target = owner.world.getMinecraftServer().getPlayerList().getPlayerByUUID(vessel.getTagCompound().getUniqueId("target"));
               if (target != null) {
                  if (!target.isDead) {
                     target.setLastAttackedEntity(owner);
                     target.playSound(SoundEvents.ENTITY_PLAYER_ATTACK_CRIT, 2.0F, 3.0F);
                     target.setHealth(target.getHealth() - event.getAmount());
                     owner.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
                     if (event.getSource().isFireDamage()) {
                        target.setFire(5);
                     }

                     if (target.getHealth() <= 0.0F) {
                        vessel.getTagCompound().removeTag("targetMost");
                        vessel.getTagCompound().removeTag("targetLeast");
                        vessel.getTagCompound().removeTag("targetName");
                        owner.playSound(SoundEvents.BLOCK_GLASS_BREAK, 1.0F, 1.0F);
                        target.extinguish();
                        target.onDeath(event.getSource());
                        target.setDead();
                     }

                     event.setCanceled(true);
                     return;
                  }
               } else {
                  vessel.getTagCompound().removeTag("targetMost");
                  vessel.getTagCompound().removeTag("targetLeast");
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onPlayerDeath(LivingDeathEvent event) {
      if (event.getEntity() instanceof EntityPlayer) {
         EntityPlayer owner = (EntityPlayer)event.getEntity();
         if (owner != null) {
            ItemStack vessel = null;

            for (int i = 0; i <= 8; i++) {
               ItemStack stack = owner.inventory.getStackInSlot(i);
               if (stack.getItem().equals(ItemInit.lifeVessel)
                  && stack.hasTagCompound()
                  && owner.world.getMinecraftServer().getPlayerList().getPlayerByUUID(stack.getTagCompound().getUniqueId("target")) != null) {
                  vessel = stack;
                  break;
               }
            }

            if (vessel != null) {
               EntityPlayer victim = owner.world.getMinecraftServer().getPlayerList().getPlayerByUUID(vessel.getTagCompound().getUniqueId("target"));
               if (victim != null && !victim.isDead) {
                  vessel.getTagCompound().removeTag("targetMost");
                  vessel.getTagCompound().removeTag("targetLeast");
                  vessel.getTagCompound().removeTag("targetName");
                  owner.playSound(SoundEvents.BLOCK_GLASS_BREAK, 1.0F, 1.0F);
                  IMaxAttack.dealMaxHealth(owner, victim, 1);
                  owner.setHealth(owner.getMaxHealth());
                  event.setCanceled(true);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onBucketFill(FillBucketEvent event) {
      if (event.getTarget() != null && event.getTarget().typeOfHit == Type.BLOCK) {
         IBlockState block = event.getWorld().getBlockState(event.getTarget().getBlockPos());
         if (block.getBlock() instanceof BlockBasicFluid) {
            ((BlockBasicFluid)block.getBlock()).handleFill(event, block);
         }
      }
   }

   @SubscribeEvent
   public void rightClickBlock(PlayerInteractEvent event) {
      ItemStack stack = event.getItemStack();
      if (event.getEntityPlayer().isPotionActive(PotionInit.SPECTRAL) && event.isCancelable() && !stack.getItem().equals(ItemInit.riftWalker)) {
         event.setCanceled(true);
      }

      if (event.getEntityPlayer().isPotionActive(PotionInit.PHASED) && event.isCancelable()) {
         event.setCanceled(true);
      }

      if ((stack.getItem() instanceof ItemBucket && !stack.getItem().equals(Items.BUCKET) || stack.getItem() instanceof UniversalBucket)
         && event.getWorld().getBiome(event.getPos()) instanceof DimensionNoBuild) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent(
      priority = EventPriority.LOWEST
   )
   public void soulboundClear(LivingDeathEvent event) {
      if (!event.isCanceled() && event.getEntity() instanceof EntityPlayer) {
         ItemSoulbound.removeSoulBound((EntityPlayer)event.getEntity());
      }
   }

   @SubscribeEvent
   public void onPlayerJump(LivingJumpEvent event) {
      if (event.getEntity() instanceof EntityPlayer) {
         World world = event.getEntity().world;
         EntityPlayer player = (EntityPlayer)event.getEntity();
         if (!world.isRemote) {
            if (world.getBlockState(player.getPosition().down()).getBlock().equals(BlockInit.launchPad)) {
               if (world.provider.getDimensionType() == DimensionType.OVERWORLD) {
                  player.motionY = 0.01;
                  player.velocityChanged = true;
                  EntitySkybooster boost = new EntitySkybooster(world);
                  boost.setPosition(player.posX, player.posY, player.posZ);
                  boost.setOwner(player);
                  world.spawnEntity(boost);
               } else {
                  DimensionActivator.transferEntity(player, DimensionType.OVERWORLD);
               }
            } else if (world.getBlockState(player.getPosition().down()).getBlock().equals(BlockInit.fabricReformulator)
               || world.getBlockState(player.getPosition().down().down()).getBlock().equals(BlockInit.fabricReformulator)) {
               if (world.provider.getDimensionType() == DimensionType.OVERWORLD) {
                  DimensionActivator.transferEntityWithCoords(
                     player, DimensionInit.infiniteMurk, player.posX, player.posY, player.posZ
                  );
               } else {
                  DimensionActivator.transferEntityWithCoords(player, DimensionType.OVERWORLD, player.posX, player.posY, player.posZ);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onPotionExpire(PotionExpiryEvent event) {
      if (event.getEntity() != null && event.getEntity() instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)event.getEntity();
         if (event.getPotionEffect().getPotion().equals(PotionInit.SPECTRAL)) {
            ItemRiftWalker.endEffect(player);
         }
      }

      if (event.getPotionEffect().getPotion().equals(PotionInit.SPONTANEOUS_COMBUSTION) && !event.getEntity().world.isRemote) {
         int level = event.getEntityLiving().getActivePotionEffect(PotionInit.SPONTANEOUS_COMBUSTION).getAmplifier();
         IMaxAttack.dealPotionDamage(event.getEntityLiving(), event.getEntityLiving().getMaxHealth() * (0.3F + 0.15F * level));
         if (event.getEntityLiving() instanceof EntityMultipleLives) {
            EntityMultipleLives multiEntity = (EntityMultipleLives)event.getEntityLiving();
            multiEntity.takeawayNumLives(1 + MathHelper.floor(level / 2));
         }

         EntityLivingBase living = event.getEntityLiving();
         CustomParticleConfig config1 = new CustomParticleConfig();
         config1.createInstance().setParticle(ParticleInit.EXPLOSION).setIgnoreRange(true);
         IParticleSpawner.spawnParticle(living.world, config1, living.posX, living.posY, living.posZ);
         event.getEntityLiving()
            .world
            .playSound(null, event.getEntityLiving().getPosition(), SoundInit.GENERIC_EXPLOSION, SoundCategory.PLAYERS, 1.0F, 1.0F);
      }
   }

   @SubscribeEvent
   public void onCommandEvent(CommandEvent event) {
      if (event.getCommand() instanceof CommandKill) {
         String sender = "";
         if (event.getParameters().length == 0) {
            sender = event.getSender().getName();
         } else if (event.getParameters().length == 1) {
            sender = event.getParameters()[0];
         }

         EntityPlayer target = event.getSender().getEntityWorld().getMinecraftServer().getPlayerList().getPlayerByUsername(sender);
         if (target != null) {
            ItemStack vessel = null;

            for (int i = 0; i <= 8; i++) {
               ItemStack stack = target.inventory.getStackInSlot(i);
               if (stack.getItem().equals(ItemInit.lifeVessel)
                  && stack.hasTagCompound()
                  && this.getPlayerByUUID(event.getSender().getEntityWorld(), stack.getTagCompound().getUniqueId("target")) != null) {
                  vessel = stack;
                  break;
               }
            }

            if (vessel != null) {
               EntityPlayer victim = event.getSender()
                  .getEntityWorld()
                  .getMinecraftServer()
                  .getPlayerList()
                  .getPlayerByUUID(vessel.getTagCompound().getUniqueId("target"));
               if (victim != null && !victim.isDead) {
                  vessel.getTagCompound().removeTag("targetMost");
                  vessel.getTagCompound().removeTag("targetLeast");
                  vessel.getTagCompound().removeTag("targetName");
                  target.playSound(SoundEvents.BLOCK_GLASS_BREAK, 1.0F, 1.0F);
                  IMaxAttack.dealMaxHealth(target, victim, 1);
                  event.setCanceled(true);
               }
            }
         }
      }
   }

   @SubscribeEvent
   public void onHarvestBlock(HarvestDropsEvent event) {
      if (event.getState().getBlock() == Blocks.DIAMOND_ORE) {
         if (event.getHarvester() != null) {
            Item held = event.getHarvester().getHeldItem(event.getHarvester().getActiveHand()).getItem();
            if (held != null && held == ItemInit.celestialMinersPickaxe && event.getWorld().rand.nextInt(25) == 1) {
               event.getDrops().add(new ItemStack(ItemInit.celestialDiamond));
            }
         }
      } else if (event.getState().getBlock() == Blocks.EMERALD_ORE) {
         if (event.getHarvester() != null) {
            Item held = event.getHarvester().getHeldItem(event.getHarvester().getActiveHand()).getItem();
            if (held != null && held == ItemInit.celestialMinersPickaxe && event.getWorld().rand.nextInt(15) == 1) {
               event.getDrops().add(new ItemStack(ItemInit.celestialEmerald));
            }
         }
      } else if (event.getState().getBlock() != Blocks.REDSTONE_ORE && event.getState().getBlock() != Blocks.LIT_REDSTONE_ORE) {
         if (event.getState().getBlock() == Blocks.QUARTZ_ORE) {
            if (event.getHarvester() != null) {
               Item held = event.getHarvester().getHeldItem(event.getHarvester().getActiveHand()).getItem();
               if (held != null && held == ItemInit.celestialMinersPickaxe && event.getWorld().rand.nextInt(35) == 1) {
                  event.getDrops().add(new ItemStack(ItemInit.celestialQuartz));
               }
            }
         } else if (event.getState().getBlock() == Blocks.IRON_ORE && event.getHarvester() != null) {
            Item held = event.getHarvester().getHeldItem(event.getHarvester().getActiveHand()).getItem();
            if (held != null && held == ItemInit.celestialMinersPickaxe && event.getWorld().rand.nextInt(25) == 1) {
               event.getDrops().add(new ItemStack(ItemInit.celestialIron));
            }
         }
      } else if (event.getHarvester() != null) {
         Item held = event.getHarvester().getHeldItem(event.getHarvester().getActiveHand()).getItem();
         if (held != null && held == ItemInit.celestialMinersPickaxe && event.getWorld().rand.nextInt(35) == 1) {
            event.getDrops().add(new ItemStack(ItemInit.celestialRedstone));
         }
      }
   }

   @SubscribeEvent
   public void onPlayerPotionAdd(PotionAddedEvent event) {
      if (event.getEntityLiving() instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)event.getEntityLiving();
         if (!player.world.isRemote) {
            ItemStack mainItem = player.getHeldItem(EnumHand.MAIN_HAND);
            if (mainItem.getItem() instanceof IPotionReactive) {
               ((IPotionReactive)mainItem.getItem())
                  .potionAddReaction(player, mainItem, EnumHand.MAIN_HAND, event.getPotionEffect(), event.getOldPotionEffect());
            }

            ItemStack offItem = player.getHeldItem(EnumHand.OFF_HAND);
            if (offItem.getItem() instanceof IPotionReactive) {
               ((IPotionReactive)offItem.getItem())
                  .potionAddReaction(player, offItem, EnumHand.OFF_HAND, event.getPotionEffect(), event.getOldPotionEffect());
            }
         }
      }
   }

   @SubscribeEvent
   public void onPlayerPotionRemove(PotionRemoveEvent event) {
      if (event.getEntityLiving() instanceof EntityPlayer) {
         EntityPlayer player = (EntityPlayer)event.getEntityLiving();
         if (!player.world.isRemote) {
            ItemStack mainItem = player.getHeldItem(EnumHand.MAIN_HAND);
            if (mainItem.getItem() instanceof IPotionReactive) {
               ((IPotionReactive)mainItem.getItem())
                  .potionRemoveReaction(player, mainItem, EnumHand.MAIN_HAND, event.getPotion(), event.getPotionEffect());
            }

            ItemStack offItem = player.getHeldItem(EnumHand.OFF_HAND);
            if (offItem.getItem() instanceof IPotionReactive) {
               ((IPotionReactive)offItem.getItem()).potionRemoveReaction(player, offItem, EnumHand.OFF_HAND, event.getPotion(), event.getPotionEffect());
            }
         }
      }
   }

   @SubscribeEvent
   public void onTickEvent(PlayerTickEvent event) {
      if (event.phase == Phase.START) {
         boolean enableArmor = PlayerManager.isWearingAnySet(event.player) && !event.player.isPotionActive(PotionInit.NULLIFIED);
         ItemLostArmor.handleStandardArmorBonus(event.player, enableArmor);
         ItemStack mainHand = event.player.getHeldItemMainhand();
         ItemStack offhand = event.player.getHeldItemOffhand();
         this.processIHeldTick(event.player, EnumHand.MAIN_HAND, mainHand);
         this.processIHeldTick(event.player, EnumHand.OFF_HAND, offhand);

         for (int i = 0; i <= 8; i++) {
            ItemStack stack = event.player.inventory.getStackInSlot(i);
            if (stack.getItem() instanceof IHotbarTick) {
               IHotbarTick hotbarItem = (IHotbarTick)stack.getItem();
               hotbarItem.hotbarTick(event.player, i, stack);
            }
         }

         if (!event.player.world.isRemote && mainHand.hasTagCompound() && mainHand.getTagCompound().hasKey("InfinityMiraged")) {
            int mirageTime = mainHand.getTagCompound().getInteger("InfinityMiraged");
            int ticksExisted = event.player.ticksExisted;
            if (Math.abs(mirageTime - ticksExisted) > 300) {
               event.player.setHeldItem(EnumHand.MAIN_HAND, ItemStack.EMPTY);
               event.player.sendMessage(new TextComponentString(TextFmt.Aqua + "The miraged item vanishes into thin air..."));
               event.player
                  .world
                  .playSound(
                     null,
                     event.player.getPosition(),
                     SoundInit.MAGIC_WEAPON_13,
                     SoundCategory.PLAYERS,
                     1.0F,
                     0.8F + event.player.world.rand.nextFloat() * 0.4F
                  );
            }
         }

         if (!event.player.world.isRemote && offhand.hasTagCompound() && offhand.getTagCompound().hasKey("InfinityMiraged")) {
            int mirageTime = offhand.getTagCompound().getInteger("InfinityMiraged");
            int ticksExisted = event.player.ticksExisted;
            if (Math.abs(mirageTime - ticksExisted) > 300) {
               event.player.setHeldItem(EnumHand.OFF_HAND, ItemStack.EMPTY);
               event.player.sendMessage(new TextComponentString(TextFmt.Aqua + "The miraged item vanishes into thin air..."));
               event.player
                  .world
                  .playSound(
                     null,
                     event.player.getPosition(),
                     SoundInit.MAGIC_WEAPON_13,
                     SoundCategory.PLAYERS,
                     1.0F,
                     0.8F + event.player.world.rand.nextFloat() * 0.4F
                  );
            }
         }

         DimensionEffectRegistry.tickPlayerDimensionEffects(event.player);
         if (event.player.isPotionActive(PotionInit.DIMENSIONAL_TEAR) && !event.player.world.isRemote && event.player.ticksExisted % 30 == 0) {
            if (event.player.getHeldItemMainhand().getItem() != ItemInit.synchronizer
               && event.player.getHeldItemOffhand().getItem() != ItemInit.synchronizer
               && event.player.getHeldItemMainhand().getItem() != ItemInit.advancedSynchronizer
               && event.player.getHeldItemOffhand().getItem() != ItemInit.advancedSynchronizer) {
               int level = event.player.getActivePotionEffect(PotionInit.DIMENSIONAL_TEAR).getAmplifier() + 1;
               float damage = level * event.player.getMaxHealth() / 20.0F;
               IMaxAttack.dealPotionDamage(event.player, damage);
               if (event.player.getHealth() <= 0.0F) {
                  DeathMessage.broadcastDeathMessage(
                     event.player.getServer(), TextFmt.Red + event.player.getName() + " was split interdimensionally."
                  );
               } else {
                  float speedMulti = level / 2;
                  event.player
                     .addVelocity(
                        this.getRandomFloat(event.player, speedMulti),
                        this.getRandomFloat(event.player, speedMulti),
                        this.getRandomFloat(event.player, speedMulti)
                     );
                  event.player.velocityChanged = true;
               }
            } else {
               event.player.removePotionEffect(PotionInit.DIMENSIONAL_TEAR);
            }
         }

         if (event.player.isPotionActive(PotionInit.SUPERSONIC) && !event.player.world.isRemote) {
            boolean found = false;
            if (mainHand.getItem() instanceof IMoveTick) {
               IMoveTick tickable = (IMoveTick)mainHand.getItem();
               tickable.moveTick(event.player, EnumHand.MAIN_HAND, mainHand);
               found = true;
            }

            if (offhand.getItem() instanceof IMoveTick) {
               IMoveTick tickable = (IMoveTick)offhand.getItem();
               tickable.moveTick(event.player, EnumHand.OFF_HAND, mainHand);
               found = true;
            }

            if (!found) {
               event.player.removeActivePotionEffect(PotionInit.SUPERSONIC);
            }
         }

         if (event.player.isPotionActive(PotionInit.RAMPAGING) && !event.player.world.isRemote && event.player.ticksExisted % 10 == 0) {
            int level = event.player.getActivePotionEffect(PotionInit.RAMPAGING).getAmplifier();
            int particleLevel = 16 + Math.floorDiv(level, 4);
            int extra = level % 4;
            CustomParticleConfig config1 = new CustomParticleConfig();
            CustomParticleConfig.Instance instance = config1.createInstance();
            switch (Math.min(18, particleLevel)) {
               case 16:
                  instance.setParticle(ParticleInit.FLAME_SMALL).setCount(1 + extra);
                  break;
               case 17:
                  instance.setParticle(ParticleInit.FLAME_MEDIUM).setCount(1 + extra * 2);
                  break;
               case 18:
                  instance.setParticle(ParticleInit.FLAME_LARGE).setCount(1 + extra * 4);
            }

            instance.setSpread(1.0, 0.0, 1.0).setSpeed(0.3, 0.0, 0.3).setVelSpread(1.0, 0.0, 1.0).setIgnoreRange(true);
            IParticleSpawner.spawnParticle(
               event.player.world, config1, event.player.posX, event.player.posY, event.player.posZ
            );
         }

         if (event.player.isPotionActive(PotionInit.SPECTRAL) && !event.player.world.isRemote && event.player.ticksExisted % 10 == 0) {
            CustomParticleConfig config1 = new CustomParticleConfig();
            config1.createInstance().setParticle(ParticleInit.SPECTRAL).setSpread(1.0, 1.0, 1.0).setIgnoreRange(true);
            IParticleSpawner.spawnParticle(
               event.player.world, config1, event.player.posX, event.player.posY, event.player.posZ
            );
         }

         if (event.player.isPotionActive(PotionInit.TERRIFIED) && !event.player.world.isRemote) {
            double radius = 8.0;

            for (EntityLivingBase near : event.player
               .world
               .getEntitiesWithinAABB(EntityLivingBase.class, new AxisAlignedBB(event.player.getPosition()).grow(radius))) {
               if (near.isPotionActive(PotionInit.FEARED)) {
                  Vec3d dir = event.player.getPositionVector().subtract(near.getPositionVector()).normalize();
                  event.player.addVelocity(dir.x / 10.0, dir.y / 10.0 + 0.1, dir.z / 10.0);
                  event.player.velocityChanged = true;
               }
            }
         }

         if (event.player.isPotionActive(PotionInit.CHARGING) && !event.player.world.isRemote) {
            int duration = event.player.getActivePotionEffect(PotionInit.CHARGING).getDuration();
            if (duration <= 1) {
               ItemStack held = event.player.getHeldItemMainhand();
               if (held.getItem() instanceof IChargeItem) {
                  IChargeItem charger = (IChargeItem)held.getItem();
                  charger.endChargeEffect(held, event.player);
                  event.player.removePotionEffect(PotionInit.CHARGING);
               }
            }
         }

         if (event.player.isPotionActive(PotionInit.TETHERED) && !event.player.world.isRemote) {
            this.tether(event);
         }
      }
   }

   private void tether(PlayerTickEvent event) {
      int radius = 7;
      double pullSpeed = 0.4;
      BlockPos logPos = this.getNearestLog(event, radius);
      if (logPos != null) {
         double x = event.player.posX;
         double y = event.player.posY;
         double z = event.player.posZ;
         double distToLog = logPos.distanceSq(x, y, z);
         if (distToLog > 0.0) {
            double diffX = logPos.getX() - x;
            double diffY = logPos.getY() - y;
            double diffZ = logPos.getZ() - z;
            Vec3d dir = new Vec3d(diffX, diffY, diffZ);
            dir.normalize();
            event.player.motionX = dir.x * pullSpeed;
            event.player.motionY = dir.y * pullSpeed;
            event.player.motionZ = dir.z * pullSpeed;
            event.player.velocityChanged = true;
         }
      }
   }

   private BlockPos getNearestLog(PlayerTickEvent event, int radius) {
      double minDist = 99.0;
      BlockPos nearest = null;
      BlockPos playerPos = event.player.getPosition();

      for (int x = playerPos.getX() - radius; x <= playerPos.getX() + radius; x++) {
         for (int y = playerPos.getY() - radius; y <= playerPos.getY() + radius; y++) {
            for (int z = playerPos.getZ() - radius; z <= playerPos.getZ() + radius; z++) {
               BlockPos pos = new BlockPos(x, y, z);
               IBlockState state = event.player.world.getBlockState(pos);
               if (state.getBlock() instanceof ITetherable) {
                  double dist = pos.getDistance((int)event.player.posX, (int)event.player.posY, (int)event.player.posZ);
                  if (dist <= minDist) {
                     minDist = dist;
                     nearest = new BlockPos(pos);
                  }
               }
            }
         }
      }

      return nearest;
   }

   private void processIHeldTick(EntityPlayer player, EnumHand hand, ItemStack curr) {
      Map<EntityPlayer, ItemStack> map = hand == EnumHand.MAIN_HAND
         ? (player.world.isRemote ? this.clientMainhandItem : this.serverMainhandItem)
         : (player.world.isRemote ? this.clientOffhandItem : this.serverOffhandItem);
      ItemStack prev = map.get(player);
      if (curr.getItem() instanceof IHeldTick) {
         IHeldTick tickable = (IHeldTick)curr.getItem();
         if (curr != prev) {
            tickable.startHolding(player, hand, curr);
            if (prev != null && prev.getItem() instanceof IHeldTick) {
               IHeldTick oldTickable = (IHeldTick)prev.getItem();
               oldTickable.stopHolding(player, hand, prev);
            }

            map.put(player, curr);
         }

         tickable.heldTick(player, hand, curr);
      } else if (prev != null && prev.getItem() instanceof IHeldTick) {
         IHeldTick oldTickable = (IHeldTick)prev.getItem();
         oldTickable.stopHolding(player, hand, prev);
         map.remove(player);
      }
   }

   private float getRandomFloat(EntityPlayer player, float mutli) {
      return (-0.5F + player.world.rand.nextFloat()) * mutli;
   }
}
