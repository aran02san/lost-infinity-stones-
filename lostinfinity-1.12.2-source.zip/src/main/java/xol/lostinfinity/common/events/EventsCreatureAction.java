package xol.lostinfinity.common.events;

import java.util.ArrayList;
import java.util.Random;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import xol.lostinfinity.block.basic.ITetherable;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.DimensionInit;
import xol.lostinfinity.init.ParticleInit;
import xol.lostinfinity.init.PotionInit;
import xol.lostinfinity.init.SoundInit;
import xol.lostinfinity.item.classify.IHealReactive;
import xol.lostinfinity.item.classify.ITransfusionEffect;
import xol.lostinfinity.mob.entity.base.EntityDeviantMob;
import xol.lostinfinity.mob.entity.base.EntityFloatingDeviant;
import xol.lostinfinity.mob.entity.base.EntityMultiLivesTameable;
import xol.lostinfinity.mob.entity.base.EntityMultipleLives;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhu;
import xol.lostinfinity.mob.entity.misc.EntityGhostCopy;
import xol.lostinfinity.mob.entity.misc.EntityStarfiend;
import xol.lostinfinity.projectile.entity.EntityEnergyBurst;
import xol.lostinfinity.util.PotionBasic;
import xol.lostinfinity.util.damagesource.DeathMessage;
import xol.lostinfinity.util.data.CustomParticleConfig;
import xol.lostinfinity.util.data.IMaxAttack;
import xol.lostinfinity.util.fx.IParticleSpawner;

public class EventsCreatureAction implements IMaxAttack {
   @SubscribeEvent
   public void deviantDropEvent(LivingDropsEvent event) {
      if ((event.getEntityLiving() instanceof EntityDeviantMob || event.getEntityLiving() instanceof EntityFloatingDeviant)
         && event.getEntityLiving().world.provider.getDimensionType() == DimensionInit.celestialVoid) {
         event.setCanceled(true);
      }
   }

   @SubscribeEvent
   public void onEntityHeal(LivingHealEvent event) {
      EntityLivingBase entity = event.getEntityLiving();
      if (!entity.world.isRemote) {
         if (entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entity;
            ItemStack main = player.getHeldItemMainhand();
            ItemStack off = player.getHeldItemOffhand();
            ItemStack reactive = null;
            if (main.getItem() instanceof IHealReactive) {
               reactive = main;
            } else if (off.getItem() instanceof IHealReactive) {
               reactive = off;
            }

            if (reactive != null) {
               float newHeal = ((IHealReactive)reactive.getItem()).itemHealReaction(player, event.getAmount(), reactive);
               event.setAmount(newHeal);
            }
         }

         if (entity.isPotionActive(PotionInit.BLOOD_TOXIN)) {
            if (entity.getHealth() > 0.0F && !entity.isDead) {
               int level = entity.getActivePotionEffect(PotionInit.BLOOD_TOXIN).getAmplifier();
               float changedAmount = event.getAmount() * (0.0F + 0.2F * level);
               IMaxAttack.dealPotionDamage(entity, changedAmount);
               if (entity.getHealth() <= 0.0F && entity instanceof EntityPlayer) {
                  DeathMessage.broadcastDeathMessage(entity.getServer(), TextFmt.Red + entity.getName() + " died of toxins.");
               }
            }

            event.setCanceled(true);
         }

         if (entity.isPotionActive(PotionInit.PLANESPLIT)) {
            float entityHP = entity.getHealth();
            int level = entity.getActivePotionEffect(PotionInit.PLANESPLIT).getAmplifier();
            float hpCap = entity.getMaxHealth() * (0.9F - 0.1F * level);
            if (entityHP + event.getAmount() > hpCap) {
               event.setAmount(hpCap - entityHP);
            }
         }
      }
   }

   @SubscribeEvent
   public void onTickEvent(LivingUpdateEvent event) {
      EntityLivingBase entity = event.getEntityLiving();
      if (entity.isPotionActive(PotionInit.LAST_BREATH) && !entity.world.isRemote && entity.ticksExisted % 10 == 0) {
         int level = entity.getActivePotionEffect(PotionInit.LAST_BREATH).getAmplifier();
         float entityMaxHp = entity.getMaxHealth();
         IMaxAttack.dealPotionDamage(entity, entityMaxHp / (20 - 2 * level));
         if (entity.getHealth() <= 0.0F && entity instanceof EntityPlayer) {
            DeathMessage.broadcastDeathMessage(entity.getServer(), TextFmt.Red + entity.getName() + " took their final breath.");
         }
      }

      if (entity.isPotionActive(PotionInit.TRANSFUSION) && !entity.world.isRemote) {
         int amplifier = entity.getActivePotionEffect(PotionInit.TRANSFUSION).getAmplifier();

         for (EntityLivingBase nearPlayer : entity.world
            .getEntitiesWithinAABB(EntityLivingBase.class, new AxisAlignedBB(entity.getPosition()).grow(2 + amplifier * 3))) {
            if (!nearPlayer.getUniqueID().equals(entity.getUniqueID())
               && !nearPlayer.isPotionActive(PotionInit.TRANSFUSION)
               && nearPlayer.getActivePotionEffects().size() > 0) {
               ArrayList<Potion> toRemove = new ArrayList<>();

               for (PotionEffect effect : nearPlayer.getActivePotionEffects()) {
                  Potion potion = effect.getPotion();
                  if (potion instanceof PotionBasic && !((PotionBasic)potion).negativeLostEffect()
                     || !(potion instanceof PotionBasic) && !potion.isBadEffect()) {
                     toRemove.add(effect.getPotion());
                     entity.addPotionEffect(effect);
                  }
               }

               for (Potion potion : toRemove) {
                  nearPlayer.removePotionEffect(potion);
               }

               if (entity instanceof EntityPlayer) {
                  ItemStack mainHand = entity.getHeldItemMainhand();
                  ItemStack offhand = entity.getHeldItemOffhand();
                  if (mainHand.getItem() instanceof ITransfusionEffect) {
                     ITransfusionEffect transfusible = (ITransfusionEffect)mainHand.getItem();
                     transfusible.transfuse((EntityPlayer)entity, nearPlayer, EnumHand.MAIN_HAND, mainHand, toRemove);
                  }

                  if (offhand.getItem() instanceof ITransfusionEffect) {
                     ITransfusionEffect transfusible = (ITransfusionEffect)offhand.getItem();
                     transfusible.transfuse((EntityPlayer)entity, nearPlayer, EnumHand.OFF_HAND, offhand, toRemove);
                  }
               }
            }
         }
      }

      if (entity.isPotionActive(PotionInit.NITROUS) && entity.ticksExisted % 20 == 0 && !entity.world.isRemote) {
         int level = entity.getActivePotionEffect(PotionInit.NITROUS).getAmplifier();

         for (EntityLivingBase near_entity : entity.world.getEntitiesWithinAABB(EntityLivingBase.class, entity.getEntityBoundingBox().grow(7.0))) {
            if (!near_entity.getUniqueID().equals(entity.getUniqueID())) {
               boolean canDealTrue = level >= 1;
               if (canDealTrue && near_entity.getDistance(entity) < 3.0F) {
                  IMaxAttack.dealTrueDamage(entity, near_entity, near_entity.getMaxHealth() * 0.75F);
               } else {
                  IMaxAttack.dealMaxHealth(entity, near_entity, 4, 3.0F);
               }
            }
         }

         entity.world
            .playSound(
               null,
               entity.getPosition(),
               SoundInit.GENERIC_WEAPON_11,
               SoundCategory.PLAYERS,
               0.5F,
               0.7F + 0.6F * entity.world.rand.nextFloat()
            );

         for (float angle = 0.0F; angle <= Math.PI * 2; angle = (float)(angle + (Math.PI / 8))) {
            double velocity_x = 10.0 * Math.cos(angle);
            double velocity_z = 10.0 * Math.sin(angle);
            CustomParticleConfig config1 = new CustomParticleConfig();
            config1.createInstance()
               .setParticle(ParticleInit.FLAME_LARGE)
               .setSpread(1.0, 0.0, 1.0)
               .setSpeed(0.3, 0.0, 0.3)
               .setVelSpread(1.0, 0.0, 1.0)
               .setCount(9)
               .setIgnoreRange(true);
            IParticleSpawner.spawnParticle(
               entity.world, config1, entity.posX + velocity_x / 2.0, entity.posY + 1.0, entity.posZ + velocity_z / 2.0
            );
         }
      }

      if (entity.isPotionActive(PotionInit.PLANESPLIT) && !entity.world.isRemote) {
         int level = entity.getActivePotionEffect(PotionInit.PLANESPLIT).getAmplifier();
         float hpCap = entity.getMaxHealth() * (0.9F - 0.1F * level);
         if (entity.getHealth() > hpCap + 0.1F) {
            entity.setHealth(hpCap);
         }

         if (entity.ticksExisted % 3 == 0 && entity instanceof EntityPlayer) {
            EntityPlayer player = (EntityPlayer)entity;
            Random rand = player.world.rand;
            float rYaw = player.rotationYaw * (float) (Math.PI / 180.0);
            float x = -MathHelper.sin(rYaw);
            float z = MathHelper.cos(rYaw);
            Vec3d look = player.getPositionVector().subtract(new Vec3d(x * 2.5, 0.0, z * 2.5).rotateYaw(-0.7F + 1.4F * rand.nextFloat()));
            EntityGhostCopy ghost = new EntityGhostCopy(player.world);
            ghost.setCopiedPlay(player);
            ghost.setPosition(look.x, player.posY + 0.5, look.z);
            player.world.spawnEntity(ghost);
            if (entity.ticksExisted % 18 == 0) {
               switch (rand.nextInt(4)) {
                  case 0:
                     player.world
                        .playSound(null, player.getPosition(), SoundInit.APPARITION_1, SoundCategory.PLAYERS, 0.5F, 0.9F + rand.nextFloat() * 0.2F);
                     break;
                  case 1:
                     player.world
                        .playSound(null, player.getPosition(), SoundInit.APPARITION_2, SoundCategory.PLAYERS, 0.5F, 0.9F + rand.nextFloat() * 0.2F);
                     break;
                  case 2:
                     player.world
                        .playSound(null, player.getPosition(), SoundInit.APPARITION_3, SoundCategory.PLAYERS, 0.5F, 0.9F + rand.nextFloat() * 0.2F);
                     break;
                  case 3:
                     player.world
                        .playSound(null, player.getPosition(), SoundInit.APPARITION_4, SoundCategory.PLAYERS, 0.5F, 0.9F + rand.nextFloat() * 0.2F);
               }
            }
         }
      }

      if (entity.isPotionActive(PotionInit.INTANGIBLE) && !entity.world.isRemote) {
         ItemStack offhandx = entity.getHeldItemOffhand();
         if (!offhandx.isEmpty()) {
            ItemStack droppedCopy = offhandx.copy();
            EntityItem stolenItem = new EntityItem(entity.world, entity.posX, entity.posY + 1.0, entity.posZ, droppedCopy);
            stolenItem.motionX = 0.0;
            stolenItem.motionY = 0.0;
            stolenItem.motionZ = 0.0;
            entity.world.spawnEntity(stolenItem);
            entity.setHeldItem(EnumHand.OFF_HAND, ItemStack.EMPTY);
         }
      }

      if (entity.isPotionActive(PotionInit.GRAVITATIONAL)) {
         int levelx = entity.getActivePotionEffect(PotionInit.GRAVITATIONAL).getAmplifier();
         double force = 0.05 + 0.05 * levelx;
         int size = 3 + levelx * 5;

         for (EntityLivingBase near_entityx : entity.world.getEntitiesWithinAABB(EntityLivingBase.class, entity.getEntityBoundingBox().grow(size, size, size))) {
            if (!near_entityx.getUniqueID().equals(entity.getUniqueID())) {
               near_entityx.addVelocity(
                  Math.signum(entity.posX - near_entityx.posX) * force,
                  Math.signum(entity.posY - near_entityx.posY) * force,
                  Math.signum(entity.posZ - near_entityx.posZ) * force
               );
               near_entityx.velocityChanged = true;
            }
         }
      }

      if (entity.isPotionActive(PotionInit.ULTRAHEAVY)) {
         int levelx = entity.getActivePotionEffect(PotionInit.ULTRAHEAVY).getAmplifier();
         if (entity.motionY > 0.7F) {
            entity.addVelocity(0.0, -(0.5 + 0.2 * levelx), 0.0);
         }
      }

      if (entity.isPotionActive(PotionInit.UNLEASHING)) {
         int levelx = entity.getActivePotionEffect(PotionInit.UNLEASHING).getAmplifier();
         int duration = entity.getActivePotionEffect(PotionInit.UNLEASHING).getDuration();
         if (!entity.world.isRemote) {
            if (entity.ticksExisted % 60 == 0) {
               entity.addPotionEffect(new PotionEffect(PotionInit.UNLEASHING, duration, Math.min(levelx + 1, 9)));
            }

            if (entity.ticksExisted % (21 - levelx * 2) == 0) {
               EntityEnergyBurst shot = new EntityEnergyBurst(entity.world, entity);
               shot.setThrower(entity);
               shot.shootNoVel(entity, entity.rotationPitch, entity.rotationYaw, 0.0F, 2.0F, 0.0F);
               entity.world.spawnEntity(shot);
               entity.world
                  .playSound(
                     null,
                     entity.getPosition(),
                     SoundInit.LASER_WEAPON_7,
                     SoundCategory.PLAYERS,
                     0.4F,
                     0.8F + entity.world.rand.nextFloat() * 0.4F
                  );
            }
         }
      }

      if (entity.isPotionActive(PotionInit.CONTAGIOUS) && !entity.world.isRemote && entity.isPotionActive(PotionInit.PLAGUE)) {
         int levelx = entity.getActivePotionEffect(PotionInit.PLAGUE).getAmplifier();
         if (levelx < 4 && entity.ticksExisted % 100 == 0) {
            int duration = entity.getActivePotionEffect(PotionInit.PLAGUE).getDuration();
            entity.addPotionEffect(new PotionEffect(PotionInit.PLAGUE, duration, levelx + 1));
         }
      }

      if (entity.isPotionActive(PotionInit.RACING_HEART) && !entity.world.isRemote) {
         int duration = entity.getActivePotionEffect(PotionInit.RACING_HEART).getDuration();
         if (duration <= 1) {
            if (entity.getHealth() < entity.getMaxHealth() / 2.0F && !entity.isDead) {
               entity.setDead();
               if (entity instanceof EntityPlayer) {
                  DeathMessage.broadcastDeathMessage(entity.getServer(), TextFmt.Red + entity.getName() + " had a heart attack.");
               }
            }
         } else if (entity.ticksExisted % 5 == 0) {
            entity.heal(entity.getMaxHealth() * 0.1F);
         }
      }

      if (entity.isPotionActive(PotionInit.SUPERCHARGED) && !entity.world.isRemote && entity.ticksExisted % 5 == 0) {
         entity.heal(entity.getMaxHealth() * 0.1F);
      }

      if (entity.isPotionActive(PotionInit.TERRIFIED) && !entity.world.isRemote && entity instanceof EntityLiving) {
         double radius = 8.0;

         for (EntityLivingBase near : entity.world
            .getEntitiesWithinAABB(EntityLivingBase.class, new AxisAlignedBB(entity.getPosition()).grow(radius))) {
            if (near.isPotionActive(PotionInit.FEARED)) {
               Vec3d dir = entity.getPositionVector().subtract(near.getPositionVector()).normalize();
               entity.addVelocity(dir.x / 10.0, dir.y / 10.0 + 0.1, dir.z / 10.0);
               entity.velocityChanged = true;
            }
         }
      }

      if (entity.isPotionActive(PotionInit.TETHERED) && !entity.world.isRemote) {
         this.tether(event);
      }

      if (entity.isPotionActive(PotionInit.PLAGUE) && !entity.world.isRemote) {
         int levelx = entity.getActivePotionEffect(PotionInit.PLAGUE).getAmplifier();
         float entityMaxHp = entity.getMaxHealth();
         int tickDiv = Math.max(2, 50 - 5 * levelx);
         if (entity.ticksExisted % tickDiv == 0) {
            IMaxAttack.dealPotionDamage(entity, entityMaxHp / 3.0F);
            if (entity.getHealth() <= 0.0F) {
               this.doContagion(entity, levelx);
               if (entity instanceof EntityPlayer) {
                  DeathMessage.broadcastDeathMessage(entity.getServer(), TextFmt.Dark_Green + entity.getName() + " has succumbed to the plague.");
               }
            }
         }
      }

      if (entity.isPotionActive(PotionInit.MIASMA) && !entity.world.isRemote) {
         double radius = 5 + entity.getActivePotionEffect(PotionInit.MIASMA).getAmplifier() * 3;

         for (EntityMob nearEntity : entity.world.getEntitiesWithinAABB(EntityMob.class, new AxisAlignedBB(entity.getPosition()).grow(radius))) {
            if (!nearEntity.getUniqueID().equals(entity.getUniqueID())) {
               EntityLivingBase target = nearEntity.getAttackTarget();
               if (target != null && target.getUniqueID().equals(entity.getUniqueID())) {
                  EntityLivingBase nearest = null;
                  double minDist = 99.0;

                  for (EntityLivingBase nearx : entity.world
                     .getEntitiesWithinAABB(EntityLivingBase.class, new AxisAlignedBB(nearEntity.getPosition()).grow(radius))) {
                     if (!nearx.getUniqueID().equals(entity.getUniqueID()) && !nearx.getUniqueID().equals(nearEntity.getUniqueID())) {
                        double dist = nearx.getDistance(nearEntity);
                        if (dist < minDist) {
                           minDist = dist;
                           nearest = nearx;
                        }
                     }
                  }

                  nearEntity.setAttackTarget(nearest);
                  CustomParticleConfig config1 = new CustomParticleConfig();
                  config1.createInstance().setParticle(ParticleInit.MIASMA).setSpread(4.0, 1.0, 4.0).setCount(5).setIgnoreRange(true);
                  IParticleSpawner.spawnParticle(
                     entity.world,
                     config1,
                     nearEntity.posX,
                     nearEntity.posY + nearEntity.height / 2.0F,
                     nearEntity.posZ
                  );
                  entity.world
                     .playSound(
                        null,
                        nearEntity.getPosition(),
                        SoundInit.MIND_CONTROL_POTION,
                        SoundCategory.PLAYERS,
                        1.5F,
                        0.7F + entity.world.rand.nextFloat() * 0.6F
                     );
               }
            }
         }
      }
   }

   private void tether(LivingUpdateEvent event) {
      int radius = 7;
      double pullSpeed = 0.4;
      BlockPos logPos = this.getNearestLog(event, radius);
      if (logPos != null) {
         double x = event.getEntity().posX;
         double y = event.getEntity().posY;
         double z = event.getEntity().posZ;
         double diffX = logPos.getX() - x;
         double diffY = logPos.getY() - y;
         double diffZ = logPos.getZ() - z;
         Vec3d dir = new Vec3d(diffX, diffY, diffZ);
         dir.normalize();
         event.getEntity().motionX = dir.x * pullSpeed;
         event.getEntity().motionY = dir.y * pullSpeed;
         event.getEntity().motionZ = dir.z * pullSpeed;
         event.getEntity().velocityChanged = true;
      }
   }

   private BlockPos getNearestLog(LivingUpdateEvent event, int radius) {
      double minDist = 99.0;
      BlockPos nearest = null;
      BlockPos entityPos = event.getEntity().getPosition();

      for (int x = entityPos.getX() - radius; x <= entityPos.getX() + radius; x++) {
         for (int y = entityPos.getY() - radius; y <= entityPos.getY() + radius; y++) {
            for (int z = entityPos.getZ() - radius; z <= entityPos.getZ() + radius; z++) {
               BlockPos pos = new BlockPos(x, y, z);
               IBlockState state = event.getEntity().world.getBlockState(pos);
               if (state.getBlock() instanceof ITetherable) {
                  double dist = pos.getDistance(entityPos.getX(), entityPos.getY(), entityPos.getZ());
                  if (dist <= minDist) {
                     minDist = dist;
                     nearest = new BlockPos(pos);
                  }
               }
            }
         }
      }

      return nearest;
   }

   private void doContagion(EntityLivingBase entity, int level) {
      if (entity.isPotionActive(PotionInit.CONTAGIOUS)) {
         for (EntityLivingBase near_pl : entity.world.getEntitiesWithinAABB(EntityLivingBase.class, entity.getEntityBoundingBox().grow(10.0, 4.0, 10.0))) {
            near_pl.addPotionEffect(new PotionEffect(PotionInit.PLAGUE, 300, level));
            near_pl.addPotionEffect(new PotionEffect(PotionInit.CONTAGIOUS, 300, level));
         }

         CustomParticleConfig config1 = new CustomParticleConfig();
         config1.createInstance().setParticle(ParticleInit.GLOOM_BURST).setSpread(1.0, 1.0, 1.0).setCount(3).setIgnoreRange(true);
         IParticleSpawner.spawnParticle(
            entity.world, config1, entity.posX, entity.posY + entity.height / 2.0F, entity.posZ
         );
         entity.world.playSound(null, entity.getPosition(), SoundInit.MAGIC_WEAPON_7, SoundCategory.PLAYERS, 1.0F, 1.0F);
         entity.clearActivePotions();
      }
   }

   @SubscribeEvent
   public void onEntityDeath(LivingDeathEvent event) {
      if (!(event.getEntity() instanceof EntityPlayer)) {
         if (event.getEntity() instanceof EntityStarfiend) {
            EntityStarfiend fiend = (EntityStarfiend)event.getEntity();
            if (fiend.getScaleType() != 9) {
               fiend.setScaleType((byte)(fiend.getScaleType() + 1));
               fiend.setHealth(Float.MAX_VALUE);
               event.setCanceled(true);
            }
         } else if (event.getEntity() instanceof EntityMultipleLives) {
            EntityMultipleLives creature = (EntityMultipleLives)event.getEntity();
            if (!creature.onFinalLife()) {
               creature.takewayLife();
               creature.setHealth(Float.MAX_VALUE);
               event.setCanceled(true);
            } else {
               boolean flag = true;
               if (creature instanceof EntityDeviantMob) {
                  EntityDeviantMob deviant = (EntityDeviantMob)creature;
                  if (deviant.getMutation() != 0 && !deviant.atMaxMutation()) {
                     flag = false;
                     deviant.updateSupermutationAI();
                     deviant.setHealth(Float.MAX_VALUE);
                     deviant.increaseMutation();
                     deviant.setLivesCount(0);
                     event.setCanceled(true);
                  }
               }

               if (creature instanceof EntityCthulhu) {
                  EntityCthulhu cthulhu = (EntityCthulhu)creature;
                  if (!cthulhu.isEssenceCharged()) {
                     flag = false;
                     cthulhu.setHealth(Float.MAX_VALUE);
                     cthulhu.setLivesCount(cthulhu.numberOfLives());
                     event.setCanceled(true);
                  }
               }

               if (flag && !creature.didDeathAction()) {
                  creature.trueDeathAction();
                  creature.deathActionComplete();
               }
            }
         } else if (event.getEntity() instanceof EntityMultiLivesTameable) {
            EntityMultiLivesTameable creature = (EntityMultiLivesTameable)event.getEntity();
            if (!creature.onFinalLife()) {
               creature.takewayLife();
               creature.setHealth(Float.MAX_VALUE);
               event.setCanceled(true);
            } else if (!creature.didDeathAction()) {
               creature.trueDeathAction();
               creature.deathActionComplete();
            }
         }
      }
   }
}
