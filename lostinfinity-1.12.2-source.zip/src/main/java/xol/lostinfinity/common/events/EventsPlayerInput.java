package xol.lostinfinity.common.events;

import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import xol.lostinfinity.common.ClientProxy;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.common.packets.serverbound.PacketDismount;
import xol.lostinfinity.common.packets.serverbound.PacketItemMode;
import xol.lostinfinity.common.packets.serverbound.PacketSetBonus;
import xol.lostinfinity.mob.entity.base.EntityMultipleLivesMount;
import xol.lostinfinity.util.player.PlayerManager;

public class EventsPlayerInput {
   @SideOnly(Side.CLIENT)
   @SubscribeEvent(
      priority = EventPriority.NORMAL,
      receiveCanceled = true
   )
   public void onKeyInput(KeyInputEvent event) {
      if (ClientProxy.armorSetBonus.isPressed() && PlayerManager.isWearingAnySet(Minecraft.getMinecraft().player)) {
         lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketSetBonus());
      }

      if (ClientProxy.itemMode.isPressed()) {
         lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketItemMode());
      }

      if (ClientProxy.dismount.isPressed() && Minecraft.getMinecraft().player.getLowestRidingEntity() instanceof EntityMultipleLivesMount) {
         lostinfinity.instance.packetHandler.sendServerBasicPacket(new PacketDismount());
      }
   }
}
