package xol.lostinfinity.common.events;

import io.netty.channel.Channel;
import io.netty.channel.ChannelPipeline;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.NetworkManager;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
import xol.lostinfinity.common.packets.LostInfinityPacketListener;

public class EventsNetworkInjection {
   public static final String LISTENER = "lost_infinity_packet_listener";

   @SubscribeEvent
   public void onClientDisconnect(PlayerLoggedOutEvent event) {
      if (event.player instanceof EntityPlayerMP) {
         NetHandlerPlayServer connection = ((EntityPlayerMP)event.player).connection;
         if (connection == null) {
            return;
         }

         Channel channel = connection.netManager.channel();
         channel.eventLoop().submit(() -> {
            channel.pipeline().remove("lost_infinity_packet_listener");
            return null;
         });
      }
   }

   @SubscribeEvent
   public void onClientConnect(PlayerLoggedInEvent event) {
      if (event.player instanceof EntityPlayerMP) {
         NetHandlerPlayServer connection = ((EntityPlayerMP)event.player).connection;
         ChannelPipeline pipeline = connection.netManager.channel().pipeline();
         LostInfinityPacketListener listener = new LostInfinityPacketListener(connection);

         for (String name : pipeline.toMap().keySet()) {
            if (pipeline.get(name) instanceof NetworkManager) {
               pipeline.addBefore(name, "lost_infinity_packet_listener", listener);
               break;
            }
         }
      }
   }
}
