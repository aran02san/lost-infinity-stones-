package xol.lostinfinity.common.special;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.EnumActionResult;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedOutEvent;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.common.packets.clientbound.PacketSetControlled;

public class CommonMindControlHandler {
   public static CommonMindControlHandler INSTANCE;
   private final Map<UUID, EntityPlayer> puppeteers = new ConcurrentHashMap<>();
   private final Map<UUID, EntityPlayer> controlled = new ConcurrentHashMap<>();

   public CommonMindControlHandler() {
      INSTANCE = this;
   }

   @SubscribeEvent
   public void onClientDisconnect(PlayerLoggedOutEvent event) {
      onDisconnect(event.player);
   }

   @SubscribeEvent
   public void onRightClick(PlayerInteractEvent event) {
      if (this.controlled.containsKey(event.getEntityPlayer().getUniqueID())) {
         event.setCancellationResult(EnumActionResult.PASS);
         if (event.isCancelable()) {
            event.setCanceled(true);
         }
      }
   }

   public static void registerPair(EntityPlayer puppeteer, EntityPlayer target) {
      INSTANCE.puppeteers.put(puppeteer.getUniqueID(), target);
      INSTANCE.controlled.put(target.getUniqueID(), puppeteer);
   }

   public static void unregisterPair(EntityPlayer puppeteer, EntityPlayer target) {
      INSTANCE.puppeteers.remove(puppeteer.getUniqueID());
      INSTANCE.controlled.remove(target.getUniqueID());
   }

   public static void onDisconnect(EntityPlayer disconnected) {
      EntityPlayer player = removeControllerOfPlayer(disconnected.getUniqueID());
      if (player != null) {
         lostinfinity.instance.packetHandler.sendToPlayer((EntityPlayerMP)player, new PacketSetControlled());
      }

      player = removeTargetOfPlayer(disconnected.getUniqueID());
      if (player != null) {
         lostinfinity.instance.packetHandler.sendToPlayer((EntityPlayerMP)player, new PacketSetControlled());
      }
   }

   public static EntityPlayer getTargetOfPlayer(EntityPlayer player) {
      return getTargetOfPlayer(player.getUniqueID());
   }

   public static EntityPlayer getTargetOfPlayer(UUID uuid) {
      return INSTANCE.puppeteers.get(uuid);
   }

   public static EntityPlayer removeTargetOfPlayer(EntityPlayer player) {
      return removeTargetOfPlayer(player.getUniqueID());
   }

   public static EntityPlayer removeTargetOfPlayer(UUID uuid) {
      return INSTANCE.puppeteers.remove(uuid);
   }

   public static EntityPlayer getControllerOfPlayer(EntityPlayer player) {
      return getControllerOfPlayer(player.getUniqueID());
   }

   public static EntityPlayer getControllerOfPlayer(UUID uuid) {
      return INSTANCE.controlled.get(uuid);
   }

   public static EntityPlayer removeControllerOfPlayer(EntityPlayer player) {
      return removeControllerOfPlayer(player.getUniqueID());
   }

   public static EntityPlayer removeControllerOfPlayer(UUID uuid) {
      return INSTANCE.controlled.remove(uuid);
   }

   public static enum State {
      NONE,
      CONTROLLED,
      CONTROLLING;
   }
}
