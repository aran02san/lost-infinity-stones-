package xol.lostinfinity.common.packets.clientbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.mob.entity.classify.ILostMultiPart;
import xol.lostinfinity.mob.entity.classify.IRelay;

public class PacketSyncParts implements IMessage {
   private int parentId;
   private int partId;
   private double posX;
   private double posY;
   private double posZ;
   private float yaw;
   private float pitch;

   public PacketSyncParts() {
   }

   public PacketSyncParts(IRelay<?> part) {
      this.parentId = part.getRelay().getEntityId();
      this.partId = part.getId();
      this.posX = part.getX();
      this.posY = part.getY();
      this.posZ = part.getZ();
      this.yaw = part.getYaw();
      this.pitch = part.getPitch();
   }

   public void fromBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      this.parentId = buf.readVarInt();
      this.partId = buf.readVarInt();
      this.posX = buf.readDouble();
      this.posY = buf.readDouble();
      this.posZ = buf.readDouble();
      this.yaw = buf.readFloat();
      this.pitch = buf.readFloat();
   }

   public void toBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      buf.writeVarInt(this.parentId);
      buf.writeVarInt(this.partId);
      buf.writeDouble(this.posX);
      buf.writeDouble(this.posY);
      buf.writeDouble(this.posZ);
      buf.writeFloat(this.yaw);
      buf.writeFloat(this.pitch);
   }

   public static class SyncPartsPacketHandler implements IMessageHandler<PacketSyncParts, IMessage> {
      public IMessage onMessage(PacketSyncParts message, MessageContext ctx) {
         Entity main = Minecraft.getMinecraft().world.getEntityByID(message.parentId);
         if (main instanceof ILostMultiPart) {
            Entity[] parts = main.getParts();
            if (parts != null && message.partId < parts.length) {
               Entity part = parts[message.partId];
               if (part instanceof IRelay) {
                  ((IRelay)part).setPos(message.posX, message.posY, message.posZ, message.yaw, message.pitch);
               }
            }
         }

         return null;
      }
   }
}
