package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.mob.entity.misc.EntitySupplyTrader;

public class PacketSupplyInventoryServer implements IMessage {
   private int sourceId;
   private int slot;
   private ItemStack stack;

   public PacketSupplyInventoryServer() {
   }

   public PacketSupplyInventoryServer(int sourceId, int slot, ItemStack stack) {
      this.sourceId = sourceId;
      this.slot = slot;
      this.stack = stack;
   }

   public void fromBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      this.sourceId = buf.readVarInt();
      this.slot = buf.readVarInt();

      try {
         this.stack = buf.readItemStack();
      } catch (IOException var4) {
         throw new RuntimeException(var4);
      }
   }

   public void toBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      buf.writeVarInt(this.sourceId);
      buf.writeVarInt(this.slot);
      buf.writeItemStack(this.stack);
   }

   public static class SupplyInventoryServerPacketHandler implements IMessageHandler<PacketSupplyInventoryServer, IMessage> {
      public IMessage onMessage(PacketSupplyInventoryServer message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         EntitySupplyTrader trader = (EntitySupplyTrader)player.world.getEntityByID(message.sourceId);
         trader.setInventorySlotContents(message.slot, message.stack);
         return null;
      }
   }
}
