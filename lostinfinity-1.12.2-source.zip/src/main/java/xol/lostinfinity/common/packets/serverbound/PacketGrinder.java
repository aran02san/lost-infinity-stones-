package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.block.tileentity.TileEntityGrinder;

public class PacketGrinder implements IMessage {
   private int x;
   private int y;
   private int z;
   private boolean success;

   public PacketGrinder() {
   }

   public PacketGrinder(BlockPos blockPos, boolean success) {
      this.x = blockPos.getX();
      this.y = blockPos.getY();
      this.z = blockPos.getZ();
      this.success = success;
   }

   public void fromBytes(ByteBuf buf) {
      this.x = buf.readInt();
      this.y = buf.readInt();
      this.z = buf.readInt();
      this.success = buf.readBoolean();
   }

   public void toBytes(ByteBuf buf) {
      buf.writeInt(this.x);
      buf.writeInt(this.y);
      buf.writeInt(this.z);
      buf.writeBoolean(this.success);
   }

   public static class GUIGrinderPacketHandler implements IMessageHandler<PacketGrinder, IMessage> {
      public IMessage onMessage(PacketGrinder message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         World world = player.world;
         player.getServerWorld().addScheduledTask(() -> {
            TileEntity tileEntity = world.getTileEntity(new BlockPos(message.x, message.y, message.z));
            if (tileEntity instanceof TileEntityGrinder) {
               if (message.success) {
                  ((TileEntityGrinder)tileEntity).grind();
               } else {
                  ((TileEntityGrinder)tileEntity).failGrind();
               }
            }
         });
         return null;
      }
   }
}
