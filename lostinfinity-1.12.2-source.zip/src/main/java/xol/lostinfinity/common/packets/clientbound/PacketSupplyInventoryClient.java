package xol.lostinfinity.common.packets.clientbound;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.mob.entity.misc.EntitySupplyTrader;

public class PacketSupplyInventoryClient implements IMessage {
   private int sourceId;
   private int slot;
   private ItemStack stack;

   public PacketSupplyInventoryClient() {
   }

   public PacketSupplyInventoryClient(int sourceId, int slot, ItemStack stack) {
      this.sourceId = sourceId;
      this.slot = slot;
      this.stack = stack;
   }

   public void fromBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      this.sourceId = buf.readVarInt();
      this.slot = buf.readVarInt();

      try {
         this.stack = buf.readItemStack();
      } catch (IOException var4) {
         throw new RuntimeException(var4);
      }
   }

   public void toBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      buf.writeVarInt(this.sourceId);
      buf.writeVarInt(this.slot);
      buf.writeItemStack(this.stack);
   }

   public static class SupplyInventoryClientPacketHandler implements IMessageHandler<PacketSupplyInventoryClient, IMessage> {
      public IMessage onMessage(PacketSupplyInventoryClient message, MessageContext ctx) {
         EntitySupplyTrader trader = (EntitySupplyTrader)Minecraft.getMinecraft().world.getEntityByID(message.sourceId);
         trader.setInventorySlotContents(message.slot, message.stack);
         return null;
      }
   }
}
