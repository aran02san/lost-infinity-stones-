package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketUpdatePlayerPickedItem implements IMessage {
   private int targetId;
   private ItemStack stack;

   public PacketUpdatePlayerPickedItem() {
   }

   public PacketUpdatePlayerPickedItem(int targetId, ItemStack stack) {
      this.targetId = targetId;
      this.stack = stack;
   }

   public void fromBytes(ByteBuf buf) {
      PacketBuffer buffer = new PacketBuffer(buf);
      this.targetId = buffer.readVarInt();

      try {
         this.stack = buffer.readItemStack();
      } catch (IOException var4) {
         throw new RuntimeException(var4);
      }
   }

   public void toBytes(ByteBuf buf) {
      PacketBuffer buffer = new PacketBuffer(buf);
      buffer.writeVarInt(this.targetId);
      buffer.writeItemStack(this.stack);
   }

   public static class UpdatePlayerPickedItemPacketHandler implements IMessageHandler<PacketUpdatePlayerPickedItem, IMessage> {
      public IMessage onMessage(PacketUpdatePlayerPickedItem message, MessageContext ctx) {
         EntityPlayerMP serverPlayer = ctx.getServerHandler().player;
         EntityPlayer target = (EntityPlayer)serverPlayer.world.getEntityByID(message.targetId);
         target.inventory.setItemStack(message.stack);
         return null;
      }
   }
}
