package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.block.tileentity.TileEntityWeldingChamber;

public class PacketWeldingChamber implements IMessage {
   private int acetyleneAmount;
   private int x;
   private int y;
   private int z;

   public PacketWeldingChamber() {
   }

   public PacketWeldingChamber(BlockPos blockPos, int acetyleneAmount) {
      this.x = blockPos.getX();
      this.y = blockPos.getY();
      this.z = blockPos.getZ();
      this.acetyleneAmount = acetyleneAmount;
   }

   public void fromBytes(ByteBuf buf) {
      this.x = buf.readInt();
      this.y = buf.readInt();
      this.z = buf.readInt();
      this.acetyleneAmount = buf.readInt();
   }

   public void toBytes(ByteBuf buf) {
      buf.writeInt(this.x);
      buf.writeInt(this.y);
      buf.writeInt(this.z);
      buf.writeInt(this.acetyleneAmount);
   }

   public static class WeldingChamberGUIPacketHandler implements IMessageHandler<PacketWeldingChamber, IMessage> {
      public IMessage onMessage(PacketWeldingChamber message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         World world = player.world;
         player.getServerWorld().addScheduledTask(() -> {
            TileEntity tileEntity = world.getTileEntity(new BlockPos(message.x, message.y, message.z));
            if (tileEntity instanceof TileEntityWeldingChamber) {
               ((TileEntityWeldingChamber)tileEntity).setField(2, message.acetyleneAmount);
            }
         });
         return null;
      }
   }
}
