package xol.lostinfinity.common.packets.clientbound;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.ItemStackHandler;

public class PacketShipmentBoxUpdate implements IMessage {
   private ItemStack boxStack;
   private int slot;
   private ItemStack stack;

   public PacketShipmentBoxUpdate() {
   }

   public PacketShipmentBoxUpdate(ItemStack boxStack, int slot, ItemStack stack) {
      this.boxStack = boxStack;
      this.slot = slot;
      this.stack = stack;
   }

   public void fromBytes(ByteBuf buf) {
      PacketBuffer buffer = new PacketBuffer(buf);
      this.slot = buffer.readVarInt();

      try {
         this.boxStack = buffer.readItemStack();
         this.stack = buffer.readItemStack();
      } catch (IOException var4) {
         throw new RuntimeException(var4);
      }
   }

   public void toBytes(ByteBuf buf) {
      PacketBuffer buffer = new PacketBuffer(buf);
      buffer.writeVarInt(this.slot);
      buffer.writeItemStack(this.boxStack);
      buffer.writeItemStack(this.stack);
   }

   public static class ShipmentBoxUpdatePacketHandler implements IMessageHandler<PacketShipmentBoxUpdate, IMessage> {
      public IMessage onMessage(PacketShipmentBoxUpdate message, MessageContext ctx) {
         ItemStack shipmentBox = message.boxStack;
         ItemStackHandler boxHandler = (ItemStackHandler)shipmentBox.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, null);
         boxHandler.insertItem(message.slot, message.stack, false);
         return null;
      }
   }
}
