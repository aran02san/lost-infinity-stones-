package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.mob.entity.cthulhu.EntityCthulhu;

public class PacketCthulhuBarrier implements IMessage {
   private int flag;
   private int value;
   private int entityID;

   public PacketCthulhuBarrier() {
   }

   public PacketCthulhuBarrier(int flag, int value, int entityID) {
      this.flag = flag;
      this.value = value;
      this.entityID = entityID;
   }

   public void fromBytes(ByteBuf buf) {
      this.flag = buf.readInt();
      this.value = buf.readInt();
      this.entityID = buf.readInt();
   }

   public void toBytes(ByteBuf buf) {
      buf.writeInt(this.flag);
      buf.writeInt(this.value);
      buf.writeInt(this.entityID);
   }

   public static class CthulhuBarrierPacketHandler implements IMessageHandler<PacketCthulhuBarrier, IMessage> {
      public IMessage onMessage(PacketCthulhuBarrier message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         World world = player.world;
         player.getServerWorld().addScheduledTask(() -> {
            Entity entity = world.getEntityByID(message.entityID);
            if (entity instanceof EntityCthulhu) {
               EntityCthulhu cthulhu = (EntityCthulhu)entity;
               switch (message.flag) {
                  case 1:
                     cthulhu.setBarrierCd1(message.value);
                     break;
                  case 2:
                     cthulhu.setBarrierCd2(message.value);
                     break;
                  case 3:
                     cthulhu.setBarrierCd3(message.value);
                     break;
                  case 4:
                     cthulhu.setBarrierCd4(message.value);
                     break;
                  case 5:
                     cthulhu.setAllBarrierCd(message.value);
               }
            }
         });
         return null;
      }
   }
}
