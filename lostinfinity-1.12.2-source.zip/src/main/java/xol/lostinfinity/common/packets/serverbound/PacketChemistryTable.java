package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.block.tileentity.TileEntityChemistryTable;

public class PacketChemistryTable implements IMessage {
   private int field;
   private int value;
   private int x;
   private int y;
   private int z;

   public PacketChemistryTable() {
   }

   public PacketChemistryTable(BlockPos pos, int field, int value) {
      this.field = field;
      this.value = value;
      this.x = pos.getX();
      this.y = pos.getY();
      this.z = pos.getZ();
   }

   public void fromBytes(ByteBuf buf) {
      this.x = buf.readInt();
      this.y = buf.readInt();
      this.z = buf.readInt();
      this.field = buf.readInt();
      this.value = buf.readInt();
   }

   public void toBytes(ByteBuf buf) {
      buf.writeInt(this.x);
      buf.writeInt(this.y);
      buf.writeInt(this.z);
      buf.writeInt(this.field);
      buf.writeInt(this.value);
   }

   public static class ChemistryTableGUIPacketHandler implements IMessageHandler<PacketChemistryTable, IMessage> {
      public IMessage onMessage(PacketChemistryTable message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         World world = player.world;
         player.getServerWorld().addScheduledTask(() -> {
            TileEntity tileEntity = world.getTileEntity(new BlockPos(message.x, message.y, message.z));
            if (tileEntity instanceof TileEntityChemistryTable) {
               ((TileEntityChemistryTable)tileEntity).setField(message.field, message.value);
               if (message.field != 9) {
                  ((TileEntityChemistryTable)tileEntity).setField(9, ((TileEntityChemistryTable)tileEntity).getField(9) + 1);
               }
            }
         });
         return null;
      }
   }
}
