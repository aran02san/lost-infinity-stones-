package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.item.classify.IModeSelect;

public class PacketItemMode implements IMessage {
   public void toBytes(ByteBuf buf) {
   }

   public void fromBytes(ByteBuf buf) {
   }

   public static class ItemModePacketHandler implements IMessageHandler<PacketItemMode, IMessage> {
      public IMessage onMessage(PacketItemMode message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         ItemStack stack = player.getHeldItemMainhand();
         player.getServerWorld().addScheduledTask(() -> {
            if (stack.getItem() instanceof IModeSelect) {
               IModeSelect mode_item = (IModeSelect)stack.getItem();
               mode_item.modeUpdate(stack, player);
            }
         });
         return null;
      }
   }
}
