package xol.lostinfinity.common.packets.clientbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.client.audio.MovingSoundHandler;
import xol.lostinfinity.client.audio.UniversalMovingSound;
import xol.lostinfinity.item.classify.IMovingSoundSource;

public class PacketUniversalMovingSound implements IMessage {
   private boolean isPlay;
   private int soundId;
   private SoundEvent sound;
   private SoundCategory category;
   private int sourceId;
   private float soundVolume;
   private float soundPitch;
   private boolean repeat;
   private int repeatDelay;

   public PacketUniversalMovingSound() {
   }

   public PacketUniversalMovingSound(int soundId) {
      this.soundId = soundId;
      this.isPlay = false;
   }

   public PacketUniversalMovingSound(
      int soundId, SoundEvent sound, SoundCategory category, int sourceId, float soundVolume, float soundPitch, boolean repeat, int repeatDelay
   ) {
      this.soundId = soundId;
      this.isPlay = true;
      this.sound = sound;
      this.category = category;
      this.sourceId = sourceId;
      this.soundVolume = soundVolume;
      this.soundPitch = soundPitch;
      this.repeat = repeat;
      this.repeatDelay = repeatDelay;
   }

   public void fromBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      this.soundId = buf.readVarInt();
      this.isPlay = buf.readBoolean();
      if (this.isPlay) {
         this.sound = (SoundEvent)SoundEvent.REGISTRY.getObjectById(buf.readVarInt());
         this.category = (SoundCategory)buf.readEnumValue(SoundCategory.class);
         this.sourceId = buf.readVarInt();
         this.soundVolume = buf.readFloat();
         this.soundPitch = buf.readFloat();
         this.repeat = buf.readBoolean();
         this.repeatDelay = buf.readInt();
      }
   }

   public void toBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      buf.writeVarInt(this.soundId);
      buf.writeBoolean(this.isPlay);
      if (this.isPlay) {
         buf.writeVarInt(SoundEvent.REGISTRY.getIDForObject(this.sound));
         buf.writeEnumValue(this.category);
         buf.writeVarInt(this.sourceId);
         buf.writeFloat(this.soundVolume);
         buf.writeFloat(this.soundPitch);
         buf.writeBoolean(this.repeat);
         buf.writeInt(this.repeatDelay);
      }
   }

   public static class UniversalMovingSoundPacketHandler implements IMessageHandler<PacketUniversalMovingSound, IMessage> {
      public IMessage onMessage(PacketUniversalMovingSound message, MessageContext ctx) {
         if (!message.isPlay) {
            MovingSoundHandler.instance.stopSound(message.soundId);
            return null;
         } else {
            Entity source = Minecraft.getMinecraft().world.getEntityByID(message.sourceId);
            if (source == null) {
               return null;
            } else {
               UniversalMovingSound sound = new UniversalMovingSound(
                  message.sound,
                  message.category,
                  new IMovingSoundSource.Follower(message.soundId, source, message.repeat, message.repeatDelay),
                  message.soundVolume,
                  message.soundPitch
               );
               MovingSoundHandler.instance.trackSound(message.soundId, sound);
               return null;
            }
         }
      }
   }
}
