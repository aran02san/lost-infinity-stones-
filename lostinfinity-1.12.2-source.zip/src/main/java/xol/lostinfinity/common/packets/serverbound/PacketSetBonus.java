package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.client.TextFmt;
import xol.lostinfinity.init.SoundInit;

public class PacketSetBonus implements IMessage {
   public void toBytes(ByteBuf buf) {
   }

   public void fromBytes(ByteBuf buf) {
   }

   public static class SetBonusPacketHandler implements IMessageHandler<PacketSetBonus, IMessage> {
      public IMessage onMessage(PacketSetBonus message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         ItemStack helmet = (ItemStack)player.inventory.armorInventory.get(3);
         player.getServerWorld()
            .addScheduledTask(
               () -> {
                  if (helmet.getTagCompound() == null) {
                     helmet.setTagCompound(new NBTTagCompound());
                  }

                  NBTTagCompound tag = helmet.getTagCompound();
                  if (tag.hasKey("setBonus")) {
                     tag.setBoolean("setBonus", !tag.getBoolean("setBonus"));
                  } else {
                     tag.setBoolean("setBonus", false);
                  }

                  boolean enabled = tag.getBoolean("setBonus");
                  player.sendMessage(new TextComponentString(enabled ? TextFmt.Green + "Set Effect enabled" : TextFmt.Red + "Set Effect disabled"));
                  player.world
                     .playSound(
                        null, player.getPosition(), enabled ? SoundInit.ARMOR_ACTIVATE : SoundInit.ARMOR_DEACTIVATE, SoundCategory.MASTER, 1.0F, 1.0F
                     );
               }
            );
         return null;
      }
   }
}
