package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.block.tileentity.TileEntityFusionTable;

public class PacketFusionTable implements IMessage {
   private int x;
   private int y;
   private int z;
   private int shapeId;
   private int fieldId;

   public PacketFusionTable() {
   }

   public PacketFusionTable(BlockPos blockPos, int shapeId, int fieldId) {
      this.x = blockPos.getX();
      this.y = blockPos.getY();
      this.z = blockPos.getZ();
      this.shapeId = shapeId;
      this.fieldId = fieldId;
   }

   public void fromBytes(ByteBuf buf) {
      this.x = buf.readInt();
      this.y = buf.readInt();
      this.z = buf.readInt();
      this.shapeId = buf.readInt();
      this.fieldId = buf.readInt();
   }

   public void toBytes(ByteBuf buf) {
      buf.writeInt(this.x);
      buf.writeInt(this.y);
      buf.writeInt(this.z);
      buf.writeInt(this.shapeId);
      buf.writeInt(this.fieldId);
   }

   public static class FusionTableGUIPacketHandler implements IMessageHandler<PacketFusionTable, IMessage> {
      public IMessage onMessage(PacketFusionTable message, MessageContext ctx) {
         EntityPlayerMP player = ctx.getServerHandler().player;
         World world = player.world;
         player.getServerWorld().addScheduledTask(() -> {
            TileEntity tileEntity = world.getTileEntity(new BlockPos(message.x, message.y, message.z));
            if (tileEntity instanceof TileEntityFusionTable) {
               ((TileEntityFusionTable)tileEntity).setField(message.fieldId, message.shapeId);
            }
         });
         return null;
      }
   }
}
