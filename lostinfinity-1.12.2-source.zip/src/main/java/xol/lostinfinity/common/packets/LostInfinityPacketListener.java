package xol.lostinfinity.common.packets;

import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import net.minecraft.entity.Entity;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketInput;
import xol.lostinfinity.mob.entity.base.EntityMultipleLivesMount;

public class LostInfinityPacketListener extends ChannelDuplexHandler {
   private final NetHandlerPlayServer connection;

   public LostInfinityPacketListener(NetHandlerPlayServer connection) {
      this.connection = connection;
   }

   public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise) throws Exception {
      super.write(ctx, msg, promise);
   }

   public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
      if (msg instanceof CPacketInput) {
         CPacketInput input = (CPacketInput)msg;
         PacketBuffer buf = new PacketBuffer(Unpooled.buffer());
         buf.writeFloat(input.getStrafeSpeed());
         buf.writeFloat(input.getForwardSpeed());
         byte flags = 0;
         if (input.isJumping()) {
            flags = (byte)(flags | 1);
         }

         if (input.isSneaking()) {
            Entity mount = this.connection.player.getLowestRidingEntity();
            if (!(mount instanceof EntityMultipleLivesMount)) {
               flags = (byte)(flags | 2);
            }
         }

         buf.writeByte(flags);
         input.readPacketData(buf);
      }

      super.channelRead(ctx, msg);
   }
}
