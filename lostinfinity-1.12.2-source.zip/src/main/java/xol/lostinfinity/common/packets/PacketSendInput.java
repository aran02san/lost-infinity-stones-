package xol.lostinfinity.common.packets;

import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
import xol.lostinfinity.client.special.ClientMindControlHandler;
import xol.lostinfinity.common.lostinfinity;
import xol.lostinfinity.common.special.CommonMindControlHandler;

public class PacketSendInput implements IMessage {
   private float forward;
   private float side;
   private boolean jump;
   private boolean sneak;

   public PacketSendInput() {
   }

   public PacketSendInput(float forward, float side, boolean jump, boolean sneak) {
      this.forward = forward;
      this.side = side;
      this.jump = jump;
      this.sneak = sneak;
   }

   public void fromBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      this.forward = buf.readFloat();
      this.side = buf.readFloat();
      this.jump = buf.readBoolean();
      this.sneak = buf.readBoolean();
   }

   public void toBytes(ByteBuf b) {
      PacketBuffer buf = new PacketBuffer(b);
      buf.writeFloat(this.forward);
      buf.writeFloat(this.side);
      buf.writeBoolean(this.jump);
      buf.writeBoolean(this.sneak);
   }

   public static class SendInputPacketHandler implements IMessageHandler<PacketSendInput, IMessage> {
      public IMessage onMessage(PacketSendInput message, MessageContext ctx) {
         switch (ctx.side) {
            case CLIENT:
               ClientMindControlHandler.INSTANCE.lastForward = message.forward;
               ClientMindControlHandler.INSTANCE.lastStrafe = message.side;
               ClientMindControlHandler.INSTANCE.lastJump = message.jump;
               ClientMindControlHandler.INSTANCE.lastSneak = message.sneak;
               break;
            case SERVER:
               EntityPlayer player = ctx.getServerHandler().player;
               EntityPlayer target = CommonMindControlHandler.getTargetOfPlayer(player);
               if (target != null) {
                  lostinfinity.instance.packetHandler.sendToPlayer((EntityPlayerMP)target, message);
               }
         }

         return null;
      }
   }
}
