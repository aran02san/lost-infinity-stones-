package xol.lostinfinity.common.packets.serverbound;

import io.netty.buffer.ByteBuf;
import java.io.IOException;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class PacketNBTSyncLong implements IMessage {
   private String key;
   private long value;
   private ItemStack stack;

   public PacketNBTSyncLong() {
   }

   public PacketNBTSyncLong(String nbtKey, long nbtValue, ItemStack adjustedStack) {
      this.key = nbtKey;
      this.value = nbtValue;
      this.stack = adjustedStack;
   }

   public void toBytes(ByteBuf buf) {
      PacketBuffer modifiedBuffer = new PacketBuffer(buf);
      modifiedBuffer.writeString(this.key);
      modifiedBuffer.writeItemStack(this.stack);
      buf.writeLong(this.value);
   }

   public void fromBytes(ByteBuf buf) {
      PacketBuffer modifiedBuffer = new PacketBuffer(buf);
      this.key = modifiedBuffer.readString(20);

      try {
         this.stack = modifiedBuffer.readItemStack();
      } catch (IOException var4) {
      }

      this.value = buf.readLong();
   }

   public static class PacketNBTSyncLongHandler implements IMessageHandler<PacketNBTSyncLong, IMessage> {
      public IMessage onMessage(PacketNBTSyncLong message, MessageContext ctx) {
         ItemStack stack = message.stack;
         if (!stack.hasTagCompound()) {
            stack.setTagCompound(new NBTTagCompound());
         }

         stack.getTagCompound().setLong(message.key, message.value);
         return null;
      }
   }
}
